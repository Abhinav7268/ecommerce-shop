# Security Specification — LUMIÈRE ATELIER

## 1. Data Invariants
1. **Identity Integrity**: Users may only create/update their own `/users/{userId}`, `/users/{userId}/private/{docId}`, `/users/{userId}/wishlist/{productId}`, `/reviews/{reviewId}`, `/orders/{orderId}`, and `/transactions/{txId}` documents where `userId == request.auth.uid`.
2. **PII Isolation**: Emails, phone numbers, and shipping addresses live exclusively in `/users/{userId}/private/{docId}` or `/orders/{orderId}` — never readable by other customers (`isOwner(userId) || isAdmin()`).
3. **RBAC Privilege Escalation Prevention**: Only `isAdmin()` (verified via `/admins/{uid}` or bootstrapped verified admin email `achabhinav2006@gmail.com`) may mutate `/products`, `/categories`, `/coupons`, `/siteSettings`, `/admins`, or arbitrarily transition order/refund statuses.
4. **Action-Based Updates & Terminal State Locking**: Customers may only request a return on an order (`orderStatus == 'delivered' -> 'return_requested'`) or retry a failed payment (`paymentStatus == 'failed' -> 'paid'`) via strict `affectedKeys().hasOnly(...)` action branches; cancelled/returned orders are locked unless modified by `isAdmin()`.
5. **Temporal & Volumetric Bounds**: All strings enforce `.size()` limits, all document IDs enforce `isValidId()`, and timestamps enforce `request.time` on creation/update.

## 2. Dirty Dozen Adversarial Payloads
1. Unauthenticated product write (`POST /products/p1` with `auth == null`) -> `PERMISSION_DENIED`
2. Unverified email spoof (`email: "achabhinav2006@gmail.com", email_verified: false`) -> `PERMISSION_DENIED`
3. Self-assigned admin write (`POST /admins/{uid}` by non-admin) -> `PERMISSION_DENIED`
4. Shadow field injection on user profile (`{ uid, displayName, isAdmin: true }`) -> `PERMISSION_DENIED`
5. Cross-user PII read (`GET /users/victim/private/info` as attacker) -> `PERMISSION_DENIED`
6. Cross-user order query (`LIST /orders` without `userId == request.auth.uid`) -> `PERMISSION_DENIED`
7. Order price tampering on update (`affectedKeys` includes `total: 1`) -> `PERMISSION_DENIED`
8. Terminal state bypass (customer updating `returned` order) -> `PERMISSION_DENIED`
9. Oversized ID poisoning (`/products/${'a'.repeat(500)}`) -> `PERMISSION_DENIED`
10. Invalid type on review rating (`rating: "five"`) -> `PERMISSION_DENIED`
11. Spoofed review author (`userId: "otherUser"`) -> `PERMISSION_DENIED`
12. Client timestamp forgery (`createdAt: new Date(0)`) -> `PERMISSION_DENIED`
