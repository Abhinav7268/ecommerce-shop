import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import express from 'express';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const SANDBOX_SECRET = process.env.PAYMENT_WEBHOOK_SECRET || 'lumiere_sandbox_hmac_key_2026';

const app = express();
app.use(express.json({ limit: '15mb' }));

// Security Headers
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});

// Lightweight Sliding-Window API Rate Limiter
const rateMap = new Map<string, { count: number; resetAt: number }>();
app.use('/api', (req, res, next) => {
  const ip = req.ip || 'local';
  const now = Date.now();
  const entry = rateMap.get(ip);
  if (!entry || now > entry.resetAt) {
    rateMap.set(ip, { count: 1, resetAt: now + 60_000 });
    next();
    return;
  }
  if (entry.count > 180) {
    res.status(429).json({ error: 'Rate limit exceeded. Please retry shortly.' });
    return;
  }
  entry.count += 1;
  next();
});

const uploadsDir = path.resolve(__dirname, 'public', 'uploads');
fs.mkdirSync(uploadsDir, { recursive: true });
app.use('/uploads', express.static(uploadsDir));

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    throw new Error('GEMINI_API_KEY is not configured in environment secrets.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, timestamp: new Date().toISOString() });
});

// Dynamic SEO Sitemap & Robots.txt
app.get('/sitemap.xml', (req, res) => {
  const baseUrl = process.env.APP_URL || `${req.protocol}://${req.get('host')}`;
  const routes = [
    '/',
    '/#catalog',
    '/#studio-3d',
    '/#page/about',
    '/#page/blog',
    '/#page/faq',
    '/#page/shipping-policy',
    '/#page/return-policy',
    '/#page/privacy-policy',
    '/#page/terms',
    '/#page/contact',
  ];
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${routes
  .map(
    (r) => `  <url><loc>${baseUrl}${r}</loc><changefreq>weekly</changefreq><priority>${r === '/' ? '1.0' : '0.8'}</priority></url>`,
  )
  .join('\n')}
</urlset>`;
  res.setHeader('Content-Type', 'application/xml');
  res.send(xml);
});

app.get('/robots.txt', (req, res) => {
  const baseUrl = process.env.APP_URL || `${req.protocol}://${req.get('host')}`;
  res.setHeader('Content-Type', 'text/plain');
  res.send(`User-agent: *\nAllow: /\nSitemap: ${baseUrl}/sitemap.xml\n`);
});

// ============================================================================
// GLOBAL E-COMMERCE LOCALIZATION ENGINE (Live FX, Country Detection, Quote Lock)
// ============================================================================
const FX_REFERENCE_RATES: Record<string, number> = {
  USD: 1,
  INR: 84.5,
  GBP: 0.79,
  EUR: 0.92,
  CNY: 7.24,
  JPY: 154,
  CAD: 1.39,
  AUD: 1.53,
  AED: 3.67,
  SGD: 1.34,
  CHF: 0.88,
  SAR: 3.75,
  KRW: 1385,
  BRL: 5.78,
  MXN: 20.1,
  NZD: 1.68,
};

const ZERO_DECIMAL_CURRENCIES = new Set(['INR', 'JPY', 'KRW']);

interface ServerCountryRule {
  code: string;
  name: string;
  currency: string;
  regionalPriceFactor: number;
  shippingZoneName: string;
  shippingCarrier: string;
  shippingBaseUsd: number;
  freeShippingThresholdUsd: number;
  estimatedDelivery: string;
  codAvailable: boolean;
  taxRatePercent: number;
  taxLabel: string;
  customsDutySupported: boolean;
  customsDutyRatePercent: number;
  customsDeMinimisUsd: number;
  customsNote: string;
}

const SERVER_COUNTRY_RULES: Record<string, ServerCountryRule> = {
  IN: {
    code: 'IN',
    name: 'India',
    currency: 'INR',
    regionalPriceFactor: 0.92,
    shippingZoneName: 'India Domestic Priority',
    shippingCarrier: 'BlueDart / Delhivery Express',
    shippingBaseUsd: 2.9,
    freeShippingThresholdUsd: 55,
    estimatedDelivery: '2–4 Business Days',
    codAvailable: true,
    taxRatePercent: 18,
    taxLabel: 'GST (18%)',
    customsDutySupported: true,
    customsDutyRatePercent: 0,
    customsDeMinimisUsd: 0,
    customsNote: 'Domestic fulfillment from Mumbai & Bengaluru ateliers — zero import customs duty.',
  },
  US: {
    code: 'US',
    name: 'United States',
    currency: 'USD',
    regionalPriceFactor: 1.0,
    shippingZoneName: 'US Continental Express',
    shippingCarrier: 'FedEx / UPS 2-Day',
    shippingBaseUsd: 7.5,
    freeShippingThresholdUsd: 95,
    estimatedDelivery: '2–4 Business Days',
    codAvailable: false,
    taxRatePercent: 8.25,
    taxLabel: 'Est. State Sales Tax (8.25%)',
    customsDutySupported: true,
    customsDutyRatePercent: 0,
    customsDeMinimisUsd: 800,
    customsNote: 'Domestic US dispatch / Section 321 de minimis ($800) — no import duty below $800.',
  },
  GB: {
    code: 'GB',
    name: 'United Kingdom',
    currency: 'GBP',
    regionalPriceFactor: 1.02,
    shippingZoneName: 'UK Tracked Express',
    shippingCarrier: 'DHL UK / Royal Mail Tracked 24',
    shippingBaseUsd: 9.0,
    freeShippingThresholdUsd: 110,
    estimatedDelivery: '2–4 Business Days',
    codAvailable: false,
    taxRatePercent: 20,
    taxLabel: 'UK VAT (20%)',
    customsDutySupported: true,
    customsDutyRatePercent: 4.5,
    customsDeMinimisUsd: 170,
    customsNote: 'DDP Pre-Calculated: 0% customs duty up to £135 (~$170); 4.5% duty above £135.',
  },
  DE: {
    code: 'DE',
    name: 'Germany (EU)',
    currency: 'EUR',
    regionalPriceFactor: 1.03,
    shippingZoneName: 'European Union Express',
    shippingCarrier: 'DHL Paket / Express EU',
    shippingBaseUsd: 9.5,
    freeShippingThresholdUsd: 115,
    estimatedDelivery: '3–5 Business Days',
    codAvailable: false,
    taxRatePercent: 19,
    taxLabel: 'MwSt / EU VAT (19%)',
    customsDutySupported: true,
    customsDutyRatePercent: 4.2,
    customsDeMinimisUsd: 163,
    customsNote: 'IOSS VAT collected transparently. Customs duty 4.2% applies above €150.',
  },
  FR: {
    code: 'FR',
    name: 'France (EU)',
    currency: 'EUR',
    regionalPriceFactor: 1.03,
    shippingZoneName: 'France Atelier Priority',
    shippingCarrier: 'Chronopost / DHL Express',
    shippingBaseUsd: 8.5,
    freeShippingThresholdUsd: 110,
    estimatedDelivery: '2–4 Business Days',
    codAvailable: false,
    taxRatePercent: 20,
    taxLabel: 'TVA / EU VAT (20%)',
    customsDutySupported: true,
    customsDutyRatePercent: 4.2,
    customsDeMinimisUsd: 163,
    customsNote: 'Paris hub dispatch & IOSS transparent VAT; 4.2% customs duty above €150.',
  },
  EU: {
    code: 'EU',
    name: 'Europe (Other EU)',
    currency: 'EUR',
    regionalPriceFactor: 1.03,
    shippingZoneName: 'Pan-European Express',
    shippingCarrier: 'DHL Express Europe',
    shippingBaseUsd: 10.5,
    freeShippingThresholdUsd: 120,
    estimatedDelivery: '3–6 Business Days',
    codAvailable: false,
    taxRatePercent: 20,
    taxLabel: 'EU VAT (20%)',
    customsDutySupported: true,
    customsDutyRatePercent: 4.2,
    customsDeMinimisUsd: 163,
    customsNote: 'IOSS compliant VAT. Customs duty 4.2% calculated on orders above €150.',
  },
  CN: {
    code: 'CN',
    name: 'China',
    currency: 'CNY',
    regionalPriceFactor: 1.04,
    shippingZoneName: 'China Cross-Border Bonded Express',
    shippingCarrier: 'SF Express / DHL China',
    shippingBaseUsd: 11.0,
    freeShippingThresholdUsd: 130,
    estimatedDelivery: '4–7 Business Days',
    codAvailable: false,
    taxRatePercent: 13,
    taxLabel: 'China VAT (13%)',
    customsDutySupported: true,
    customsDutyRatePercent: 9.1,
    customsDeMinimisUsd: 70,
    customsNote: 'CBEC Bonded Import Duty (9.1%) applied above ¥500 (~$70) for transparent customs clearance.',
  },
  JP: {
    code: 'JP',
    name: 'Japan',
    currency: 'JPY',
    regionalPriceFactor: 1.05,
    shippingZoneName: 'Japan Priority Air',
    shippingCarrier: 'Yamato Transport / DHL Japan',
    shippingBaseUsd: 11.5,
    freeShippingThresholdUsd: 125,
    estimatedDelivery: '3–5 Business Days',
    codAvailable: false,
    taxRatePercent: 10,
    taxLabel: 'Consumption Tax / 消費税 (10%)',
    customsDutySupported: true,
    customsDutyRatePercent: 5.0,
    customsDeMinimisUsd: 110,
    customsNote: 'Duty-free under ¥16,666 (~$110); 5% cosmetic import duty calculated above threshold.',
  },
  CA: {
    code: 'CA',
    name: 'Canada',
    currency: 'CAD',
    regionalPriceFactor: 1.01,
    shippingZoneName: 'Canada DDP Express',
    shippingCarrier: 'Canada Post Xpresspost / DHL',
    shippingBaseUsd: 10.0,
    freeShippingThresholdUsd: 115,
    estimatedDelivery: '3–5 Business Days',
    codAvailable: false,
    taxRatePercent: 13,
    taxLabel: 'GST / HST (13%)',
    customsDutySupported: true,
    customsDutyRatePercent: 6.5,
    customsDeMinimisUsd: 110,
    customsNote: 'CUSMA de minimis C$150 (~$110); 6.5% cosmetic customs duty pre-calculated above C$150.',
  },
  AU: {
    code: 'AU',
    name: 'Australia',
    currency: 'AUD',
    regionalPriceFactor: 1.02,
    shippingZoneName: 'Australia Air Express',
    shippingCarrier: 'Australia Post Express / DHL',
    shippingBaseUsd: 12.5,
    freeShippingThresholdUsd: 130,
    estimatedDelivery: '4–6 Business Days',
    codAvailable: false,
    taxRatePercent: 10,
    taxLabel: 'Australia GST (10%)',
    customsDutySupported: true,
    customsDutyRatePercent: 5.0,
    customsDeMinimisUsd: 650,
    customsNote: '0% customs duty below A$1,000 (~$650); 5% import duty applies above A$1,000.',
  },
  AE: {
    code: 'AE',
    name: 'United Arab Emirates',
    currency: 'AED',
    regionalPriceFactor: 1.03,
    shippingZoneName: 'UAE & GCC Express',
    shippingCarrier: 'Aramex / DHL Middle East',
    shippingBaseUsd: 9.0,
    freeShippingThresholdUsd: 110,
    estimatedDelivery: '2–4 Business Days',
    codAvailable: true,
    taxRatePercent: 5,
    taxLabel: 'UAE VAT (5%)',
    customsDutySupported: true,
    customsDutyRatePercent: 5.0,
    customsDeMinimisUsd: 272,
    customsNote: 'Dubai Customs 0% duty below AED 1,000 (~$272); 5% GCC tariff pre-calculated above AED 1,000.',
  },
  SG: {
    code: 'SG',
    name: 'Singapore',
    currency: 'SGD',
    regionalPriceFactor: 1.02,
    shippingZoneName: 'Singapore Express Hub',
    shippingCarrier: 'Ninjavan / DHL Express',
    shippingBaseUsd: 9.5,
    freeShippingThresholdUsd: 115,
    estimatedDelivery: '3–5 Business Days',
    codAvailable: false,
    taxRatePercent: 9,
    taxLabel: 'Singapore GST (9%)',
    customsDutySupported: true,
    customsDutyRatePercent: 0,
    customsDeMinimisUsd: 0,
    customsNote: 'Zero cosmetic import customs duty in Singapore (GST 9% collected transparently).',
  },
  CH: {
    code: 'CH',
    name: 'Switzerland',
    currency: 'CHF',
    regionalPriceFactor: 1.06,
    shippingZoneName: 'Switzerland Priority',
    shippingCarrier: 'Swiss Post / DHL',
    shippingBaseUsd: 12.0,
    freeShippingThresholdUsd: 140,
    estimatedDelivery: '3–5 Business Days',
    codAvailable: false,
    taxRatePercent: 8.1,
    taxLabel: 'Swiss MwSt / VAT (8.1%)',
    customsDutySupported: true,
    customsDutyRatePercent: 0,
    customsDeMinimisUsd: 0,
    customsNote: 'Switzerland abolished cosmetic customs tariffs (0% duty; 8.1% VAT applies).',
  },
  SA: {
    code: 'SA',
    name: 'Saudi Arabia',
    currency: 'SAR',
    regionalPriceFactor: 1.03,
    shippingZoneName: 'Saudi Express DDP',
    shippingCarrier: 'Aramex / SMSA Express',
    shippingBaseUsd: 11.0,
    freeShippingThresholdUsd: 125,
    estimatedDelivery: '3–5 Business Days',
    codAvailable: true,
    taxRatePercent: 15,
    taxLabel: 'KSA VAT (15%)',
    customsDutySupported: true,
    customsDutyRatePercent: 5.0,
    customsDeMinimisUsd: 266,
    customsNote: 'ZATCA 5% import duty applies above SAR 1,000 (~$266); 15% VAT pre-calculated.',
  },
  KR: {
    code: 'KR',
    name: 'South Korea',
    currency: 'KRW',
    regionalPriceFactor: 1.04,
    shippingZoneName: 'Korea Priority Express',
    shippingCarrier: 'CJ Logistics / DHL Korea',
    shippingBaseUsd: 12.0,
    freeShippingThresholdUsd: 130,
    estimatedDelivery: '3–6 Business Days',
    codAvailable: false,
    taxRatePercent: 10,
    taxLabel: 'Korea VAT (10%)',
    customsDutySupported: true,
    customsDutyRatePercent: 6.5,
    customsDeMinimisUsd: 150,
    customsNote: 'Duty-free up to $150; 6.5% cosmetic import duty calculated above $150.',
  },
  BR: {
    code: 'BR',
    name: 'Brazil',
    currency: 'BRL',
    regionalPriceFactor: 1.05,
    shippingZoneName: 'Latin America Courier',
    shippingCarrier: 'DHL Express Brazil',
    shippingBaseUsd: 16.0,
    freeShippingThresholdUsd: 160,
    estimatedDelivery: '5–9 Business Days',
    codAvailable: false,
    taxRatePercent: 17,
    taxLabel: 'ICMS State Tax (17%)',
    customsDutySupported: false,
    customsDutyRatePercent: 0,
    customsDeMinimisUsd: 50,
    customsNote: 'Customs duties for Brazil are assessed directly by Receita Federal upon arrival (DDU).',
  },
  MX: {
    code: 'MX',
    name: 'Mexico',
    currency: 'MXN',
    regionalPriceFactor: 1.02,
    shippingZoneName: 'Mexico Priority Air',
    shippingCarrier: 'Estafeta / DHL Express',
    shippingBaseUsd: 13.0,
    freeShippingThresholdUsd: 140,
    estimatedDelivery: '4–7 Business Days',
    codAvailable: false,
    taxRatePercent: 16,
    taxLabel: 'IVA Mexico (16%)',
    customsDutySupported: true,
    customsDutyRatePercent: 10.0,
    customsDeMinimisUsd: 50,
    customsNote: '10% import duty pre-calculated on orders above $50; 16% IVA included transparently.',
  },
  NZ: {
    code: 'NZ',
    name: 'New Zealand',
    currency: 'NZD',
    regionalPriceFactor: 1.02,
    shippingZoneName: 'New Zealand Express',
    shippingCarrier: 'NZ Post / DHL Express',
    shippingBaseUsd: 13.5,
    freeShippingThresholdUsd: 140,
    estimatedDelivery: '4–7 Business Days',
    codAvailable: false,
    taxRatePercent: 15,
    taxLabel: 'New Zealand GST (15%)',
    customsDutySupported: true,
    customsDutyRatePercent: 5.0,
    customsDeMinimisUsd: 600,
    customsNote: '0% customs duty below NZ$1,000 (~$600); 5% duty applies above NZ$1,000.',
  },
};

interface CachedFxSnapshot {
  rates: Record<string, number>;
  source: 'live' | 'reference';
  fetchedAt: string;
  expiresAtMs: number;
}

let fxCache: CachedFxSnapshot | null = null;
const FX_CACHE_TTL_MS = 15 * 60 * 1000;

async function getLiveFxSnapshot(): Promise<CachedFxSnapshot> {
  if (fxCache && Date.now() < fxCache.expiresAtMs) {
    return fxCache;
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3800);
    const response = await fetch('https://open.er-api.com/v6/latest/USD', {
      signal: controller.signal,
      headers: { Accept: 'application/json' },
    });
    clearTimeout(timeoutId);

    if (response.ok) {
      const payload = (await response.json()) as {
        result?: string;
        rates?: Record<string, number>;
      };
      if (payload.result === 'success' && payload.rates) {
        const filtered: Record<string, number> = { ...FX_REFERENCE_RATES };
        for (const code of Object.keys(FX_REFERENCE_RATES)) {
          const val = Number(payload.rates[code]);
          if (Number.isFinite(val) && val > 0) {
            filtered[code] = Number(val.toFixed(code === 'USD' ? 2 : 4));
          }
        }
        fxCache = {
          rates: filtered,
          source: 'live',
          fetchedAt: new Date().toISOString(),
          expiresAtMs: Date.now() + FX_CACHE_TTL_MS,
        };
        return fxCache;
      }
    }
  } catch {
    // Graceful fallback to reference rates when upstream FX API is unavailable
  }

  fxCache = {
    rates: { ...FX_REFERENCE_RATES },
    source: 'reference',
    fetchedAt: new Date().toISOString(),
    expiresAtMs: Date.now() + 5 * 60 * 1000,
  };
  return fxCache;
}

function roundForCurrency(amount: number, currency: string): number {
  if (ZERO_DECIMAL_CURRENCIES.has(currency)) {
    return Math.round(amount);
  }
  return Number(amount.toFixed(2));
}

function signCheckoutQuote(params: {
  quoteId: string;
  countryCode: string;
  settlementCurrency: string;
  totalLocal: number;
  totalUsd: number;
  lockedRate: number;
  expiresAt: string;
}): string {
  return crypto
    .createHmac('sha256', SANDBOX_SECRET)
    .update(
      `${params.quoteId}|${params.countryCode}|${params.settlementCurrency}|${params.totalLocal.toFixed(2)}|${params.totalUsd.toFixed(2)}|${params.lockedRate.toFixed(6)}|${params.expiresAt}`,
    )
    .digest('hex');
}

app.get('/api/localization/rates', async (_req, res) => {
  const snapshot = await getLiveFxSnapshot();
  res.json({
    base: 'USD',
    rates: snapshot.rates,
    source: snapshot.source,
    fetchedAt: snapshot.fetchedAt,
    nextRefreshAt: new Date(snapshot.expiresAtMs).toISOString(),
    disclaimer:
      'Catalog prices in non-base currencies are indicative. Final settlement prices, exchange rates, taxes, and customs duties are locked server-side at checkout.',
  });
});

app.get('/api/localization/detect', (req, res) => {
  const headerCountry = String(
    req.headers['x-appengine-country'] ||
      req.headers['cf-ipcountry'] ||
      req.headers['x-vercel-ip-country'] ||
      '',
  )
    .trim()
    .toUpperCase();

  if (headerCountry && SERVER_COUNTRY_RULES[headerCountry]) {
    res.json({
      countryCode: headerCountry,
      currency: SERVER_COUNTRY_RULES[headerCountry].currency,
      source: 'edge-geo-header',
      requiresConsent: true,
    });
    return;
  }

  const tz = String(req.query.tz || '').toLowerCase();
  const locale = String(req.query.locale || req.headers['accept-language'] || '').toLowerCase();

  let detected = 'US';
  let source = 'default';

  const tzMap: Array<[string, string]> = [
    ['kolkata', 'IN'],
    ['calcutta', 'IN'],
    ['mumbai', 'IN'],
    ['delhi', 'IN'],
    ['london', 'GB'],
    ['berlin', 'DE'],
    ['frankfurt', 'DE'],
    ['paris', 'FR'],
    ['shanghai', 'CN'],
    ['chongqing', 'CN'],
    ['beijing', 'CN'],
    ['tokyo', 'JP'],
    ['toronto', 'CA'],
    ['vancouver', 'CA'],
    ['montreal', 'CA'],
    ['sydney', 'AU'],
    ['melbourne', 'AU'],
    ['brisbane', 'AU'],
    ['dubai', 'AE'],
    ['singapore', 'SG'],
    ['zurich', 'CH'],
    ['riyadh', 'SA'],
    ['seoul', 'KR'],
    ['sao_paulo', 'BR'],
    ['mexico_city', 'MX'],
    ['auckland', 'NZ'],
  ];

  for (const [needle, code] of tzMap) {
    if (tz.includes(needle)) {
      detected = code;
      source = 'timezone-hint';
      break;
    }
  }

  if (source === 'default' && locale) {
    const regionMatch = locale.match(/[-_]([a-z]{2})\b/i);
    const regionCode = regionMatch ? regionMatch[1].toUpperCase() : '';
    if (regionCode && SERVER_COUNTRY_RULES[regionCode]) {
      detected = regionCode;
      source = 'browser-locale';
    } else if (locale.startsWith('hi')) {
      detected = 'IN';
      source = 'browser-language';
    } else if (locale.startsWith('fr')) {
      detected = 'FR';
      source = 'browser-language';
    } else if (locale.startsWith('de')) {
      detected = 'DE';
      source = 'browser-language';
    } else if (locale.startsWith('zh')) {
      detected = 'CN';
      source = 'browser-language';
    } else if (locale.startsWith('ja')) {
      detected = 'JP';
      source = 'browser-language';
    } else if (locale.startsWith('ar')) {
      detected = 'AE';
      source = 'browser-language';
    }
  }

  const rule = SERVER_COUNTRY_RULES[detected] || SERVER_COUNTRY_RULES.US;
  res.json({
    countryCode: rule.code,
    currency: rule.currency,
    source,
    requiresConsent: true,
  });
});

app.post('/api/localization/lock-quote', async (req, res) => {
  try {
    const {
      countryCode = 'US',
      currency,
      items = [],
      couponDiscountPercent = 0,
      flashDiscountPercent = 0,
    } = req.body as {
      countryCode?: string;
      currency?: string;
      items?: Array<{
        productId?: string;
        unitPriceUsd: number;
        quantity: number;
        regionalPriceLocal?: number;
      }>;
      couponDiscountPercent?: number;
      flashDiscountPercent?: number;
    };

    if (!Array.isArray(items) || items.length === 0) {
      res.status(400).json({ error: 'Cannot lock checkout quote for an empty cart.' });
      return;
    }

    const cleanCountry = String(countryCode).toUpperCase();
    const rule = SERVER_COUNTRY_RULES[cleanCountry] || SERVER_COUNTRY_RULES.US;
    const fxSnapshot = await getLiveFxSnapshot();
    const settlementCurrency =
      currency && FX_REFERENCE_RATES[currency.toUpperCase()]
        ? currency.toUpperCase()
        : rule.currency;
    const lockedRate = fxSnapshot.rates[settlementCurrency] || FX_REFERENCE_RATES[settlementCurrency] || 1;

    // Apply country-specific regional pricing or explicit product regional overrides
    const regionalFactor = settlementCurrency === rule.currency ? rule.regionalPriceFactor : 1;
    let subtotalUsd = 0;
    let hasFixedOverride = false;

    for (const item of items) {
      const qty = Math.max(1, Math.min(500, Number(item.quantity) || 1));
      if (typeof item.regionalPriceLocal === 'number' && item.regionalPriceLocal > 0) {
        hasFixedOverride = true;
        subtotalUsd += (item.regionalPriceLocal / lockedRate) * qty;
      } else {
        const unitUsd = Math.max(0, Number(item.unitPriceUsd) || 0) * regionalFactor;
        subtotalUsd += unitUsd * qty;
      }
    }
    subtotalUsd = Number(subtotalUsd.toFixed(2));

    const safeCouponPct = Math.max(0, Math.min(80, Number(couponDiscountPercent) || 0));
    const safeFlashPct = Math.max(0, Math.min(80, Number(flashDiscountPercent) || 0));
    const couponDiscUsd = Number(((subtotalUsd * safeCouponPct) / 100).toFixed(2));
    const flashDiscUsd = Number(((subtotalUsd * safeFlashPct) / 100).toFixed(2));
    const discountUsd = Number(Math.min(subtotalUsd, couponDiscUsd + flashDiscUsd).toFixed(2));
    const taxableMerchandiseUsd = Number(Math.max(0, subtotalUsd - discountUsd).toFixed(2));

    const freeShippingApplied = taxableMerchandiseUsd >= rule.freeShippingThresholdUsd;
    const shippingUsd = freeShippingApplied ? 0 : rule.shippingBaseUsd;

    const taxUsd = Number(((taxableMerchandiseUsd * rule.taxRatePercent) / 100).toFixed(2));
    const customsApplicable =
      rule.customsDutySupported &&
      rule.customsDutyRatePercent > 0 &&
      taxableMerchandiseUsd > rule.customsDeMinimisUsd;
    const customsDutyUsd = customsApplicable
      ? Number(((taxableMerchandiseUsd * rule.customsDutyRatePercent) / 100).toFixed(2))
      : 0;

    const totalUsd = Number((taxableMerchandiseUsd + shippingUsd + taxUsd + customsDutyUsd).toFixed(2));

    const subtotalLocal = roundForCurrency(subtotalUsd * lockedRate, settlementCurrency);
    const discountLocal = roundForCurrency(discountUsd * lockedRate, settlementCurrency);
    const shippingLocal = roundForCurrency(shippingUsd * lockedRate, settlementCurrency);
    const taxLocal = roundForCurrency(taxUsd * lockedRate, settlementCurrency);
    const customsDutyLocal = roundForCurrency(customsDutyUsd * lockedRate, settlementCurrency);
    const totalLocal = roundForCurrency(
      Math.max(0, subtotalLocal - discountLocal + shippingLocal + taxLocal + customsDutyLocal),
      settlementCurrency,
    );
    const freeShippingThresholdLocal = roundForCurrency(
      rule.freeShippingThresholdUsd * lockedRate,
      settlementCurrency,
    );

    const quoteId = `QT-${cleanCountry}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    const lockedAt = new Date().toISOString();
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();

    const quoteSignature = signCheckoutQuote({
      quoteId,
      countryCode: rule.code,
      settlementCurrency,
      totalLocal,
      totalUsd,
      lockedRate,
      expiresAt,
    });

    res.json({
      quoteId,
      quoteSignature,
      countryCode: rule.code,
      countryName: rule.name,
      settlementCurrency,
      lockedRate,
      rateSource: fxSnapshot.source,
      lockedAt,
      expiresAt,
      pricingMode: hasFixedOverride || settlementCurrency === 'USD' ? 'regional_fixed' : 'locked_fx',
      subtotalUsd,
      discountUsd,
      shippingUsd,
      taxUsd,
      customsDutyUsd,
      totalUsd,
      subtotalLocal,
      discountLocal,
      shippingLocal,
      taxLocal,
      customsDutyLocal,
      totalLocal,
      taxRatePercent: rule.taxRatePercent,
      taxLabel: rule.taxLabel,
      customsDutyRatePercent: customsApplicable ? rule.customsDutyRatePercent : 0,
      customsSupported: rule.customsDutySupported,
      customsNote: rule.customsNote,
      shippingCarrier: rule.shippingCarrier,
      estimatedDelivery: rule.estimatedDelivery,
      freeShippingThresholdLocal,
      freeShippingApplied,
      codAvailable: rule.codAvailable,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Failed to lock checkout quote.';
    res.status(500).json({ error: message });
  }
});

// Pincode & International Delivery Serviceability Check
app.post('/api/shipping/check-pincode', (req, res) => {
  const { pincode, country, countryCode } = req.body as {
    pincode?: string;
    country?: string;
    countryCode?: string;
  };
  const clean = (pincode || '').trim();
  if (clean.length < 3 || clean.length > 14) {
    res.status(400).json({ error: 'Please enter a valid 3–14 character postal or PIN code.' });
    return;
  }

  const codeUpper = (countryCode || '').trim().toUpperCase();
  const isIndia = codeUpper === 'IN' || (!codeUpper && /^\d{6}$/.test(clean) && (!country || country.toLowerCase().includes('india')));

  if (isIndia) {
    const firstDigit = Number(clean[0]);
    const isMetro = [1, 4, 5, 6].includes(firstDigit);
    res.json({
      serviceable: true,
      countryCode: 'IN',
      zone: isMetro ? 'Metro Express India' : 'Pan-India Courier',
      carrier: isMetro ? 'BlueDart Air Priority' : 'Delhivery Express',
      estimatedDays: isMetro ? '1–2 Business Days' : '3–5 Business Days',
      codAvailable: true,
      shippingFeeUsd: 2.9,
      freeAboveUsd: 55,
    });
    return;
  }

  const rule =
    (codeUpper && SERVER_COUNTRY_RULES[codeUpper]) ||
    Object.values(SERVER_COUNTRY_RULES).find(
      (r) => country && r.name.toLowerCase() === country.trim().toLowerCase(),
    );

  if (rule) {
    res.json({
      serviceable: true,
      countryCode: rule.code,
      zone: rule.shippingZoneName,
      carrier: rule.shippingCarrier,
      estimatedDays: rule.estimatedDelivery,
      codAvailable: rule.codAvailable,
      shippingFeeUsd: rule.shippingBaseUsd,
      freeAboveUsd: rule.freeShippingThresholdUsd,
    });
    return;
  }

  res.json({
    serviceable: true,
    countryCode: codeUpper || 'INTL',
    zone: `International Priority (${country || 'Global'})`,
    carrier: 'DHL Express Worldwide',
    estimatedDays: '4–7 Business Days',
    codAvailable: false,
    shippingFeeUsd: 14,
    freeAboveUsd: 140,
  });
});

// Bulk CSV Parser for Admin Product Import
app.post('/api/products/parse-csv', (req, res) => {
  try {
    const { csvText } = req.body as { csvText?: string };
    if (!csvText || typeof csvText !== 'string') {
      res.status(400).json({ error: 'Missing csvText payload.' });
      return;
    }
    const lines = csvText
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean);
    if (lines.length < 2) {
      res.status(400).json({ error: 'CSV must include header row and at least one product row.' });
      return;
    }

    const headers = lines[0].split(',').map((h) => h.trim().toLowerCase());
    const parsed = lines.slice(1).map((line, idx) => {
      const cols = line.split(',').map((c) => c.trim());
      const get = (key: string, fallback = '') => {
        const i = headers.indexOf(key);
        return i >= 0 && cols[i] ? cols[i] : fallback;
      };
      return {
        id: get('id', `prod_csv_${Date.now()}_${idx}`),
        name: get('name', `Imported Formula ${idx + 1}`),
        brand: get('brand', 'LUMIÈRE ATELIER'),
        category: get('category', 'Lipsticks, Gloss & Liners'),
        collection: get('collection', 'Signature'),
        price: Math.max(1, Number(get('price', '45')) || 45),
        stock: Math.max(0, Math.round(Number(get('stock', '30')) || 30)),
        sku: get('sku', `LA-CSV-${100 + idx}`),
        description: get('description', 'Imported luxury cosmetic formula.'),
        ingredients: get('ingredients', 'Clean botanical cosmetic base.'),
        finish: get('finish', 'Velvet Matte'),
        modelType: get('modeltype', 'lipstick'),
        imageUrl: get('imageurl', '/src/assets/images/cat_lipsticks_gloss_1794984607329.jpg'),
        shadeName: get('shadename', 'Atelier Rose'),
        shadeHex: get('shadehex', '#9E1B32'),
      };
    });

    res.json({ products: parsed, count: parsed.length });
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'CSV parse error.' });
  }
});

// Media upload endpoint
app.post('/api/uploads/media', (req, res) => {
  try {
    const { dataUrl, filename } = req.body as { dataUrl?: string; filename?: string };
    if (!dataUrl || typeof dataUrl !== 'string') {
      res.status(400).json({ error: 'Missing media dataUrl payload.' });
      return;
    }

    const match = /^data:(image\/(?:png|jpeg|jpg|webp)|video\/(?:mp4|webm));base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
    if (!match) {
      res.status(400).json({ error: 'Unsupported media format. Allowed: PNG, JPEG, WEBP, MP4, WEBM.' });
      return;
    }

    const mime = match[1];
    const base64Data = match[2];
    const buffer = Buffer.from(base64Data, 'base64');
    if (buffer.byteLength > 10 * 1024 * 1024) {
      res.status(413).json({ error: 'Media exceeds 10MB upload limit.' });
      return;
    }

    const ext = mime.split('/')[1] === 'jpeg' ? 'jpg' : mime.split('/')[1];
    const safeName = (filename || 'media').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 40) || 'media';
    const outName = `${safeName}_${Date.now()}_${crypto.randomBytes(4).toString('hex')}.${ext}`;
    const outPath = path.join(uploadsDir, outName);
    fs.writeFileSync(outPath, buffer);

    res.json({ url: `/uploads/${outName}`, mime, size: buffer.byteLength });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Media upload failed.';
    res.status(500).json({ error: message });
  }
});

// Gemini AI Shade Finder
interface CatalogItemSummary {
  id: string;
  name: string;
  category: string;
  finish: string;
  shades: { id: string; name: string; hex: string; undertone?: string }[];
  skinTones?: string[];
}

app.post('/api/ai/shade-finder', async (req, res) => {
  try {
    const {
      imageBase64,
      mimeType,
      skinTone,
      undertone,
      occasion,
      finishPreference,
      concern,
      catalog,
    } = req.body as {
      imageBase64?: string;
      mimeType?: string;
      skinTone?: string;
      undertone?: string;
      occasion?: string;
      finishPreference?: string;
      concern?: string;
      catalog?: CatalogItemSummary[];
    };

    const ai = getGeminiClient();
    const catalogText = JSON.stringify(catalog || [], null, 2);
    const promptText = `You are a master celebrity makeup artist and cosmetic chemist at LUMIÈRE ATELIER.
Analyze the user's complexion profile (and photo if provided) and recommend the best matching shades and products ONLY from the provided catalog JSON.

User Preferences:
- Reported Skin Tone: ${skinTone || 'Analyze from photo or general'}
- Reported Undertone: ${undertone || 'Analyze from photo or general'}
- Occasion: ${occasion || 'Everyday Luxury'}
- Preferred Finish: ${finishPreference || 'Balanced'}
- Focus / Concern: ${concern || 'Radiant longevity'}

Available Product Catalog:
${catalogText}

Return exact product IDs and exact shade names from the catalog.`;

    const parts: Array<{ text: string } | { inlineData: { mimeType: string; data: string } }> = [];
    if (imageBase64 && mimeType) {
      parts.push({ inlineData: { mimeType, data: imageBase64 } });
    }
    parts.push({ text: promptText });

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: { parts },
      config: {
        systemInstruction:
          'You are an inclusive, precision luxury cosmetic shade-matching specialist. Always select real product IDs and shade names present in the provided catalog.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            detectedSkinTone: { type: Type.STRING },
            detectedUndertone: { type: Type.STRING },
            confidenceNote: { type: Type.STRING },
            applicationTips: { type: Type.STRING },
            recommendations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  productId: { type: Type.STRING },
                  shadeName: { type: Type.STRING },
                  reason: { type: Type.STRING },
                },
                required: ['productId', 'shadeName', 'reason'],
              },
            },
          },
          required: [
            'detectedSkinTone',
            'detectedUndertone',
            'confidenceNote',
            'applicationTips',
            'recommendations',
          ],
        },
      },
    });

    const rawText = (response.text ?? '{}').trim();
    res.json(JSON.parse(rawText));
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Failed to analyze shade profile.';
    res.status(500).json({ error: message });
  }
});

// Multi-Gateway Payment Architecture
type GatewayName = 'Razorpay' | 'Cashfree' | 'PayU' | 'CCAvenue' | 'Stripe' | 'PayPal' | 'COD';

function getGatewaySecret(gateway: GatewayName): string {
  switch (gateway) {
    case 'Razorpay':
      return process.env.RAZORPAY_KEY_SECRET || SANDBOX_SECRET;
    case 'Cashfree':
      return process.env.CASHFREE_SECRET_KEY || SANDBOX_SECRET;
    case 'PayU':
      return process.env.PAYU_MERCHANT_SALT || SANDBOX_SECRET;
    case 'CCAvenue':
      return process.env.CCAVENUE_WORKING_KEY || SANDBOX_SECRET;
    case 'Stripe':
      return process.env.STRIPE_SECRET_KEY || SANDBOX_SECRET;
    case 'PayPal':
      return process.env.PAYPAL_CLIENT_SECRET || SANDBOX_SECRET;
    default:
      return SANDBOX_SECRET;
  }
}

app.get('/api/payments/gateways', (_req, res) => {
  const gateways = [
    {
      id: 'Razorpay',
      name: 'Razorpay',
      region: 'India & Global',
      supportedCountries: ['IN', 'SG', 'AE', 'US', 'GB'],
      supportedCurrencies: ['INR', 'USD', 'GBP', 'EUR', 'SGD', 'AED'],
      mode: process.env.RAZORPAY_KEY_ID ? 'live' : 'sandbox',
      methods: ['UPI', 'Google Pay', 'PhonePe', 'Paytm', 'Debit/Credit Card', 'Net Banking', 'Wallets', 'EMI'],
    },
    {
      id: 'Cashfree',
      name: 'Cashfree Payments',
      region: 'India',
      supportedCountries: ['IN'],
      supportedCurrencies: ['INR', 'USD'],
      mode: process.env.CASHFREE_APP_ID ? 'live' : 'sandbox',
      methods: ['UPI', 'Google Pay', 'PhonePe', 'Paytm', 'Debit/Credit Card', 'Net Banking', 'Wallets'],
    },
    {
      id: 'PayU',
      name: 'PayU India',
      region: 'India',
      supportedCountries: ['IN'],
      supportedCurrencies: ['INR'],
      mode: process.env.PAYU_MERCHANT_KEY ? 'live' : 'sandbox',
      methods: ['UPI', 'Debit/Credit Card', 'Net Banking', 'EMI', 'Wallets'],
    },
    {
      id: 'CCAvenue',
      name: 'CCAvenue',
      region: 'India & Middle East (UAE/KSA)',
      supportedCountries: ['IN', 'AE', 'SA'],
      supportedCurrencies: ['INR', 'AED', 'SAR', 'USD', 'GBP', 'EUR'],
      mode: process.env.CCAVENUE_ACCESS_CODE ? 'live' : 'sandbox',
      methods: ['Net Banking', 'Debit/Credit Card', 'Apple Pay', 'Mada', 'UPI', 'Wallets', 'EMI'],
    },
    {
      id: 'Stripe',
      name: 'Stripe Global',
      region: 'Worldwide (US, UK, EU, CN, JP, CA, AU, AE+)',
      supportedCountries: ['US', 'GB', 'DE', 'FR', 'EU', 'CN', 'JP', 'CA', 'AU', 'AE', 'SG', 'CH', 'SA', 'KR', 'BR', 'MX', 'NZ', 'IN'],
      supportedCurrencies: Object.keys(FX_REFERENCE_RATES),
      mode: process.env.STRIPE_SECRET_KEY ? 'live' : 'sandbox',
      methods: [
        'Debit/Credit Card',
        'Apple Pay',
        'Google Pay',
        'SEPA / Giropay (EU)',
        'Alipay / WeChat Pay (CN)',
        'JCB / Konbini (JP)',
        'Interac (CA)',
      ],
    },
    {
      id: 'PayPal',
      name: 'PayPal International',
      region: 'Global 200+ Markets',
      supportedCountries: ['US', 'GB', 'DE', 'FR', 'EU', 'CN', 'JP', 'CA', 'AU', 'AE', 'SG', 'CH', 'KR', 'BR', 'MX', 'NZ'],
      supportedCurrencies: Object.keys(FX_REFERENCE_RATES),
      mode: process.env.PAYPAL_CLIENT_ID ? 'live' : 'sandbox',
      methods: ['PayPal Wallet', 'PayPal Pay Later', 'Debit/Credit Card'],
    },
    {
      id: 'COD',
      name: 'Cash on Delivery',
      region: 'India, UAE & Saudi Arabia',
      supportedCountries: ['IN', 'AE', 'SA'],
      supportedCurrencies: ['INR', 'AED', 'SAR', 'USD'],
      mode: 'active',
      methods: ['Pay on Delivery'],
    },
  ];
  res.json({ gateways });
});

app.post('/api/payments/create-order', async (req, res) => {
  try {
    const { orderId, amount, currency, gateway, method, customerEmail, quoteLock } = req.body as {
      orderId: string;
      amount: number;
      currency: string;
      gateway: GatewayName;
      method: string;
      customerEmail?: string;
      quoteLock?: {
        quoteId: string;
        quoteSignature: string;
        countryCode: string;
        settlementCurrency: string;
        totalLocal: number;
        totalUsd: number;
        lockedRate: number;
        expiresAt: string;
      };
    };

    if (!orderId || typeof amount !== 'number' || amount <= 0 || !gateway) {
      res.status(400).json({ error: 'Invalid payment order request parameters.' });
      return;
    }

    // Enforce server-locked quote verification so FX estimates are never used as confirmed prices
    let verifiedAmount = amount;
    let verifiedCurrency = currency || 'USD';
    let verifiedQuoteId: string | undefined;

    if (quoteLock) {
      if (Date.now() > new Date(quoteLock.expiresAt).getTime()) {
        res.status(409).json({
          error: 'Checkout price quote expired. Refreshing locked exchange rate and totals.',
          code: 'QUOTE_EXPIRED',
        });
        return;
      }

      const expectedSig = signCheckoutQuote({
        quoteId: quoteLock.quoteId,
        countryCode: quoteLock.countryCode,
        settlementCurrency: quoteLock.settlementCurrency,
        totalLocal: Number(quoteLock.totalLocal),
        totalUsd: Number(quoteLock.totalUsd),
        lockedRate: Number(quoteLock.lockedRate),
        expiresAt: quoteLock.expiresAt,
      });

      const sigValid =
        expectedSig.length === (quoteLock.quoteSignature || '').length &&
        crypto.timingSafeEqual(Buffer.from(expectedSig), Buffer.from(quoteLock.quoteSignature));

      if (!sigValid) {
        res.status(403).json({
          error: 'Checkout quote signature verification failed. Please re-lock your checkout quote.',
          code: 'INVALID_QUOTE_SIGNATURE',
        });
        return;
      }

      verifiedAmount = Number(quoteLock.totalLocal);
      verifiedCurrency = quoteLock.settlementCurrency;
      verifiedQuoteId = quoteLock.quoteId;
    }

    const prefixMap: Record<GatewayName, string> = {
      Razorpay: 'order_rzp',
      Cashfree: 'cf_order',
      PayU: 'payu_txn',
      CCAvenue: 'ccav_ord',
      Stripe: 'pi_stripe',
      PayPal: 'pp_order',
      COD: 'cod_ref',
    };

    let gatewayOrderId = `${prefixMap[gateway] || 'gw_ord'}_${crypto.randomBytes(6).toString('hex')}`;
    let liveProviderPayload: Record<string, unknown> | null = null;

    if (gateway === 'Razorpay' && process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET) {
      const authHeader = Buffer.from(
        `${process.env.RAZORPAY_KEY_ID}:${process.env.RAZORPAY_KEY_SECRET}`,
      ).toString('base64');
      const rzpRes = await fetch('https://api.razorpay.com/v1/orders', {
        method: 'POST',
        headers: {
          Authorization: `Basic ${authHeader}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: Math.round(verifiedAmount * 100),
          currency: verifiedCurrency || 'INR',
          receipt: orderId,
          notes: { method, customerEmail: customerEmail || '', quoteId: verifiedQuoteId || '' },
        }),
      });
      if (rzpRes.ok) {
        const rzpData = (await rzpRes.json()) as { id: string };
        gatewayOrderId = rzpData.id;
        liveProviderPayload = rzpData;
      }
    }

    const secret = getGatewaySecret(gateway);
    const nonce = crypto.randomBytes(8).toString('hex');
    const serverToken = crypto
      .createHmac('sha256', secret)
      .update(`${orderId}|${gatewayOrderId}|${verifiedAmount.toFixed(2)}|${verifiedCurrency}|${nonce}`)
      .digest('hex');

    res.json({
      orderId,
      gateway,
      method,
      gatewayOrderId,
      amount: verifiedAmount,
      currency: verifiedCurrency,
      quoteId: verifiedQuoteId,
      nonce,
      serverToken,
      mode: liveProviderPayload ? 'live' : 'sandbox',
      expiresAt: new Date(Date.now() + 15 * 60 * 1000).toISOString(),
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Could not initiate payment order.';
    res.status(500).json({ error: message });
  }
});

app.post('/api/payments/verify', (req, res) => {
  try {
    const {
      orderId,
      gateway,
      gatewayOrderId,
      amount,
      currency,
      nonce,
      serverToken,
      simulateFailure,
    } = req.body as {
      orderId: string;
      gateway: GatewayName;
      gatewayOrderId: string;
      amount: number;
      currency: string;
      nonce: string;
      serverToken: string;
      simulateFailure?: boolean;
    };

    if (!orderId || !gateway || !gatewayOrderId || !nonce || !serverToken) {
      res.status(400).json({ error: 'Missing required payment verification fields.' });
      return;
    }

    const secret = getGatewaySecret(gateway);
    const expectedToken = crypto
      .createHmac('sha256', secret)
      .update(`${orderId}|${gatewayOrderId}|${Number(amount).toFixed(2)}|${currency}|${nonce}`)
      .digest('hex');

    const validToken =
      expectedToken.length === serverToken.length &&
      crypto.timingSafeEqual(Buffer.from(expectedToken), Buffer.from(serverToken));

    if (!validToken) {
      res.status(403).json({
        verified: false,
        status: 'failed',
        error: 'Cryptographic payment signature verification failed.',
      });
      return;
    }

    if (simulateFailure) {
      res.json({
        verified: false,
        status: 'failed',
        gatewayPaymentId: null,
        failureReason: 'Sandbox bank authorization declined (simulated for retry testing).',
        webhookEvent: `${gateway.toLowerCase()}.payment.failed`,
      });
      return;
    }

    const gatewayPaymentId = `pay_${gateway.toLowerCase()}_${crypto.randomBytes(7).toString('hex')}`;
    const signature = crypto
      .createHmac('sha256', secret)
      .update(`${gatewayOrderId}|${gatewayPaymentId}`)
      .digest('hex');

    res.json({
      verified: true,
      status: gateway === 'COD' ? 'pending' : 'succeeded',
      gatewayPaymentId,
      signature,
      webhookConfirmed: true,
      webhookEvent: gateway === 'COD' ? 'cod.order.confirmed' : `${gateway.toLowerCase()}.payment.captured`,
      verifiedAt: new Date().toISOString(),
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Payment verification error.';
    res.status(500).json({ error: message });
  }
});

app.post('/api/payments/retry', (req, res) => {
  try {
    const { orderId, gateway, method, amount } = req.body as {
      orderId: string;
      gateway: GatewayName;
      method: string;
      amount: number;
    };

    if (!orderId || !gateway || typeof amount !== 'number') {
      res.status(400).json({ error: 'Invalid payment retry payload.' });
      return;
    }

    const gatewayOrderId = `retry_${gateway.toLowerCase()}_${crypto.randomBytes(5).toString('hex')}`;
    const gatewayPaymentId = `pay_${gateway.toLowerCase()}_${crypto.randomBytes(7).toString('hex')}`;
    const secret = getGatewaySecret(gateway);
    const signature = crypto
      .createHmac('sha256', secret)
      .update(`${gatewayOrderId}|${gatewayPaymentId}`)
      .digest('hex');

    res.json({
      verified: true,
      status: gateway === 'COD' ? 'pending' : 'succeeded',
      gateway,
      method,
      gatewayOrderId,
      gatewayPaymentId,
      signature,
      webhookConfirmed: true,
      retriedAt: new Date().toISOString(),
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Payment retry error.';
    res.status(500).json({ error: message });
  }
});

app.post('/api/payments/refund', (req, res) => {
  try {
    const { orderId, gateway, gatewayPaymentId, refundAmount, totalAmount, reason } = req.body as {
      orderId: string;
      gateway: GatewayName;
      gatewayPaymentId?: string;
      refundAmount: number;
      totalAmount: number;
      reason?: string;
    };

    if (!orderId || typeof refundAmount !== 'number' || refundAmount <= 0 || refundAmount > totalAmount) {
      res.status(400).json({ error: 'Invalid refund amount requested.' });
      return;
    }

    const isFull = Math.abs(refundAmount - totalAmount) < 0.01;
    const refundId = `rfnd_${(gateway || 'gw').toLowerCase()}_${crypto.randomBytes(6).toString('hex')}`;

    res.json({
      refundId,
      orderId,
      gatewayPaymentId: gatewayPaymentId || 'direct_settlement',
      refundAmount,
      refundType: isFull ? 'full' : 'partial',
      status: isFull ? 'refunded' : 'partially_refunded',
      reason: reason || 'Customer refund processed',
      processedAt: new Date().toISOString(),
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Refund processing failed.';
    res.status(500).json({ error: message });
  }
});

app.post('/api/payments/webhook/:gateway', (req, res) => {
  const gateway = req.params.gateway as GatewayName;
  const sigHeader =
    (req.headers['x-razorpay-signature'] as string | undefined) ||
    (req.headers['stripe-signature'] as string | undefined) ||
    (req.headers['x-webhook-signature'] as string | undefined);

  const secret = getGatewaySecret(gateway);
  const expected = crypto
    .createHmac('sha256', secret)
    .update(JSON.stringify(req.body || {}))
    .digest('hex');

  const verified = Boolean(
    sigHeader && sigHeader.length === expected.length && crypto.timingSafeEqual(Buffer.from(sigHeader), Buffer.from(expected)),
  );

  res.status(verified || process.env.NODE_ENV !== 'production' ? 200 : 401).json({
    received: true,
    gateway,
    signatureVerified: verified,
    timestamp: new Date().toISOString(),
  });
});

// ============================================================================
// ERP: AUTOMATIC ORDER ROUTING ENGINE
// ============================================================================
interface RouteOrderItemInput {
  productId: string;
  name: string;
  sku?: string;
  shadeName?: string;
  shadeHex?: string;
  quantity: number;
  unitPrice: number;
  purchasePrice?: number;
  supplierId?: string;
  supplierSku?: string;
  warehouseId?: string;
  fulfillmentMethod?: 'own_inventory' | 'dropshipping' | 'private_label';
  ownedStock?: number;
  supplierStock?: number;
  moq?: number;
  taxRatePercent?: number;
}

interface RouteSupplierInput {
  id: string;
  companyName: string;
  email: string;
  integrationType: 'API' | 'Shopify' | 'CSV' | 'Email' | 'WhatsApp' | 'Manual' | 'Portal';
  leadTimeDays: number;
  privateLabelCapable?: boolean;
}

app.post('/api/orders/route', (req, res) => {
  try {
    const {
      orderId,
      orderSource = 'Online Store',
      customerType = 'retail',
      paymentGateway = 'Razorpay',
      discount = 0,
      shippingCost = 0,
      items = [],
      suppliers = [],
      requestedPackagingType = 'custom_brand_box',
    } = req.body as {
      orderId?: string;
      orderSource?: string;
      customerType?: 'retail' | 'wholesale' | 'dealer' | 'distributor' | 'enterprise';
      paymentGateway?: string;
      discount?: number;
      shippingCost?: number;
      items?: RouteOrderItemInput[];
      suppliers?: RouteSupplierInput[];
      requestedPackagingType?: 'poly_mailer' | 'cardboard_box' | 'custom_brand_box' | 'wholesale_master_carton';
    };

    if (!Array.isArray(items) || items.length === 0) {
      res.status(400).json({ error: 'Order routing requires at least one line item.' });
      return;
    }

    const isOfflineOrB2BChannel = [
      'WhatsApp Orders',
      'Phone Orders',
      'Offline Sales',
      'Field Sales',
      'Retailer Orders',
      'Dealer Orders',
      'Distributor Orders',
      'Admin Created Orders',
    ].includes(orderSource);

    const salesChannel =
      customerType !== 'retail'
        ? 'WHOLESALE_B2B'
        : isOfflineOrB2BChannel
          ? 'OFFLINE_DIRECT'
          : orderSource === 'Marketplace Orders'
            ? 'MARKETPLACE'
            : 'D2C_ONLINE';

    const warehouseAllocations: Array<{ productId: string; warehouseId: string; quantity: number }> = [];
    const supplierGroups = new Map<
      string,
      {
        supplierId: string;
        supplierName: string;
        supplierEmail: string;
        integrationType: RouteSupplierInput['integrationType'];
        channelMode: 'online_dropship' | 'private_label' | 'offline_wholesale';
        items: Array<{
          productId: string;
          sku: string;
          supplierSku: string;
          name: string;
          shadeName: string;
          quantity: number;
          unitCost: number;
        }>;
      }
    >();

    let subtotal = 0;
    let totalPurchaseCost = 0;
    let totalTax = 0;
    let usedOwnInventory = false;
    let usedDropship = false;
    let usedPrivateLabel = false;
    const warnings: string[] = [];

    const routedItems = items.map((item) => {
      const qty = Math.max(1, Math.round(item.quantity || 1));
      const unitPrice = Number(item.unitPrice || 0);
      const unitPurchase = Number(item.purchasePrice ?? unitPrice * 0.42);
      const lineTotal = unitPrice * qty;
      subtotal += lineTotal;
      totalPurchaseCost += unitPurchase * qty;
      totalTax += lineTotal * ((item.taxRatePercent ?? 12) / 100);

      const ownedAvail = Math.max(0, Math.round(item.ownedStock ?? 0));
      const supplierAvail = Math.max(0, Math.round(item.supplierStock ?? 200));
      const preferredMethod = item.fulfillmentMethod || 'own_inventory';

      let chosenMethod: 'own_inventory' | 'dropshipping' | 'private_label' = preferredMethod;
      if (preferredMethod === 'own_inventory' && ownedAvail < qty) {
        if (supplierAvail >= qty) {
          chosenMethod = 'dropshipping';
          warnings.push(`${item.name}: Own warehouse stock (${ownedAvail}) < qty (${qty}); auto-routed to supplier.`);
        } else {
          warnings.push(`${item.name}: Low combined stock; flagged for warehouse backorder/manual review.`);
        }
      }

      if (chosenMethod === 'own_inventory') {
        usedOwnInventory = true;
        warehouseAllocations.push({
          productId: item.productId,
          warehouseId: item.warehouseId || 'wh_mumbai_central',
          quantity: qty,
        });
      } else {
        if (chosenMethod === 'private_label') usedPrivateLabel = true;
        else usedDropship = true;

        const sup =
          suppliers.find((s) => s.id === item.supplierId) ||
          suppliers[0] || {
            id: item.supplierId || 'sup_laboratoire_paris',
            companyName: 'Laboratoire Lumière Paris',
            email: 'fulfillment@laboratoirelumiere.example',
            integrationType: 'Portal' as const,
            leadTimeDays: 3,
          };

        // Never mix online dropshipping and offline wholesale inside the same supplier PO
        const channelMode: 'online_dropship' | 'private_label' | 'offline_wholesale' =
          customerType !== 'retail' || isOfflineOrB2BChannel
            ? 'offline_wholesale'
            : chosenMethod === 'private_label'
              ? 'private_label'
              : 'online_dropship';

        const groupKey = `${sup.id}__${channelMode}`;
        if (!supplierGroups.has(groupKey)) {
          supplierGroups.set(groupKey, {
            supplierId: sup.id,
            supplierName: sup.companyName,
            supplierEmail: sup.email,
            integrationType: sup.integrationType,
            channelMode,
            items: [],
          });
        }
        supplierGroups.get(groupKey)!.items.push({
          productId: item.productId,
          sku: item.sku || item.productId,
          supplierSku: item.supplierSku || `SUP-${item.sku || item.productId}`,
          name: item.name,
          shadeName: item.shadeName || 'Standard',
          quantity: qty,
          unitCost: Number(unitPurchase.toFixed(2)),
        });
      }

      return {
        ...item,
        quantity: qty,
        purchaseCost: Number((unitPurchase * qty).toFixed(2)),
        fulfillmentMethod: chosenMethod,
      };
    });

    const poCount = supplierGroups.size;
    let fulfillmentType: 'own_inventory' | 'dropshipping' | 'private_label' | 'offline_wholesale' | 'mixed_split' =
      'own_inventory';

    if (usedOwnInventory && (usedDropship || usedPrivateLabel)) {
      fulfillmentType = 'mixed_split';
    } else if (customerType !== 'retail' && poCount > 0) {
      fulfillmentType = 'offline_wholesale';
    } else if (usedPrivateLabel && !usedDropship) {
      fulfillmentType = 'private_label';
    } else if (usedDropship) {
      fulfillmentType = 'dropshipping';
    }

    const totalDiscount = Math.max(0, Number(discount || 0));
    const netRevenue = Math.max(0, subtotal - totalDiscount);
    const packagingUnitCost =
      requestedPackagingType === 'wholesale_master_carton'
        ? 4.2
        : requestedPackagingType === 'custom_brand_box'
          ? 1.85
          : requestedPackagingType === 'cardboard_box'
            ? 1.15
            : 0.65;
    const packagingCost = Number((packagingUnitCost * Math.max(1, poCount || 1)).toFixed(2));
    const gatewayFee = paymentGateway === 'COD' ? 0 : Number((netRevenue * 0.022).toFixed(2));
    const grossProfit = Number((netRevenue - totalPurchaseCost).toFixed(2));
    const netProfit = Number((grossProfit - packagingCost - Number(shippingCost || 0) - gatewayFee).toFixed(2));

    const nowIso = new Date().toISOString();
    const baseId = orderId || `ord_${Date.now()}`;
    const purchaseOrders = Array.from(supplierGroups.values()).map((grp, idx) => {
      const poCost = grp.items.reduce((s, it) => s + it.unitCost * it.quantity, 0);
      return {
        id: `po_${baseId.replace(/[^a-zA-Z0-9_-]/g, '')}_${idx + 1}`,
        parentOrderId: baseId,
        supplierId: grp.supplierId,
        supplierName: grp.supplierName,
        supplierEmail: grp.supplierEmail,
        channelMode: grp.channelMode,
        customerType,
        items: grp.items,
        totalCost: Number(poCost.toFixed(2)),
        shippingCost: Number((Number(shippingCost || 0) / Math.max(1, poCount)).toFixed(2)),
        packagingCost: packagingUnitCost,
        integrationType: grp.integrationType,
        status: grp.integrationType === 'API' || grp.integrationType === 'Shopify' ? 'sent' : 'pending_dispatch',
        packagingSpec: {
          packagingType: requestedPackagingType,
          boxBranding: true,
          thankYouCard: true,
          customTape: true,
          customSticker: true,
          customLabel: grp.channelMode === 'private_label',
          noSupplierBranding: true,
          noSupplierPriceInvoice: true,
          unitCost: packagingUnitCost,
          qcChecklistPassed: false,
          specialInstructions:
            'Pack strictly under LUMIÈRE ATELIER brand guidelines. Do NOT include supplier invoice or branding.',
        },
        dispatchNotes:
          grp.integrationType === 'API' || grp.integrationType === 'Shopify'
            ? `Queued via ${grp.integrationType} integration. Awaiting supplier acceptance.`
            : `Pending manual ${grp.integrationType} dispatch to ${grp.supplierName}.`,
      };
    });

    res.json({
      orderId: baseId,
      orderSource,
      salesChannel,
      customerType,
      fulfillmentType,
      erpStatus: purchaseOrders.length > 0 ? 'PURCHASE_ORDER_CREATED' : 'ORDER_VERIFIED',
      warehouseId: warehouseAllocations[0]?.warehouseId || 'wh_mumbai_central',
      warehouseAllocations,
      routedItems,
      purchaseOrders,
      financials: {
        subtotal: Number(subtotal.toFixed(2)),
        discount: Number(totalDiscount.toFixed(2)),
        purchaseCost: Number(totalPurchaseCost.toFixed(2)),
        shippingCost: Number(Number(shippingCost || 0).toFixed(2)),
        packagingCost,
        gatewayFee,
        taxAmount: Number(totalTax.toFixed(2)),
        grossProfit,
        netProfit,
      },
      warnings,
      timeline: [
        { stage: 'NEW', timestamp: nowIso, actor: 'Routing Engine', note: `Captured from ${orderSource}` },
        { stage: 'ROUTING', timestamp: nowIso, actor: 'Routing Engine', note: `Channel: ${salesChannel} | Mode: ${fulfillmentType}` },
        {
          stage: purchaseOrders.length > 0 ? 'PURCHASE_ORDER_CREATED' : 'ORDER_VERIFIED',
          timestamp: nowIso,
          actor: 'Routing Engine',
          note:
            purchaseOrders.length > 0
              ? `Generated ${purchaseOrders.length} separated supplier PO(s)`
              : 'Allocated from owned warehouse inventory',
        },
      ],
    });
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Order routing error.' });
  }
});

// ============================================================================
// ERP: SUPPLIER PO AUTOMATION & WHITE-LABEL DISPATCH
// ============================================================================
app.post('/api/suppliers/dispatch-po', async (req, res) => {
  try {
    const { poId, supplierName, supplierEmail, integrationType, webhookUrl, items, packagingSpec, channelMode } =
      req.body as {
        poId: string;
        supplierName: string;
        supplierEmail: string;
        integrationType: 'API' | 'Shopify' | 'CSV' | 'Email' | 'WhatsApp' | 'Manual' | 'Portal';
        webhookUrl?: string;
        items: Array<{ sku: string; supplierSku?: string; name: string; quantity: number; unitCost: number }>;
        packagingSpec?: { noSupplierBranding?: boolean; noSupplierPriceInvoice?: boolean; specialInstructions?: string };
        channelMode?: string;
      };

    if (!poId || !supplierName || !Array.isArray(items) || items.length === 0) {
      res.status(400).json({ error: 'Missing required Purchase Order dispatch fields.' });
      return;
    }

    const brandGuard =
      'BRAND GUARD: Pack in LUMIÈRE ATELIER branded box + thank-you card. Strictly NO supplier branding and NO supplier pricing slip.';
    const itemLines = items
      .map((it) => `${it.supplierSku || it.sku} | ${it.name} × ${it.quantity} (@ $${Number(it.unitCost).toFixed(2)})`)
      .join('\n');

    let nextStatus: 'sent' | 'pending_dispatch' = 'pending_dispatch';
    let dispatchPayload = '';

    if (integrationType === 'API') {
      if (webhookUrl && webhookUrl.startsWith('https://') && !webhookUrl.includes('.local') && !webhookUrl.includes('.example')) {
        try {
          const hookRes = await fetch(webhookUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ poId, channelMode, items, packagingSpec }),
          });
          nextStatus = hookRes.ok ? 'sent' : 'pending_dispatch';
        } catch {
          nextStatus = 'pending_dispatch';
        }
      } else {
        nextStatus = 'sent';
      }
      dispatchPayload = JSON.stringify({ poId, supplierEmail, channelMode, items, packagingSpec }, null, 2);
    } else if (integrationType === 'Shopify') {
      nextStatus = 'sent';
      dispatchPayload = JSON.stringify(
        {
          fulfillment_order_ref: poId,
          line_items: items.map((i) => ({ sku: i.supplierSku || i.sku, quantity: i.quantity })),
          note: `${brandGuard} ${packagingSpec?.specialInstructions || ''}`,
        },
        null,
        2,
      );
    } else if (integrationType === 'CSV') {
      nextStatus = 'sent';
      const csvRows = items.map((i) => `${poId},${i.supplierSku || i.sku},"${i.name}",${i.quantity},"${brandGuard}"`);
      dispatchPayload = `po_id,supplier_sku,product_name,qty,packaging_rule\n${csvRows.join('\n')}`;
    } else {
      nextStatus = 'pending_dispatch';
      dispatchPayload = `PO #${poId} (${channelMode || 'fulfillment'}) for ${supplierName}\n${itemLines}\n\n${brandGuard}`;
    }

    res.json({
      poId,
      integrationType,
      status: nextStatus,
      awaitingSupplierAcceptance: true,
      dispatchedAt: new Date().toISOString(),
      dispatchPayload,
      dispatchNotes:
        nextStatus === 'sent'
          ? `PO transmitted via ${integrationType}. Awaiting supplier confirmation (not auto-confirmed).`
          : `PO queued for ${integrationType} manual/portal dispatch. Supplier acceptance pending.`,
    });
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'PO dispatch failed.' });
  }
});

app.post('/api/webhooks/supplier-update', (req, res) => {
  const { poId, status, trackingNumber, carrier, notes } = req.body as {
    poId?: string;
    status?: string;
    trackingNumber?: string;
    carrier?: string;
    notes?: string;
  };
  const allowed = ['supplier_accepted', 'packed', 'shipped', 'delayed', 'rejected'];
  if (!poId || !status || !allowed.includes(status)) {
    res.status(400).json({ error: 'Invalid supplier webhook update payload.' });
    return;
  }
  res.json({
    ok: true,
    poId,
    status,
    trackingNumber: trackingNumber || undefined,
    carrier: carrier || undefined,
    notes: notes || `Supplier webhook confirmed status: ${status}`,
    updatedAt: new Date().toISOString(),
  });
});

// ============================================================================
// ERP: FINANCIAL & OPERATIONAL CSV REPORT EXPORT
// ============================================================================
app.post('/api/erp/export-report', (req, res) => {
  const { reportType = 'pnl', orders = [], products = [], suppliers = [] } = req.body as {
    reportType?: 'pnl' | 'channels' | 'suppliers' | 'inventory';
    orders?: Array<Record<string, unknown>>;
    products?: Array<Record<string, unknown>>;
    suppliers?: Array<Record<string, unknown>>;
  };

  const escape = (val: unknown) => `"${String(val ?? '').replace(/"/g, '""')}"`;
  let headers: string[] = [];
  let rows: unknown[][] = [];

  if (reportType === 'pnl') {
    headers = ['OrderID', 'Channel', 'CustomerType', 'Fulfillment', 'Total', 'COGS', 'Shipping', 'Packaging', 'GatewayFee', 'NetProfit', 'Status'];
    rows = orders.map((o) => [
      o.id,
      o.orderSource || 'Online Store',
      o.customerType || 'retail',
      o.fulfillmentType || 'own_inventory',
      o.total,
      o.purchaseCost ?? 0,
      o.shippingCost ?? 0,
      o.packagingCost ?? 0,
      o.gatewayFee ?? 0,
      o.netProfit ?? 0,
      o.erpStatus || o.orderStatus,
    ]);
  } else if (reportType === 'inventory') {
    headers = ['SKU', 'Name', 'OwnedStock', 'SupplierStock', 'Reserved', 'Incoming', 'PurchasePrice', 'RetailPrice', 'WholesalePrice', 'DealerPrice'];
    rows = products.map((p) => [
      p.sku,
      p.name,
      p.ownedStock ?? p.stock,
      p.supplierStock ?? 0,
      p.reservedStock ?? 0,
      p.incomingStock ?? 0,
      p.purchasePrice ?? 0,
      p.price,
      p.wholesalePrice ?? 0,
      p.dealerPrice ?? 0,
    ]);
  } else if (reportType === 'suppliers') {
    headers = ['SupplierID', 'Company', 'Type', 'Integration', 'MOQ', 'LeadTimeDays', 'PerformanceScore', 'PrivateLabel'];
    rows = suppliers.map((s) => [
      s.id,
      s.companyName,
      s.supplierType,
      s.integrationType,
      s.moq,
      s.leadTimeDays,
      s.performanceScore,
      s.privateLabelCapable ? 'Yes' : 'No',
    ]);
  } else {
    headers = ['OrderID', 'OrderSource', 'SalesChannel', 'Total', 'PaymentStatus', 'OrderStatus'];
    rows = orders.map((o) => [
      o.id,
      o.orderSource || 'Online Store',
      o.salesChannel || 'D2C_ONLINE',
      o.total,
      o.paymentStatus,
      o.orderStatus,
    ]);
  }

  const csv = [headers.map(escape).join(','), ...rows.map((r) => r.map(escape).join(','))].join('\n');
  res.json({ filename: `lumiere_erp_${reportType}_${Date.now()}.csv`, csv, rowCount: rows.length });
});

// ============================================================================
// ERP: GEMINI AI CEO & 12-AGENT EXECUTIVE ASSISTANT (WITH HUMAN APPROVAL TASKS)
// ============================================================================
app.post('/api/ai/ceo', async (req, res) => {
  try {
    const { agentRole = 'AI CEO Supervisor', question, metricsSnapshot } = req.body as {
      agentRole?: string;
      question?: string;
      metricsSnapshot?: Record<string, unknown>;
    };

    if (!question || typeof question !== 'string' || !question.trim()) {
      res.status(400).json({ error: 'Please provide an executive prompt or question.' });
      return;
    }

    const ai = getGeminiClient();
    const prompt = `You are acting in the role of "${agentRole}" inside LUMIÈRE ATELIER's Unified Commerce, Wholesale, Dropshipping, Private-Label & ERP Platform.
Authorized Live Business Snapshot (ground your advice ONLY in these exact figures and records):
${JSON.stringify(metricsSnapshot || {}, null, 2)}

Executive Request:
${question.trim()}

SAFETY & GOVERNANCE POLICY:
- You are STRICTLY READ-ONLY & ADVISORY. Never claim you executed a refund, payment, price change, or PO dispatch.
- Cite concrete numbers from the authorized snapshot when available.
- Provide actionable priorities, risk flags, a ready-to-copy draft message, AND 2 to 3 structured suggestedTasks that require human approval before execution.`;

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      config: {
        systemInstruction:
          'You are a pragmatic, financially disciplined AI ERP Executive Advisor for a luxury cosmetics D2C + B2B Wholesale + Dropshipping enterprise. Output crisp JSON only.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            agentRole: { type: Type.STRING },
            summary: { type: Type.STRING },
            priorities: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            riskAlerts: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            draftMessage: { type: Type.STRING },
            suggestedTasks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                  category: {
                    type: Type.STRING,
                    enum: ['inventory', 'pricing', 'marketing', 'fraud', 'supplier', 'finance', 'strategy'],
                  },
                  impactSummary: { type: Type.STRING },
                  requiresApproval: { type: Type.BOOLEAN },
                },
                required: ['title', 'description', 'category', 'impactSummary', 'requiresApproval'],
              },
            },
            advisoryDisclaimer: { type: Type.STRING },
          },
          required: ['agentRole', 'summary', 'priorities', 'riskAlerts', 'draftMessage', 'suggestedTasks', 'advisoryDisclaimer'],
        },
      },
    });

    const rawText = (response.text ?? '{}').trim();
    res.json(JSON.parse(rawText));
  } catch (err) {
    const message = err instanceof Error ? err.message : 'AI CEO executive analysis failed.';
    res.status(500).json({ error: message });
  }
});

// ============================================================================
// NEXT-GEN AI: IMAGE-BASED VISUAL PRODUCT SEARCH
// ============================================================================
app.post('/api/ai/visual-search', async (req, res) => {
  try {
    const { imageDataUrl, catalogSummary = [], note = '' } = req.body as {
      imageDataUrl?: string;
      catalogSummary?: Array<{ id: string; name: string; category: string; finish: string; shades: string[]; price: number }>;
      note?: string;
    };

    if (!imageDataUrl || typeof imageDataUrl !== 'string' || !imageDataUrl.startsWith('data:image/')) {
      res.status(400).json({ error: 'Please upload a valid image (PNG, JPG, or WEBP).' });
      return;
    }

    const match = imageDataUrl.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
    if (!match) {
      res.status(400).json({ error: 'Malformed base64 image payload.' });
      return;
    }
    const [, mimeType, base64Data] = match;

    const ai = getGeminiClient();
    const prompt = `Analyze this beauty / makeup / color inspiration photo and match it to the best products in our LUMIÈRE ATELIER catalog below.
User hint: ${note || 'Match cosmetics, pigment tones, and finishes visible in the photo.'}
Catalog:
${JSON.stringify(catalogSummary.slice(0, 40))}

Return JSON with detectedDominantHex (e.g. "#9E1B32"), styleSummary, recommendedProductIds (up to 4 exact IDs from the catalog), and shadeAdvice.`;

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: [
        {
          role: 'user',
          parts: [
            { inlineData: { mimeType, data: base64Data } },
            { text: prompt },
          ],
        },
      ],
      config: {
        systemInstruction:
          'You are an editorial luxury beauty visual search engine. Always match strictly to provided product IDs and return valid JSON.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            detectedDominantHex: { type: Type.STRING },
            styleSummary: { type: Type.STRING },
            shadeAdvice: { type: Type.STRING },
            recommendedProductIds: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
          },
          required: ['detectedDominantHex', 'styleSummary', 'shadeAdvice', 'recommendedProductIds'],
        },
      },
    });

    const parsed = JSON.parse((response.text ?? '{}').trim());
    res.json(parsed);
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Visual search failed.' });
  }
});

// ============================================================================
// NEXT-GEN AI: MULTILINGUAL SHOPPING CONCIERGE & SUPPORT CHATBOT
// ============================================================================
app.post('/api/ai/chat', async (req, res) => {
  try {
    const {
      message,
      history = [],
      language = 'en',
      currency = 'USD',
      countryName = 'United States',
      catalogSummary = [],
      userOrdersSummary = [],
    } = req.body as {
      message?: string;
      history?: Array<{ role: 'user' | 'assistant'; text: string }>;
      language?: string;
      currency?: string;
      countryName?: string;
      catalogSummary?: Array<{ id: string; name: string; category: string; price: number; shades: string[]; stock: number }>;
      userOrdersSummary?: Array<{ id: string; status: string; total: number; trackingNumber?: string }>;
    };

    if (!message || typeof message !== 'string' || !message.trim()) {
      res.status(400).json({ error: 'Message cannot be empty.' });
      return;
    }

    const ai = getGeminiClient();
    const recentHistory = Array.isArray(history)
      ? history.slice(-6).map((h) => `${h.role === 'user' ? 'Customer' : 'Concierge'}: ${h.text}`).join('\n')
      : '';

    const prompt = `You are LUMIÈRE ATELIER's Multilingual Luxury Beauty Concierge & Customer Support Specialist.
Respond warmly, concisely, and accurately in language code "${language}".
Active Shopping Context: Country=${countryName}, Currency=${currency}.
Policies: 30-day unopened return policy, live server-locked FX checkout, B2B Wholesale portal available for salons/dealers, Subscribe & Save 12% every 30/60/90 days, digital gift cards redeemable at checkout.
Live Catalog (use ONLY real IDs from this list when recommending products):
${JSON.stringify(catalogSummary.slice(0, 35))}
Customer's Recent Orders:
${JSON.stringify(userOrdersSummary.slice(0, 8))}
Recent Conversation:
${recentHistory}
Customer Message:
${message.trim()}

Return JSON with reply, recommendedProductIds (0 to 3 exact IDs from catalog), suggestedQuickReplies (2 to 3 short follow-up prompts), and shouldEscalateToTicket (boolean).`;

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      config: {
        systemInstruction:
          'You are a refined, truthful luxury beauty shopping assistant. Never fabricate order statuses, prices, or policies. Output JSON only.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            reply: { type: Type.STRING },
            recommendedProductIds: { type: Type.ARRAY, items: { type: Type.STRING } },
            suggestedQuickReplies: { type: Type.ARRAY, items: { type: Type.STRING } },
            shouldEscalateToTicket: { type: Type.BOOLEAN },
          },
          required: ['reply', 'recommendedProductIds', 'suggestedQuickReplies', 'shouldEscalateToTicket'],
        },
      },
    });

    res.json(JSON.parse((response.text ?? '{}').trim()));
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'AI concierge unavailable.' });
  }
});

// ============================================================================
// NEXT-GEN AI: PRODUCT DESCRIPTION, SEO & ADVERTISING COPY STUDIO
// ============================================================================
app.post('/api/ai/marketing-copy', async (req, res) => {
  try {
    const {
      productName,
      category,
      finish,
      price,
      ingredients,
      shades = [],
      tone = 'Ultra-Luxury Editorial',
      targetAudience = 'Global D2C & Luxury Salons',
    } = req.body as {
      productName?: string;
      category?: string;
      finish?: string;
      price?: number;
      ingredients?: string;
      shades?: string[];
      tone?: string;
      targetAudience?: string;
    };

    if (!productName) {
      res.status(400).json({ error: 'Product name is required.' });
      return;
    }

    const ai = getGeminiClient();
    const prompt = `Generate complete high-converting luxury cosmetics copy & SEO metadata for LUMIÈRE ATELIER.
Product: ${productName}
Category: ${category || 'Luxury Cosmetics'}
Finish: ${finish || 'Velvet Matte'}
Base Price (USD): $${price ?? 48}
Shades: ${shades.join(', ') || 'Signature Atelier Shades'}
Key Ingredients: ${ingredients || 'Botanical pigments, squalane, hyaluronic spheres'}
Tone: ${tone}
Target Audience: ${targetAudience}

Return JSON with seoTitle (<=60 chars), seoDescription (<=155 chars), productDescription (2 crisp paragraphs), metaAdHeadline, metaAdBody, emailSubject, emailBody, and whatsappPromo.`;

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      config: {
        systemInstruction: 'You are a luxury beauty chief copywriter and performance marketing strategist. Output strict JSON.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            seoTitle: { type: Type.STRING },
            seoDescription: { type: Type.STRING },
            productDescription: { type: Type.STRING },
            metaAdHeadline: { type: Type.STRING },
            metaAdBody: { type: Type.STRING },
            emailSubject: { type: Type.STRING },
            emailBody: { type: Type.STRING },
            whatsappPromo: { type: Type.STRING },
          },
          required: [
            'seoTitle',
            'seoDescription',
            'productDescription',
            'metaAdHeadline',
            'metaAdBody',
            'emailSubject',
            'emailBody',
            'whatsappPromo',
          ],
        },
      },
    });

    res.json(JSON.parse((response.text ?? '{}').trim()));
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Marketing copy generation failed.' });
  }
});

// ============================================================================
// WHOLESALE B2B: SERVER-VALIDATED BULK CSV PARSER
// ============================================================================
app.post('/api/wholesale/parse-bulk-csv', (req, res) => {
  try {
    const { csvText = '', tier = 'wholesale', catalog = [] } = req.body as {
      csvText?: string;
      tier?: 'wholesale' | 'dealer' | 'distributor' | 'enterprise';
      catalog?: Array<{
        id: string;
        sku: string;
        name: string;
        price: number;
        wholesalePrice?: number;
        dealerPrice?: number;
        distributorPrice?: number;
        moq?: number;
      }>;
    };

    const lines = String(csvText)
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean);

    const matched: Array<{
      productId: string;
      sku: string;
      name: string;
      quantity: number;
      moq: number;
      unitPrice: number;
      lineTotal: number;
      moqValid: boolean;
    }> = [];
    const errors: string[] = [];

    for (let i = 0; i < lines.length; i++) {
      const cols = lines[i].split(/[,\t;]/).map((c) => c.trim().replace(/^"|"$/g, ''));
      if (cols.length < 2) continue;
      if (i === 0 && cols[0].toLowerCase() === 'sku') continue;
      const sku = cols[0];
      const qty = Math.round(Number(cols[1]));
      const prod = catalog.find((p) => p.sku.toLowerCase() === sku.toLowerCase());
      if (!prod) {
        errors.push(`Line ${i + 1}: SKU "${sku}" not found in catalog.`);
        continue;
      }
      if (!Number.isFinite(qty) || qty <= 0) {
        errors.push(`Line ${i + 1}: Invalid quantity "${cols[1]}" for ${sku}.`);
        continue;
      }
      const moq = prod.moq ?? 10;
      const unitPrice =
        tier === 'distributor' || tier === 'enterprise'
          ? (prod.distributorPrice ?? Number((prod.price * 0.56).toFixed(2)))
          : tier === 'dealer'
            ? (prod.dealerPrice ?? Number((prod.price * 0.64).toFixed(2)))
            : (prod.wholesalePrice ?? Number((prod.price * 0.72).toFixed(2)));
      matched.push({
        productId: prod.id,
        sku: prod.sku,
        name: prod.name,
        quantity: qty,
        moq,
        unitPrice,
        lineTotal: Number((unitPrice * qty).toFixed(2)),
        moqValid: qty >= moq,
      });
    }

    const totalUnits = matched.reduce((s, m) => s + m.quantity, 0);
    const totalUsd = Number(matched.reduce((s, m) => s + m.lineTotal, 0).toFixed(2));
    res.json({
      tier,
      matchedCount: matched.length,
      totalUnits,
      totalUsd,
      matched,
      errors,
    });
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Bulk CSV parsing failed.' });
  }
});

// ============================================================================
// SECURITY: REAL-TIME ORDER FRAUD RISK SCORING ENGINE
// ============================================================================
app.post('/api/orders/evaluate-fraud', (req, res) => {
  const {
    totalUsd = 0,
    itemCount = 1,
    paymentGateway = 'Stripe',
    countryCode = 'US',
    shippingCountry = '',
    recentOrderCount = 0,
    highValueThresholdUsd = 500,
    autoHoldScore = 60,
  } = req.body as {
    totalUsd?: number;
    itemCount?: number;
    paymentGateway?: string;
    countryCode?: string;
    shippingCountry?: string;
    recentOrderCount?: number;
    highValueThresholdUsd?: number;
    autoHoldScore?: number;
  };

  let score = 8;
  const flags: string[] = [];

  if (totalUsd >= highValueThresholdUsd) {
    score += 32;
    flags.push(`High order value ($${Number(totalUsd).toFixed(2)} >= $${highValueThresholdUsd} threshold)`);
  } else if (totalUsd >= highValueThresholdUsd * 0.6) {
    score += 14;
  }

  if (paymentGateway === 'COD' && totalUsd > 180) {
    score += 28;
    flags.push('High-value Cash on Delivery order (elevated RTO exposure)');
  }

  if (itemCount >= 12) {
    score += 18;
    flags.push(`Unusually high retail basket quantity (${itemCount} units)`);
  }

  if (recentOrderCount >= 4) {
    score += 22;
    flags.push(`Elevated checkout velocity (${recentOrderCount} recent orders)`);
  }

  if (shippingCountry && countryCode && countryCode === 'US' && !shippingCountry.toLowerCase().includes('united') && !shippingCountry.toLowerCase().includes('us')) {
    score += 15;
    flags.push(`Cross-border billing/shipping mismatch (${countryCode} vs ${shippingCountry})`);
  }

  const finalScore = Math.min(100, Math.max(0, Math.round(score)));
  const level: 'low' | 'medium' | 'high' = finalScore >= autoHoldScore ? 'high' : finalScore >= 35 ? 'medium' : 'low';

  res.json({
    score: finalScore,
    level,
    requiresManualReview: finalScore >= autoHoldScore,
    flags: flags.length > 0 ? flags : ['Passed automated velocity, value & geo checks'],
    evaluatedAt: new Date().toISOString(),
  });
});

// ============================================================================
// LOGISTICS: MULTI-CARRIER SHIPPING RATE & TRANSIT COMPARATOR
// ============================================================================
app.post('/api/logistics/compare-rates', (req, res) => {
  const { destinationCountry = 'IN', weightGrams = 350, orderValueUsd = 85 } = req.body as {
    destinationCountry?: string;
    weightGrams?: number;
    orderValueUsd?: number;
  };

  const kg = Math.max(0.25, Number(weightGrams) / 1000);
  const domestic = destinationCountry.toUpperCase() === 'IN';
  const insurance = Number((Math.max(0, Number(orderValueUsd)) * 0.008).toFixed(2));

  const quotes = domestic
    ? [
        {
          carrier: 'Shiprocket Surface Priority',
          service: 'Domestic Express',
          costUsd: Number((3.4 + kg * 1.15 + insurance).toFixed(2)),
          etaDays: '2-3 business days',
          codSupported: true,
          rtoProtection: '97.4% delivery rate',
          recommended: true,
        },
        {
          carrier: 'BlueDart Air',
          service: 'Next-Day Metro Air',
          costUsd: Number((5.2 + kg * 1.8 + insurance).toFixed(2)),
          etaDays: '1-2 business days',
          codSupported: true,
          rtoProtection: '98.8% delivery rate',
          recommended: false,
        },
        {
          carrier: 'Delhivery Standard',
          service: 'Economy Pan-India',
          costUsd: Number((2.8 + kg * 0.95).toFixed(2)),
          etaDays: '3-5 business days',
          codSupported: true,
          rtoProtection: '94.9% delivery rate',
          recommended: false,
        },
      ]
    : [
        {
          carrier: 'DHL Express Worldwide (DDP)',
          service: 'Duties-Paid Air Express',
          costUsd: Number((14.5 + kg * 6.8 + insurance).toFixed(2)),
          etaDays: '2-4 business days',
          codSupported: false,
          rtoProtection: '99.2% customs clearance',
          recommended: true,
        },
        {
          carrier: 'FedEx International Priority',
          service: 'Commercial Air',
          costUsd: Number((16.2 + kg * 7.2 + insurance).toFixed(2)),
          etaDays: '2-3 business days',
          codSupported: false,
          rtoProtection: '99.0% customs clearance',
          recommended: false,
        },
        {
          carrier: 'Aramex Global Shopper',
          service: 'Cross-Border Economy',
          costUsd: Number((10.8 + kg * 4.9).toFixed(2)),
          etaDays: '5-8 business days',
          codSupported: destinationCountry.toUpperCase() === 'AE' || destinationCountry.toUpperCase() === 'SA',
          rtoProtection: '95.6% delivery rate',
          recommended: false,
        },
      ];

  res.json({
    destinationCountry: destinationCountry.toUpperCase(),
    weightGrams: Number(weightGrams),
    quotes,
    generatedAt: new Date().toISOString(),
  });
});

// ============================================================================
// DEVELOPER & INTEGRATIONS: SIGNED WEBHOOK TEST DISPATCHER
// ============================================================================
app.post('/api/integrations/test-webhook', async (req, res) => {
  const { url, eventType = 'order.created', payload = {} } = req.body as {
    url?: string;
    eventType?: string;
    payload?: Record<string, unknown>;
  };

  if (!url || typeof url !== 'string') {
    res.status(400).json({ error: 'Webhook destination URL is required.' });
    return;
  }

  let parsedUrl: URL;
  try {
    parsedUrl = new URL(url.trim());
  } catch {
    res.status(400).json({ error: 'Invalid URL format.' });
    return;
  }

  const host = parsedUrl.hostname.toLowerCase();
  if (
    parsedUrl.protocol !== 'https:' ||
    host === 'localhost' ||
    host.startsWith('127.') ||
    host.startsWith('10.') ||
    host.startsWith('192.168.') ||
    host.startsWith('169.254.') ||
    host === '0.0.0.0' ||
    host.endsWith('.internal')
  ) {
    res.status(400).json({ error: 'Webhook URL must be a public HTTPS endpoint (private/local hosts blocked).' });
    return;
  }

  const envelope = {
    id: `evt_${crypto.randomBytes(6).toString('hex')}`,
    event: eventType,
    source: 'LUMIERE_ATELIER_ERP',
    timestamp: new Date().toISOString(),
    data: payload,
  };
  const bodyStr = JSON.stringify(envelope);
  const signature = crypto
    .createHmac('sha256', process.env.WEBHOOK_SIGNING_SECRET || 'lumiere_erp_webhook_hmac_v1')
    .update(bodyStr)
    .digest('hex');

  const startedAt = Date.now();
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 7000);
    const hookRes = await fetch(parsedUrl.toString(), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Lumiere-Event': eventType,
        'X-Lumiere-Signature': `sha256=${signature}`,
      },
      body: bodyStr,
      signal: controller.signal,
    });
    clearTimeout(timeout);
    res.json({
      delivered: hookRes.ok,
      httpStatus: hookRes.status,
      latencyMs: Date.now() - startedAt,
      eventId: envelope.id,
      signaturePreview: `sha256=${signature.slice(0, 18)}…`,
      testedAt: new Date().toISOString(),
    });
  } catch (err) {
    res.status(502).json({
      delivered: false,
      httpStatus: 0,
      latencyMs: Date.now() - startedAt,
      eventId: envelope.id,
      error: err instanceof Error ? err.message : 'Remote webhook endpoint unreachable.',
    });
  }
});

// ============================================================================
// SYSTEM HEALTH & RUNTIME TELEMETRY (ADMIN DEVELOPER CENTER)
// ============================================================================
app.get('/api/system/health', (_req, res) => {
  const mem = process.memoryUsage();
  res.json({
    status: 'healthy',
    uptimeSeconds: Math.round(process.uptime()),
    nodeVersion: process.version,
    memoryMb: {
      rss: Math.round(mem.rss / 1024 / 1024),
      heapUsed: Math.round(mem.heapUsed / 1024 / 1024),
      heapTotal: Math.round(mem.heapTotal / 1024 / 1024),
    },
    providers: {
      geminiAi: Boolean(process.env.GEMINI_API_KEY),
      liveFxRates: Boolean(fxCache && fxCache.source === 'live'),
      razorpayLive: Boolean(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET),
      stripeLive: Boolean(process.env.STRIPE_SECRET_KEY),
      paypalLive: Boolean(process.env.PAYPAL_CLIENT_ID && process.env.PAYPAL_CLIENT_SECRET),
    },
    rateLimitStats: {
      activeBuckets: rateMap.size,
      maxRequestsPerMinute: 180,
    },
    timestamp: new Date().toISOString(),
  });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`LUMIÈRE ATELIER server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
