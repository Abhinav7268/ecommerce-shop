/**
 * Centralized Chromatic Design System Palette & Module Color Identities
 * Harmonizes Electric Blue, Neon Cyan, Royal Purple, Deep Violet, Magenta,
 * Hot Pink, Vibrant Orange, Golden Yellow, Emerald Green, Aqua, Coral,
 * Premium Black, and Pure White across Light & Dark Themes.
 */

export type KpiTone =
  | 'revenue'
  | 'profit'
  | 'orders'
  | 'products'
  | 'suppliers'
  | 'inventory'
  | 'payments'
  | 'analytics'
  | 'notifications'
  | 'wholesale';

export interface KpiColorTheme {
  label: string;
  cardBg: string;
  border: string;
  topBar: string;
  valueText: string;
  subText: string;
  iconBg: string;
  progressTone: 'brand' | 'emerald' | 'amber' | 'rose' | 'cyan' | 'violet' | 'orange';
}

export const KPI_COLOR_THEMES: Record<KpiTone, KpiColorTheme> = {
  revenue: {
    label: 'Revenue',
    cardBg:
      'bg-gradient-to-br from-blue-50 via-cyan-50/70 to-white dark:from-[#0C1933] dark:via-[#0E162B] dark:to-[#0D1120]',
    border: 'border-[#2563EB]/25 dark:border-[#22D3EE]/30',
    topBar: 'bg-gradient-to-r from-[#2563EB] via-[#06B6D4] to-[#22D3EE]',
    valueText: 'text-[#1D4ED8] dark:text-[#38BDF8]',
    subText: 'text-[#2563EB]/85 dark:text-[#67E8F9]',
    iconBg: 'bg-gradient-to-br from-[#2563EB] to-[#06B6D4] text-white',
    progressTone: 'cyan',
  },
  profit: {
    label: 'Net Profit',
    cardBg:
      'bg-gradient-to-br from-emerald-50 via-teal-50/70 to-white dark:from-[#08241E] dark:via-[#0B1E24] dark:to-[#0D1120]',
    border: 'border-[#10B981]/25 dark:border-[#2DD4BF]/30',
    topBar: 'bg-gradient-to-r from-[#10B981] via-[#14B8A6] to-[#2DD4BF]',
    valueText: 'text-[#047857] dark:text-[#34D399]',
    subText: 'text-[#0D9488] dark:text-[#5EEAD4]',
    iconBg: 'bg-gradient-to-br from-[#10B981] to-[#14B8A6] text-white',
    progressTone: 'emerald',
  },
  orders: {
    label: 'Orders',
    cardBg:
      'bg-gradient-to-br from-violet-50 via-purple-50/70 to-white dark:from-[#1B1136] dark:via-[#15122B] dark:to-[#0D1120]',
    border: 'border-[#7C3AED]/25 dark:border-[#A78BFA]/30',
    topBar: 'bg-gradient-to-r from-[#5B21B6] via-[#7C3AED] to-[#D946EF]',
    valueText: 'text-[#6D28D9] dark:text-[#C4B5FD]',
    subText: 'text-[#7C3AED]/85 dark:text-[#DDD6FE]',
    iconBg: 'bg-gradient-to-br from-[#5B21B6] to-[#7C3AED] text-white',
    progressTone: 'violet',
  },
  products: {
    label: 'Products',
    cardBg:
      'bg-gradient-to-br from-fuchsia-50 via-pink-50/70 to-white dark:from-[#2A1030] dark:via-[#211028] dark:to-[#0D1120]',
    border: 'border-[#D946EF]/25 dark:border-[#F472B6]/30',
    topBar: 'bg-gradient-to-r from-[#D946EF] via-[#EC4899] to-[#FB7185]',
    valueText: 'text-[#A21CAF] dark:text-[#F472B6]',
    subText: 'text-[#BE185D] dark:text-[#F9A8D4]',
    iconBg: 'bg-gradient-to-br from-[#D946EF] to-[#EC4899] text-white',
    progressTone: 'rose',
  },
  suppliers: {
    label: 'Suppliers',
    cardBg:
      'bg-gradient-to-br from-teal-50 via-sky-50/70 to-white dark:from-[#092329] dark:via-[#0D1B2A] dark:to-[#0D1120]',
    border: 'border-[#14B8A6]/25 dark:border-[#2DD4BF]/30',
    topBar: 'bg-gradient-to-r from-[#14B8A6] via-[#06B6D4] to-[#2563EB]',
    valueText: 'text-[#0F766E] dark:text-[#2DD4BF]',
    subText: 'text-[#0284C7] dark:text-[#67E8F9]',
    iconBg: 'bg-gradient-to-br from-[#14B8A6] to-[#2563EB] text-white',
    progressTone: 'cyan',
  },
  inventory: {
    label: 'Inventory',
    cardBg:
      'bg-gradient-to-br from-amber-50 via-orange-50/70 to-white dark:from-[#2B1B09] dark:via-[#23150E] dark:to-[#0D1120]',
    border: 'border-[#F59E0B]/30 dark:border-[#FBBF24]/30',
    topBar: 'bg-gradient-to-r from-[#F59E0B] via-[#F97316] to-[#FB7185]',
    valueText: 'text-[#B45309] dark:text-[#FBBF24]',
    subText: 'text-[#C2410C] dark:text-[#FDBA74]',
    iconBg: 'bg-gradient-to-br from-[#F59E0B] to-[#F97316] text-white',
    progressTone: 'amber',
  },
  payments: {
    label: 'Payments',
    cardBg:
      'bg-gradient-to-br from-cyan-50 via-blue-50/70 to-white dark:from-[#082230] dark:via-[#0E1930] dark:to-[#0D1120]',
    border: 'border-[#06B6D4]/25 dark:border-[#22D3EE]/30',
    topBar: 'bg-gradient-to-r from-[#06B6D4] via-[#2563EB] to-[#7C3AED]',
    valueText: 'text-[#0E7490] dark:text-[#22D3EE]',
    subText: 'text-[#1D4ED8] dark:text-[#93C5FD]',
    iconBg: 'bg-gradient-to-br from-[#06B6D4] to-[#2563EB] text-white',
    progressTone: 'brand',
  },
  analytics: {
    label: 'Analytics',
    cardBg:
      'bg-gradient-to-br from-indigo-50 via-fuchsia-50/60 to-white dark:from-[#161336] dark:via-[#1F1233] dark:to-[#0D1120]',
    border: 'border-[#6D28D9]/25 dark:border-[#D946EF]/30',
    topBar: 'bg-gradient-to-r from-[#2563EB] via-[#7C3AED] to-[#EC4899]',
    valueText: 'text-[#4338CA] dark:text-[#E879F9]',
    subText: 'text-[#7C3AED] dark:text-[#C4B5FD]',
    iconBg: 'bg-gradient-to-br from-[#2563EB] via-[#7C3AED] to-[#D946EF] text-white',
    progressTone: 'brand',
  },
  notifications: {
    label: 'Notifications',
    cardBg:
      'bg-gradient-to-br from-rose-50 via-orange-50/70 to-white dark:from-[#2C0F1D] dark:via-[#26121A] dark:to-[#0D1120]',
    border: 'border-[#F43F5E]/25 dark:border-[#FB7185]/30',
    topBar: 'bg-gradient-to-r from-[#F43F5E] via-[#EC4899] to-[#F97316]',
    valueText: 'text-[#BE123C] dark:text-[#FB7185]',
    subText: 'text-[#EA580C] dark:text-[#FDBA74]',
    iconBg: 'bg-gradient-to-br from-[#F43F5E] to-[#F97316] text-white',
    progressTone: 'orange',
  },
  wholesale: {
    label: 'Wholesale & B2B',
    cardBg:
      'bg-gradient-to-br from-orange-50 via-amber-50/70 to-white dark:from-[#2A1508] dark:via-[#21150B] dark:to-[#0D1120]',
    border: 'border-[#F97316]/25 dark:border-[#FB923C]/30',
    topBar: 'bg-gradient-to-r from-[#F97316] via-[#F59E0B] to-[#EC4899]',
    valueText: 'text-[#C2410C] dark:text-[#FB923C]',
    subText: 'text-[#B45309] dark:text-[#FDE047]',
    iconBg: 'bg-gradient-to-br from-[#F97316] to-[#F59E0B] text-white',
    progressTone: 'orange',
  },
};

export interface CategoryStyle {
  backdrop: string;
  cardSurface: string;
  cardBorder: string;
  tileGradient: string;
  accentText: string;
  activeBtn: string;
  glowRing: string;
  labelGradient: string;
}

const CATEGORY_STYLE_PALETTE: CategoryStyle[] = [
  {
    backdrop: 'from-pink-200 via-rose-100 to-fuchsia-200 dark:from-[#3D123B] dark:via-[#291036] dark:to-[#1E1032]',
    cardSurface: 'bg-gradient-to-br from-pink-50 via-white to-fuchsia-100/80 dark:from-[#260E2B] dark:via-[#140F26] dark:to-[#2A0E24]',
    cardBorder: 'border-[#EC4899]/40 dark:border-[#F472B6]/45',
    tileGradient: 'from-[#EC4899] via-[#D946EF] to-[#7C3AED]',
    accentText: 'text-[#DB2777] dark:text-[#F472B6]',
    activeBtn: 'bg-gradient-to-r from-[#EC4899] via-[#D946EF] to-[#7C3AED] text-white border-transparent shadow-md',
    glowRing: 'hover:border-[#EC4899]/75 dark:hover:border-[#F472B6]/75',
    labelGradient: 'from-[#EC4899] via-[#D946EF] to-[#F43F5E]',
  },
  {
    backdrop: 'from-amber-200 via-orange-100 to-yellow-200 dark:from-[#3B200B] dark:via-[#2B170F] dark:to-[#22121A]',
    cardSurface: 'bg-gradient-to-br from-amber-50 via-white to-orange-100/85 dark:from-[#291709] dark:via-[#181122] dark:to-[#2B1316]',
    cardBorder: 'border-[#F97316]/40 dark:border-[#FBBF24]/45',
    tileGradient: 'from-[#F97316] via-[#F59E0B] to-[#F43F5E]',
    accentText: 'text-[#D97706] dark:text-[#FBBF24]',
    activeBtn: 'bg-gradient-to-r from-[#F97316] via-[#F59E0B] to-[#FB7185] text-white border-transparent shadow-md',
    glowRing: 'hover:border-[#F97316]/75 dark:hover:border-[#FBBF24]/75',
    labelGradient: 'from-[#F97316] via-[#F59E0B] to-[#EC4899]',
  },
  {
    backdrop: 'from-violet-200 via-purple-100 to-indigo-200 dark:from-[#25134D] dark:via-[#1B133D] dark:to-[#121638]',
    cardSurface: 'bg-gradient-to-br from-violet-50 via-white to-indigo-100/85 dark:from-[#1C103A] dark:via-[#11132B] dark:to-[#12193B]',
    cardBorder: 'border-[#7C3AED]/40 dark:border-[#A78BFA]/45',
    tileGradient: 'from-[#5B21B6] via-[#7C3AED] to-[#2563EB]',
    accentText: 'text-[#6D28D9] dark:text-[#C4B5FD]',
    activeBtn: 'bg-gradient-to-r from-[#5B21B6] via-[#7C3AED] to-[#2563EB] text-white border-transparent shadow-md',
    glowRing: 'hover:border-[#7C3AED]/75 dark:hover:border-[#A78BFA]/75',
    labelGradient: 'from-[#7C3AED] via-[#5B21B6] to-[#2563EB]',
  },
  {
    backdrop: 'from-cyan-200 via-sky-100 to-blue-200 dark:from-[#0A2D45] dark:via-[#0D213B] dark:to-[#111838]',
    cardSurface: 'bg-gradient-to-br from-cyan-50 via-white to-blue-100/85 dark:from-[#0A2036] dark:via-[#0E152B] dark:to-[#121B3A]',
    cardBorder: 'border-[#06B6D4]/45 dark:border-[#22D3EE]/45',
    tileGradient: 'from-[#2563EB] via-[#06B6D4] to-[#14B8A6]',
    accentText: 'text-[#0284C7] dark:text-[#38BDF8]',
    activeBtn: 'bg-gradient-to-r from-[#2563EB] via-[#06B6D4] to-[#14B8A6] text-white border-transparent shadow-md',
    glowRing: 'hover:border-[#06B6D4]/75 dark:hover:border-[#22D3EE]/75',
    labelGradient: 'from-[#2563EB] via-[#06B6D4] to-[#22D3EE]',
  },
  {
    backdrop: 'from-emerald-200 via-teal-100 to-cyan-200 dark:from-[#09332D] dark:via-[#0C2630] dark:to-[#0F1B33]',
    cardSurface: 'bg-gradient-to-br from-emerald-50 via-white to-teal-100/85 dark:from-[#082620] dark:via-[#0C1826] dark:to-[#0A2130]',
    cardBorder: 'border-[#10B981]/45 dark:border-[#34D399]/45',
    tileGradient: 'from-[#10B981] via-[#14B8A6] to-[#06B6D4]',
    accentText: 'text-[#059669] dark:text-[#34D399]',
    activeBtn: 'bg-gradient-to-r from-[#10B981] via-[#14B8A6] to-[#06B6D4] text-white border-transparent shadow-md',
    glowRing: 'hover:border-[#10B981]/75 dark:hover:border-[#34D399]/75',
    labelGradient: 'from-[#10B981] via-[#14B8A6] to-[#06B6D4]',
  },
  {
    backdrop: 'from-rose-200 via-pink-100 to-orange-200 dark:from-[#3D1226] dark:via-[#2E1324] dark:to-[#22112B]',
    cardSurface: 'bg-gradient-to-br from-rose-50 via-white to-orange-100/80 dark:from-[#2B0E1D] dark:via-[#171024] dark:to-[#29121E]',
    cardBorder: 'border-[#F43F5E]/40 dark:border-[#FB7185]/45',
    tileGradient: 'from-[#F43F5E] via-[#EC4899] to-[#F97316]',
    accentText: 'text-[#E11D48] dark:text-[#FB7185]',
    activeBtn: 'bg-gradient-to-r from-[#F43F5E] via-[#EC4899] to-[#F97316] text-white border-transparent shadow-md',
    glowRing: 'hover:border-[#F43F5E]/75 dark:hover:border-[#FB7185]/75',
    labelGradient: 'from-[#F43F5E] via-[#EC4899] to-[#F97316]',
  },
  {
    backdrop: 'from-fuchsia-200 via-violet-100 to-cyan-200 dark:from-[#341347] dark:via-[#22143E] dark:to-[#0F1F3A]',
    cardSurface: 'bg-gradient-to-br from-fuchsia-50 via-white to-cyan-100/80 dark:from-[#250F38] dark:via-[#15112B] dark:to-[#0E1E36]',
    cardBorder: 'border-[#D946EF]/40 dark:border-[#E879F9]/45',
    tileGradient: 'from-[#D946EF] via-[#7C3AED] to-[#06B6D4]',
    accentText: 'text-[#A21CAF] dark:text-[#E879F9]',
    activeBtn: 'bg-gradient-to-r from-[#D946EF] via-[#7C3AED] to-[#06B6D4] text-white border-transparent shadow-md',
    glowRing: 'hover:border-[#D946EF]/75 dark:hover:border-[#E879F9]/75',
    labelGradient: 'from-[#D946EF] via-[#7C3AED] to-[#22D3EE]',
  },
  {
    backdrop: 'from-yellow-200 via-amber-100 to-rose-200 dark:from-[#3B260A] dark:via-[#2F1A12] dark:to-[#291124]',
    cardSurface: 'bg-gradient-to-br from-yellow-50 via-white to-pink-100/85 dark:from-[#291B09] dark:via-[#1C1222] dark:to-[#2A0E20]',
    cardBorder: 'border-[#F59E0B]/45 dark:border-[#FDE047]/45',
    tileGradient: 'from-[#F59E0B] via-[#F97316] to-[#EC4899]',
    accentText: 'text-[#CA8A04] dark:text-[#FDE047]',
    activeBtn: 'bg-gradient-to-r from-[#F59E0B] via-[#F97316] to-[#EC4899] text-white border-transparent shadow-md',
    glowRing: 'hover:border-[#F59E0B]/75 dark:hover:border-[#FDE047]/75',
    labelGradient: 'from-[#F59E0B] via-[#F97316] to-[#EC4899]',
  },
];

export function getCategoryStyle(categoryName: string, index?: number): CategoryStyle {
  if (typeof index === 'number') {
    return CATEGORY_STYLE_PALETTE[Math.abs(index) % CATEGORY_STYLE_PALETTE.length];
  }
  const key = categoryName.toLowerCase();
  if (key.includes('lip')) return CATEGORY_STYLE_PALETTE[0];
  if (key.includes('face') || key.includes('foundation')) return CATEGORY_STYLE_PALETTE[1];
  if (key.includes('eye')) return CATEGORY_STYLE_PALETTE[2];
  if (key.includes('skin') || key.includes('prep')) return CATEGORY_STYLE_PALETTE[4];
  if (key.includes('cheek') || key.includes('glow') || key.includes('blush')) return CATEGORY_STYLE_PALETTE[5];
  if (key.includes('tool') || key.includes('brush')) return CATEGORY_STYLE_PALETTE[3];
  if (key.includes('fragrance') || key.includes('mist')) return CATEGORY_STYLE_PALETTE[6];
  if (key.includes('bridal') || key.includes('pro') || key.includes('party')) return CATEGORY_STYLE_PALETTE[7];
  let hash = 0;
  for (let i = 0; i < key.length; i++) hash = (hash * 31 + key.charCodeAt(i)) | 0;
  return CATEGORY_STYLE_PALETTE[Math.abs(hash) % CATEGORY_STYLE_PALETTE.length];
}

/**
 * Multi-spectrum gradient bar palette for 3D analytics charts
 */
export const CHART_BAR_GRADIENTS = [
  'from-[#2563EB] via-[#06B6D4] to-[#22D3EE]',
  'from-[#7C3AED] via-[#D946EF] to-[#EC4899]',
  'from-[#10B981] via-[#14B8A6] to-[#2DD4BF]',
  'from-[#F97316] via-[#F59E0B] to-[#FACC15]',
  'from-[#F43F5E] via-[#EC4899] to-[#FB7185]',
  'from-[#5B21B6] via-[#2563EB] to-[#06B6D4]',
];
