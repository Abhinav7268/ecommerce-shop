import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { doc, serverTimestamp, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import {
  ALL_CURRENCIES,
  CountryCode,
  CURRENCY_RATES,
  CurrencyCode,
  LanguageCode,
  setLiveExchangeRates,
  UserProfile,
} from '../types/store';
import {
  COUNTRY_CONFIGS,
  CountryConfig,
  SUPPORTED_LANGUAGES,
  translate,
  TranslationKey,
} from '../lib/localization';

const STORAGE_KEY = 'lumiere_global_localization_v1';

interface StoredLocalization {
  countryCode: CountryCode;
  currency: CurrencyCode;
  language: LanguageCode;
  consent: 'accepted' | 'dismissed' | 'custom';
}

export interface DetectedCountrySuggestion {
  countryCode: CountryCode;
  country: CountryConfig;
  source: string;
}

interface LocalizationContextValue {
  countryCode: CountryCode;
  country: CountryConfig;
  currency: CurrencyCode;
  language: LanguageCode;
  isRtl: boolean;
  rates: Record<CurrencyCode, number>;
  rateSource: 'live' | 'reference';
  ratesFetchedAt: string | null;
  ratesLoading: boolean;
  detectedSuggestion: DetectedCountrySuggestion | null;
  selectorOpen: boolean;
  setSelectorOpen: (open: boolean) => void;
  setCountry: (code: CountryCode, syncCurrencyAndLang?: boolean) => void;
  setCurrency: (currency: CurrencyCode) => void;
  setLanguage: (lang: LanguageCode) => void;
  applyPreferences: (prefs: { countryCode: CountryCode; currency: CurrencyCode; language: LanguageCode }) => void;
  acceptDetectedCountry: () => void;
  dismissDetectedCountry: () => void;
  refreshRates: () => Promise<void>;
  syncUserProfile: (uid?: string, profile?: UserProfile | null) => void;
  t: (key: TranslationKey) => string;
}

const DEFAULT_RATES: Record<CurrencyCode, number> = ALL_CURRENCIES.reduce((acc, code) => {
  acc[code] = CURRENCY_RATES[code].rate;
  return acc;
}, {} as Record<CurrencyCode, number>);

function readStoredLocalization(): StoredLocalization | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<StoredLocalization>;
    if (
      parsed.countryCode &&
      COUNTRY_CONFIGS[parsed.countryCode] &&
      parsed.currency &&
      CURRENCY_RATES[parsed.currency] &&
      parsed.language &&
      SUPPORTED_LANGUAGES.some((l) => l.code === parsed.language)
    ) {
      return {
        countryCode: parsed.countryCode,
        currency: parsed.currency,
        language: parsed.language,
        consent: parsed.consent || 'custom',
      };
    }
  } catch {
    // Ignore storage errors
  }
  return null;
}

const LocalizationContext = createContext<LocalizationContextValue | null>(null);

interface LocalizationProviderProps {
  children: React.ReactNode;
  userUid?: string;
  userProfile?: UserProfile | null;
  defaultCurrency?: CurrencyCode;
  onCurrencyChangeExternal?: (currency: CurrencyCode) => void;
}

export const LocalizationProvider: React.FC<LocalizationProviderProps> = ({
  children,
  userUid,
  userProfile,
  defaultCurrency,
  onCurrencyChangeExternal,
}) => {
  const initialStored = useMemo(() => readStoredLocalization(), []);

  const [countryCode, setCountryCodeState] = useState<CountryCode>(initialStored?.countryCode || 'US');
  const [currency, setCurrencyState] = useState<CurrencyCode>(
    initialStored?.currency || defaultCurrency || 'USD',
  );
  const [language, setLanguageState] = useState<LanguageCode>(initialStored?.language || 'en');
  const [consent, setConsent] = useState<'none' | 'accepted' | 'dismissed' | 'custom'>(
    initialStored ? initialStored.consent : 'none',
  );

  const [rates, setRates] = useState<Record<CurrencyCode, number>>(DEFAULT_RATES);
  const [rateSource, setRateSource] = useState<'live' | 'reference'>('reference');
  const [ratesFetchedAt, setRatesFetchedAt] = useState<string | null>(null);
  const [ratesLoading, setRatesLoading] = useState(false);

  const [detectedSuggestion, setDetectedSuggestion] = useState<DetectedCountrySuggestion | null>(null);
  const [selectorOpen, setSelectorOpen] = useState(false);

  const country = COUNTRY_CONFIGS[countryCode] || COUNTRY_CONFIGS.US;
  const isRtl = useMemo(
    () => Boolean(SUPPORTED_LANGUAGES.find((l) => l.code === language)?.rtl),
    [language],
  );

  const [syncedUid, setSyncedUid] = useState<string | undefined>(userUid);
  const [syncedProfile, setSyncedProfile] = useState<UserProfile | null | undefined>(userProfile);

  const effectiveUid = userUid ?? syncedUid;
  const effectiveProfile = userProfile ?? syncedProfile;

  const syncUserProfile = useCallback((uid?: string, nextProfile?: UserProfile | null) => {
    setSyncedUid(uid);
    setSyncedProfile(nextProfile ?? null);
  }, []);

  const persistPreferences = useCallback(
    (next: {
      countryCode: CountryCode;
      currency: CurrencyCode;
      language: LanguageCode;
      consent: 'accepted' | 'dismissed' | 'custom';
    }) => {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {
        // Ignore storage quota errors
      }
      if (effectiveUid && effectiveProfile) {
        updateDoc(doc(db, 'users', effectiveUid), {
          preferredCountry: next.countryCode,
          preferredCurrency: next.currency,
          preferredLanguage: next.language,
          localizationConsent: next.consent,
          updatedAt: serverTimestamp(),
        }).catch(() => {
          // Non-blocking profile preference sync
        });
      }
    },
    [effectiveUid, effectiveProfile],
  );

  // Sync saved preferences from authenticated Firestore profile once loaded
  useEffect(() => {
    if (!effectiveProfile) return;
    const savedCountry = effectiveProfile.preferredCountry;
    const savedCurrency = effectiveProfile.preferredCurrency;
    const savedLang = effectiveProfile.preferredLanguage;
    if (savedCountry && COUNTRY_CONFIGS[savedCountry]) {
      setCountryCodeState(savedCountry);
    }
    if (savedCurrency && CURRENCY_RATES[savedCurrency]) {
      setCurrencyState(savedCurrency);
      onCurrencyChangeExternal?.(savedCurrency);
    }
    if (savedLang && SUPPORTED_LANGUAGES.some((l) => l.code === savedLang)) {
      setLanguageState(savedLang);
    }
    if (effectiveProfile.localizationConsent) {
      setConsent(effectiveProfile.localizationConsent);
      setDetectedSuggestion(null);
    }
  }, [
    effectiveProfile?.uid,
    effectiveProfile?.preferredCountry,
    effectiveProfile?.preferredCurrency,
    effectiveProfile?.preferredLanguage,
    effectiveProfile?.localizationConsent,
  ]);

  // Keep external App currency state synced
  useEffect(() => {
    onCurrencyChangeExternal?.(currency);
  }, [currency, onCurrencyChangeExternal]);

  // Fetch live exchange rates from server proxy
  const refreshRates = useCallback(async () => {
    setRatesLoading(true);
    try {
      const res = await fetch('/api/localization/rates');
      if (!res.ok) throw new Error('Failed to fetch exchange rates');
      const data = await res.json();
      if (data && data.rates) {
        const merged: Record<CurrencyCode, number> = { ...DEFAULT_RATES };
        for (const code of ALL_CURRENCIES) {
          const val = Number(data.rates[code]);
          if (Number.isFinite(val) && val > 0) {
            merged[code] = val;
          }
        }
        setRates(merged);
        setLiveExchangeRates(merged);
        setRateSource(data.source === 'live' ? 'live' : 'reference');
        setRatesFetchedAt(data.fetchedAt || new Date().toISOString());
      }
    } catch {
      setLiveExchangeRates(DEFAULT_RATES);
      setRateSource('reference');
    } finally {
      setRatesLoading(false);
    }
  }, []);

  useEffect(() => {
    void refreshRates();
    const timer = window.setInterval(() => {
      void refreshRates();
    }, 15 * 60 * 1000);
    return () => window.clearInterval(timer);
  }, [refreshRates]);

  // Automatic country detection with explicit customer consent (never switches silently!)
  useEffect(() => {
    if (consent !== 'none') return;
    let cancelled = false;
    const detectCountry = async () => {
      try {
        const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
        const locale = navigator.language || '';
        const res = await fetch(
          `/api/localization/detect?tz=${encodeURIComponent(tz)}&locale=${encodeURIComponent(locale)}`,
        );
        if (!res.ok || cancelled) return;
        const data = await res.json();
        const suggestedCode = data?.countryCode as CountryCode | undefined;
        if (suggestedCode && COUNTRY_CONFIGS[suggestedCode] && !cancelled) {
          setDetectedSuggestion({
            countryCode: suggestedCode,
            country: COUNTRY_CONFIGS[suggestedCode],
            source: data.source || 'regional signal',
          });
        }
      } catch {
        // Non-blocking detection
      }
    };
    void detectCountry();
    return () => {
      cancelled = true;
    };
  }, [consent]);

  const setCountry = useCallback(
    (code: CountryCode, syncCurrencyAndLang = true) => {
      const cfg = COUNTRY_CONFIGS[code] || COUNTRY_CONFIGS.US;
      const nextCurrency = syncCurrencyAndLang ? cfg.currency : currency;
      const nextLang = syncCurrencyAndLang ? cfg.defaultLanguage : language;
      setCountryCodeState(code);
      if (syncCurrencyAndLang) {
        setCurrencyState(nextCurrency);
        setLanguageState(nextLang);
      }
      setConsent('custom');
      setDetectedSuggestion(null);
      persistPreferences({
        countryCode: code,
        currency: nextCurrency,
        language: nextLang,
        consent: 'custom',
      });
    },
    [currency, language, persistPreferences],
  );

  const setCurrency = useCallback(
    (nextCurrency: CurrencyCode) => {
      if (!CURRENCY_RATES[nextCurrency]) return;
      setCurrencyState(nextCurrency);
      setConsent('custom');
      persistPreferences({
        countryCode,
        currency: nextCurrency,
        language,
        consent: 'custom',
      });
    },
    [countryCode, language, persistPreferences],
  );

  const setLanguage = useCallback(
    (nextLang: LanguageCode) => {
      setLanguageState(nextLang);
      setConsent('custom');
      persistPreferences({
        countryCode,
        currency,
        language: nextLang,
        consent: 'custom',
      });
    },
    [countryCode, currency, persistPreferences],
  );

  const applyPreferences = useCallback(
    (prefs: { countryCode: CountryCode; currency: CurrencyCode; language: LanguageCode }) => {
      setCountryCodeState(prefs.countryCode);
      setCurrencyState(prefs.currency);
      setLanguageState(prefs.language);
      setConsent('custom');
      setDetectedSuggestion(null);
      persistPreferences({ ...prefs, consent: 'custom' });
    },
    [persistPreferences],
  );

  const acceptDetectedCountry = useCallback(() => {
    if (!detectedSuggestion) return;
    const cfg = detectedSuggestion.country;
    setCountryCodeState(cfg.code);
    setCurrencyState(cfg.currency);
    setLanguageState(cfg.defaultLanguage);
    setConsent('accepted');
    setDetectedSuggestion(null);
    persistPreferences({
      countryCode: cfg.code,
      currency: cfg.currency,
      language: cfg.defaultLanguage,
      consent: 'accepted',
    });
  }, [detectedSuggestion, persistPreferences]);

  const dismissDetectedCountry = useCallback(() => {
    setConsent('dismissed');
    setDetectedSuggestion(null);
    persistPreferences({
      countryCode,
      currency,
      language,
      consent: 'dismissed',
    });
  }, [countryCode, currency, language, persistPreferences]);

  const t = useCallback((key: TranslationKey) => translate(language, key), [language]);

  const value = useMemo<LocalizationContextValue>(
    () => ({
      countryCode,
      country,
      currency,
      language,
      isRtl,
      rates,
      rateSource,
      ratesFetchedAt,
      ratesLoading,
      detectedSuggestion,
      selectorOpen,
      setSelectorOpen,
      setCountry,
      setCurrency,
      setLanguage,
      applyPreferences,
      acceptDetectedCountry,
      dismissDetectedCountry,
      refreshRates,
      syncUserProfile,
      t,
    }),
    [
      countryCode,
      country,
      currency,
      language,
      isRtl,
      rates,
      rateSource,
      ratesFetchedAt,
      ratesLoading,
      detectedSuggestion,
      selectorOpen,
      setCountry,
      setCurrency,
      setLanguage,
      applyPreferences,
      acceptDetectedCountry,
      dismissDetectedCountry,
      refreshRates,
      syncUserProfile,
      t,
    ],
  );

  return <LocalizationContext.Provider value={value}>{children}</LocalizationContext.Provider>;
};

export function useLocalization(): LocalizationContextValue {
  const ctx = useContext(LocalizationContext);
  if (!ctx) {
    throw new Error('useLocalization must be used within a LocalizationProvider');
  }
  return ctx;
}
