import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { MotionConfig } from 'motion/react';
import {
  AnimationIntensity,
  LightColorPreset,
  LightingIntensity,
  LightSpeed,
  MotionSpeed,
  NeonGlowLevel,
  PageTransitionStyle,
  ParticleDensity,
  SiteSettings,
} from '../types/store';

export interface LightPaletteColors {
  c1: string;
  c2: string;
  c3: string;
  c4: string;
  hex1: number;
  hex2: number;
  hex3: number;
}

export const LIGHT_PRESET_PALETTES: Record<LightColorPreset, LightPaletteColors> = {
  rainbow: {
    c1: '#22D3EE',
    c2: '#2563EB',
    c3: '#7C3AED',
    c4: '#EC4899',
    hex1: 0x22d3ee,
    hex2: 0xd946ef,
    hex3: 0x2563eb,
  },
  cyber_cyan: {
    c1: '#22D3EE',
    c2: '#06B6D4',
    c3: '#2563EB',
    c4: '#38BDF8',
    hex1: 0x22d3ee,
    hex2: 0x2563eb,
    hex3: 0x14b8a6,
  },
  royal_magenta: {
    c1: '#7C3AED',
    c2: '#D946EF',
    c3: '#EC4899',
    c4: '#2563EB',
    hex1: 0xd946ef,
    hex2: 0xec4899,
    hex3: 0x7c3aed,
  },
  emerald_aqua: {
    c1: '#10B981',
    c2: '#14B8A6',
    c3: '#22D3EE',
    c4: '#2563EB',
    hex1: 0x10b981,
    hex2: 0x22d3ee,
    hex3: 0x14b8a6,
  },
  solar_gold: {
    c1: '#F59E0B',
    c2: '#F97316',
    c3: '#EC4899',
    c4: '#D946EF',
    hex1: 0xf59e0b,
    hex2: 0xec4899,
    hex3: 0xf97316,
  },
};

export interface MotionPreferences {
  enabled: boolean;
  intensity: AnimationIntensity;
  speed: MotionSpeed;
  speedMultiplier: number;
  intensityScale: number;
  backgroundEffects: boolean;
  enable3DEffects: boolean;
  particleDensity: ParticleDensity;
  effectiveParticleDensity: ParticleDensity;
  hoverEffects: boolean;
  pageTransitionStyle: PageTransitionStyle;
  mobileOptimization: boolean;
  reducedMotionMode: boolean;
  isMobileViewport: boolean;
  effectiveReducedMotion: boolean;
  // 360° Global Lighting & Neon Illumination Controls
  globalLightingEnabled: boolean;
  ambientLightingIntensity: LightingIntensity;
  ambientLightingScale: number;
  neonGlowIntensity: NeonGlowLevel;
  neonGlowScale: number;
  lightAnimationSpeed: LightSpeed;
  lightSpeedMultiplier: number;
  lightColorPreset: LightColorPreset;
  lightPalette: LightPaletteColors;
  borderGlowEnabled: boolean;
  backgroundLightEffects: boolean;
  mouseFollowLighting: boolean;
  mobileLightingOptimization: boolean;
  effectiveGlobalLighting: boolean;
  effectiveBorderGlow: boolean;
  effectiveBackgroundLighting: boolean;
  effectiveMouseLighting: boolean;
}

const DEFAULT_PREFS: MotionPreferences = {
  enabled: true,
  intensity: 'cinematic',
  speed: 'normal',
  speedMultiplier: 1,
  intensityScale: 1,
  backgroundEffects: true,
  enable3DEffects: true,
  particleDensity: 'medium',
  effectiveParticleDensity: 'medium',
  hoverEffects: true,
  pageTransitionStyle: 'cinematic',
  mobileOptimization: true,
  reducedMotionMode: false,
  isMobileViewport: false,
  effectiveReducedMotion: false,
  globalLightingEnabled: true,
  ambientLightingIntensity: 'cinematic',
  ambientLightingScale: 0.92,
  neonGlowIntensity: 'medium',
  neonGlowScale: 1,
  lightAnimationSpeed: 'normal',
  lightSpeedMultiplier: 1,
  lightColorPreset: 'rainbow',
  lightPalette: LIGHT_PRESET_PALETTES.rainbow,
  borderGlowEnabled: true,
  backgroundLightEffects: true,
  mouseFollowLighting: true,
  mobileLightingOptimization: true,
  effectiveGlobalLighting: true,
  effectiveBorderGlow: true,
  effectiveBackgroundLighting: true,
  effectiveMouseLighting: true,
};

const MotionPreferencesContext = createContext<MotionPreferences>(DEFAULT_PREFS);

export function useMotionPreferences(): MotionPreferences {
  return useContext(MotionPreferencesContext);
}

interface MotionProviderProps {
  settings: SiteSettings;
  children: React.ReactNode;
}

export const MotionProvider: React.FC<MotionProviderProps> = ({ settings, children }) => {
  const [osReducedMotion, setOsReducedMotion] = useState(false);
  const [isMobileViewport, setIsMobileViewport] = useState(false);

  useEffect(() => {
    const mqReduce = window.matchMedia('(prefers-reduced-motion: reduce)');
    const mqMobile = window.matchMedia('(max-width: 767px)');

    const sync = () => {
      setOsReducedMotion(mqReduce.matches);
      setIsMobileViewport(mqMobile.matches);
    };

    sync();
    mqReduce.addEventListener('change', sync);
    mqMobile.addEventListener('change', sync);
    return () => {
      mqReduce.removeEventListener('change', sync);
      mqMobile.removeEventListener('change', sync);
    };
  }, []);

  const prefs = useMemo<MotionPreferences>(() => {
    const enabled = settings.enableAnimations !== false;
    const reducedMotionMode = Boolean(settings.reducedMotionMode);
    const effectiveReducedMotion = !enabled || reducedMotionMode || osReducedMotion;

    const intensity: AnimationIntensity = settings.animationIntensity || 'cinematic';
    const speed: MotionSpeed = settings.motionSpeed || 'normal';
    const mobileOptimization = settings.mobileOptimization !== false;
    const speedMultiplier = speed === 'slow' ? 1.38 : speed === 'snappy' ? 0.72 : 1;
    const intensityScale = intensity === 'subtle' ? 0.45 : intensity === 'balanced' ? 0.75 : 1;

    // 360° Global Lighting & Neon Controls
    const globalLightingEnabled = settings.globalLightingEnabled !== false;
    const ambientLightingIntensity: LightingIntensity = settings.ambientLightingIntensity || 'cinematic';
    const neonGlowIntensity: NeonGlowLevel = settings.neonGlowIntensity || 'medium';
    const lightAnimationSpeed: LightSpeed = settings.lightAnimationSpeed || 'normal';
    const lightColorPreset: LightColorPreset = settings.lightColorPreset || 'rainbow';
    const borderGlowEnabled = settings.borderGlowEnabled !== false;
    const backgroundLightEffects = settings.backgroundLightEffects !== false;
    const mouseFollowLighting = settings.mouseFollowLighting !== false;
    const mobileLightingOptimization = settings.mobileLightingOptimization !== false;

    const mobileThrottle = isMobileViewport && mobileLightingOptimization ? 0.62 : 1;
    const ambientLightingScale =
      (ambientLightingIntensity === 'subtle'
        ? 0.45
        : ambientLightingIntensity === 'balanced'
          ? 0.72
          : ambientLightingIntensity === 'ultra'
            ? 1.15
            : 0.92) * mobileThrottle;

    const neonGlowScale =
      (neonGlowIntensity === 'low' ? 0.55 : neonGlowIntensity === 'high' ? 1.35 : 1) * mobileThrottle;

    const lightSpeedMultiplier =
      lightAnimationSpeed === 'slow' ? 1.55 : lightAnimationSpeed === 'dynamic' ? 0.68 : 1;

    const effectiveGlobalLighting = globalLightingEnabled;
    const effectiveBorderGlow = globalLightingEnabled && borderGlowEnabled;
    const effectiveBackgroundLighting =
      globalLightingEnabled && backgroundLightEffects && settings.backgroundEffects !== false;
    const effectiveMouseLighting =
      globalLightingEnabled &&
      mouseFollowLighting &&
      !effectiveReducedMotion &&
      !(isMobileViewport && mobileLightingOptimization);

    const rawDensity: ParticleDensity = settings.particleDensity || 'medium';
    let effectiveParticleDensity: ParticleDensity = rawDensity;
    if (effectiveReducedMotion || settings.backgroundEffects === false || !globalLightingEnabled) {
      effectiveParticleDensity = 'off';
    } else if (isMobileViewport && (mobileOptimization || mobileLightingOptimization)) {
      effectiveParticleDensity = rawDensity === 'off' ? 'off' : 'low';
    }

    return {
      enabled,
      intensity,
      speed,
      speedMultiplier,
      intensityScale,
      backgroundEffects: settings.backgroundEffects !== false && !effectiveReducedMotion,
      enable3DEffects: settings.enable3DEffects !== false && !effectiveReducedMotion,
      particleDensity: rawDensity,
      effectiveParticleDensity,
      hoverEffects: settings.hoverEffects !== false && !effectiveReducedMotion && !(isMobileViewport && mobileOptimization),
      pageTransitionStyle: settings.pageTransitionStyle || 'cinematic',
      mobileOptimization,
      reducedMotionMode,
      isMobileViewport,
      effectiveReducedMotion,
      globalLightingEnabled,
      ambientLightingIntensity,
      ambientLightingScale,
      neonGlowIntensity,
      neonGlowScale,
      lightAnimationSpeed,
      lightSpeedMultiplier,
      lightColorPreset,
      lightPalette: LIGHT_PRESET_PALETTES[lightColorPreset] || LIGHT_PRESET_PALETTES.rainbow,
      borderGlowEnabled,
      backgroundLightEffects,
      mouseFollowLighting,
      mobileLightingOptimization,
      effectiveGlobalLighting,
      effectiveBorderGlow,
      effectiveBackgroundLighting,
      effectiveMouseLighting,
    };
  }, [settings, osReducedMotion, isMobileViewport]);

  // Reflect live motion & 360° lighting settings into DOM attributes & CSS variables
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--motion-speed', String(prefs.speedMultiplier));
    root.style.setProperty('--motion-intensity', String(prefs.intensityScale));
    root.style.setProperty('--light-ambient-opacity', String(prefs.ambientLightingScale));
    root.style.setProperty('--neon-glow-scale', String(prefs.neonGlowScale));
    root.style.setProperty('--light-speed', String(prefs.lightSpeedMultiplier));
    root.style.setProperty('--light-c1', prefs.lightPalette.c1);
    root.style.setProperty('--light-c2', prefs.lightPalette.c2);
    root.style.setProperty('--light-c3', prefs.lightPalette.c3);
    root.style.setProperty('--light-c4', prefs.lightPalette.c4);

    root.dataset.motionDisabled = prefs.effectiveReducedMotion ? 'true' : 'false';
    root.dataset.hoverDisabled = prefs.hoverEffects ? 'false' : 'true';
    root.dataset.bgEffectsDisabled = prefs.backgroundEffects ? 'false' : 'true';
    root.dataset.mobileOptimized = prefs.isMobileViewport && prefs.mobileOptimization ? 'true' : 'false';
    root.dataset.lightingEnabled = prefs.effectiveGlobalLighting ? 'true' : 'false';
    root.dataset.borderGlow = prefs.effectiveBorderGlow ? 'true' : 'false';
    root.dataset.bgLighting = prefs.effectiveBackgroundLighting ? 'true' : 'false';
    root.dataset.mouseLighting = prefs.effectiveMouseLighting ? 'true' : 'false';
    root.dataset.lightPreset = prefs.lightColorPreset;
  }, [prefs]);

  return (
    <MotionPreferencesContext.Provider value={prefs}>
      <MotionConfig reducedMotion={prefs.effectiveReducedMotion ? 'always' : 'user'}>
        {children}
      </MotionConfig>
    </MotionPreferencesContext.Provider>
  );
};
