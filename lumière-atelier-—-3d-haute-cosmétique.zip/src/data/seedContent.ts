import { BlogPost, CmsPage, ShippingZone } from '../types/store';

export const SEED_BLOG_POSTS: BlogPost[] = [
  {
    id: 'blog-undertone-science',
    title: 'The Colorimetry of Skin: Mapping Warm, Cool & Olive Undertones',
    slug: 'colorimetry-mapping-undertones',
    category: 'Shade Science',
    excerpt:
      'How our Paris & Mumbai pigment labs calibrate mineral iron oxides so foundations never oxidize or turn ashy under flash photography.',
    content:
      'Finding a second-skin foundation begins beneath the surface tone. While depth ranges from Fair to Deep, undertone dictates whether neutral beige, golden ochre, olive green, or rosy pearl pigments harmonize with your natural melanin.\n\nIn the LUMIÈRE ATELIER laboratory, every shade in Voile de Lumière Serum Foundation is balanced across three axes: surface luminosity, hemoglobin warmth, and carotene goldenness. Use our AI Shade Finder with natural window light or launch live Virtual Try-On in 3D before ordering.',
    coverImage: '/src/assets/images/cat_foundation_concealer_1794984608463.jpg',
    author: 'Dr. Elodie Marchand, Chief Formulator',
    published: true,
  },
  {
    id: 'blog-bridal-longevity',
    title: '16-Hour Bridal Artistry: Layering Serums, Velvets & Rose-Quartz Mists',
    slug: 'bridal-artistry-longevity-ritual',
    category: 'Bridal Atelier',
    excerpt:
      'Backstage techniques from celebrity makeup artists for transfer-proof, flash-friendly luminosity across multi-day celebrations.',
    content:
      'Bridal makeup must endure high humidity, studio flash, and emotional celebrations without caking. The secret lies in micro-layering rather than heavy powdering.\n\nBegin with a fine mist of Aura Dew Rose-Quartz Setting Mist prior to primer, press Voile de Lumière Serum Foundation with a damp Kumano sponge, and lock Rouge Velours Couture Lipstick by blotting once through a single-ply tissue before sealing the perimeter.',
    coverImage: '/src/assets/images/cat_bridal_kits_1794984609940.jpg',
    author: 'Meera Kapoor, Bridal Creative Director',
    published: true,
  },
  {
    id: 'blog-kumano-craft',
    title: 'Inside Kumano Brushmaking: Why Tapered Taklon Outperforms Natural Hair',
    slug: 'kumano-brushmaking-taklon-craft',
    category: 'Craftsmanship',
    excerpt:
      'Discover how micro-crimped vegan synthetic fibers pick up both liquid serums and Italian-baked powders with zero shedding.',
    content:
      'Each brush in our 6-Piece Kumano Artisanal Set undergoes 28 hand-inspection steps. Unlike porous animal hair, our ultra-fine vegan taklon fibers do not absorb expensive serum foundations—meaning up to 30% less product waste and effortless sanitation between clients.',
    coverImage: '/src/assets/images/cat_brushes_tools_1794984611073.jpg',
    author: 'Kenji Takahashi, Master Brush Artisan',
    published: true,
  },
];

export const SEED_CMS_PAGES: CmsPage[] = [
  {
    id: 'page-about',
    title: 'About LUMIÈRE ATELIER',
    slug: 'about',
    group: 'company',
    content:
      'Founded across Paris, Mumbai, and Tokyo, LUMIÈRE ATELIER fuses haute couture pigment craft with clean botanical skincare actives and real-time 3D cosmetic visualization.\n\nEvery formula is cruelty-free, paraben-free, ophthalmologically tested, and engineered to perform across all skin depths and undertones.',
    visible: true,
  },
  {
    id: 'page-story',
    title: 'Our Story',
    slug: 'our-story',
    group: 'company',
    content:
      'Born backstage at international couture weeks, LUMIÈRE ATELIER began with a single mission: eliminate the guesswork of buying luxury cosmetics online.\n\nBy uniting interactive 3D packaging inspection, camera-based Virtual Try-On, and AI skin colorimetry, collectors experience boutique-grade consultation from anywhere in the world.',
    visible: true,
  },
  {
    id: 'page-mission',
    title: 'Mission & Vision',
    slug: 'mission-vision',
    group: 'company',
    content:
      'Our mission is inclusive pigment precision powered by clean botanical chemistry.\n\nOur vision is a zero-waste luxury beauty ecosystem featuring refillable champagne-gold hardware, full INCI ingredient transparency, and carbon-neutral express fulfillment.',
    visible: true,
  },
  {
    id: 'page-careers',
    title: 'Careers at the Atelier',
    slug: 'careers',
    group: 'company',
    content:
      'We are hiring formulation chemists, 3D WebGL creative technologists, and regional merchandising specialists in Paris, Mumbai, London, and Tokyo.\n\nSubmit your portfolio or CV through our Contact Atelier form with the subject line "Careers Inquiry".',
    visible: true,
  },
  {
    id: 'page-faq',
    title: 'Frequently Asked Questions',
    slug: 'faq',
    group: 'support',
    content:
      'Q: How accurate is the AI Shade Finder?\nA: Our Gemini-powered colorimetry studio analyzes natural lighting, skin depth, and undertone cues to match real shades across our catalog.\n\nQ: Which payment methods are supported?\nA: We support Razorpay, Cashfree, PayU, CCAvenue, Stripe, PayPal, UPI (Google Pay, PhonePe, Paytm), cards, net banking, EMI, and COD.\n\nQ: Can I track or return an order?\nA: Yes—visit Track Order or your Client Atelier dashboard for live milestone updates and 30-day unopened/shade-guarantee returns.',
    visible: true,
  },
  {
    id: 'page-shipping',
    title: 'Shipping Policy',
    slug: 'shipping-policy',
    group: 'policy',
    content:
      'Orders placed before 2:00 PM local hub time dispatch the same business day via insured air courier.\n\nComplimentary express shipping applies automatically on orders over $50 across India, US, EU, UK, UAE, and Japan. Use the Pincode / Postal Check tool at checkout or Track Order for live carrier estimates.',
    visible: true,
  },
  {
    id: 'page-return',
    title: 'Return Policy',
    slug: 'return-policy',
    group: 'policy',
    content:
      'We offer a 30-day Atelier Return Guarantee on unused items in original packaging as well as complimentary shade exchanges on serum foundations.',
    visible: true,
  },
  {
    id: 'page-refund',
    title: 'Refund Policy',
    slug: 'refund-policy',
    group: 'policy',
    content:
      'Approved full and partial refunds are issued directly back to your original payment gateway (Razorpay, Stripe, PayPal, Cashfree, PayU, CCAvenue, or UPI) within 3–5 business days.',
    visible: true,
  },
  {
    id: 'page-exchange',
    title: 'Exchange Policy',
    slug: 'exchange-policy',
    group: 'policy',
    content:
      'Need a warmer or deeper shade? Initiate an instant shade exchange from your Client Atelier Order History within 14 days of delivery.',
    visible: true,
  },
  {
    id: 'page-cancellation',
    title: 'Cancellation Policy',
    slug: 'cancellation-policy',
    group: 'policy',
    content:
      'Orders in "processing" status may be cancelled directly from your Customer Dashboard for immediate reversal before courier dispatch.',
    visible: true,
  },
  {
    id: 'page-privacy',
    title: 'Privacy Policy',
    slug: 'privacy-policy',
    group: 'policy',
    content:
      'Your personal profile and private shipping details are strictly partitioned in encrypted Firebase storage. Virtual Try-On camera frames are processed locally on-device unless explicitly submitted to the AI Shade Finder.',
    visible: true,
  },
  {
    id: 'page-terms',
    title: 'Terms & Conditions',
    slug: 'terms-conditions',
    group: 'policy',
    content:
      'All formulations, 3D packaging designs, and trademarks belong to LUMIÈRE ATELIER. Promotional codes and flash discounts apply per published eligibility rules at checkout.',
    visible: true,
  },
  {
    id: 'page-cookies',
    title: 'Cookie Policy',
    slug: 'cookie-policy',
    group: 'policy',
    content:
      'We use essential local storage keys solely to preserve your shopping bag, currency selection, theme mode, and recently viewed formulations.',
    visible: true,
  },
  {
    id: 'page-payment',
    title: 'Payment Security Policy',
    slug: 'payment-policy',
    group: 'policy',
    content:
      'All gateway transactions are protected by server-side HMAC-SHA256 cryptographic signature verification, PCI-DSS compliant partner checkouts, and automatic retry recovery.',
    visible: true,
  },
  {
    id: 'page-warranty',
    title: 'Hardware & Brush Warranty Policy',
    slug: 'warranty-policy',
    group: 'policy',
    content:
      'Refillable magnetic lipstick cases, palette hinges, and Kumano artisanal brush ferrules carry a 2-year craftsmanship warranty against manufacturing defects.',
    visible: true,
  },
  {
    id: 'page-disclaimer',
    title: 'Cosmetic & Color Disclaimer',
    slug: 'disclaimer',
    group: 'policy',
    content:
      'Digital swatch rendering and 3D lighting approximations may vary slightly by screen calibration. All formulations undergo dermatological patch testing; consult full INCI lists on each product page before use.',
    visible: true,
  },
];

export const SEED_SHIPPING_ZONES: ShippingZone[] = [
  {
    id: 'zone-india-metro',
    name: 'Metro Express India',
    region: 'India (Mumbai, Delhi NCR, Bengaluru, Chennai, Hyderabad)',
    baseRate: 0,
    freeThreshold: 50,
    estimatedDays: '1–2 Business Days',
    codAvailable: true,
    active: true,
  },
  {
    id: 'zone-india-pan',
    name: 'Pan-India Insured Air',
    region: 'India (All Serviceable PIN Codes)',
    baseRate: 4,
    freeThreshold: 50,
    estimatedDays: '3–5 Business Days',
    codAvailable: true,
    active: true,
  },
  {
    id: 'zone-intl-dhl',
    name: 'International Priority Worldwide',
    region: 'USA, UK, EU, UAE, Japan, Singapore',
    baseRate: 12,
    freeThreshold: 120,
    estimatedDays: '4–7 Business Days',
    codAvailable: false,
    active: true,
  },
];
