import {
  PackagingSpec,
  Product,
  PurchaseOrder,
  Supplier,
  Warehouse,
  WholesaleAccount,
  WholesaleQuote,
} from '../types/store';

export const SEED_WAREHOUSES: Warehouse[] = [
  {
    id: 'wh_mumbai_central',
    name: 'Mumbai BKC Atelier Hub',
    code: 'MUM-01',
    city: 'Mumbai',
    country: 'India',
    managerName: 'Aarav Mehta',
    capacityUnits: 45000,
    active: true,
  },
  {
    id: 'wh_paris_atelier',
    name: 'Paris Saint-Honoré Vault',
    code: 'PAR-01',
    city: 'Paris',
    country: 'France',
    managerName: 'Camille Laurent',
    capacityUnits: 28000,
    active: true,
  },
  {
    id: 'wh_delhi_ncr',
    name: 'Delhi NCR Wholesale Depot',
    code: 'DEL-02',
    city: 'Gurugram',
    country: 'India',
    managerName: 'Rohan Kapoor',
    capacityUnits: 60000,
    active: true,
  },
];

export const SEED_SUPPLIERS: Supplier[] = [
  {
    id: 'sup_laboratoire_paris',
    companyName: 'Laboratoire Lumière Paris',
    contactName: 'Claire Moreau',
    email: 'fulfillment@laboratoirelumiere.example',
    phone: '+33 1 42 68 55 00',
    whatsapp: '+33612457890',
    gstNumber: 'FR89402918273',
    country: 'France',
    supplierType: 'private_label',
    integrationType: 'API',
    webhookUrl: 'https://sandbox-supplier.lumiere.local/api/po',
    moq: 25,
    paymentTerms: 'Net 30',
    leadTimeDays: 3,
    performanceScore: 98,
    privateLabelCapable: true,
    brandingOptions: ['Gold-Foil Box', 'Custom Engraved Cap', 'Velvet Pouch', 'Zero Supplier Invoice'],
    verified: true,
    active: true,
  },
  {
    id: 'sup_kumano_botanicals',
    companyName: 'Kumano Craft & Botanicals Co.',
    contactName: 'Kenji Takahashi',
    email: 'orders@kumanocraft.example',
    phone: '+81 82 854 0011',
    whatsapp: '+819012345678',
    gstNumber: 'JP-7010401098',
    country: 'Japan',
    supplierType: 'dropship',
    integrationType: 'Shopify',
    moq: 10,
    paymentTerms: 'Prepaid / Net 15',
    leadTimeDays: 4,
    performanceScore: 95,
    privateLabelCapable: true,
    brandingOptions: ['Neutral Craft Sleeve', 'Custom Wax Seal', 'Thank You Card Insert'],
    verified: true,
    active: true,
  },
  {
    id: 'sup_aurum_pigments',
    companyName: 'Aurum Pigments & Formulations Pvt Ltd',
    contactName: 'Neha Deshmukh',
    email: 'dispatch@aurumpigments.example',
    phone: '+91 22 6128 9400',
    whatsapp: '+919820112233',
    gstNumber: '27AABCA9281K1Z4',
    country: 'India',
    supplierType: 'wholesale_distributor',
    integrationType: 'Email',
    moq: 50,
    paymentTerms: 'Net 45 (B2B Credit)',
    leadTimeDays: 2,
    performanceScore: 93,
    privateLabelCapable: true,
    brandingOptions: ['Custom Brand Box', 'Batch QR Label', 'Tamper-Proof Security Tape'],
    verified: true,
    active: true,
  },
];

export const DEFAULT_WHITE_LABEL_PACKAGING: PackagingSpec = {
  packagingType: 'custom_brand_box',
  boxBranding: true,
  thankYouCard: true,
  customTape: true,
  customSticker: true,
  customLabel: true,
  noSupplierBranding: true,
  noSupplierPriceInvoice: true,
  unitCost: 1.85,
  qcChecklistPassed: true,
  specialInstructions: 'Pack with LUMIÈRE ATELIER ribbon card. Strictly omit supplier branding and supplier pricing.',
};

export function getProductErpDefaults(p: Product, index: number) {
  const isDropship = index % 3 === 1;
  const isPrivateLabel = index % 3 === 2;
  const supplier =
    isDropship
      ? SEED_SUPPLIERS[1]
      : isPrivateLabel
        ? SEED_SUPPLIERS[0]
        : SEED_SUPPLIERS[2];

  const purchasePrice = p.purchasePrice ?? Number((p.price * 0.42).toFixed(2));
  const wholesalePrice = p.wholesalePrice ?? Number((p.price * 0.65).toFixed(2));
  const dealerPrice = p.dealerPrice ?? Number((p.price * 0.58).toFixed(2));
  const distributorPrice = p.distributorPrice ?? Number((p.price * 0.52).toFixed(2));
  const ownedStock = p.ownedStock ?? (isDropship ? Math.max(0, Math.floor(p.stock * 0.25)) : p.stock);
  const supplierStock = p.supplierStock ?? (isDropship || isPrivateLabel ? 320 : 180);

  return {
    purchasePrice,
    wholesalePrice,
    dealerPrice,
    distributorPrice,
    moq: p.moq ?? 12,
    supplierId: p.supplierId ?? supplier.id,
    supplierSku: p.supplierSku ?? `SUP-${p.sku}`,
    warehouseId: p.warehouseId ?? (index % 2 === 0 ? 'wh_mumbai_central' : 'wh_paris_atelier'),
    fulfillmentMethod:
      p.fulfillmentMethod ??
      (isDropship ? 'dropshipping' : isPrivateLabel ? 'private_label' : 'own_inventory'),
    packagingType: p.packagingType ?? (isPrivateLabel ? 'custom_brand_box' : 'cardboard_box'),
    privateLabelAvailable: p.privateLabelAvailable ?? true,
    ownedStock,
    supplierStock,
    reservedStock: p.reservedStock ?? 4,
    incomingStock: p.incomingStock ?? 60,
    damagedStock: p.damagedStock ?? 0,
    returnedStock: p.returnedStock ?? 1,
    taxRatePercent: p.taxRatePercent ?? 12,
    weightGrams: p.weightGrams ?? 140,
    dimensions: p.dimensions ?? '11 × 4 × 4 cm',
    material: p.material ?? 'Recycled Anodized Aluminum & Frosted Glass',
    batchNumber: p.batchNumber ?? `B26-${100 + index}`,
  } as const;
}

export function enrichProductWithErp(p: Product, index: number): Product {
  return {
    ...p,
    ...getProductErpDefaults(p, index),
  };
}

export const SEED_PURCHASE_ORDERS: PurchaseOrder[] = [
  {
    id: 'po_seed_2026_01',
    parentOrderId: 'ord_seed_b2c_1',
    customerUid: 'system_seed',
    supplierId: 'sup_kumano_botanicals',
    supplierName: 'Kumano Craft & Botanicals Co.',
    supplierEmail: 'orders@kumanocraft.example',
    channelMode: 'online_dropship',
    customerType: 'retail',
    items: [
      {
        productId: 'prod-crystal-gloss',
        sku: 'LA-LIP-009',
        supplierSku: 'SUP-LA-LIP-009',
        name: 'Crystal Nectar Lip Gloss & Liner Duo',
        shadeName: 'Rose Quartz',
        quantity: 2,
        unitCost: 15.96,
      },
    ],
    totalCost: 31.92,
    shippingCost: 4.5,
    packagingCost: 1.85,
    integrationType: 'Shopify',
    status: 'pending_dispatch',
    packagingSpec: DEFAULT_WHITE_LABEL_PACKAGING,
    dispatchNotes: 'Awaiting automated Shopify PO confirmation webhook.',
  },
  {
    id: 'po_seed_2026_02',
    parentOrderId: 'ord_seed_b2b_1',
    customerUid: 'system_seed',
    supplierId: 'sup_laboratoire_paris',
    supplierName: 'Laboratoire Lumière Paris',
    supplierEmail: 'fulfillment@laboratoirelumiere.example',
    channelMode: 'private_label',
    customerType: 'dealer',
    items: [
      {
        productId: 'prod-silk-serum',
        sku: 'LA-FND-004',
        supplierSku: 'SUP-LA-FND-004',
        name: 'Lumière Silk Serum Foundation SPF 30',
        shadeName: 'Warm Sand 210',
        quantity: 30,
        unitCost: 24.36,
      },
    ],
    totalCost: 730.8,
    shippingCost: 28,
    packagingCost: 36,
    integrationType: 'API',
    status: 'supplier_accepted',
    packagingSpec: {
      ...DEFAULT_WHITE_LABEL_PACKAGING,
      packagingType: 'wholesale_master_carton',
      qcChecklistPassed: true,
    },
    trackingNumber: 'DHL-PAR-8839201',
    carrier: 'DHL Express Freight',
    dispatchNotes: 'Private label batch #B26-102 sealed with Maison gold-foil box.',
  },
];

export const SEED_WHOLESALE_ACCOUNTS: WholesaleAccount[] = [
  {
    id: 'wacc_maison_bombay',
    userId: 'seed_dealer_bombay',
    businessName: 'Maison Aura Luxury Retail Pvt Ltd',
    contactName: 'Riya Malhotra',
    email: 'procurement@maisonaura.example',
    phone: '+91 98204 55110',
    gstNumber: '27AAACM4421B1Z8',
    tier: 'dealer',
    status: 'approved',
    creditLimit: 25000,
    creditUsed: 4800,
    creditTermsDays: 30,
    discountPercent: 42,
    assignedSalesRep: 'Aarav Mehta',
  },
  {
    id: 'wacc_tokyo_bridal',
    userId: 'seed_dist_tokyo',
    businessName: 'Ginza Bridal Studio Group',
    contactName: 'Haruka Sato',
    email: 'buying@ginzabridal.example',
    phone: '+81 3 5550 1982',
    gstNumber: 'JP-901000112233',
    tier: 'distributor',
    status: 'pending',
    creditLimit: 0,
    creditUsed: 0,
    creditTermsDays: 0,
    discountPercent: 0,
    assignedSalesRep: 'Camille Laurent',
  },
];

export const SEED_WHOLESALE_QUOTES: WholesaleQuote[] = [
  {
    id: 'rfq_seed_101',
    accountId: 'wacc_maison_bombay',
    userId: 'seed_dealer_bombay',
    businessName: 'Maison Aura Luxury Retail Pvt Ltd',
    items: [
      {
        productId: 'prod-rouge-velours',
        sku: 'LA-LIP-001',
        name: 'Rouge Velours Couture Lipstick',
        quantity: 60,
        targetUnitPrice: 23.5,
      },
      {
        productId: 'prod-bridal-coffret',
        sku: 'LA-KIT-018',
        name: 'Royal Bridal Atelier Coffret',
        quantity: 15,
        targetUnitPrice: 112.0,
      },
    ],
    requestedTotal: 3090,
    approvedTotal: 3180,
    status: 'approved',
    notes: 'Q3 Festive Bridal Trunk Pre-Allocation with private label ribbon insert.',
  },
];
