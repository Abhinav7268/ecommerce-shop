export type CurrencyCode =
  | 'USD'
  | 'INR'
  | 'GBP'
  | 'EUR'
  | 'CNY'
  | 'JPY'
  | 'CAD'
  | 'AUD'
  | 'AED'
  | 'SGD'
  | 'CHF'
  | 'SAR'
  | 'KRW'
  | 'BRL'
  | 'MXN'
  | 'NZD';

export type CountryCode =
  | 'IN'
  | 'US'
  | 'GB'
  | 'DE'
  | 'FR'
  | 'EU'
  | 'CN'
  | 'JP'
  | 'CA'
  | 'AU'
  | 'AE'
  | 'SG'
  | 'CH'
  | 'SA'
  | 'KR'
  | 'BR'
  | 'MX'
  | 'NZ';

export type LanguageCode = 'en' | 'hi' | 'fr' | 'de' | 'es' | 'zh' | 'ja' | 'ar';

export type MeasurementSystem = 'metric' | 'imperial';

export interface LockedCheckoutQuote {
  quoteId: string;
  quoteSignature: string;
  countryCode: CountryCode;
  countryName: string;
  settlementCurrency: CurrencyCode;
  lockedRate: number;
  rateSource: 'live' | 'reference';
  lockedAt: string;
  expiresAt: string;
  pricingMode: 'regional_fixed' | 'locked_fx';
  subtotalUsd: number;
  discountUsd: number;
  shippingUsd: number;
  taxUsd: number;
  customsDutyUsd: number;
  totalUsd: number;
  subtotalLocal: number;
  discountLocal: number;
  shippingLocal: number;
  taxLocal: number;
  customsDutyLocal: number;
  totalLocal: number;
  taxRatePercent: number;
  taxLabel: string;
  customsDutyRatePercent: number;
  customsSupported: boolean;
  customsNote: string;
  shippingCarrier: string;
  estimatedDelivery: string;
  freeShippingThresholdLocal: number;
  freeShippingApplied: boolean;
  codAvailable: boolean;
}

export type ModelType = 'lipstick' | 'bottle' | 'compact' | 'palette' | 'brush';

export type ProductFinish =
  | 'Velvet Matte'
  | 'Satin Gloss'
  | 'Luminous Dew'
  | 'Metallic Shimmer'
  | 'Precision';

export type ProductCollection = 'Signature' | 'Bridal' | 'Party' | 'Professional';

export type GatewayName =
  | 'Razorpay'
  | 'Cashfree'
  | 'PayU'
  | 'CCAvenue'
  | 'Stripe'
  | 'PayPal'
  | 'COD';

export type OrderChannel =
  | 'Online Store'
  | 'WhatsApp Orders'
  | 'Phone Orders'
  | 'Offline Sales'
  | 'Field Sales'
  | 'Retailer Orders'
  | 'Dealer Orders'
  | 'Distributor Orders'
  | 'Social Media Orders'
  | 'Marketplace Orders'
  | 'Admin Created Orders';

export type CustomerType = 'retail' | 'wholesale' | 'dealer' | 'distributor' | 'enterprise';

export type FulfillmentType =
  | 'own_inventory'
  | 'dropshipping'
  | 'private_label'
  | 'offline_wholesale'
  | 'mixed_split';

export type PackagingType =
  | 'poly_mailer'
  | 'cardboard_box'
  | 'custom_brand_box'
  | 'wholesale_master_carton';

export type SupplierIntegrationType =
  | 'API'
  | 'Shopify'
  | 'CSV'
  | 'Email'
  | 'WhatsApp'
  | 'Manual'
  | 'Portal';

export type ErpLifecycleStatus =
  | 'NEW'
  | 'PAYMENT_PENDING'
  | 'PAYMENT_CONFIRMED'
  | 'ORDER_VERIFIED'
  | 'ROUTING'
  | 'SUPPLIER_ASSIGNED'
  | 'PURCHASE_ORDER_CREATED'
  | 'SUPPLIER_ACCEPTED'
  | 'PROCESSING'
  | 'PACKED'
  | 'SHIPPED'
  | 'IN_TRANSIT'
  | 'OUT_FOR_DELIVERY'
  | 'DELIVERED'
  | 'CANCELLED'
  | 'REJECTED'
  | 'PAYMENT_FAILED'
  | 'OUT_OF_STOCK'
  | 'SUPPLIER_DELAYED'
  | 'RETURN_REQUESTED'
  | 'RETURN_APPROVED'
  | 'RETURNED'
  | 'REFUND_PENDING'
  | 'REFUNDED'
  | 'ON_HOLD'
  | 'MANUAL_REVIEW';

export type ErpRole =
  | 'super_admin'
  | 'admin'
  | 'operations_manager'
  | 'order_manager'
  | 'supplier_manager'
  | 'warehouse_manager'
  | 'finance_manager'
  | 'marketing_manager'
  | 'sales_rep'
  | 'customer_support'
  | 'merchandiser'
  | 'support'
  | 'analyst'
  | 'wholesale_customer'
  | 'supplier'
  | 'customer';

export interface PackagingSpec {
  packagingType: PackagingType;
  boxBranding: boolean;
  thankYouCard: boolean;
  customTape: boolean;
  customSticker: boolean;
  customLabel: boolean;
  noSupplierBranding: boolean;
  noSupplierPriceInvoice: boolean;
  unitCost: number;
  qcChecklistPassed?: boolean;
  specialInstructions?: string;
}

export interface OrderTimelineEntry {
  stage: string;
  timestamp: string;
  actor: string;
  note?: string;
}

export interface ProductShade {
  id: string;
  name: string;
  hex: string;
  undertone?: 'Warm' | 'Cool' | 'Neutral' | 'Universal';
}

export interface Product {
  id: string;
  name: string;
  brand: string;
  category: string;
  subcategory?: string;
  collection: ProductCollection;
  price: number; // Retail Base price in USD
  compareAtPrice?: number;
  stock: number; // Available sellable stock
  lowStockThreshold?: number;
  sku: string;
  barcode?: string;
  description: string;
  ingredients: string;
  finish: ProductFinish;
  modelType: ModelType;
  imageUrl: string;
  videoUrl?: string;
  shades: ProductShade[];
  skinTones?: string[];
  seoTitle?: string;
  seoDescription?: string;
  rating: number;
  reviewCount: number;
  featured?: boolean;
  trending?: boolean;
  newArrival?: boolean;
  bestSeller?: boolean;
  // ERP & Multi-Channel Extensions
  purchasePrice?: number;
  wholesalePrice?: number;
  dealerPrice?: number;
  distributorPrice?: number;
  moq?: number;
  supplierId?: string;
  supplierSku?: string;
  warehouseId?: string;
  fulfillmentMethod?: 'own_inventory' | 'dropshipping' | 'private_label';
  packagingType?: PackagingType;
  privateLabelAvailable?: boolean;
  ownedStock?: number;
  supplierStock?: number;
  reservedStock?: number;
  incomingStock?: number;
  damagedStock?: number;
  returnedStock?: number;
  weightGrams?: number;
  dimensions?: string;
  material?: string;
  taxRatePercent?: number;
  batchNumber?: string;
  expiryDate?: string;
  preorderEnabled?: boolean;
  subscriptionEligible?: boolean;
  regionalPrices?: Partial<Record<CurrencyCode, number>>;
  localizedCopy?: Partial<Record<LanguageCode, { tagline?: string; finish?: string }>>;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  parentId?: string;
  description?: string;
  imageUrl?: string;
  discountPercent?: number;
  visible?: boolean;
  sortOrder: number;
}

export interface Coupon {
  id: string;
  code: string;
  discountPercent: number;
  minOrderAmount?: number;
  active: boolean;
  expiresAt?: string;
}

export interface AutomationRule {
  id: string;
  name: string;
  trigger: string;
  action: string;
  active: boolean;
}

export type AnimationIntensity = 'subtle' | 'balanced' | 'cinematic';
export type MotionSpeed = 'slow' | 'normal' | 'snappy';
export type ParticleDensity = 'off' | 'low' | 'medium' | 'high';
export type PageTransitionStyle = 'cinematic' | 'slide' | 'scale' | 'fade';
export type LightingIntensity = 'subtle' | 'balanced' | 'cinematic' | 'ultra';
export type NeonGlowLevel = 'low' | 'medium' | 'high';
export type LightSpeed = 'slow' | 'normal' | 'dynamic';
export type LightColorPreset = 'rainbow' | 'cyber_cyan' | 'royal_magenta' | 'emerald_aqua' | 'solar_gold';

export interface SiteSettings {
  logoText?: string;
  heroTitle: string;
  heroSubtitle: string;
  heroImageUrl?: string;
  promoBannerText?: string;
  promoBannerActive: boolean;
  flashSaleActive: boolean;
  flashSaleDiscount?: number;
  accentColor?: string;
  defaultTheme?: 'light' | 'dark';
  seasonalTheme?: 'atelier' | 'bridal' | 'festival' | 'obsidian';
  enable3DEffects?: boolean;
  enableAnimations?: boolean;
  animationIntensity?: AnimationIntensity;
  motionSpeed?: MotionSpeed;
  backgroundEffects?: boolean;
  particleDensity?: ParticleDensity;
  hoverEffects?: boolean;
  pageTransitionStyle?: PageTransitionStyle;
  mobileOptimization?: boolean;
  reducedMotionMode?: boolean;
  globalLightingEnabled?: boolean;
  ambientLightingIntensity?: LightingIntensity;
  neonGlowIntensity?: NeonGlowLevel;
  lightAnimationSpeed?: LightSpeed;
  lightColorPreset?: LightColorPreset;
  borderGlowEnabled?: boolean;
  backgroundLightEffects?: boolean;
  mouseFollowLighting?: boolean;
  mobileLightingOptimization?: boolean;
  autoRouteDropship?: boolean;
  autoDispatchPo?: boolean;
  lowStockAlertEnabled?: boolean;
  codEnabled?: boolean;
  emailNotificationsEnabled?: boolean;
  whatsappAlertsEnabled?: boolean;
  defaultTaxRate?: number;
  freeShippingThreshold?: number;
  defaultCurrency?: CurrencyCode;
  supportEmail?: string;
  whatsappSupportPhone?: string;
  fraudHighValueThresholdUsd?: number;
  fraudAutoHoldScore?: number;
  automationRules?: AutomationRule[];
  updatedAt?: unknown;
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  category?: string;
  excerpt: string;
  content: string;
  coverImage?: string;
  author?: string;
  published: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface CmsPage {
  id: string;
  title: string;
  slug: string;
  group: 'company' | 'policy' | 'support' | 'custom';
  content: string;
  visible: boolean;
  updatedAt?: unknown;
}

export interface SupportTicket {
  id: string;
  userId?: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  orderId?: string;
  status: 'open' | 'in_progress' | 'resolved';
  adminReply?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface NewsletterSubscriber {
  id: string;
  email: string;
  subscribedAt?: unknown;
}

export interface ShippingZone {
  id: string;
  name: string;
  region: string;
  baseRate: number;
  freeThreshold: number;
  estimatedDays: string;
  codAvailable: boolean;
  active: boolean;
}

export interface Review {
  id: string;
  productId: string;
  userId: string;
  authorName: string;
  rating: number;
  title: string;
  comment: string;
  shadeName?: string;
  photoUrl?: string;
  verifiedPurchase?: boolean;
  createdAt?: unknown;
}

export interface SavedAddress {
  id: string;
  label: string;
  fullName: string;
  phone: string;
  line1: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  isDefault?: boolean;
}

export interface UserProfile {
  uid: string;
  displayName: string;
  skinTone?: string;
  undertone?: string;
  loyaltyPoints?: number;
  customerSegment?: CustomerType;
  preferredCountry?: CountryCode;
  preferredCurrency?: CurrencyCode;
  preferredLanguage?: LanguageCode;
  localizationConsent?: 'accepted' | 'dismissed' | 'custom';
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface UserPrivateInfo {
  uid: string;
  email: string;
  phone?: string;
  addresses?: SavedAddress[];
  updatedAt?: unknown;
}

export interface WishlistItem {
  productId: string;
  userId: string;
  shadeId?: string;
  addedAt?: unknown;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  read: boolean;
  createdAt?: unknown;
}

export interface CartItem {
  productId: string;
  name: string;
  brand: string;
  price: number;
  imageUrl: string;
  shade: ProductShade;
  quantity: number;
  subscriptionIntervalDays?: 30 | 60 | 90;
  bundleId?: string;
}

export type OrderStatus =
  | 'processing'
  | 'confirmed'
  | 'packed'
  | 'shipped'
  | 'out_for_delivery'
  | 'delivered'
  | 'return_requested'
  | 'returned'
  | 'cancelled';

export type PaymentStatus = 'pending' | 'paid' | 'failed' | 'refunded' | 'partially_refunded';

export interface Order {
  id: string;
  userId: string;
  customerName?: string;
  customerEmail?: string;
  items: {
    productId: string;
    name: string;
    shadeName: string;
    shadeHex: string;
    quantity: number;
    unitPrice: number;
    purchaseCost?: number;
    supplierId?: string;
    fulfillmentMethod?: string;
  }[];
  subtotal: number;
  discount: number;
  total: number;
  currency: string;
  paymentGateway: GatewayName;
  paymentMethod: string;
  paymentStatus: PaymentStatus;
  orderStatus: OrderStatus;
  trackingNumber?: string;
  couponCode?: string;
  shippingAddress: SavedAddress;
  refundStatus?: 'none' | 'requested' | 'partial' | 'full';
  refundAmount?: number;
  returnReason?: string;
  // ERP Multi-Channel, Routing & P&L Extensions
  orderSource?: OrderChannel;
  salesChannel?: 'D2C_ONLINE' | 'WHOLESALE_B2B' | 'OFFLINE_DIRECT' | 'MARKETPLACE';
  customerType?: CustomerType;
  fulfillmentType?: FulfillmentType;
  erpStatus?: ErpLifecycleStatus;
  warehouseId?: string;
  parentOrderId?: string;
  supplierOrderIds?: string[];
  purchaseCost?: number;
  shippingCost?: number;
  packagingCost?: number;
  gatewayFee?: number;
  taxAmount?: number;
  grossProfit?: number;
  netProfit?: number;
  packagingSpec?: PackagingSpec;
  salesRepName?: string;
  notes?: string;
  countryCode?: string;
  customsDuty?: number;
  lockedExchangeRate?: number;
  quoteId?: string;
  settlementTotal?: number;
  taxLabel?: string;
  shippingCarrier?: string;
  giftCardCode?: string;
  giftCardDiscount?: number;
  fraudScore?: number;
  fraudFlags?: string[];
  timeline?: OrderTimelineEntry[];
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface Transaction {
  id: string;
  orderId: string;
  userId: string;
  gateway: GatewayName;
  method: string;
  amount: number;
  currency: string;
  status: 'initiated' | 'succeeded' | 'failed' | 'refunded' | 'partially_refunded';
  gatewayOrderId?: string;
  gatewayPaymentId?: string;
  signatureVerified: boolean;
  webhookReceived?: boolean;
  refundAmount?: number;
  failureReason?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface Supplier {
  id: string;
  companyName: string;
  contactName: string;
  email: string;
  phone: string;
  whatsapp?: string;
  gstNumber?: string;
  country: string;
  supplierType: 'dropship' | 'manufacturer' | 'private_label' | 'wholesale_distributor';
  integrationType: SupplierIntegrationType;
  webhookUrl?: string;
  moq: number;
  paymentTerms: string;
  leadTimeDays: number;
  performanceScore: number;
  privateLabelCapable: boolean;
  brandingOptions: string[];
  verified: boolean;
  active: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export type PurchaseOrderStatus =
  | 'pending_dispatch'
  | 'sent'
  | 'supplier_accepted'
  | 'packed'
  | 'shipped'
  | 'delayed'
  | 'rejected';

export interface PurchaseOrder {
  id: string;
  parentOrderId: string;
  customerUid: string;
  supplierId: string;
  supplierName: string;
  supplierEmail: string;
  channelMode: 'online_dropship' | 'private_label' | 'warehouse_restock' | 'offline_wholesale';
  customerType: CustomerType;
  items: {
    productId: string;
    sku: string;
    supplierSku?: string;
    name: string;
    shadeName?: string;
    quantity: number;
    unitCost: number;
  }[];
  totalCost: number;
  shippingCost: number;
  packagingCost: number;
  integrationType: SupplierIntegrationType;
  status: PurchaseOrderStatus;
  packagingSpec: PackagingSpec;
  trackingNumber?: string;
  carrier?: string;
  qcPhotoUrl?: string;
  dispatchNotes?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface Warehouse {
  id: string;
  name: string;
  code: string;
  city: string;
  country: string;
  managerName: string;
  capacityUnits: number;
  active: boolean;
  updatedAt?: unknown;
}

export interface WholesaleAccount {
  id: string;
  userId: string;
  businessName: string;
  contactName: string;
  email: string;
  phone: string;
  gstNumber: string;
  tier: Exclude<CustomerType, 'retail'>;
  status: 'pending' | 'approved' | 'rejected';
  creditLimit: number;
  creditUsed: number;
  creditTermsDays: number;
  discountPercent: number;
  assignedSalesRep?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface WholesaleQuote {
  id: string;
  accountId: string;
  userId: string;
  businessName: string;
  items: {
    productId: string;
    sku: string;
    name: string;
    quantity: number;
    targetUnitPrice: number;
  }[];
  requestedTotal: number;
  approvedTotal?: number;
  status: 'requested' | 'negotiating' | 'approved' | 'converted' | 'rejected';
  notes?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface AuditLogEntry {
  id: string;
  actorUid: string;
  actorEmail: string;
  actorRole: string;
  action: string;
  entityType: string;
  entityId: string;
  details: string;
  createdAt?: unknown;
}

export interface AdminRecord {
  uid: string;
  email: string;
  role?: ErpRole;
  grantedAt?: unknown;
}

// ============================================================================
// NEXT-GEN ENTERPRISE FEATURE TYPES
// ============================================================================
export interface ProductBundle {
  id: string;
  name: string;
  tagline: string;
  description: string;
  productIds: string[];
  bundlePriceUsd: number;
  compareAtUsd: number;
  discountPercent: number;
  badge?: string;
  imageUrl?: string;
  active: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface SubscriptionPlan {
  id: string;
  userId: string;
  customerEmail?: string;
  productId: string;
  productName: string;
  shadeName: string;
  shadeHex: string;
  unitPriceUsd: number;
  discountPercent: number;
  intervalDays: 30 | 60 | 90;
  quantity: number;
  status: 'active' | 'paused' | 'cancelled';
  nextBillingDate: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface GiftCard {
  id: string;
  code: string;
  initialBalanceUsd: number;
  balanceUsd: number;
  recipientEmail?: string;
  senderName?: string;
  message?: string;
  active: boolean;
  expiresAt?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface StockAlert {
  id: string;
  productId: string;
  productName: string;
  userId?: string;
  email: string;
  alertType: 'back_in_stock' | 'preorder_waitlist';
  status: 'waiting' | 'notified';
  createdAt?: unknown;
}

export interface ReferralRecord {
  id: string;
  referrerUid: string;
  referralCode: string;
  refereeEmail?: string;
  rewardPoints: number;
  status: 'pending' | 'credited';
  createdAt?: unknown;
}

export interface MarketingCampaign {
  id: string;
  name: string;
  channel: 'email' | 'whatsapp' | 'sms' | 'social' | 'affiliate' | 'influencer' | 'abandoned_cart';
  status: 'draft' | 'active' | 'paused' | 'completed';
  audienceSegment: string;
  budgetUsd: number;
  spendUsd: number;
  revenueUsd: number;
  impressions: number;
  clicks: number;
  conversions: number;
  utmCampaign: string;
  copyPreview?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface ExpenseRecord {
  id: string;
  title: string;
  category: 'marketing' | 'warehouse' | 'logistics' | 'supplier_payout' | 'payroll' | 'software' | 'tax' | 'credit_note' | 'debit_note';
  amountUsd: number;
  currency: string;
  vendor?: string;
  referenceId?: string;
  dateIso: string;
  status: 'recorded' | 'reconciled';
  notes?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface AutomationWorkflow {
  id: string;
  name: string;
  triggerEvent:
    | 'order.created'
    | 'order.high_value'
    | 'stock.low'
    | 'cart.abandoned'
    | 'supplier.delayed'
    | 'wholesale.applied'
    | 'subscription.due';
  actionType:
    | 'route_supplier_po'
    | 'flag_fraud_review'
    | 'create_restock_task'
    | 'queue_recovery_campaign'
    | 'notify_admin'
    | 'dispatch_webhook';
  webhookUrl?: string;
  conditionSummary: string;
  active: boolean;
  runsCount: number;
  lastRunAt?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface IntegrationConfig {
  id: string;
  name: string;
  category: 'commerce' | 'payments' | 'shipping' | 'messaging' | 'marketing' | 'erp_crm' | 'automation';
  provider: string;
  status: 'connected' | 'webhook_verified' | 'awaiting_credentials' | 'disabled';
  endpointUrl?: string;
  permissions: string[];
  lastSyncAt?: string;
  syncNote?: string;
  active: boolean;
  updatedAt?: unknown;
}

export interface AiTaskItem {
  id: string;
  agentRole: string;
  title: string;
  description: string;
  category: 'inventory' | 'pricing' | 'marketing' | 'fraud' | 'supplier' | 'finance' | 'strategy';
  impactSummary: string;
  requiresApproval: boolean;
  status: 'pending_approval' | 'approved' | 'rejected' | 'executed';
  approvedBy?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface SecuritySession {
  id: string;
  userId: string;
  userEmail: string;
  userAgent: string;
  platform: string;
  countryCode?: string;
  status: 'active' | 'revoked';
  createdAt?: unknown;
}

export interface FraudCheckResult {
  score: number;
  level: 'low' | 'medium' | 'high';
  requiresManualReview: boolean;
  flags: string[];
  evaluatedAt: string;
}

export interface SystemHealthReport {
  status: 'healthy' | 'degraded';
  uptimeSeconds: number;
  nodeVersion: string;
  memoryMb: { rss: number; heapUsed: number; heapTotal: number };
  providers: {
    geminiAi: boolean;
    liveFxRates: boolean;
    razorpayLive: boolean;
    stripeLive: boolean;
    paypalLive: boolean;
  };
  rateLimitStats: {
    activeBuckets: number;
    maxRequestsPerMinute: number;
  };
  timestamp: string;
}

export interface CurrencyMeta {
  code: CurrencyCode;
  symbol: string;
  name: string;
  locale: string;
  decimals: number;
  rate: number;
}

export const CURRENCY_RATES: Record<CurrencyCode, CurrencyMeta> = {
  USD: { code: 'USD', symbol: '$', name: 'US Dollar', locale: 'en-US', decimals: 2, rate: 1 },
  INR: { code: 'INR', symbol: '₹', name: 'Indian Rupee', locale: 'en-IN', decimals: 0, rate: 84.5 },
  GBP: { code: 'GBP', symbol: '£', name: 'British Pound', locale: 'en-GB', decimals: 2, rate: 0.79 },
  EUR: { code: 'EUR', symbol: '€', name: 'Euro', locale: 'de-DE', decimals: 2, rate: 0.92 },
  CNY: { code: 'CNY', symbol: '¥', name: 'Chinese Yuan', locale: 'zh-CN', decimals: 2, rate: 7.24 },
  JPY: { code: 'JPY', symbol: '¥', name: 'Japanese Yen', locale: 'ja-JP', decimals: 0, rate: 154 },
  CAD: { code: 'CAD', symbol: 'C$', name: 'Canadian Dollar', locale: 'en-CA', decimals: 2, rate: 1.39 },
  AUD: { code: 'AUD', symbol: 'A$', name: 'Australian Dollar', locale: 'en-AU', decimals: 2, rate: 1.53 },
  AED: { code: 'AED', symbol: 'د.إ', name: 'UAE Dirham', locale: 'en-AE', decimals: 2, rate: 3.67 },
  SGD: { code: 'SGD', symbol: 'S$', name: 'Singapore Dollar', locale: 'en-SG', decimals: 2, rate: 1.34 },
  CHF: { code: 'CHF', symbol: 'CHF ', name: 'Swiss Franc', locale: 'de-CH', decimals: 2, rate: 0.88 },
  SAR: { code: 'SAR', symbol: '﷼', name: 'Saudi Riyal', locale: 'en-SA', decimals: 2, rate: 3.75 },
  KRW: { code: 'KRW', symbol: '₩', name: 'South Korean Won', locale: 'ko-KR', decimals: 0, rate: 1385 },
  BRL: { code: 'BRL', symbol: 'R$', name: 'Brazilian Real', locale: 'pt-BR', decimals: 2, rate: 5.78 },
  MXN: { code: 'MXN', symbol: 'MX$', name: 'Mexican Peso', locale: 'es-MX', decimals: 2, rate: 20.1 },
  NZD: { code: 'NZD', symbol: 'NZ$', name: 'New Zealand Dollar', locale: 'en-NZ', decimals: 2, rate: 1.68 },
};

export const ALL_CURRENCIES: CurrencyCode[] = Object.keys(CURRENCY_RATES) as CurrencyCode[];

let liveExchangeRates: Partial<Record<CurrencyCode, number>> = {};

export function setLiveExchangeRates(rates: Partial<Record<string, number>>): void {
  const next: Partial<Record<CurrencyCode, number>> = {};
  for (const code of ALL_CURRENCIES) {
    const val = rates[code];
    if (typeof val === 'number' && Number.isFinite(val) && val > 0) {
      next[code] = val;
    }
  }
  liveExchangeRates = next;
}

export function getLiveExchangeRate(currency: CurrencyCode): number {
  return liveExchangeRates[currency] ?? CURRENCY_RATES[currency]?.rate ?? 1;
}

export function formatMoney(
  amount: number,
  currency: CurrencyCode = 'USD',
  options?: { alreadyConverted?: boolean; overrideRate?: number },
): string {
  const meta = CURRENCY_RATES[currency] || CURRENCY_RATES.USD;
  const rate = options?.overrideRate ?? getLiveExchangeRate(currency);
  const val = options?.alreadyConverted ? amount : amount * rate;
  const safeVal = Number.isFinite(val) ? val : 0;
  if (meta.decimals === 0) {
    return `${meta.symbol}${Math.round(safeVal).toLocaleString(meta.locale)}`;
  }
  return `${meta.symbol}${safeVal.toLocaleString(meta.locale, {
    minimumFractionDigits: meta.decimals,
    maximumFractionDigits: meta.decimals,
  })}`;
}
