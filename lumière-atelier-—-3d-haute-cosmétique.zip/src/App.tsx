import React, { useEffect, useMemo, useState } from 'react';
import {
  Bell,
  Camera,
  ChevronDown,
  Heart,
  Menu,
  Mic,
  Minus,
  Moon,
  Plus,
  Scale,
  Search,
  ShoppingBag,
  Sparkles,
  Star,
  Sun,
  Trash2,
  X,
  Zap,
} from 'lucide-react';
import {
  collection,
  deleteDoc,
  doc,
  getDocs,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { onAuthStateChanged, signOut, User } from 'firebase/auth';
import { ADMIN_EMAIL, auth, db, handleFirestoreError, OperationType } from './lib/firebase';
import {
  SEED_CATEGORIES,
  SEED_COUPONS,
  SEED_PRODUCTS,
  SEED_REVIEWS,
  SEED_SITE_SETTINGS,
} from './data/seedCatalog';
import { SEED_BLOG_POSTS, SEED_CMS_PAGES, SEED_SHIPPING_ZONES } from './data/seedContent';
import {
  enrichProductWithErp,
  SEED_PURCHASE_ORDERS,
  SEED_SUPPLIERS,
  SEED_WAREHOUSES,
  SEED_WHOLESALE_ACCOUNTS,
  SEED_WHOLESALE_QUOTES,
} from './data/seedErp';
import {
  SEED_AI_TASKS,
  SEED_AUTOMATION_WORKFLOWS,
  SEED_BUNDLES,
  SEED_EXPENSES,
  SEED_GIFT_CARDS,
  SEED_INTEGRATIONS,
  SEED_MARKETING_CAMPAIGNS,
} from './data/seedNextGen';
import {
  AiTaskItem,
  ALL_CURRENCIES,
  AuditLogEntry,
  AutomationWorkflow,
  BlogPost,
  CartItem,
  Category,
  CmsPage,
  Coupon,
  CURRENCY_RATES,
  CurrencyCode,
  ExpenseRecord,
  formatMoney,
  GiftCard,
  IntegrationConfig,
  MarketingCampaign,
  NotificationItem,
  Order,
  Product,
  ProductBundle,
  ProductCollection,
  ProductShade,
  PurchaseOrder,
  ReferralRecord,
  Review,
  SecuritySession,
  ShippingZone,
  SiteSettings,
  StockAlert,
  SubscriptionPlan,
  Supplier,
  SupportTicket,
  Transaction,
  UserPrivateInfo,
  UserProfile,
  Warehouse,
  WholesaleAccount,
  WholesaleQuote,
  WishlistItem,
} from './types/store';
import { ThreeCosmeticStage } from './components/ThreeCosmeticStage';
import { ProductDetailModal } from './components/ProductDetailModal';
import { VirtualTryOnModal } from './components/VirtualTryOnModal';
import { AiShadeFinderModal } from './components/AiShadeFinderModal';
import { CompareDrawer } from './components/CompareDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { CustomerDashboard } from './components/CustomerDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { AuthModal } from './components/AuthModal';
import { EnterpriseModalView, EnterprisePagesModal } from './components/EnterprisePagesModal';
import { WholesalePortalModal } from './components/WholesalePortalModal';
import { SupplierPortalModal } from './components/SupplierPortalModal';
import { AiShoppingChatbot } from './components/AiShoppingChatbot';
import { VisualSearchModal } from './components/VisualSearchModal';
import { OfflineIndicator, PWAInstallButton } from './components/PWAControls';
import { AnimatePresence, motion } from 'motion/react';
import { ConfirmDialog } from './components/ConfirmDialog';
import { ParticleField } from './components/ParticleField';
import { AmbientLightingEngine } from './components/AmbientLightingEngine';
import { MotionProvider } from './context/MotionContext';
import { useLocalization } from './context/LocalizationContext';
import {
  CountryConsentBanner,
  CountryCurrencySelectorModal,
  CountryCurrencyTrigger,
} from './components/LocalizationControls';
import { getLocalizedProductInfo, getLocalizedProductPrice } from './lib/localization';
import {
  CinematicSection,
  FloatingQuickDock,
  MagneticButton,
  MorphingLightField,
  ScrollProgressBeam,
  Tilt3DCard,
} from './components/MotionPrimitives';
import { getCategoryStyle } from './lib/themePalette';

function matchesColorFamily(hex: string, family: string): boolean {
  if (family === 'All') return true;
  const r = parseInt(hex.slice(1, 3), 16) || 0;
  const g = parseInt(hex.slice(3, 5), 16) || 0;
  const b = parseInt(hex.slice(5, 7), 16) || 0;
  if (family === 'Reds & Berries') return r > g + 35 && r > 100;
  if (family === 'Nudes & Neutrals') return r > 150 && g > 110 && Math.abs(r - g) < 65;
  if (family === 'Golds & Bronzes') return r > 140 && g > 90 && b < 110;
  if (family === 'Plums & Noir') return r < 130 && g < 90;
  return true;
}

type DiscoveryTab = 'all' | 'new' | 'trending' | 'bestsellers' | 'offers';
type SortOption = 'featured' | 'price_asc' | 'price_desc' | 'rating' | 'newest';
type PriceTier = 'all' | 'under50' | '50to100' | 'over100';

export default function App() {
  // Theme State (Light / Dark)
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    try {
      return localStorage.getItem('lumiere_theme') === 'dark';
    } catch {
      return false;
    }
  });

  // Catalog & Enterprise Content State
  const [products, setProducts] = useState<Product[]>(SEED_PRODUCTS);
  const [categories, setCategories] = useState<Category[]>(SEED_CATEGORIES);
  const [coupons, setCoupons] = useState<Coupon[]>(SEED_COUPONS);
  const [reviews, setReviews] = useState<Review[]>(SEED_REVIEWS);
  const [siteSettings, setSiteSettings] = useState<SiteSettings>(SEED_SITE_SETTINGS);
  const [blogPosts, setBlogPosts] = useState<BlogPost[]>(SEED_BLOG_POSTS);
  const [cmsPages, setCmsPages] = useState<CmsPage[]>(SEED_CMS_PAGES);
  const [shippingZones, setShippingZones] = useState<ShippingZone[]>(SEED_SHIPPING_ZONES);
  const [promoDismissed, setPromoDismissed] = useState(false);

  // Auth & User State
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [privateInfo, setPrivateInfo] = useState<UserPrivateInfo | null>(null);
  const [wishlist, setWishlist] = useState<WishlistItem[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [supportTickets, setSupportTickets] = useState<SupportTicket[]>([]);
  const [customers, setCustomers] = useState<UserProfile[]>([]);

  // Unified ERP, Wholesale, Dropshipping & Supplier State
  const [suppliers, setSuppliers] = useState<Supplier[]>(SEED_SUPPLIERS);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>(SEED_PURCHASE_ORDERS);
  const [warehouses, setWarehouses] = useState<Warehouse[]>(SEED_WAREHOUSES);
  const [wholesaleAccounts, setWholesaleAccounts] = useState<WholesaleAccount[]>(SEED_WHOLESALE_ACCOUNTS);
  const [wholesaleQuotes, setWholesaleQuotes] = useState<WholesaleQuote[]>(SEED_WHOLESALE_QUOTES);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);

  // Next-Gen Enterprise & Growth State
  const [bundles, setBundles] = useState<ProductBundle[]>(SEED_BUNDLES);
  const [giftCards, setGiftCards] = useState<GiftCard[]>(SEED_GIFT_CARDS);
  const [subscriptions, setSubscriptions] = useState<SubscriptionPlan[]>([]);
  const [stockAlerts, setStockAlerts] = useState<StockAlert[]>([]);
  const [referrals, setReferrals] = useState<ReferralRecord[]>([]);
  const [marketingCampaigns, setMarketingCampaigns] = useState<MarketingCampaign[]>(SEED_MARKETING_CAMPAIGNS);
  const [expenses, setExpenses] = useState<ExpenseRecord[]>(SEED_EXPENSES);
  const [automationWorkflows, setAutomationWorkflows] = useState<AutomationWorkflow[]>(SEED_AUTOMATION_WORKFLOWS);
  const [integrations, setIntegrations] = useState<IntegrationConfig[]>(SEED_INTEGRATIONS);
  const [aiTasks, setAiTasks] = useState<AiTaskItem[]>(SEED_AI_TASKS);
  const [securitySessions, setSecuritySessions] = useState<SecuritySession[]>([]);

  // Global Localization (Country, Currency, Live FX, Language & Persistence)
  const {
    country,
    currency,
    setCurrency,
    language,
    isRtl,
    rateSource,
    syncUserProfile,
    setSelectorOpen,
    t,
  } = useLocalization();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchFocused, setSearchFocused] = useState(false);
  const [voiceListening, setVoiceListening] = useState(false);
  const [megaMenuOpen, setMegaMenuOpen] = useState(false);
  const [discoveryTab, setDiscoveryTab] = useState<DiscoveryTab>('all');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedCollection, setSelectedCollection] = useState<'All' | ProductCollection>('All');
  const [selectedSkinTone, setSelectedSkinTone] = useState('All');
  const [selectedColorFamily, setSelectedColorFamily] = useState('All');
  const [priceTier, setPriceTier] = useState<PriceTier>('all');
  const [inStockOnly, setInStockOnly] = useState(false);
  const [sortBy, setSortBy] = useState<SortOption>('featured');
  const [cardSelectedShades, setCardSelectedShades] = useState<Record<string, ProductShade>>({});

  // Hero 3D Showcase Product & Shade
  const [heroProduct, setHeroProduct] = useState<Product>(SEED_PRODUCTS[0]);
  const [heroShade, setHeroShade] = useState<ProductShade>(SEED_PRODUCTS[0].shades[0]);

  // Recently Viewed & Cart
  const [recentIds, setRecentIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('lumiere_recent');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('lumiere_bag');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Modals & Drawers
  const [bagOpen, setBagOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [enterpriseModal, setEnterpriseModal] = useState<{
    view: EnterpriseModalView;
    slug?: string;
  } | null>(null);
  const [activeProductModal, setActiveProductModal] = useState<{ product: Product; shade?: ProductShade } | null>(null);
  const [tryOnTarget, setTryOnTarget] = useState<{ product: Product; shade: ProductShade } | null>(null);
  const [shadeFinderOpen, setShadeFinderOpen] = useState(false);
  const [compareItems, setCompareItems] = useState<Product[]>([]);
  const [compareOpen, setCompareOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [customerDashOpen, setCustomerDashOpen] = useState(false);
  const [adminDashOpen, setAdminDashOpen] = useState(false);
  const [wholesaleOpen, setWholesaleOpen] = useState(false);
  const [supplierPortalOpen, setSupplierPortalOpen] = useState(false);
  const [chatbotOpen, setChatbotOpen] = useState(false);
  const [visualSearchOpen, setVisualSearchOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [clearBagConfirmOpen, setClearBagConfirmOpen] = useState(false);
  const [catalogHydrating, setCatalogHydrating] = useState(true);
  const [bagPulseKey, setBagPulseKey] = useState(0);
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const isAdmin = Boolean(user && user.emailVerified && user.email === ADMIN_EMAIL);
  const unreadNotificationsCount = useMemo(
    () => notifications.filter((n) => !n.read).length,
    [notifications],
  );

  const notify = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2800);
  };

  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
    try {
      localStorage.setItem('lumiere_theme', darkMode ? 'dark' : 'light');
    } catch {
      // Ignore storage errors
    }
  }, [darkMode]);

  useEffect(() => {
    syncUserProfile(user?.uid, profile);
  }, [user?.uid, profile, syncUserProfile]);

  useEffect(() => {
    try {
      localStorage.setItem('lumiere_bag', JSON.stringify(cart));
    } catch {
      // Ignore quota errors
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem('lumiere_recent', JSON.stringify(recentIds));
    } catch {
      // Ignore quota errors
    }
  }, [recentIds]);

  const openProductModal = (product: Product, shade?: ProductShade) => {
    setActiveProductModal({ product, shade });
    setRecentIds((prev) => [product.id, ...prev.filter((id) => id !== product.id)].slice(0, 6));
  };

  // Public Firestore Listeners
  useEffect(() => {
    const hydrateTimer = window.setTimeout(() => setCatalogHydrating(false), 420);
    const unsubProducts = onSnapshot(
      collection(db, 'products'),
      (snap) => {
        if (!snap.empty) {
          setProducts(snap.docs.map((d) => d.data() as Product));
        }
        setCatalogHydrating(false);
      },
      (err) => {
        console.warn('Products listener notice:', err.message);
        setCatalogHydrating(false);
      },
    );

    const unsubCategories = onSnapshot(
      collection(db, 'categories'),
      (snap) => {
        if (!snap.empty) {
          setCategories(
            snap.docs
              .map((d) => d.data() as Category)
              .sort((a, b) => a.sortOrder - b.sortOrder),
          );
        }
      },
      (err) => console.warn('Categories listener notice:', err.message),
    );

    const unsubCoupons = onSnapshot(
      collection(db, 'coupons'),
      (snap) => {
        if (!snap.empty) setCoupons(snap.docs.map((d) => d.data() as Coupon));
      },
      (err) => console.warn('Coupons listener notice:', err.message),
    );

    const unsubReviews = onSnapshot(
      collection(db, 'reviews'),
      (snap) => {
        if (!snap.empty) setReviews(snap.docs.map((d) => d.data() as Review));
      },
      (err) => console.warn('Reviews listener notice:', err.message),
    );

    const unsubSettings = onSnapshot(
      doc(db, 'siteSettings', 'main'),
      (snap) => {
        if (snap.exists()) {
          const next = snap.data() as SiteSettings;
          setSiteSettings(next);
          if (!localStorage.getItem('lumiere_theme') && next.defaultTheme) {
            setDarkMode(next.defaultTheme === 'dark');
          }
        }
      },
      (err) => console.warn('Settings listener notice:', err.message),
    );

    const unsubBlog = onSnapshot(
      query(collection(db, 'blogPosts'), where('published', '==', true)),
      (snap) => {
        if (!snap.empty) setBlogPosts(snap.docs.map((d) => d.data() as BlogPost));
      },
      (err) => console.warn('Blog listener notice:', err.message),
    );

    const unsubPages = onSnapshot(
      collection(db, 'cmsPages'),
      (snap) => {
        if (!snap.empty) setCmsPages(snap.docs.map((d) => d.data() as CmsPage));
      },
      (err) => console.warn('CMS listener notice:', err.message),
    );

    const unsubZones = onSnapshot(
      collection(db, 'shippingZones'),
      (snap) => {
        if (!snap.empty) setShippingZones(snap.docs.map((d) => d.data() as ShippingZone));
      },
      (err) => console.warn('Shipping zones notice:', err.message),
    );

    const unsubBundles = onSnapshot(
      collection(db, 'bundles'),
      (snap) => {
        if (!snap.empty) setBundles(snap.docs.map((d) => d.data() as ProductBundle));
      },
      (err) => console.warn('Bundles listener notice:', err.message),
    );

    return () => {
      window.clearTimeout(hydrateTimer);
      unsubProducts();
      unsubCategories();
      unsubCoupons();
      unsubReviews();
      unsubSettings();
      unsubBlog();
      unsubPages();
      unsubZones();
      unsubBundles();
    };
  }, []);

  // Auth Listener & Bootstrap
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      setAuthReady(true);
      if (firebaseUser) {
        try {
          await setDoc(
            doc(db, 'users', firebaseUser.uid),
            {
              uid: firebaseUser.uid,
              displayName: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'Client',
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            },
            { merge: true },
          );
          await setDoc(
            doc(db, 'users', firebaseUser.uid, 'private', 'info'),
            {
              uid: firebaseUser.uid,
              email: firebaseUser.email || '',
              updatedAt: serverTimestamp(),
            },
            { merge: true },
          );

          // Admin first-login bootstrap seeding
          if (firebaseUser.emailVerified && firebaseUser.email === ADMIN_EMAIL) {
            await setDoc(
              doc(db, 'admins', firebaseUser.uid),
              {
                uid: firebaseUser.uid,
                email: firebaseUser.email,
                role: 'super_admin',
                grantedAt: serverTimestamp(),
              },
              { merge: true },
            );

            const [existingProds, existingPages, existingBlog, existingSuppliers] = await Promise.all([
              getDocs(collection(db, 'products')),
              getDocs(collection(db, 'cmsPages')),
              getDocs(query(collection(db, 'blogPosts'), where('published', '==', true))),
              getDocs(collection(db, 'suppliers')),
            ]);

            if (existingProds.empty) {
              const batch = writeBatch(db);
              SEED_PRODUCTS.forEach((p, idx) => {
                batch.set(doc(db, 'products', p.id), {
                  ...enrichProductWithErp(p, idx),
                  createdAt: serverTimestamp(),
                  updatedAt: serverTimestamp(),
                });
              });
              for (const c of SEED_CATEGORIES) {
                batch.set(doc(db, 'categories', c.id), c);
              }
              for (const cp of SEED_COUPONS) {
                batch.set(doc(db, 'coupons', cp.id), cp);
              }
              batch.set(doc(db, 'siteSettings', 'main'), {
                ...SEED_SITE_SETTINGS,
                updatedAt: serverTimestamp(),
              });
              for (const r of SEED_REVIEWS) {
                batch.set(doc(db, 'reviews', r.id), {
                  ...r,
                  userId: firebaseUser.uid,
                  createdAt: serverTimestamp(),
                });
              }
              await batch.commit();
            }

            if (existingPages.empty || existingBlog.empty) {
              const contentBatch = writeBatch(db);
              if (existingPages.empty) {
                for (const pg of SEED_CMS_PAGES) {
                  contentBatch.set(doc(db, 'cmsPages', pg.id), {
                    ...pg,
                    updatedAt: serverTimestamp(),
                  });
                }
              }
              if (existingBlog.empty) {
                for (const post of SEED_BLOG_POSTS) {
                  contentBatch.set(doc(db, 'blogPosts', post.id), {
                    ...post,
                    createdAt: serverTimestamp(),
                    updatedAt: serverTimestamp(),
                  });
                }
              }
              for (const zone of SEED_SHIPPING_ZONES) {
                contentBatch.set(doc(db, 'shippingZones', zone.id), zone);
              }
              await contentBatch.commit();
            }

            if (existingSuppliers.empty) {
              const erpBatch = writeBatch(db);
              for (const wh of SEED_WAREHOUSES) {
                erpBatch.set(doc(db, 'warehouses', wh.id), {
                  ...wh,
                  updatedAt: serverTimestamp(),
                });
              }
              for (const sup of SEED_SUPPLIERS) {
                erpBatch.set(doc(db, 'suppliers', sup.id), {
                  ...sup,
                  createdAt: serverTimestamp(),
                  updatedAt: serverTimestamp(),
                });
              }
              for (const po of SEED_PURCHASE_ORDERS) {
                erpBatch.set(doc(db, 'purchaseOrders', po.id), {
                  ...po,
                  createdAt: serverTimestamp(),
                  updatedAt: serverTimestamp(),
                });
              }
              for (const wacc of SEED_WHOLESALE_ACCOUNTS) {
                erpBatch.set(doc(db, 'wholesaleAccounts', wacc.id), {
                  ...wacc,
                  createdAt: serverTimestamp(),
                  updatedAt: serverTimestamp(),
                });
              }
              for (const rfq of SEED_WHOLESALE_QUOTES) {
                erpBatch.set(doc(db, 'wholesaleQuotes', rfq.id), {
                  ...rfq,
                  createdAt: serverTimestamp(),
                  updatedAt: serverTimestamp(),
                });
              }
              await erpBatch.commit();
            }

            // Next-Gen Enterprise Collections Bootstrap (idempotent)
            const [existingBundles, existingIntegrations] = await Promise.all([
              getDocs(collection(db, 'bundles')),
              getDocs(collection(db, 'integrations')),
            ]);
            if (existingBundles.empty || existingIntegrations.empty) {
              const ngBatch = writeBatch(db);
              if (existingBundles.empty) {
                for (const bnd of SEED_BUNDLES) {
                  ngBatch.set(doc(db, 'bundles', bnd.id), { ...bnd, updatedAt: serverTimestamp() });
                }
                for (const gc of SEED_GIFT_CARDS) {
                  ngBatch.set(doc(db, 'giftCards', gc.id), { ...gc, createdAt: serverTimestamp() });
                }
              }
              if (existingIntegrations.empty) {
                for (const cmp of SEED_MARKETING_CAMPAIGNS) {
                  ngBatch.set(doc(db, 'marketingCampaigns', cmp.id), {
                    ...cmp,
                    createdAt: serverTimestamp(),
                    updatedAt: serverTimestamp(),
                  });
                }
                for (const exp of SEED_EXPENSES) {
                  ngBatch.set(doc(db, 'expenses', exp.id), { ...exp, createdAt: serverTimestamp() });
                }
                for (const wf of SEED_AUTOMATION_WORKFLOWS) {
                  ngBatch.set(doc(db, 'automationWorkflows', wf.id), {
                    ...wf,
                    createdAt: serverTimestamp(),
                    updatedAt: serverTimestamp(),
                  });
                }
                for (const intg of SEED_INTEGRATIONS) {
                  ngBatch.set(doc(db, 'integrations', intg.id), {
                    ...intg,
                    updatedAt: serverTimestamp(),
                  });
                }
                for (const task of SEED_AI_TASKS) {
                  ngBatch.set(doc(db, 'aiTasks', task.id), {
                    ...task,
                    createdAt: serverTimestamp(),
                    updatedAt: serverTimestamp(),
                  });
                }
              }
              await ngBatch.commit();
            }
          }

          // Record active security session once per browser session for verified users
          if (firebaseUser.emailVerified && firebaseUser.email) {
            const sessionKey = `lumiere_sess_${firebaseUser.uid}`;
            if (!sessionStorage.getItem(sessionKey)) {
              const sid = `sess_${firebaseUser.uid.slice(0, 8)}_${Date.now()}`;
              sessionStorage.setItem(sessionKey, sid);
              setDoc(doc(db, 'securitySessions', sid), {
                id: sid,
                userId: firebaseUser.uid,
                userEmail: firebaseUser.email,
                userAgent: (navigator.userAgent || 'Browser').slice(0, 380),
                platform: (navigator.platform || 'Web').slice(0, 70),
                status: 'active',
                createdAt: serverTimestamp(),
              }).catch(() => {});
            }
          }
        } catch (err) {
          console.warn('Profile bootstrap notice:', err);
        }
      } else {
        setProfile(null);
        setPrivateInfo(null);
        setWishlist([]);
        setNotifications([]);
        setOrders([]);
        setTransactions([]);
        setSupportTickets([]);
        setSubscriptions([]);
        setReferrals([]);
        setStockAlerts([]);
        setSecuritySessions([]);
      }
    });
    return () => unsub();
  }, []);

  // Authenticated Private Listeners
  useEffect(() => {
    if (!authReady || !user) return;

    const unsubProfile = onSnapshot(
      doc(db, 'users', user.uid),
      (snap) => {
        if (snap.exists()) setProfile(snap.data() as UserProfile);
      },
      (err) => handleFirestoreError(err, OperationType.GET, `users/${user.uid}`),
    );

    const unsubPrivate = onSnapshot(
      doc(db, 'users', user.uid, 'private', 'info'),
      (snap) => {
        if (snap.exists()) setPrivateInfo(snap.data() as UserPrivateInfo);
      },
      (err) => handleFirestoreError(err, OperationType.GET, `users/${user.uid}/private/info`),
    );

    const unsubWishlist = onSnapshot(
      collection(db, 'users', user.uid, 'wishlist'),
      (snap) => setWishlist(snap.docs.map((d) => d.data() as WishlistItem)),
      (err) => handleFirestoreError(err, OperationType.LIST, `users/${user.uid}/wishlist`),
    );

    const unsubNotifs = onSnapshot(
      collection(db, 'users', user.uid, 'notifications'),
      (snap) => setNotifications(snap.docs.map((d) => d.data() as NotificationItem)),
      (err) => handleFirestoreError(err, OperationType.LIST, `users/${user.uid}/notifications`),
    );

    const ordersQuery = isAdmin
      ? collection(db, 'orders')
      : query(collection(db, 'orders'), where('userId', '==', user.uid));

    const unsubOrders = onSnapshot(
      ordersQuery,
      (snap) => setOrders(snap.docs.map((d) => d.data() as Order)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'orders'),
    );

    const txQuery = isAdmin
      ? collection(db, 'transactions')
      : query(collection(db, 'transactions'), where('userId', '==', user.uid));

    const unsubTx = onSnapshot(
      txQuery,
      (snap) => setTransactions(snap.docs.map((d) => d.data() as Transaction)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'transactions'),
    );

    const ticketsQuery = isAdmin
      ? collection(db, 'supportTickets')
      : query(collection(db, 'supportTickets'), where('userId', '==', user.uid));

    const unsubTickets = onSnapshot(
      ticketsQuery,
      (snap) => setSupportTickets(snap.docs.map((d) => d.data() as SupportTicket)),
      (err) => console.warn('Support tickets notice:', err.message),
    );

    let unsubCustomers = () => {};
    let unsubAudit = () => {};
    let unsubCampaigns = () => {};
    let unsubExpenses = () => {};
    let unsubWorkflows = () => {};
    let unsubIntegrations = () => {};
    let unsubAiTasks = () => {};
    if (isAdmin) {
      unsubCustomers = onSnapshot(
        collection(db, 'users'),
        (snap) => setCustomers(snap.docs.map((d) => d.data() as UserProfile)),
        (err) => console.warn('Customers list notice:', err.message),
      );
      unsubAudit = onSnapshot(
        collection(db, 'auditLogs'),
        (snap) => setAuditLogs(snap.docs.map((d) => d.data() as AuditLogEntry)),
        (err) => console.warn('Audit log notice:', err.message),
      );
      unsubCampaigns = onSnapshot(
        collection(db, 'marketingCampaigns'),
        (snap) => {
          if (!snap.empty) setMarketingCampaigns(snap.docs.map((d) => d.data() as MarketingCampaign));
        },
        (err) => console.warn('Campaigns notice:', err.message),
      );
      unsubExpenses = onSnapshot(
        collection(db, 'expenses'),
        (snap) => {
          if (!snap.empty) setExpenses(snap.docs.map((d) => d.data() as ExpenseRecord));
        },
        (err) => console.warn('Expenses notice:', err.message),
      );
      unsubWorkflows = onSnapshot(
        collection(db, 'automationWorkflows'),
        (snap) => {
          if (!snap.empty) setAutomationWorkflows(snap.docs.map((d) => d.data() as AutomationWorkflow));
        },
        (err) => console.warn('Workflows notice:', err.message),
      );
      unsubIntegrations = onSnapshot(
        collection(db, 'integrations'),
        (snap) => {
          if (!snap.empty) setIntegrations(snap.docs.map((d) => d.data() as IntegrationConfig));
        },
        (err) => console.warn('Integrations notice:', err.message),
      );
      unsubAiTasks = onSnapshot(
        collection(db, 'aiTasks'),
        (snap) => {
          if (!snap.empty) setAiTasks(snap.docs.map((d) => d.data() as AiTaskItem));
        },
        (err) => console.warn('AI tasks notice:', err.message),
      );
    }

    const gcQuery = isAdmin
      ? collection(db, 'giftCards')
      : query(collection(db, 'giftCards'), where('active', '==', true));
    const unsubGiftCards = onSnapshot(
      gcQuery,
      (snap) => {
        if (!snap.empty) setGiftCards(snap.docs.map((d) => d.data() as GiftCard));
      },
      (err) => console.warn('Gift cards notice:', err.message),
    );

    const subsQuery = isAdmin
      ? collection(db, 'subscriptions')
      : query(collection(db, 'subscriptions'), where('userId', '==', user.uid));
    const unsubSubs = onSnapshot(
      subsQuery,
      (snap) => setSubscriptions(snap.docs.map((d) => d.data() as SubscriptionPlan)),
      (err) => console.warn('Subscriptions notice:', err.message),
    );

    const alertsQuery = isAdmin
      ? collection(db, 'stockAlerts')
      : query(collection(db, 'stockAlerts'), where('userId', '==', user.uid));
    const unsubAlerts = onSnapshot(
      alertsQuery,
      (snap) => setStockAlerts(snap.docs.map((d) => d.data() as StockAlert)),
      (err) => console.warn('Stock alerts notice:', err.message),
    );

    const refsQuery = isAdmin
      ? collection(db, 'referrals')
      : query(collection(db, 'referrals'), where('referrerUid', '==', user.uid));
    const unsubReferrals = onSnapshot(
      refsQuery,
      (snap) => setReferrals(snap.docs.map((d) => d.data() as ReferralRecord)),
      (err) => console.warn('Referrals notice:', err.message),
    );

    const sessQuery = isAdmin
      ? collection(db, 'securitySessions')
      : query(collection(db, 'securitySessions'), where('userId', '==', user.uid));
    const unsubSessions = onSnapshot(
      sessQuery,
      (snap) => setSecuritySessions(snap.docs.map((d) => d.data() as SecuritySession)),
      (err) => console.warn('Security sessions notice:', err.message),
    );

    const unsubWarehouses = onSnapshot(
      collection(db, 'warehouses'),
      (snap) => {
        if (!snap.empty) setWarehouses(snap.docs.map((d) => d.data() as Warehouse));
      },
      (err) => console.warn('Warehouses notice:', err.message),
    );

    const supQuery = isAdmin
      ? collection(db, 'suppliers')
      : query(collection(db, 'suppliers'), where('email', '==', user.email || ''));
    const unsubSuppliers = onSnapshot(
      supQuery,
      (snap) => {
        if (!snap.empty || isAdmin) setSuppliers(snap.docs.map((d) => d.data() as Supplier));
      },
      (err) => console.warn('Suppliers notice:', err.message),
    );

    const poQuery = isAdmin
      ? collection(db, 'purchaseOrders')
      : query(collection(db, 'purchaseOrders'), where('supplierEmail', '==', user.email || ''));
    const unsubPos = onSnapshot(
      poQuery,
      (snap) => {
        if (!snap.empty || isAdmin) setPurchaseOrders(snap.docs.map((d) => d.data() as PurchaseOrder));
      },
      (err) => console.warn('POs notice:', err.message),
    );

    const waccQuery = isAdmin
      ? collection(db, 'wholesaleAccounts')
      : query(collection(db, 'wholesaleAccounts'), where('userId', '==', user.uid));
    const unsubWacc = onSnapshot(
      waccQuery,
      (snap) => {
        if (!snap.empty || isAdmin) setWholesaleAccounts(snap.docs.map((d) => d.data() as WholesaleAccount));
      },
      (err) => console.warn('Wholesale accounts notice:', err.message),
    );

    const wquoteQuery = isAdmin
      ? collection(db, 'wholesaleQuotes')
      : query(collection(db, 'wholesaleQuotes'), where('userId', '==', user.uid));
    const unsubWquote = onSnapshot(
      wquoteQuery,
      (snap) => {
        if (!snap.empty || isAdmin) setWholesaleQuotes(snap.docs.map((d) => d.data() as WholesaleQuote));
      },
      (err) => console.warn('Wholesale quotes notice:', err.message),
    );

    return () => {
      unsubProfile();
      unsubPrivate();
      unsubWishlist();
      unsubNotifs();
      unsubOrders();
      unsubTx();
      unsubTickets();
      unsubCustomers();
      unsubAudit();
      unsubCampaigns();
      unsubExpenses();
      unsubWorkflows();
      unsubIntegrations();
      unsubAiTasks();
      unsubGiftCards();
      unsubSubs();
      unsubAlerts();
      unsubReferrals();
      unsubSessions();
      unsubWarehouses();
      unsubSuppliers();
      unsubPos();
      unsubWacc();
      unsubWquote();
    };
  }, [authReady, user, isAdmin]);

  const handleSignOut = async () => {
    await signOut(auth);
    setCustomerDashOpen(false);
    setAdminDashOpen(false);
    notify('Signed out.');
  };

  const handleVoiceSearch = () => {
    const SpeechRec =
      (window as unknown as { SpeechRecognition?: new () => unknown; webkitSpeechRecognition?: new () => unknown })
        .SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: new () => unknown }).webkitSpeechRecognition;

    if (!SpeechRec) {
      notify('Voice search is unavailable in this browser. Type to filter instantly.');
      return;
    }

    const recognition = new SpeechRec() as {
      lang: string;
      onstart: () => void;
      onend: () => void;
      onresult: (e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void;
      start: () => void;
    };
    recognition.lang = 'en-US';
    recognition.onstart = () => setVoiceListening(true);
    recognition.onend = () => setVoiceListening(false);
    recognition.onresult = (event) => {
      const transcript = event.results?.[0]?.[0]?.transcript;
      if (transcript) {
        setSearchQuery(transcript);
        document.getElementById('catalog')?.scrollIntoView({ behavior: 'smooth' });
      }
    };
    recognition.start();
  };

  const addToBag = (
    product: Product,
    shade: ProductShade,
    options?: { subscriptionIntervalDays?: 30 | 60 | 90; bundleId?: string; overridePrice?: number },
  ) => {
    const unitPrice =
      options?.overridePrice ??
      (options?.subscriptionIntervalDays ? Number((product.price * 0.88).toFixed(2)) : product.price);
    setCart((prev) => {
      const idx = prev.findIndex(
        (i) =>
          i.productId === product.id &&
          i.shade.id === shade.id &&
          i.subscriptionIntervalDays === options?.subscriptionIntervalDays &&
          i.bundleId === options?.bundleId,
      );
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = { ...next[idx], quantity: next[idx].quantity + 1 };
        return next;
      }
      return [
        ...prev,
        {
          productId: product.id,
          name: product.name,
          brand: product.brand,
          price: unitPrice,
          imageUrl: product.imageUrl,
          shade,
          quantity: 1,
          ...(options?.subscriptionIntervalDays
            ? { subscriptionIntervalDays: options.subscriptionIntervalDays }
            : {}),
          ...(options?.bundleId ? { bundleId: options.bundleId } : {}),
        },
      ];
    });
    setBagPulseKey((k) => k + 1);
    setBagOpen(true);
    notify(
      options?.subscriptionIntervalDays
        ? `Added ${product.name} (Subscribe & Save 12% · every ${options.subscriptionIntervalDays}d) to bag.`
        : `Added ${product.name} (${shade.name}) to bag.`,
    );
  };

  const addBundleToBag = (bundle: ProductBundle) => {
    const matched = bundle.productIds
      .map((pid) => products.find((p) => p.id === pid))
      .filter((p): p is Product => Boolean(p));
    const items = matched.length > 0 ? matched : products.slice(0, 3);
    if (items.length === 0) return;
    const perItemPrice = Number((bundle.bundlePriceUsd / items.length).toFixed(2));
    setCart((prev) => {
      const next = [...prev];
      for (const prod of items) {
        const shade = prod.shades[0];
        const idx = next.findIndex(
          (i) => i.productId === prod.id && i.shade.id === shade.id && i.bundleId === bundle.id,
        );
        if (idx >= 0) {
          next[idx] = { ...next[idx], quantity: next[idx].quantity + 1 };
        } else {
          next.push({
            productId: prod.id,
            name: prod.name,
            brand: prod.brand,
            price: perItemPrice,
            imageUrl: prod.imageUrl,
            shade,
            quantity: 1,
            bundleId: bundle.id,
          });
        }
      }
      return next;
    });
    setBagPulseKey((k) => k + 1);
    setBagOpen(true);
    notify(`Added "${bundle.name}" (${bundle.badge}) to bag.`);
  };

  const buyNow = (product: Product, shade: ProductShade) => {
    setCart((prev) => {
      const idx = prev.findIndex((i) => i.productId === product.id && i.shade.id === shade.id);
      if (idx >= 0) return prev;
      return [
        ...prev,
        {
          productId: product.id,
          name: product.name,
          brand: product.brand,
          price: product.price,
          imageUrl: product.imageUrl,
          shade,
          quantity: 1,
        },
      ];
    });
    setActiveProductModal(null);
    setBagOpen(false);
    setCheckoutOpen(true);
  };

  const toggleWishlist = async (product: Product, shade: ProductShade) => {
    if (!user) {
      setAuthModalOpen(true);
      return;
    }
    const exists = wishlist.some((w) => w.productId === product.id);
    try {
      if (exists) {
        await deleteDoc(doc(db, 'users', user.uid, 'wishlist', product.id));
        notify('Removed from wishlist.');
      } else {
        await setDoc(doc(db, 'users', user.uid, 'wishlist', product.id), {
          productId: product.id,
          userId: user.uid,
          shadeId: shade.id,
          addedAt: serverTimestamp(),
        });
        notify(`Saved ${product.name} to wishlist.`);
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}/wishlist/${product.id}`);
    }
  };

  const toggleCompare = (product: Product) => {
    setCompareItems((prev) => {
      if (prev.some((p) => p.id === product.id)) {
        return prev.filter((p) => p.id !== product.id);
      }
      if (prev.length >= 3) {
        notify('Compare up to 3 formulas at once.');
        return prev;
      }
      return [...prev, product];
    });
  };

  const handleNewsletterSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = newsletterEmail.trim().toLowerCase();
    if (!clean || !clean.includes('@')) return;
    const id = `sub_${Date.now()}`;
    try {
      await setDoc(doc(db, 'newsletter', id), {
        id,
        email: clean,
        subscribedAt: serverTimestamp(),
      });
      setNewsletterEmail('');
      notify('Subscribed to LUMIÈRE ATELIER private dispatches.');
    } catch {
      notify('Unable to subscribe right now. Please try again.');
    }
  };

  const visibleTopCategories = useMemo(
    () => categories.filter((c) => c.visible !== false && !c.parentId),
    [categories],
  );

  const searchSuggestions = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return [];
    return products
      .filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.shades.some((s) => s.name.toLowerCase().includes(q)),
      )
      .slice(0, 5);
  }, [products, searchQuery]);

  const filteredProducts = useMemo(() => {
    const list = products.filter((p) => {
      if (discoveryTab === 'new' && !p.newArrival) return false;
      if (discoveryTab === 'trending' && !p.trending) return false;
      if (discoveryTab === 'bestsellers' && !p.bestSeller) return false;
      if (discoveryTab === 'offers' && !(p.compareAtPrice && p.compareAtPrice > p.price)) return false;

      if (selectedCategory !== 'All' && p.category !== selectedCategory && p.subcategory !== selectedCategory) {
        return false;
      }
      if (selectedCollection !== 'All' && p.collection !== selectedCollection) return false;
      if (selectedSkinTone !== 'All' && p.skinTones && !p.skinTones.includes(selectedSkinTone)) return false;
      if (selectedColorFamily !== 'All' && !p.shades.some((s) => matchesColorFamily(s.hex, selectedColorFamily))) {
        return false;
      }
      if (priceTier === 'under50' && p.price >= 50) return false;
      if (priceTier === '50to100' && (p.price < 50 || p.price > 100)) return false;
      if (priceTier === 'over100' && p.price <= 100) return false;
      if (inStockOnly && p.stock <= 0) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const hit =
          p.name.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          (p.subcategory && p.subcategory.toLowerCase().includes(q)) ||
          p.description.toLowerCase().includes(q) ||
          p.shades.some((s) => s.name.toLowerCase().includes(q));
        if (!hit) return false;
      }
      return true;
    });

    const sorted = [...list];
    if (sortBy === 'price_asc') sorted.sort((a, b) => a.price - b.price);
    else if (sortBy === 'price_desc') sorted.sort((a, b) => b.price - a.price);
    else if (sortBy === 'rating') sorted.sort((a, b) => b.rating - a.rating);
    else if (sortBy === 'newest') sorted.sort((a, b) => Number(Boolean(b.newArrival)) - Number(Boolean(a.newArrival)));
    else sorted.sort((a, b) => Number(Boolean(b.featured)) - Number(Boolean(a.featured)));

    return sorted;
  }, [
    products,
    discoveryTab,
    selectedCategory,
    selectedCollection,
    selectedSkinTone,
    selectedColorFamily,
    priceTier,
    inStockOnly,
    searchQuery,
    sortBy,
  ]);

  const recentlyViewedProducts = useMemo(
    () => recentIds.map((id) => products.find((p) => p.id === id)).filter((p): p is Product => Boolean(p)),
    [recentIds, products],
  );

  const recommendedProducts = useMemo(() => {
    const tone = profile?.skinTone;
    if (tone) {
      return products.filter((p) => p.skinTones?.includes(tone)).slice(0, 3);
    }
    return products.filter((p) => p.bestSeller || p.featured).slice(0, 3);
  }, [products, profile?.skinTone]);

  const bagCount = cart.reduce((s, i) => s + i.quantity, 0);
  const bagSubtotal = cart.reduce((s, i) => s + i.price * i.quantity, 0);
  const animationsEnabled = siteSettings.enableAnimations !== false && !siteSettings.reducedMotionMode;
  const use3DCards = siteSettings.enable3DEffects !== false && animationsEnabled;
  const heroParticleDensity =
    !animationsEnabled || siteSettings.backgroundEffects === false
      ? 'off'
      : siteSettings.particleDensity || 'medium';
  const heroSpeedMultiplier =
    siteSettings.motionSpeed === 'slow' ? 1.38 : siteSettings.motionSpeed === 'snappy' ? 0.72 : 1;

  return (
    <MotionProvider settings={siteSettings}>
    <div dir={isRtl ? 'rtl' : 'ltr'} className="min-h-screen flex flex-col chromatic-canvas text-[#0B1020] dark:text-[#F8FAFC] transition-colors relative">
      <AmbientLightingEngine />
      <ScrollProgressBeam />
      {/* Slim Dismissible Top Promo Strip */}
      {siteSettings.promoBannerActive && !promoDismissed && siteSettings.promoBannerText && (
        <div className="relative z-40 h-9 px-4 text-white text-xs flex items-center justify-between gap-4 bg-gradient-to-r from-[#2563EB] via-[#7C3AED] via-45% via-[#EC4899] via-75% to-[#F97316]">
          <span className="w-4" />
          <p className="truncate font-medium tracking-wide drop-shadow-sm">{siteSettings.promoBannerText}</p>
          <button
            type="button"
            onClick={() => setPromoDismissed(true)}
            aria-label="Dismiss promotional banner"
            className="p-1 hover:bg-white/20 transition-colors shrink-0"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Top Bar Contract: 3 Zones Separated by gap-8 */}
      <header className="sticky top-0 z-40 glass-surface neon-header-glow">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4 lg:gap-8 relative">
          {/* Zone 1: Brand Wordmark + Mobile Menu Trigger */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open Navigation Menu"
              className="lg:hidden p-2 border border-indigo-500/25 dark:border-cyan-400/25 hover:border-[#2563EB] text-[#2563EB] dark:text-[#22D3EE] transition-colors"
            >
              <Menu className="w-4 h-4" />
            </button>
            <a
              href="#top"
              className="font-display text-xl sm:text-2xl font-bold tracking-tight whitespace-nowrap shrink-0 gradient-heading"
            >
              {siteSettings.logoText || 'LUMIÈRE ATELIER'}
            </a>
          </div>

          {/* Zone 2: Clean Single-Line Vibrant Navigation Links */}
          <nav className="hidden lg:flex items-center gap-3.5 xl:gap-5 text-xs xl:text-sm font-semibold">
            <button
              type="button"
              onClick={() => setMegaMenuOpen((v) => !v)}
              className="px-2.5 py-1 bg-[#2563EB]/12 dark:bg-[#2563EB]/25 text-[#1D4ED8] dark:text-[#67E8F9] hover:bg-[#2563EB] hover:text-white flex items-center gap-1 whitespace-nowrap shrink-0 transition-all"
            >
              Categories <ChevronDown className="w-3.5 h-3.5" />
            </button>
            <a
              href="#studio-3d"
              className="text-[#0284C7] dark:text-[#22D3EE] hover:text-[#2563EB] dark:hover:text-white whitespace-nowrap shrink-0 transition-colors"
            >
              {t('nav.studio3d')}
            </a>
            <button
              type="button"
              onClick={() => setShadeFinderOpen(true)}
              className="text-[#A21CAF] dark:text-[#F0ABFC] hover:text-[#EC4899] dark:hover:text-white whitespace-nowrap shrink-0 transition-colors"
            >
              {t('nav.shadeFinder')}
            </button>
            <button
              type="button"
              onClick={() => setEnterpriseModal({ view: 'blog' })}
              className="text-[#DB2777] dark:text-[#F472B6] hover:text-[#F43F5E] dark:hover:text-white whitespace-nowrap shrink-0 transition-colors"
            >
              {t('nav.journal')}
            </button>
            <button
              type="button"
              onClick={() => setWholesaleOpen(true)}
              className="text-[#EA580C] dark:text-[#FBBF24] hover:text-[#F97316] dark:hover:text-white whitespace-nowrap shrink-0 transition-colors"
            >
              {t('nav.wholesale')}
            </button>
            <button
              type="button"
              onClick={() => setSupplierPortalOpen(true)}
              className="text-[#059669] dark:text-[#34D399] hover:text-[#10B981] dark:hover:text-white whitespace-nowrap shrink-0 transition-colors"
            >
              {t('nav.suppliers')}
            </button>
            <button
              type="button"
              onClick={() => setEnterpriseModal({ view: 'track' })}
              className="text-[#0D9488] dark:text-[#2DD4BF] hover:text-[#06B6D4] dark:hover:text-white whitespace-nowrap shrink-0 transition-colors"
            >
              {t('nav.trackOrder')}
            </button>
            <button
              type="button"
              onClick={() => (user ? setCustomerDashOpen(true) : setAuthModalOpen(true))}
              className="text-[#4F46E5] dark:text-[#93C5FD] hover:text-[#2563EB] dark:hover:text-white whitespace-nowrap shrink-0 flex items-center gap-1.5 transition-colors"
            >
              <span>{user ? t('nav.account') : t('nav.signIn')}</span>
              {user && unreadNotificationsCount > 0 && (
                <span className="px-1.5 py-0.5 text-[10px] font-mono bg-gradient-to-r from-[#F43F5E] to-[#F97316] text-white leading-none">
                  {unreadNotificationsCount}
                </span>
              )}
            </button>
            {isAdmin && (
              <button
                type="button"
                onClick={() => setAdminDashOpen(true)}
                className="px-2.5 py-1 bg-gradient-to-r from-[#7C3AED] via-[#D946EF] to-[#EC4899] text-white font-semibold shadow-sm hover:brightness-110 transition-all whitespace-nowrap shrink-0"
              >
                Admin ERP
              </button>
            )}
          </nav>

          {/* Zone 3: Global Region/Currency Selector + Theme Toggle + Bag Action */}
          <div className="flex items-center gap-2 shrink-0">
            <CountryCurrencyTrigger />
            {user && unreadNotificationsCount > 0 && (
              <button
                type="button"
                onClick={() => setCustomerDashOpen(true)}
                aria-label={`${unreadNotificationsCount} unread notifications`}
                title="View notifications"
                className="relative p-2 border border-rose-500/30 bg-rose-500/10 hover:bg-rose-500/20 transition-colors"
              >
                <Bell className="w-4 h-4 text-[#F43F5E] dark:text-[#FB7185]" />
                <span className="absolute -top-1 -right-1 px-1 text-[10px] font-mono bg-gradient-to-r from-[#F43F5E] to-[#F97316] text-white leading-tight">
                  {unreadNotificationsCount}
                </span>
              </button>
            )}
            <button
              type="button"
              onClick={() => setDarkMode((d) => !d)}
              aria-label="Toggle Light/Dark Theme"
              title={darkMode ? 'Switch to Colorful Light Mode' : 'Switch to Colorful Dark Mode'}
              className="p-2 border border-indigo-500/25 dark:border-amber-400/35 bg-gradient-to-br from-blue-500/10 to-purple-500/10 dark:from-amber-400/15 dark:to-orange-500/15 hover:border-[#7C3AED] dark:hover:border-[#FACC15] transition-all"
            >
              {darkMode ? <Sun className="w-4 h-4 text-[#FACC15]" /> : <Moon className="w-4 h-4 text-[#7C3AED]" />}
            </button>
            <motion.button
              key={bagPulseKey}
              type="button"
              initial={bagPulseKey > 0 ? { scale: 1.12 } : false}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', stiffness: 380, damping: 18 }}
              onClick={() => setBagOpen(true)}
              className="px-4 py-2 btn-futuristic text-xs font-semibold tracking-wider uppercase flex items-center gap-2 whitespace-nowrap shrink-0"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>{t('nav.bag')} ({bagCount})</span>
            </motion.button>
          </div>

          {/* Dynamic Nested Categories Mega Menu */}
          <AnimatePresence>
          {megaMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -10, scale: 0.99 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8, scale: 0.99 }}
              transition={{ duration: 0.2 * heroSpeedMultiplier, ease: [0.16, 1, 0.3, 1] }}
              onMouseLeave={() => setMegaMenuOpen(false)}
              className="absolute left-0 right-0 top-16 bg-white/95 dark:bg-[#0D1120]/95 backdrop-blur-xl border border-indigo-500/25 dark:border-cyan-400/25 prism-modal-rim p-6 z-50 grid grid-cols-2 md:grid-cols-4 gap-6"
            >
              {visibleTopCategories.map((cat, idx) => {
                const subs = categories.filter((s) => s.parentId === cat.id && s.visible !== false);
                const catTheme = getCategoryStyle(cat.name, idx);
                return (
                  <div key={cat.id} className="space-y-2 p-3 bg-gradient-to-br from-slate-50/70 to-white dark:from-white/[0.03] dark:to-transparent border border-indigo-500/10 dark:border-white/10">
                    <div className={`h-0.5 w-full bg-gradient-to-r ${catTheme.labelGradient}`} />
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedCategory(cat.name);
                        setMegaMenuOpen(false);
                        document.getElementById('catalog')?.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className={`text-left text-xs font-bold uppercase tracking-wider ${catTheme.accentText} hover:underline`}
                    >
                      {cat.name}
                      {cat.discountPercent ? ` · ${cat.discountPercent}% Off` : ''}
                    </button>
                    {subs.length > 0 && (
                      <ul className="space-y-1">
                        {subs.map((sub) => (
                          <li key={sub.id}>
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedCategory(sub.name);
                                setMegaMenuOpen(false);
                                document.getElementById('catalog')?.scrollIntoView({ behavior: 'smooth' });
                              }}
                              className="text-xs text-[#434C66] dark:text-slate-300 hover:text-[#2563EB] dark:hover:text-[#22D3EE] transition-colors"
                            >
                              {sub.name}
                            </button>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                );
              })}
              <div className="col-span-full pt-3 border-t border-indigo-500/15 dark:border-cyan-400/15 flex flex-wrap justify-between items-center text-xs gap-3">
                <div className="flex flex-wrap gap-4">
                  <button
                    type="button"
                    onClick={() => {
                      setEnterpriseModal({ view: 'support' });
                      setMegaMenuOpen(false);
                    }}
                    className="text-[#2563EB] dark:text-[#22D3EE] font-medium hover:underline"
                  >
                    Help Center & Contact
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setEnterpriseModal({ view: 'page', slug: 'about' });
                      setMegaMenuOpen(false);
                    }}
                    className="text-[#7C3AED] dark:text-[#C4B5FD] font-medium hover:underline"
                  >
                    About Us & Policies
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setEnterpriseModal({ view: 'sitemap' });
                      setMegaMenuOpen(false);
                    }}
                    className="text-[#EC4899] dark:text-[#F472B6] font-medium hover:underline"
                  >
                    Full Sitemap
                  </button>
                </div>
                <button type="button" onClick={() => setMegaMenuOpen(false)} className="text-[#434C66] dark:text-slate-300 hover:text-[#F43F5E]">
                  Close Menu
                </button>
              </div>
            </motion.div>
          )}
          </AnimatePresence>
        </div>
        <div className="prism-divider opacity-85" />
      </header>

      <main id="top" className="flex-1">
        {/* Section 1: Cinematic Multi-Color Aurora Hero with Live 3D Cosmetic Stage */}
        <section
          id="studio-3d"
          className="relative overflow-hidden chromatic-hero-bg text-white"
        >
          <MorphingLightField variant="hero" />
          <ParticleField
            enabled={heroParticleDensity !== 'off'}
            density={heroParticleDensity}
            speedMultiplier={heroSpeedMultiplier}
            className="opacity-85"
          />

          <div className="relative z-10 max-w-[1440px] mx-auto grid grid-cols-1 lg:grid-cols-12 items-stretch">
            <motion.div
              initial={animationsEnabled ? { opacity: 0, y: 16 } : false}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55 * heroSpeedMultiplier, ease: [0.16, 1, 0.3, 1] }}
              className="lg:col-span-5 px-6 sm:px-10 py-8 lg:py-10 flex flex-col justify-between gap-6 border-b lg:border-b-0 lg:border-r border-white/15 bg-gradient-to-br from-[#2563EB]/20 via-[#7C3AED]/15 to-[#EC4899]/20"
            >
              <div className="space-y-5">
                <span className="inline-block px-3 py-1 bg-gradient-to-r from-[#06B6D4]/30 via-[#7C3AED]/30 to-[#EC4899]/30 border border-cyan-300/40 text-[11px] uppercase tracking-[0.22em] text-[#67E8F9] font-bold">
                  Unified Commerce · 3D Atelier · Global ERP
                </span>
                <h1 className="font-display text-[clamp(2.4rem,4vw,3.75rem)] font-bold leading-[1.06] text-balance gradient-heading-hero drop-shadow-[0_6px_26px_rgba(217,70,239,0.35)]">
                  {siteSettings.heroTitle}
                </h1>
                <p className="text-sm sm:text-base text-indigo-100/90 leading-relaxed max-w-lg">
                  {siteSettings.heroSubtitle}
                </p>

                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <MagneticButton
                    type="button"
                    onClick={() => document.getElementById('catalog')?.scrollIntoView({ behavior: 'smooth' })}
                    className="px-6 py-3 btn-futuristic text-xs font-semibold uppercase tracking-widest whitespace-nowrap"
                  >
                    Shop Collection
                  </MagneticButton>
                  <MagneticButton
                    type="button"
                    onClick={() => setShadeFinderOpen(true)}
                    className="px-5 py-3 btn-prism-cyan text-xs font-semibold uppercase tracking-widest flex items-center gap-2 whitespace-nowrap"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-[#FDE047]" /> AI Shade Finder
                  </MagneticButton>
                  <MagneticButton
                    type="button"
                    onClick={() => setWholesaleOpen(true)}
                    className="px-5 py-3 btn-prism-sunset text-xs font-semibold uppercase tracking-widest whitespace-nowrap"
                  >
                    Wholesale Desk
                  </MagneticButton>
                </div>
              </div>

              {/* Interactive Hero 3D Model Switcher */}
              <div className="pt-6 border-t border-white/20 space-y-3">
                <p className="text-xs text-[#FDE047] uppercase tracking-wider font-bold">Inspect Live 3D Showcase</p>
                <div className="flex flex-wrap gap-2">
                  {[SEED_PRODUCTS[0], SEED_PRODUCTS[2], SEED_PRODUCTS[4], SEED_PRODUCTS[5]].map((item, idx) => {
                    const activeBorder = [
                      'border-[#22D3EE] bg-gradient-to-r from-[#2563EB] to-[#06B6D4]',
                      'border-[#F472B6] bg-gradient-to-r from-[#D946EF] to-[#EC4899]',
                      'border-[#34D399] bg-gradient-to-r from-[#10B981] to-[#14B8A6]',
                      'border-[#FBBF24] bg-gradient-to-r from-[#F97316] to-[#F59E0B]',
                    ][idx % 4];
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => {
                          setHeroProduct(item);
                          setHeroShade(item.shades[0]);
                        }}
                        className={`px-3 py-1.5 text-xs border transition-all whitespace-nowrap ${
                          heroProduct.id === item.id
                            ? `${activeBorder} text-white shadow-[0_0_20px_rgba(34,211,238,0.45)] font-bold`
                            : 'border-white/25 bg-white/10 text-white/90 hover:text-white hover:border-[#22D3EE]'
                        }`}
                      >
                        {item.name.split(' ').slice(0, 2).join(' ')}
                      </button>
                    );
                  })}
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <span className="text-xs text-cyan-200 font-semibold">Shade:</span>
                  {heroProduct.shades.slice(0, 5).map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => setHeroShade(s)}
                      title={s.name}
                      className={`w-6 h-6 rounded-full border-2 transition-transform ${
                        heroShade.id === s.id ? 'border-[#22D3EE] scale-115 ring-2 ring-[#EC4899]' : 'border-white/45'
                      }`}
                      style={{ backgroundColor: s.hex }}
                    />
                  ))}
                  <span className="text-xs text-[#FDE047] font-semibold ml-1 truncate">{heroShade.name}</span>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={animationsEnabled ? { opacity: 0, scale: 0.98 } : false}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.65 * heroSpeedMultiplier, ease: [0.16, 1, 0.3, 1] }}
              className="lg:col-span-7 relative"
            >
              <ThreeCosmeticStage
                modelType={heroProduct.modelType}
                shadeHex={heroShade.hex}
                shadeName={heroShade.name}
                productName={heroProduct.name}
                heightClass="h-[400px] lg:h-[520px]"
                fallbackImageUrl={siteSettings.heroImageUrl || heroProduct.imageUrl}
              />
            </motion.div>
          </div>

          {/* 3-Column Luminous Chromatic Feature Strip */}
          <div className="relative z-10 max-w-[1440px] mx-auto px-6 py-4 border-t border-white/20 bg-gradient-to-r from-[#2563EB]/45 via-[#7C3AED]/45 via-50% to-[#EC4899]/45 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-white font-medium">
            <div className="flex items-center justify-between md:justify-start gap-3">
              <span className="px-2 py-0.5 bg-[#06B6D4] text-[#06070E] font-mono font-bold">01</span>
              <span>360° Interactive PBR 3D Packaging & Real Shade Rendering</span>
            </div>
            <div className="flex items-center justify-between md:justify-start gap-3">
              <span className="px-2 py-0.5 bg-[#10B981] text-[#06070E] font-mono font-bold">02</span>
              <span>Virtual Try-On Studio, AI Shade Finder & AI CEO Analytics</span>
            </div>
            <div className="flex items-center justify-between md:justify-start gap-3">
              <span className="px-2 py-0.5 bg-[#F59E0B] text-[#06070E] font-mono font-bold">03</span>
              <span>Retail · B2B Wholesale · Dropshipping · Razorpay · Stripe · UPI</span>
            </div>
          </div>
          <div className="prism-divider" />
        </section>

        {/* Section 1.5: Super-Colorful 4-Portal Experience & Flash Offer Banners */}
        <CinematicSection className="relative z-10 max-w-[1440px] mx-auto px-6 pt-10 pb-2">
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
            <button
              type="button"
              onClick={() => {
                setDiscoveryTab('offers');
                document.getElementById('catalog')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="neon-card-orbit holographic-card text-left p-5 bg-gradient-to-br from-[#F97316] via-[#F43F5E] to-[#EC4899] text-white shadow-lg shadow-rose-500/30 hover:-translate-y-1 transition-all group"
            >
              <p className="text-[10px] uppercase tracking-[0.22em] text-amber-100 font-bold">Flash Runway Deals</p>
              <p className="font-display text-2xl font-bold mt-1">
                Up to {siteSettings.flashSaleDiscount || 20}% Off Atelier Sets
              </p>
              <p className="text-xs text-white/90 mt-1.5 font-medium group-hover:underline">
                Shop Offers & Savings →
              </p>
            </button>

            <button
              type="button"
              onClick={() => setShadeFinderOpen(true)}
              className="neon-card-orbit holographic-card text-left p-5 bg-gradient-to-br from-[#7C3AED] via-[#D946EF] to-[#EC4899] text-white shadow-lg shadow-fuchsia-500/30 hover:-translate-y-1 transition-all group"
            >
              <p className="text-[10px] uppercase tracking-[0.22em] text-cyan-200 font-bold">AI Colorimetry & AR</p>
              <p className="font-display text-2xl font-bold mt-1">AI Shade Finder & Try-On</p>
              <p className="text-xs text-white/90 mt-1.5 font-medium group-hover:underline">
                Match Your Exact Undertone →
              </p>
            </button>

            <button
              type="button"
              onClick={() => setWholesaleOpen(true)}
              className="neon-card-orbit holographic-card text-left p-5 bg-gradient-to-br from-[#2563EB] via-[#06B6D4] to-[#14B8A6] text-white shadow-lg shadow-cyan-500/30 hover:-translate-y-1 transition-all group"
            >
              <p className="text-[10px] uppercase tracking-[0.22em] text-amber-200 font-bold">B2B & Distributors</p>
              <p className="font-display text-2xl font-bold mt-1">Wholesale & Bulk Pricing</p>
              <p className="text-xs text-white/90 mt-1.5 font-medium group-hover:underline">
                Open Wholesale Desk →
              </p>
            </button>

            <button
              type="button"
              onClick={() => setSupplierPortalOpen(true)}
              className="neon-card-orbit holographic-card text-left p-5 bg-gradient-to-br from-[#10B981] via-[#14B8A6] to-[#2563EB] text-white shadow-lg shadow-emerald-500/30 hover:-translate-y-1 transition-all group"
            >
              <p className="text-[10px] uppercase tracking-[0.22em] text-yellow-200 font-bold">Global Fulfillment</p>
              <p className="font-display text-2xl font-bold mt-1">Dropship & Private Label</p>
              <p className="text-xs text-white/90 mt-1.5 font-medium group-hover:underline">
                Launch Supplier Portal →
              </p>
            </button>
          </div>
        </CinematicSection>

        {/* Section 1.75: Vibrant 8-Category Chromatic Showcase Grid */}
        <CinematicSection className="relative z-10 max-w-[1440px] mx-auto px-6 pt-8 pb-2 space-y-4">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <p className="text-xs uppercase tracking-[0.22em] text-[#7C3AED] dark:text-[#22D3EE] font-bold">
                Explore Every Spectrum
              </p>
              <h2 className="font-display text-2xl sm:text-3xl font-bold gradient-heading">
                Shop by Vibrant Category
              </h2>
            </div>
            <button
              type="button"
              onClick={() => {
                setSelectedCategory('All');
                document.getElementById('catalog')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="px-3.5 py-1.5 btn-prism-outline text-xs font-semibold text-[#2563EB] dark:text-[#22D3EE]"
            >
              View All {products.length} Products
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
            {visibleTopCategories.slice(0, 8).map((cat, idx) => {
              const catStyle = getCategoryStyle(cat.name, idx);
              const count = products.filter((p) => p.category === cat.name).length;
              const isSelected = selectedCategory === cat.name;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => {
                    setSelectedCategory(cat.name);
                    document.getElementById('catalog')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className={`neon-card-orbit relative p-3.5 text-left bg-gradient-to-br ${catStyle.tileGradient} text-white transition-all hover:-translate-y-1 shadow-md overflow-hidden ${
                    isSelected ? 'ring-3 ring-[#0B1020] dark:ring-white scale-[1.02]' : 'opacity-95 hover:opacity-100'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1 mb-2">
                    <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 bg-black/20">
                      {count} SKUs
                    </span>
                    {cat.discountPercent ? (
                      <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 bg-white text-[#0B1020]">
                        -{cat.discountPercent}%
                      </span>
                    ) : null}
                  </div>
                  <p className="font-display text-base font-bold leading-tight line-clamp-2">
                    {cat.name}
                  </p>
                </button>
              );
            })}
          </div>
        </CinematicSection>

        {/* Section 2: Curated Catalog, Autocomplete Search, Voice Search & Multi-Facet Filters */}
        <CinematicSection id="catalog" className="relative z-10 max-w-[1440px] mx-auto px-6 py-10 space-y-7">
          <div className="neon-card-orbit flex flex-col xl:flex-row xl:items-end justify-between gap-6 p-5 bg-gradient-to-r from-indigo-100/90 via-fuchsia-100/80 to-cyan-100/90 dark:from-[#14173B]/90 dark:via-[#24123D]/90 dark:to-[#0C2540]/90 border border-indigo-500/30 dark:border-cyan-400/30 shadow-md">
            <div>
              <p className="text-xs uppercase tracking-[0.2em] text-[#EC4899] dark:text-[#22D3EE] font-bold">
                {t('catalog.eyebrow')} · {country.flag} {country.name} ({country.shippingCarrier.split('/')[0].trim()} · {country.estimatedDelivery})
              </p>
              <h2 className="font-display text-3xl sm:text-4xl font-bold mt-1 gradient-heading">
                {t('catalog.title')}
              </h2>
              <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-1">
                {rateSource === 'live' ? t('loc.liveRates') : t('loc.refRates')} · {t('product.estPriceNote')} ·{' '}
                <button
                  type="button"
                  onClick={() => setSelectorOpen(true)}
                  className="text-[#2563EB] dark:text-[#22D3EE] font-semibold hover:underline"
                >
                  Change Country / Language ({language.toUpperCase()})
                </button>
              </p>
            </div>

            {/* Workspace Toolbar */}
            <div className="flex flex-wrap items-center gap-2.5">
              {/* Instant Autocomplete + Voice Search + Visual Image Search */}
              <div className="relative">
                <Search className="w-4 h-4 text-[#2563EB] dark:text-[#22D3EE] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder={t('catalog.searchPlaceholder')}
                  value={searchQuery}
                  onFocus={() => setSearchFocused(true)}
                  onBlur={() => setTimeout(() => setSearchFocused(false), 180)}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 pr-16 py-2 bg-white dark:bg-[#0D1120] border border-indigo-500/25 dark:border-cyan-400/25 text-[#0B1020] dark:text-white placeholder:text-[#64748B] dark:placeholder:text-slate-400 text-xs w-64"
                />
                <button
                  type="button"
                  onClick={() => setVisualSearchOpen(true)}
                  aria-label="Visual Image Search"
                  title="Search by Photo (AI Visual Matcher)"
                  className="absolute right-8 top-1/2 -translate-y-1/2 text-[#06B6D4] dark:text-[#22D3EE] hover:text-[#EC4899] transition-colors"
                >
                  <Camera className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={handleVoiceSearch}
                  aria-label="Voice Search"
                  title="Voice Search"
                  className={`absolute right-2.5 top-1/2 -translate-y-1/2 ${
                    voiceListening ? 'text-[#F43F5E]' : 'text-[#7C3AED] dark:text-[#A78BFA] hover:text-[#EC4899]'
                  }`}
                >
                  <Mic className="w-3.5 h-3.5" />
                </button>

                {searchFocused && searchSuggestions.length > 0 && (
                  <div className="absolute left-0 right-0 top-full mt-1 bg-white dark:bg-[#0D1120] border border-indigo-500/30 dark:border-cyan-400/30 prism-modal-rim z-30 divide-y divide-indigo-500/10 dark:divide-white/10">
                    {searchSuggestions.map((s) => (
                      <button
                        key={s.id}
                        type="button"
                        onMouseDown={() => openProductModal(s, s.shades[0])}
                        className="w-full px-3 py-2 text-left text-xs hover:bg-indigo-50 dark:hover:bg-cyan-500/10 flex justify-between items-center gap-2"
                      >
                        <span className="truncate font-medium text-[#0B1020] dark:text-white">{s.name}</span>
                        <span className="font-mono shrink-0 text-[#2563EB] dark:text-[#22D3EE] font-semibold">
                          {getLocalizedProductPrice(s, country, currency).formatted}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <select
                aria-label="Filter by Skin Tone"
                value={selectedSkinTone}
                onChange={(e) => setSelectedSkinTone(e.target.value)}
                className="px-2.5 py-2 bg-white dark:bg-[#0D1120] border border-indigo-500/25 dark:border-cyan-400/25 text-[#0B1020] dark:text-white text-xs"
              >
                <option value="All">All Skin Tones</option>
                {['Fair', 'Light', 'Medium', 'Tan', 'Rich', 'Deep'].map((tOpt) => (
                  <option key={tOpt} value={tOpt}>
                    {tOpt} Skin
                  </option>
                ))}
              </select>

              <select
                aria-label="Filter by Color Family"
                value={selectedColorFamily}
                onChange={(e) => setSelectedColorFamily(e.target.value)}
                className="px-2.5 py-2 bg-white dark:bg-[#0D1120] border border-purple-500/25 dark:border-fuchsia-400/25 text-[#0B1020] dark:text-white text-xs"
              >
                {['All', 'Reds & Berries', 'Nudes & Neutrals', 'Golds & Bronzes', 'Plums & Noir'].map((f) => (
                  <option key={f} value={f}>
                    {f === 'All' ? 'All Pigments' : f}
                  </option>
                ))}
              </select>

              <select
                aria-label="Filter by Price"
                value={priceTier}
                onChange={(e) => setPriceTier(e.target.value as PriceTier)}
                className="px-2.5 py-2 bg-white dark:bg-[#0D1120] border border-emerald-500/25 dark:border-teal-400/25 text-[#0B1020] dark:text-white text-xs"
              >
                <option value="all">All Prices</option>
                <option value="under50">Under {formatMoney(50, currency)}</option>
                <option value="50to100">
                  {formatMoney(50, currency)} – {formatMoney(100, currency)}
                </option>
                <option value="over100">{formatMoney(100, currency)}+</option>
              </select>

              <select
                aria-label="Sort Products"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
                className="px-2.5 py-2 bg-white dark:bg-[#0D1120] border border-amber-500/30 dark:border-amber-400/30 text-[#0B1020] dark:text-white text-xs"
              >
                <option value="featured">Sort: Featured</option>
                <option value="newest">Sort: Newest</option>
                <option value="rating">Sort: Top Rated</option>
                <option value="price_asc">Price: Low to High</option>
                <option value="price_desc">Price: High to Low</option>
              </select>

              <select
                aria-label="Select Currency"
                value={currency}
                onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                className="px-2.5 py-2 bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-[#0E1930] dark:to-[#111E33] border border-[#2563EB]/30 dark:border-[#22D3EE]/35 text-[#1D4ED8] dark:text-[#22D3EE] text-xs font-mono font-semibold"
              >
                {ALL_CURRENCIES.map((code) => (
                  <option key={code} value={code}>
                    {code} ({CURRENCY_RATES[code].symbol.trim()})
                  </option>
                ))}
              </select>

              {compareItems.length > 0 && (
                <button
                  type="button"
                  onClick={() => setCompareOpen(true)}
                  className="px-3.5 py-2 btn-prism-sunset text-xs font-semibold flex items-center gap-1.5"
                >
                  <Scale className="w-3.5 h-3.5" /> Compare ({compareItems.length})
                </button>
              )}
            </div>
          </div>

          {/* Merchandising Discovery Tabs + Colorful Categories Strip */}
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-1.5 overflow-x-auto">
                {(
                  [
                    { id: 'all', label: t('catalog.shopAll') },
                    { id: 'new', label: t('catalog.newArrivals') },
                    { id: 'trending', label: t('catalog.trending') },
                    { id: 'bestsellers', label: t('catalog.bestSellers') },
                    { id: 'offers', label: t('catalog.offers') },
                  ] as const
                ).map((tabItem) => (
                  <button
                    key={tabItem.id}
                    type="button"
                    onClick={() => setDiscoveryTab(tabItem.id)}
                    className={`relative px-3.5 py-1.5 text-xs font-semibold border transition-colors whitespace-nowrap shrink-0 overflow-hidden ${
                      discoveryTab === tabItem.id
                        ? 'text-white border-transparent'
                        : 'bg-white dark:bg-[#0D1120] text-[#334155] dark:text-slate-200 border-indigo-500/20 dark:border-cyan-400/20 hover:border-[#7C3AED] dark:hover:border-[#22D3EE]'
                    }`}
                  >
                    {discoveryTab === tabItem.id && (
                      <motion.span
                        layoutId="activeDiscoveryTab"
                        transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                        className="absolute inset-0 btn-futuristic -z-0"
                      />
                    )}
                    <span className="relative z-10">{tabItem.label}</span>
                  </button>
                ))}
              </div>

              <label className="flex items-center gap-2 text-xs text-[#434C66] dark:text-slate-300 font-medium cursor-pointer">
                <input
                  type="checkbox"
                  checked={inStockOnly}
                  onChange={(e) => setInStockOnly(e.target.checked)}
                />
                In Stock Only
              </label>
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              <button
                type="button"
                onClick={() => setSelectedCategory('All')}
                className={`px-3.5 py-1.5 text-xs font-semibold transition-all whitespace-nowrap shrink-0 border ${
                  selectedCategory === 'All'
                    ? 'btn-prism-cyan border-transparent text-white'
                    : 'bg-white dark:bg-[#0D1120] text-[#334155] dark:text-slate-200 border-indigo-500/20 dark:border-cyan-400/20 hover:border-[#2563EB]'
                }`}
              >
                All Categories
              </button>
              {visibleTopCategories.map((cat, idx) => {
                const catStyle = getCategoryStyle(cat.name, idx);
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setSelectedCategory(cat.name)}
                    className={`px-3.5 py-1.5 text-xs font-semibold transition-all whitespace-nowrap shrink-0 border ${
                      selectedCategory === cat.name
                        ? catStyle.activeBtn
                        : `bg-white dark:bg-[#0D1120] text-[#334155] dark:text-slate-200 border-indigo-500/15 dark:border-white/15 ${catStyle.glowRing}`
                    }`}
                  >
                    {cat.name}
                  </button>
                );
              })}
            </div>

            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className="text-[#434C66] dark:text-slate-400 font-medium">Curated Edits:</span>
              {(['All', 'Signature', 'Bridal', 'Party', 'Professional'] as const).map((col, idx) => {
                const activeTone = [
                  'text-[#2563EB] dark:text-[#22D3EE]',
                  'text-[#7C3AED] dark:text-[#C4B5FD]',
                  'text-[#EC4899] dark:text-[#F472B6]',
                  'text-[#F97316] dark:text-[#FBBF24]',
                  'text-[#10B981] dark:text-[#34D399]',
                ][idx % 5];
                return (
                  <button
                    key={col}
                    type="button"
                    onClick={() => setSelectedCollection(col)}
                    className={`px-2.5 py-1 transition-colors whitespace-nowrap ${
                      selectedCollection === col
                        ? `font-bold ${activeTone} underline underline-offset-4`
                        : 'text-[#434C66] dark:text-slate-300 hover:text-[#2563EB] dark:hover:text-[#22D3EE]'
                    }`}
                  >
                    {col}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 3-Column Vibrant Product Grid with Chromatic Category Studio Backdrops */}
          {catalogHydrating ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
              {Array.from({ length: 6 }).map((_, idx) => (
                <div
                  key={idx}
                  className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-4 space-y-4"
                >
                  <div className="aspect-[4/3] skeleton-shimmer" />
                  <div className="h-4 w-2/3 skeleton-shimmer" />
                  <div className="h-3 w-1/2 skeleton-shimmer" />
                  <div className="h-9 w-full skeleton-shimmer" />
                </div>
              ))}
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-12 text-center space-y-3">
              <p className="font-display text-2xl gradient-heading font-semibold">No formulations match those filters</p>
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setDiscoveryTab('all');
                  setSelectedCategory('All');
                  setSelectedCollection('All');
                  setSelectedSkinTone('All');
                  setSelectedColorFamily('All');
                  setPriceTier('all');
                  setInStockOnly(false);
                }}
                className="px-4 py-2 btn-futuristic text-xs font-semibold uppercase tracking-wider"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
              {filteredProducts.map((product) => {
                const activeShade = cardSelectedShades[product.id] || product.shades[0];
                const isWishlisted = wishlist.some((w) => w.productId === product.id);
                const isCompared = compareItems.some((c) => c.id === product.id);
                const catStyle = getCategoryStyle(product.category);

                return (
                  <Tilt3DCard
                    key={product.id}
                    className={`${catStyle.cardSurface} border-2 ${catStyle.cardBorder} glow-border holographic-card flex flex-col justify-between shadow-lg ${
                      use3DCards ? 'card-3d-tilt' : ''
                    }`}
                  >
                    <div>
                      <div className={`h-1.5 w-full bg-gradient-to-r ${catStyle.labelGradient}`} />
                      <div
                        onClick={() => openProductModal(product, activeShade)}
                        className={`aspect-[4/3] bg-gradient-to-br ${catStyle.backdrop} p-2.5 relative overflow-hidden cursor-pointer group`}
                      >
                        <div className="w-full h-full overflow-hidden border border-white/60 dark:border-white/20 shadow-md relative neon-image-halo">
                          <img
                            src={product.imageUrl}
                            alt={product.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                          />
                          <div className="pointer-events-none absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-black/55 to-transparent" />
                          <div className="absolute bottom-2.5 left-2.5 flex items-center gap-1.5">
                            <span className={`px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-white bg-gradient-to-r ${catStyle.labelGradient} shadow-sm`}>
                              {product.category.split('&')[0].trim()}
                            </span>
                            {product.bestSeller && (
                              <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-gradient-to-r from-[#F59E0B] to-[#F97316] text-white shadow-sm">
                                Best Seller
                              </span>
                            )}
                            {product.compareAtPrice && product.compareAtPrice > product.price && (
                              <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-gradient-to-r from-[#10B981] to-[#14B8A6] text-white shadow-sm">
                                -{Math.round(((product.compareAtPrice - product.price) / product.compareAtPrice) * 100)}%
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="absolute top-4 right-4 flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleWishlist(product, activeShade);
                            }}
                            aria-label="Toggle wishlist"
                            className={`p-2 border transition-colors ${
                              isWishlisted
                                ? 'bg-gradient-to-r from-[#EC4899] to-[#F43F5E] text-white border-transparent shadow-md'
                                : 'bg-white/95 dark:bg-[#0D1120]/90 border-indigo-500/25 dark:border-white/25 text-[#EC4899] dark:text-[#F472B6] hover:bg-[#EC4899] hover:text-white'
                            }`}
                          >
                            <Heart className={`w-3.5 h-3.5 ${isWishlisted ? 'fill-white text-white' : ''}`} />
                          </button>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleCompare(product);
                            }}
                            aria-label="Compare formula"
                            className={`p-2 border transition-colors ${
                              isCompared
                                ? 'bg-gradient-to-r from-[#2563EB] to-[#06B6D4] text-white border-transparent shadow-md'
                                : 'bg-white/95 dark:bg-[#0D1120]/90 border-indigo-500/25 dark:border-white/25 text-[#2563EB] dark:text-[#22D3EE] hover:bg-[#2563EB] hover:text-white'
                            }`}
                          >
                            <Scale className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <div className="p-5 space-y-3">
                        <div className="flex items-center justify-between gap-2 text-[12px]">
                          <span className={`truncate font-bold ${catStyle.accentText}`}>{product.category}</span>
                          <span className="flex items-center gap-1 px-2 py-0.5 bg-amber-500/15 dark:bg-amber-400/20 font-mono tabular-nums shrink-0 text-[#B45309] dark:text-[#FDE047] font-bold">
                            <Star className="w-3.5 h-3.5 fill-[#F59E0B] text-[#F59E0B]" />
                            {product.rating.toFixed(1)}
                          </span>
                        </div>

                        <div className="flex items-start justify-between gap-3">
                          <h3
                            onClick={() => openProductModal(product, activeShade)}
                            className="text-base font-bold text-[#0B1020] dark:text-white leading-snug cursor-pointer hover:text-[#2563EB] dark:hover:text-[#22D3EE] transition-colors"
                          >
                            {product.name}
                          </h3>
                          <div className="text-right shrink-0">
                            <span className={`px-2 py-0.5 font-mono text-[14px] font-bold tabular-nums inline-block text-white bg-gradient-to-r ${catStyle.labelGradient} shadow-sm`}>
                              {getLocalizedProductPrice(product, country, currency).formatted}
                            </span>
                            {product.compareAtPrice && product.compareAtPrice > product.price && (
                              <span className="font-mono text-[11px] line-through text-[#F43F5E] dark:text-[#FB7185] tabular-nums block mt-0.5">
                                {getLocalizedProductPrice(product, country, currency, product.compareAtPrice).formatted}
                              </span>
                            )}
                          </div>
                        </div>

                        <p className="text-xs text-[#434C66] dark:text-slate-300 font-medium">
                          {product.collection} · {getLocalizedProductInfo(product, language, country).finishLabel} ·{' '}
                          <span className={catStyle.accentText}>{activeShade.name}</span> ·{' '}
                          <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400">
                            {getLocalizedProductInfo(product, language, country).measurement.primaryUnit}
                          </span>
                        </p>

                        {/* Interactive Shade Swatches */}
                        <div className="flex items-center gap-2 pt-1">
                          {product.shades.slice(0, 6).map((shade) => (
                            <button
                              key={shade.id}
                              type="button"
                              onClick={() =>
                                setCardSelectedShades((prev) => ({ ...prev, [product.id]: shade }))
                              }
                              title={shade.name}
                              className={`w-5 h-5 rounded-full border transition-transform ${
                                activeShade.id === shade.id
                                  ? 'border-[#2563EB] dark:border-[#22D3EE] scale-115 ring-2 ring-[#D946EF]/60'
                                  : 'border-black/20 dark:border-white/30 hover:scale-105'
                              }`}
                              style={{ backgroundColor: shade.hex }}
                            />
                          ))}
                          {product.shades.length > 6 && (
                            <span className="text-[11px] font-mono text-[#7C3AED] dark:text-[#C4B5FD] font-semibold">
                              +{product.shades.length - 6}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="px-5 pb-5 pt-2 space-y-2 relative z-20">
                      <div className="grid grid-cols-2 gap-2">
                        <MagneticButton
                          type="button"
                          onClick={() => addToBag(product, activeShade)}
                          className="py-2.5 btn-prism-cyan text-xs font-semibold uppercase tracking-wider whitespace-nowrap"
                        >
                          Add to Bag
                        </MagneticButton>
                        <MagneticButton
                          type="button"
                          onClick={() => buyNow(product, activeShade)}
                          className="py-2.5 btn-prism-sunset text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-1 whitespace-nowrap"
                        >
                          <Zap className="w-3.5 h-3.5" /> Buy Now
                        </MagneticButton>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => openProductModal(product, activeShade)}
                          className="flex-1 py-2 btn-prism-outline text-[#0B1020] dark:text-white text-xs font-semibold whitespace-nowrap"
                        >
                          Inspect 3D View
                        </button>
                        <button
                          type="button"
                          onClick={() => setTryOnTarget({ product, shade: activeShade })}
                          aria-label="Virtual Try-On"
                          title="Virtual Try-On"
                          className="px-3 py-2 border border-fuchsia-500/35 bg-fuchsia-500/10 hover:bg-gradient-to-r hover:from-[#D946EF] hover:to-[#EC4899] hover:text-white text-[#A21CAF] dark:text-[#F472B6] flex items-center gap-1.5 text-xs font-semibold transition-all"
                        >
                          <Camera className="w-3.5 h-3.5" /> Try-On
                        </button>
                      </div>
                    </div>
                  </Tilt3DCard>
                );
              })}
            </div>
          )}

          {/* Curated Bundles & Combo Offers */}
          {bundles.filter((b) => b.active).length > 0 && (
            <div className="pt-8 border-t border-indigo-500/20 dark:border-cyan-400/20 space-y-4">
              <div className="flex flex-wrap items-end justify-between gap-3">
                <div>
                  <p className="text-[11px] uppercase tracking-[0.2em] text-[#EC4899] dark:text-[#22D3EE] font-bold">
                    Curated Sets &amp; Combo Vaults
                  </p>
                  <h3 className="font-display text-2xl sm:text-3xl font-bold gradient-heading">
                    Luxury Bundles &amp; Ritual Savings
                  </h3>
                </div>
                <span className="text-xs text-slate-600 dark:text-slate-300">
                  Save up to 20% + complimentary keepsake packaging
                </span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                {bundles
                  .filter((b) => b.active)
                  .map((bundle) => (
                    <div
                      key={bundle.id}
                      className="neon-card-orbit bg-white/95 dark:bg-[#0D1120]/95 border border-fuchsia-500/30 dark:border-cyan-400/30 overflow-hidden flex flex-col justify-between shadow-lg"
                    >
                      <div>
                        <div className="relative h-44 overflow-hidden">
                          <img
                            src={bundle.imageUrl}
                            alt={bundle.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent" />
                          <span className="absolute top-3 left-3 px-2.5 py-1 bg-gradient-to-r from-[#EC4899] to-[#F97316] text-white text-[10px] font-mono font-bold uppercase tracking-wider shadow">
                            {bundle.badge}
                          </span>
                          <div className="absolute bottom-3 left-3 right-3 text-white">
                            <p className="font-display text-lg font-bold leading-tight">{bundle.name}</p>
                            <p className="text-[11px] text-cyan-200">{bundle.tagline}</p>
                          </div>
                        </div>
                        <div className="p-4 space-y-2">
                          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                            {bundle.description}
                          </p>
                          <div className="flex items-baseline gap-2.5 pt-1">
                            <span className="font-mono text-lg font-bold text-[#10B981] dark:text-[#34D399]">
                              {formatMoney(bundle.bundlePriceUsd, currency)}
                            </span>
                            <span className="font-mono text-xs line-through text-rose-500">
                              {formatMoney(bundle.compareAtUsd, currency)}
                            </span>
                            <span className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 bg-emerald-500/15 text-emerald-700 dark:text-emerald-300">
                              {bundle.productIds.length} Full-Size Formulas
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="px-4 pb-4">
                        <MagneticButton
                          type="button"
                          onClick={() => addBundleToBag(bundle)}
                          className="w-full py-2.5 btn-prism-sunset text-xs font-semibold uppercase tracking-wider"
                        >
                          Add Complete Vault to Bag
                        </MagneticButton>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* Recently Viewed & Personalized Recommendations */}
          {(recentlyViewedProducts.length > 0 || recommendedProducts.length > 0) && (
            <div className="pt-8 border-t border-indigo-500/20 dark:border-cyan-400/20 space-y-8">
              {recentlyViewedProducts.length > 0 && (
                <div className="space-y-4">
                  <h3 className="font-display text-2xl font-bold gradient-heading">Recently Viewed Formulations</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                    {recentlyViewedProducts.map((p) => {
                      const catStyle = getCategoryStyle(p.category);
                      return (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => openProductModal(p, p.shades[0])}
                          className={`${catStyle.cardSurface} border-2 ${catStyle.cardBorder} text-left p-2.5 glow-border shadow-sm hover:-translate-y-0.5 transition-all`}
                        >
                          <div className={`h-1 w-full mb-2 bg-gradient-to-r ${catStyle.labelGradient}`} />
                          <img
                            src={p.imageUrl}
                            alt={p.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-24 object-cover mb-2 border border-white/60 dark:border-white/20"
                          />
                          <p className="text-xs font-bold truncate text-[#0B1020] dark:text-white">{p.name}</p>
                          <p className={`mt-1 inline-block px-1.5 py-0.5 font-mono text-[10px] font-bold text-white bg-gradient-to-r ${catStyle.labelGradient}`}>
                            {formatMoney(p.price, currency)}
                          </p>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="space-y-4">
                <div className="flex items-center justify-between gap-4">
                  <h3 className="font-display text-2xl font-bold gradient-heading-emerald">
                    {profile?.skinTone
                      ? `Curated for ${profile.skinTone} ${profile.undertone || ''} Complexions`
                      : 'Atelier Recommended Classics'}
                  </h3>
                  <button
                    type="button"
                    onClick={() => setShadeFinderOpen(true)}
                    className="text-xs font-bold text-[#EC4899] dark:text-[#F472B6] hover:underline whitespace-nowrap"
                  >
                    Refine with AI Shade Finder →
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {recommendedProducts.map((p) => {
                    const catStyle = getCategoryStyle(p.category);
                    return (
                        <div
                          key={p.id}
                          onClick={() => openProductModal(p, p.shades[0])}
                          className={`${catStyle.cardSurface} border-2 ${catStyle.cardBorder} p-4 flex items-center gap-4 cursor-pointer glow-border shadow-md transition-all hover:-translate-y-0.5`}
                        >
                          <img
                            src={p.imageUrl}
                            alt={p.name}
                            referrerPolicy="no-referrer"
                            className="w-20 h-20 object-cover shrink-0 border-2 border-white dark:border-white/25 shadow-sm"
                          />
                          <div className="min-w-0">
                            <p className={`text-[11px] uppercase tracking-wider font-bold ${catStyle.accentText}`}>
                              {p.collection} · {p.category}
                            </p>
                            <p className="text-sm font-bold truncate text-[#0B1020] dark:text-white">{p.name}</p>
                            <p className={`mt-1 inline-block px-2 py-0.5 font-mono text-xs font-bold text-white bg-gradient-to-r ${catStyle.labelGradient}`}>
                              {formatMoney(p.price, currency)}
                            </p>
                          </div>
                        </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </CinematicSection>

        <div className="prism-divider" />

        {/* Section 3: Full-Spectrum Vibrant Editorial Showcase Banner */}
        <CinematicSection className="bg-gradient-to-r from-[#5B21B6] via-[#D946EF] via-52% to-[#F97316] text-white relative overflow-hidden">
          <MorphingLightField variant="panel" />
          <div className="max-w-[1440px] mx-auto px-6 py-14 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
            <div className="lg:col-span-6 p-2.5 bg-gradient-to-br from-[#22D3EE] via-[#FDE047] to-[#EC4899] shadow-2xl group neon-card-orbit neon-image-halo">
              <div className="overflow-hidden bg-[#0B1020]">
                <img
                  src="/src/assets/images/cat_bridal_kits_1794984609940.jpg"
                  alt="Aurora Bridal & Pro Makeup Trunk"
                  referrerPolicy="no-referrer"
                  className="w-full h-[380px] object-cover transition-transform duration-700 group-hover:scale-105"
                />
              </div>
            </div>
            <div className="lg:col-span-6 space-y-5">
              <span className="inline-block px-3 py-1 bg-black/25 border border-amber-200/50 text-xs uppercase tracking-[0.22em] text-[#FDE047] font-bold">
                Atelier Standards · Global Couture
              </span>
              <h2 className="font-display text-3xl sm:text-5xl font-bold text-balance text-white drop-shadow-md">
                Bridal, Party & Pro Trunks Crafted for All Undertones
              </h2>
              <p className="text-sm sm:text-base text-white/95 leading-relaxed">
                Every formulation inside LUMIÈRE ATELIER pairs botanical squalane, camellia oil, and niacinamide with calibrated mineral pigments. Use our AI Shade Finder to map your undertone, inspect packaging in 3D, or launch live Virtual Try-On before checkout.
              </p>
              <div className="flex flex-wrap gap-2 text-[11px] font-semibold">
                <span className="px-2.5 py-1 bg-white/20 backdrop-blur-sm border border-white/30">100% Vegan & Cruelty-Free</span>
                <span className="px-2.5 py-1 bg-cyan-400/25 backdrop-blur-sm border border-cyan-200/40">60+ Calibrated Shades</span>
                <span className="px-2.5 py-1 bg-amber-400/25 backdrop-blur-sm border border-amber-200/40">Worldwide Express & B2B Ready</span>
              </div>
              <div className="flex flex-wrap gap-3 pt-2">
                <MagneticButton
                  type="button"
                  onClick={() => {
                    setSelectedCategory('Bridal, Party & Pro Collections');
                    document.getElementById('catalog')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="px-6 py-3 bg-white text-[#5B21B6] hover:bg-[#FDE047] hover:text-[#0B1020] font-bold text-xs uppercase tracking-wider shadow-lg transition-colors"
                >
                  Explore Bridal & Pro
                </MagneticButton>
                <button
                  type="button"
                  onClick={() => setEnterpriseModal({ view: 'blog' })}
                  className="px-6 py-3 bg-black/25 border border-white/50 text-white hover:bg-white/20 text-xs font-bold uppercase tracking-wider transition-colors"
                >
                  Read Beauty Journal
                </button>
              </div>
            </div>
          </div>
        </CinematicSection>
      </main>

      <div className="prism-divider" />

      {/* Enterprise Multi-Column Prismatic Footer with Newsletter, Payment Badges, Policies & Sitemap */}
      <footer className="chromatic-footer-bg neon-footer-frame relative overflow-hidden text-white">
        <MorphingLightField variant="panel" />
        <div className="relative z-10 max-w-[1440px] mx-auto px-6 py-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-4 space-y-4">
            <p className="font-display text-2xl font-bold gradient-heading-hero">
              {siteSettings.logoText || 'LUMIÈRE ATELIER'}
            </p>
            <p className="text-xs text-indigo-100/85 leading-relaxed max-w-sm">
              International 3D Haute Cosmétique Marketplace. Certified Razorpay, Stripe, PayPal, Cashfree, PayU, CCAvenue, UPI, EMI & COD checkout.
            </p>
            <div className="flex flex-wrap gap-1.5 text-[10px] font-mono font-bold">
              <span className="px-2 py-0.5 bg-[#2563EB] text-white">Razorpay</span>
              <span className="px-2 py-0.5 bg-[#7C3AED] text-white">Stripe</span>
              <span className="px-2 py-0.5 bg-[#06B6D4] text-[#06070E]">PayPal</span>
              <span className="px-2 py-0.5 bg-[#10B981] text-[#06070E]">UPI</span>
              <span className="px-2 py-0.5 bg-[#F97316] text-white">EMI</span>
              <span className="px-2 py-0.5 bg-[#EC4899] text-white">COD</span>
            </div>
            <form onSubmit={handleNewsletterSubscribe} className="flex gap-2 max-w-sm pt-1">
              <input
                type="email"
                required
                placeholder="Private dispatch email..."
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                className="flex-1 px-3 py-2 bg-white/15 border border-cyan-300/40 text-xs text-white placeholder:text-indigo-200"
              />
              <button
                type="submit"
                className="px-4 py-2 btn-prism-sunset text-xs font-semibold uppercase tracking-wider whitespace-nowrap"
              >
                Join
              </button>
            </form>
            <div className="pt-1 flex flex-wrap items-center gap-2">
              <PWAInstallButton compact />
              <button
                type="button"
                onClick={() => setChatbotOpen(true)}
                className="px-3 py-1.5 border border-cyan-300/40 bg-white/10 hover:bg-white/20 text-white text-[11px] font-semibold whitespace-nowrap transition-colors"
              >
                AI Beauty Concierge
              </button>
            </div>
          </div>

          <div className="lg:col-span-2 space-y-2 text-xs">
            <p className="uppercase tracking-[0.18em] text-[#22D3EE] font-bold">Maison</p>
            <ul className="space-y-1.5 text-slate-300">
              <li>
                <button type="button" onClick={() => setEnterpriseModal({ view: 'page', slug: 'about' })} className="hover:text-[#22D3EE] transition-colors">
                  About Us
                </button>
              </li>
              <li>
                <button type="button" onClick={() => setEnterpriseModal({ view: 'page', slug: 'our-story' })} className="hover:text-[#22D3EE] transition-colors">
                  Our Story
                </button>
              </li>
              <li>
                <button type="button" onClick={() => setEnterpriseModal({ view: 'page', slug: 'mission-vision' })} className="hover:text-[#22D3EE] transition-colors">
                  Mission & Vision
                </button>
              </li>
              <li>
                <button type="button" onClick={() => setEnterpriseModal({ view: 'page', slug: 'careers' })} className="hover:text-[#22D3EE] transition-colors">
                  Careers
                </button>
              </li>
              <li>
                <button type="button" onClick={() => setEnterpriseModal({ view: 'blog' })} className="hover:text-[#22D3EE] transition-colors">
                  Beauty Journal
                </button>
              </li>
            </ul>
          </div>

          <div className="lg:col-span-3 space-y-2 text-xs">
            <p className="uppercase tracking-[0.18em] text-[#34D399] font-bold">Client Services</p>
            <ul className="space-y-1.5 text-slate-300">
              <li>
                <button type="button" onClick={() => setEnterpriseModal({ view: 'support' })} className="hover:text-[#34D399] transition-colors">
                  Contact Us & Help Center
                </button>
              </li>
              <li>
                <button type="button" onClick={() => setEnterpriseModal({ view: 'page', slug: 'faq' })} className="hover:text-[#34D399] transition-colors">
                  FAQ
                </button>
              </li>
              <li>
                <button type="button" onClick={() => setEnterpriseModal({ view: 'track' })} className="hover:text-[#34D399] transition-colors">
                  Track Order & PIN Checker
                </button>
              </li>
              <li>
                <button type="button" onClick={() => setShadeFinderOpen(true)} className="hover:text-[#F472B6] transition-colors">
                  AI Shade Finder
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setTryOnTarget({ product: products[0], shade: products[0].shades[0] })}
                  className="hover:text-[#F472B6] transition-colors"
                >
                  Virtual Try-On Studio
                </button>
              </li>
              <li>
                <button type="button" onClick={() => setWholesaleOpen(true)} className="text-[#FBBF24] hover:text-[#FDE047] font-semibold transition-colors">
                  Wholesale & Dealer B2B Portal
                </button>
              </li>
              <li>
                <button type="button" onClick={() => setSupplierPortalOpen(true)} className="text-[#2DD4BF] hover:text-[#5EEAD4] font-semibold transition-colors">
                  Supplier & Private Label Portal
                </button>
              </li>
            </ul>
          </div>

          <div className="lg:col-span-3 space-y-2 text-xs">
            <p className="uppercase tracking-[0.18em] text-[#F472B6] font-bold">Policies & Sitemap</p>
            <div className="grid grid-cols-2 gap-1.5 text-slate-300">
              {[
                ['shipping-policy', 'Shipping'],
                ['return-policy', 'Returns'],
                ['refund-policy', 'Refunds'],
                ['exchange-policy', 'Exchanges'],
                ['cancellation-policy', 'Cancellations'],
                ['privacy-policy', 'Privacy'],
                ['terms-conditions', 'Terms'],
                ['cookie-policy', 'Cookies'],
                ['payment-policy', 'Payments'],
                ['warranty-policy', 'Warranty'],
                ['disclaimer', 'Disclaimer'],
              ].map(([slug, label]) => (
                <button
                  key={slug}
                  type="button"
                  onClick={() => setEnterpriseModal({ view: 'page', slug })}
                  className="text-left hover:text-[#F472B6] transition-colors"
                >
                  {label}
                </button>
              ))}
              <button
                type="button"
                onClick={() => setEnterpriseModal({ view: 'sitemap' })}
                className="text-left text-[#22D3EE] hover:text-white font-semibold"
              >
                Full Sitemap
              </button>
            </div>
          </div>
        </div>
      </footer>

      {/* Mobile Navigation Drawer (< lg) */}
      <AnimatePresence>
      {mobileMenuOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 * heroSpeedMultiplier }}
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex lg:hidden"
        >
          <motion.div
            initial={{ x: -320 }}
            animate={{ x: 0 }}
            exit={{ x: -320 }}
            transition={{ duration: 0.28 * heroSpeedMultiplier, ease: [0.16, 1, 0.3, 1] }}
            className="neon-sidebar-glow neon-modal-frame bg-white dark:bg-[#0D1120] text-[#0B1020] dark:text-[#F8FAFC] w-full max-w-xs h-full flex flex-col border-r border-indigo-500/25 dark:border-cyan-400/25 shadow-2xl"
          >
            <div className="px-5 py-4 bg-gradient-to-r from-[#2563EB] via-[#7C3AED] to-[#EC4899] text-white flex items-center justify-between">
              <span className="font-display text-xl font-bold">
                {siteSettings.logoText || 'LUMIÈRE ATELIER'}
              </span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                aria-label="Close Navigation Menu"
                className="p-1.5 hover:bg-white/20"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="prism-divider shrink-0" />
            <div className="flex-1 overflow-y-auto p-5 space-y-2 text-sm">
              {[
                { label: 'Shop All Collection', tone: 'hover:border-[#2563EB] hover:text-[#2563EB]', action: () => { setSelectedCategory('All'); document.getElementById('catalog')?.scrollIntoView({ behavior: 'smooth' }); } },
                { label: '3D Showcase Studio', tone: 'hover:border-[#06B6D4] hover:text-[#06B6D4]', action: () => document.getElementById('studio-3d')?.scrollIntoView({ behavior: 'smooth' }) },
                { label: 'AI Shade Finder', tone: 'hover:border-[#D946EF] hover:text-[#D946EF]', action: () => setShadeFinderOpen(true) },
                { label: 'Virtual Try-On Studio', tone: 'hover:border-[#EC4899] hover:text-[#EC4899]', action: () => setTryOnTarget({ product: products[0], shade: products[0].shades[0] }) },
                { label: 'Beauty Journal', tone: 'hover:border-[#7C3AED] hover:text-[#7C3AED]', action: () => setEnterpriseModal({ view: 'blog' }) },
                { label: 'Wholesale & Dealer B2B', tone: 'hover:border-[#F97316] hover:text-[#F97316]', action: () => setWholesaleOpen(true) },
                { label: 'Supplier Portal', tone: 'hover:border-[#10B981] hover:text-[#10B981]', action: () => setSupplierPortalOpen(true) },
                { label: 'Track Order & PIN Check', tone: 'hover:border-[#14B8A6] hover:text-[#14B8A6]', action: () => setEnterpriseModal({ view: 'track' }) },
                { label: 'Help Center & Support', tone: 'hover:border-[#F43F5E] hover:text-[#F43F5E]', action: () => setEnterpriseModal({ view: 'support' }) },
              ].map((navItem) => (
                <button
                  key={navItem.label}
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    navItem.action();
                  }}
                  className={`w-full text-left px-3 py-2.5 border border-indigo-500/15 dark:border-white/15 ${navItem.tone} font-medium transition-colors`}
                >
                  {navItem.label}
                </button>
              ))}

              <div className="pt-3 border-t border-indigo-500/15 dark:border-white/15 space-y-2">
                <button
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    if (user) setCustomerDashOpen(true);
                    else setAuthModalOpen(true);
                  }}
                  className="w-full px-3 py-2.5 btn-futuristic text-xs font-semibold uppercase tracking-wider flex items-center justify-between"
                >
                  <span>{user ? 'Customer Dashboard' : 'Sign In / Create Account'}</span>
                  {user && unreadNotificationsCount > 0 && (
                    <span className="px-1.5 py-0.5 bg-white/25 text-[10px] font-mono">
                      {unreadNotificationsCount} new
                    </span>
                  )}
                </button>
                {isAdmin && (
                  <button
                    type="button"
                    onClick={() => {
                      setMobileMenuOpen(false);
                      setAdminDashOpen(true);
                    }}
                    className="w-full px-3 py-2.5 btn-prism-emerald text-xs font-semibold uppercase tracking-wider"
                  >
                    Open Admin ERP Console
                  </button>
                )}
                <div className="pt-1 flex flex-wrap gap-2">
                  <PWAInstallButton compact />
                  <button
                    type="button"
                    onClick={() => {
                      setMobileMenuOpen(false);
                      setChatbotOpen(true);
                    }}
                    className="px-3 py-1.5 btn-prism-sunset text-white text-[11px] font-semibold"
                  >
                    AI Concierge Chat
                  </button>
                </div>
              </div>

              <div className="pt-3 border-t border-indigo-500/15 dark:border-white/15 space-y-2.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs text-[#434C66] dark:text-slate-300 font-medium">Region &amp; Language</span>
                  <button
                    type="button"
                    onClick={() => {
                      setMobileMenuOpen(false);
                      setSelectorOpen(true);
                    }}
                    className="px-2.5 py-1.5 border border-indigo-500/25 dark:border-cyan-400/25 text-xs font-semibold text-[#2563EB] dark:text-[#22D3EE]"
                  >
                    {country.flag} {country.name} · {language.toUpperCase()}
                  </button>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs text-[#434C66] dark:text-slate-300 font-medium">Currency</span>
                  <select
                    aria-label="Mobile Currency Selector"
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                    className="px-2.5 py-1.5 bg-white dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs font-mono font-semibold"
                  >
                    {ALL_CURRENCIES.map((code) => (
                      <option key={code} value={code}>
                        {code} ({CURRENCY_RATES[code].symbol.trim()})
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          </motion.div>
          <div className="flex-1" onClick={() => setMobileMenuOpen(false)} />
        </motion.div>
      )}
      </AnimatePresence>

      {/* Slide-Over Shopping Bag Drawer */}
      <AnimatePresence>
      {bagOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 * heroSpeedMultiplier }}
          onClick={(e) => {
            if (e.target === e.currentTarget) setBagOpen(false);
          }}
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex justify-end"
        >
          <motion.div
            initial={{ x: 420 }}
            animate={{ x: 0 }}
            exit={{ x: 420 }}
            transition={{ duration: 0.3 * heroSpeedMultiplier, ease: [0.16, 1, 0.3, 1] }}
            className="neon-modal-frame neon-card-orbit bg-white dark:bg-[#0D1120] text-[#0B1020] dark:text-[#F8FAFC] w-full max-w-md h-full flex flex-col border-l border-indigo-500/25 dark:border-cyan-400/25 prism-modal-rim"
          >
            <div className="px-6 py-4 bg-gradient-to-r from-[#2563EB] via-[#7C3AED] to-[#EC4899] text-white flex items-center justify-between gap-3">
              <h2 className="font-display text-2xl font-bold">Your Bag ({bagCount})</h2>
              <div className="flex items-center gap-2">
                {cart.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setClearBagConfirmOpen(true)}
                    className="px-2.5 py-1 text-xs border border-white/40 bg-white/15 hover:bg-[#F43F5E] text-white transition-colors"
                  >
                    Clear Bag
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setBagOpen(false)}
                  aria-label="Close Bag"
                  className="p-1.5 hover:bg-white/20"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="prism-divider shrink-0" />

            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {cart.length === 0 ? (
                <div className="text-center py-14 space-y-4">
                  <p className="text-sm text-[#434C66] dark:text-slate-300">
                    Your atelier bag is currently empty.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setBagOpen(false);
                      document.getElementById('catalog')?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="px-5 py-2.5 btn-futuristic text-xs font-semibold uppercase tracking-wider"
                  >
                    Explore Collection
                  </button>
                </div>
              ) : (
                cart.map((item) => {
                  const isSameCartLine = (c: CartItem) =>
                    c.productId === item.productId &&
                    c.shade.id === item.shade.id &&
                    c.subscriptionIntervalDays === item.subscriptionIntervalDays &&
                    c.bundleId === item.bundleId;
                  return (
                  <div
                    key={`${item.productId}-${item.shade.id}-${item.subscriptionIntervalDays ?? 'once'}-${item.bundleId ?? 'std'}`}
                    className="flex gap-3 border-b border-indigo-500/15 dark:border-cyan-400/15 pb-4"
                  >
                    <img
                      src={item.imageUrl}
                      alt={item.name}
                      referrerPolicy="no-referrer"
                      className="w-16 h-16 object-cover border border-indigo-500/25 shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold truncate">{item.name}</p>
                      <div className="flex items-center gap-1.5 text-xs text-[#434C66] dark:text-slate-300 mt-0.5">
                        <span
                          className="w-3 h-3 rounded-full border border-black/15"
                          style={{ backgroundColor: item.shade.hex }}
                        />
                        <span className="truncate">{item.shade.name}</span>
                      </div>
                      {item.subscriptionIntervalDays && (
                        <span className="inline-block mt-1 px-1.5 py-0.5 bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold">
                          Auto-Replenish · Every {item.subscriptionIntervalDays}d (-12%)
                        </span>
                      )}
                      {item.bundleId && (
                        <span className="inline-block mt-1 ml-1 px-1.5 py-0.5 bg-fuchsia-500/15 text-fuchsia-700 dark:text-fuchsia-300 text-[10px] font-bold">
                          Bundle Vault Pricing
                        </span>
                      )}
                      <div className="flex items-center justify-between mt-2">
                        <div className="flex items-center border border-indigo-500/25 dark:border-cyan-400/25">
                          <button
                            type="button"
                            onClick={() =>
                              setCart((prev) =>
                                prev
                                  .map((c) => (isSameCartLine(c) ? { ...c, quantity: c.quantity - 1 } : c))
                                  .filter((c) => c.quantity > 0),
                              )
                            }
                            className="p-1 hover:bg-indigo-50 dark:hover:bg-white/10"
                            aria-label="Decrease quantity"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="px-2.5 text-xs font-mono font-semibold tabular-nums">{item.quantity}</span>
                          <button
                            type="button"
                            onClick={() =>
                              setCart((prev) =>
                                prev.map((c) => (isSameCartLine(c) ? { ...c, quantity: c.quantity + 1 } : c)),
                              )
                            }
                            className="p-1 hover:bg-indigo-50 dark:hover:bg-white/10"
                            aria-label="Increase quantity"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold tabular-nums text-[#2563EB] dark:text-[#22D3EE]">
                            {formatMoney(item.price * item.quantity, currency)}
                          </span>
                          <button
                            type="button"
                            onClick={() => setCart((prev) => prev.filter((c) => !isSameCartLine(c)))}
                            aria-label="Remove item"
                            className="text-[#64748B] hover:text-[#F43F5E]"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  );
                })
              )}
            </div>

            {cart.length > 0 && (
              <div className="p-6 border-t border-indigo-500/20 dark:border-cyan-400/20 bg-gradient-to-r from-blue-50/80 via-purple-50/70 to-pink-50/80 dark:from-[#0A0F20] dark:via-[#120F24] dark:to-[#180E24] space-y-3">
                {siteSettings.flashSaleActive && (
                  <p className="text-xs text-[#EC4899] dark:text-[#FBBF24] font-semibold">
                    Atelier Flash Event active: {siteSettings.flashSaleDiscount}% auto-applied at checkout.
                  </p>
                )}
                <div className="flex justify-between text-sm font-bold">
                  <span>{t('bag.subtotal')}</span>
                  <span className="font-mono tabular-nums text-[#10B981] dark:text-[#34D399]">
                    {formatMoney(bagSubtotal, currency)}
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-300">
                  {country.flag} {country.name}: {country.taxLabel}, shipping &amp; final FX rate locked at checkout.
                </p>
                <MagneticButton
                  type="button"
                  onClick={() => {
                    setBagOpen(false);
                    setCheckoutOpen(true);
                  }}
                  className="w-full py-3.5 btn-prism-emerald text-xs font-semibold uppercase tracking-widest"
                >
                  {t('bag.checkout')}
                </MagneticButton>
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
      </AnimatePresence>

      {/* Modals & Studios */}
      {authModalOpen && (
        <AuthModal onClose={() => setAuthModalOpen(false)} onSuccess={(msg) => notify(msg)} />
      )}

      {enterpriseModal && (
        <EnterprisePagesModal
          initialView={enterpriseModal.view}
          initialSlug={enterpriseModal.slug}
          cmsPages={cmsPages}
          blogPosts={blogPosts}
          shippingZones={shippingZones}
          categories={categories}
          orders={orders}
          currency={currency}
          userUid={user?.uid}
          userEmail={user?.email || undefined}
          userName={profile?.displayName || user?.displayName || undefined}
          onSelectCategory={(catName) => {
            setSelectedCategory(catName);
            document.getElementById('catalog')?.scrollIntoView({ behavior: 'smooth' });
          }}
          onOpenAuth={() => {
            setEnterpriseModal(null);
            setAuthModalOpen(true);
          }}
          onClose={() => setEnterpriseModal(null)}
        />
      )}

      {activeProductModal && (
        <ProductDetailModal
          product={activeProductModal.product}
          initialShade={activeProductModal.shade}
          currency={currency}
          reviews={reviews}
          isWishlisted={wishlist.some((w) => w.productId === activeProductModal.product.id)}
          isCompared={compareItems.some((c) => c.id === activeProductModal.product.id)}
          userUid={user?.uid}
          userEmail={user?.email || undefined}
          userName={profile?.displayName || user?.displayName || undefined}
          onClose={() => setActiveProductModal(null)}
          onAddToBag={addToBag}
          onBuyNow={buyNow}
          onToggleWishlist={toggleWishlist}
          onToggleCompare={toggleCompare}
          onOpenTryOn={(prod, shade) => setTryOnTarget({ product: prod, shade })}
        />
      )}

      {tryOnTarget && (
        <VirtualTryOnModal
          product={tryOnTarget.product}
          initialShade={tryOnTarget.shade}
          onClose={() => setTryOnTarget(null)}
          onAddToBag={addToBag}
        />
      )}

      {shadeFinderOpen && (
        <AiShadeFinderModal
          products={products}
          onClose={() => setShadeFinderOpen(false)}
          onSelectMatch={(prod, shade) => {
            setShadeFinderOpen(false);
            openProductModal(prod, shade);
          }}
        />
      )}

      {visualSearchOpen && (
        <VisualSearchModal
          products={products}
          currency={currency}
          onAddToBag={addToBag}
          onInspectProduct={(prod) => {
            setVisualSearchOpen(false);
            openProductModal(prod, prod.shades[0]);
          }}
          onClose={() => setVisualSearchOpen(false)}
        />
      )}

      {chatbotOpen && (
        <AiShoppingChatbot
          products={products}
          orders={orders}
          currency={currency}
          whatsappPhone={siteSettings.whatsappSupportPhone}
          onAddToBag={addToBag}
          onInspectProduct={(prod) => {
            setChatbotOpen(false);
            openProductModal(prod, prod.shades[0]);
          }}
          onOpenSupportTicket={() => {
            setChatbotOpen(false);
            setEnterpriseModal({ view: 'support' });
          }}
          onClose={() => setChatbotOpen(false)}
        />
      )}

      {compareOpen && (
        <CompareDrawer
          items={compareItems}
          currency={currency}
          onRemove={(id) => setCompareItems((prev) => prev.filter((p) => p.id !== id))}
          onClose={() => setCompareOpen(false)}
          onAddToBag={addToBag}
        />
      )}

      {checkoutOpen && (
        <CheckoutModal
          cart={cart}
          products={products}
          suppliers={suppliers}
          currency={currency}
          coupons={coupons}
          giftCards={giftCards}
          siteSettings={siteSettings}
          savedAddresses={privateInfo?.addresses || []}
          userUid={user?.uid}
          userEmail={user?.email || undefined}
          userName={profile?.displayName || user?.displayName || undefined}
          onSignInPrompt={() => setAuthModalOpen(true)}
          onClearCart={() => setCart([])}
          onClose={() => setCheckoutOpen(false)}
        />
      )}

      {customerDashOpen && user && (
        <CustomerDashboard
          userUid={user.uid}
          userEmail={user.email || ''}
          profile={profile}
          privateInfo={privateInfo}
          orders={orders}
          transactions={transactions}
          wishlist={wishlist}
          notifications={notifications}
          tickets={supportTickets}
          products={products}
          subscriptions={subscriptions}
          referrals={referrals}
          giftCards={giftCards}
          currency={currency}
          isAdmin={isAdmin}
          onOpenAdmin={() => {
            setCustomerDashOpen(false);
            setAdminDashOpen(true);
          }}
          onOpenSupport={() => {
            setCustomerDashOpen(false);
            setEnterpriseModal({ view: 'support' });
          }}
          onSignOut={handleSignOut}
          onAddToBag={addToBag}
          onClose={() => setCustomerDashOpen(false)}
        />
      )}

      {adminDashOpen && isAdmin && (
        <AdminDashboard
          products={products}
          categories={categories}
          orders={orders}
          transactions={transactions}
          coupons={coupons}
          reviews={reviews}
          customers={customers}
          blogPosts={blogPosts}
          cmsPages={cmsPages}
          supportTickets={supportTickets}
          shippingZones={shippingZones}
          siteSettings={siteSettings}
          suppliers={suppliers}
          purchaseOrders={purchaseOrders}
          warehouses={warehouses}
          wholesaleAccounts={wholesaleAccounts}
          wholesaleQuotes={wholesaleQuotes}
          auditLogs={auditLogs}
          bundles={bundles}
          giftCards={giftCards}
          subscriptions={subscriptions}
          stockAlerts={stockAlerts}
          marketingCampaigns={marketingCampaigns}
          expenses={expenses}
          automationWorkflows={automationWorkflows}
          integrations={integrations}
          aiTasks={aiTasks}
          securitySessions={securitySessions}
          adminUid={user?.uid}
          adminEmail={user?.email || undefined}
          currency={currency}
          onViewProduct={(prod) => {
            setAdminDashOpen(false);
            openProductModal(prod, prod.shades[0]);
          }}
          onApplyTheme={(mode) => setDarkMode(mode === 'dark')}
          onPreviewSiteSettings={(partial) => setSiteSettings((prev) => ({ ...prev, ...partial }))}
          onClose={() => setAdminDashOpen(false)}
        />
      )}

      {wholesaleOpen && (
        <WholesalePortalModal
          products={products}
          suppliers={suppliers}
          wholesaleAccounts={wholesaleAccounts}
          wholesaleQuotes={wholesaleQuotes}
          orders={orders}
          currency={currency}
          userUid={user?.uid}
          userEmail={user?.email || undefined}
          userName={profile?.displayName || user?.displayName || undefined}
          onOpenAuth={() => {
            setWholesaleOpen(false);
            setAuthModalOpen(true);
          }}
          onClose={() => setWholesaleOpen(false)}
        />
      )}

      {supplierPortalOpen && (
        <SupplierPortalModal
          suppliers={suppliers}
          purchaseOrders={purchaseOrders}
          products={products}
          currency={currency}
          userEmail={user?.email || undefined}
          isAdmin={isAdmin}
          onClose={() => setSupplierPortalOpen(false)}
        />
      )}

      <ConfirmDialog
        open={clearBagConfirmOpen}
        title="Clear Shopping Bag?"
        message="This will remove all items currently in your shopping bag. You can add them back anytime from the catalog."
        confirmLabel="Clear Bag"
        destructive
        onConfirm={() => {
          setCart([]);
          setClearBagConfirmOpen(false);
          notify('Shopping bag cleared.');
        }}
        onCancel={() => setClearBagConfirmOpen(false)}
      />

      <CountryCurrencySelectorModal />
      <CountryConsentBanner />
      <OfflineIndicator />

      <FloatingQuickDock
        bagCount={bagCount}
        bagPulseKey={bagPulseKey}
        onOpenBag={() => setBagOpen(true)}
        onOpenShadeFinder={() => setShadeFinderOpen(true)}
        onOpenChatbot={() => setChatbotOpen(true)}
        onPreviewSiteSettings={(partial) => setSiteSettings((prev) => ({ ...prev, ...partial }))}
      />

      <AnimatePresence>
      {toastMsg && (
        <motion.div
          key={toastMsg}
          initial={{ opacity: 0, y: 16, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 12, scale: 0.96 }}
          transition={{ duration: 0.22 * heroSpeedMultiplier, ease: [0.16, 1, 0.3, 1] }}
          className="fixed bottom-5 left-5 z-[70] neon-card-orbit neon-modal-frame bg-gradient-to-r from-[#0B1020] via-[#1B1338] to-[#0B1020] text-white px-4 py-2.5 text-xs font-semibold shadow-2xl border border-[#22D3EE]/55 overflow-hidden"
        >
          <span>{toastMsg}</span>
          <motion.div
            initial={{ scaleX: 1 }}
            animate={{ scaleX: 0 }}
            transition={{ duration: 2.8, ease: 'linear' }}
            className="absolute bottom-0 left-0 right-0 h-1 origin-left bg-gradient-to-r from-[#2563EB] via-[#22D3EE] via-40% via-[#10B981] via-65% via-[#F59E0B] to-[#EC4899]"
          />
        </motion.div>
      )}
      </AnimatePresence>
    </div>
    </MotionProvider>
  );
}
