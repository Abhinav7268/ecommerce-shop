import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import { LocalizationProvider } from './context/LocalizationContext.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <ErrorBoundary>
    <LocalizationProvider>
      <App />
    </LocalizationProvider>
  </ErrorBoundary>,
);
