import React, { useState } from 'react';
import { CinematicModal } from './MotionPrimitives';
import {
  CheckCircle2,
  KeyRound,
  Loader2,
  Mail,
  ShieldCheck,
  Smartphone,
  UserPlus,
  X,
} from 'lucide-react';
import {
  createUserWithEmailAndPassword,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  updateProfile,
} from 'firebase/auth';
import { auth, googleProvider } from '../lib/firebase';

interface AuthModalProps {
  onClose: () => void;
  onSuccess: (message: string) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ onClose, onSuccess }) => {
  const [mode, setMode] = useState<'login' | 'register' | 'reset'>('login');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [infoMsg, setInfoMsg] = useState<string | null>(null);

  const handleGoogle = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      await signInWithPopup(auth, googleProvider);
      onSuccess('Signed in with Google.');
      onClose();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Google Sign-In failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg(null);
    setInfoMsg(null);

    try {
      if (mode === 'login') {
        await signInWithEmailAndPassword(auth, email.trim(), password);
        onSuccess('Signed in to your Atelier account.');
        onClose();
      } else if (mode === 'register') {
        const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
        if (fullName.trim()) {
          await updateProfile(cred.user, { displayName: fullName.trim() });
        }
        try {
          await sendEmailVerification(cred.user);
        } catch {
          // Verification email optional if SMTP/quota limits apply
        }
        onSuccess('Account created. Verification email dispatched.');
        onClose();
      } else {
        await sendPasswordResetEmail(auth, email.trim());
        setInfoMsg('Password reset email sent. Check your inbox to complete recovery.');
      }
    } catch (err: unknown) {
      const code = typeof err === 'object' && err && 'code' in err ? String((err as { code: string }).code) : '';
      if (code === 'auth/operation-not-allowed') {
        setErrorMsg(
          'Email/Password sign-in is not yet enabled in this Firebase project. Use Google Sign-In above, or enable Email/Password under Firebase Console → Authentication → Sign-in method.',
        );
      } else if (code === 'auth/invalid-credential' || code === 'auth/wrong-password') {
        setErrorMsg('Invalid email or password. Try resetting your password or sign in with Google.');
      } else if (code === 'auth/email-already-in-use') {
        setErrorMsg('An account already exists with this email. Switch to Sign In.');
      } else {
        setErrorMsg(err instanceof Error ? err.message : 'Authentication request failed.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <CinematicModal
      onBackdropClick={onClose}
      backdropClassName="flex items-center justify-center p-4"
      panelClassName="bg-[#F5F7FF] dark:bg-[#06070E] text-[#090B14] dark:text-[#F8FAFF] w-full max-w-md border border-indigo-500/30 dark:border-cyan-400/25 shadow-2xl overflow-hidden prism-modal-rim"
    >
        <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-[#090B1A] via-[#24134B] to-[#0E2B48] text-white">
          <div>
            <p className="text-[11px] uppercase tracking-[0.22em] text-cyan-300 font-semibold">
              Client Atelier Access
            </p>
            <h2 className="font-display text-2xl font-semibold gradient-heading-hero">
              {mode === 'login' ? 'Sign In' : mode === 'register' ? 'Create Account' : 'Reset Password'}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Authentication"
            className="p-2 hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="prism-divider shrink-0" />

        <div className="p-6 space-y-5">
          {/* Primary Configured OAuth Provider */}
          <button
            type="button"
            disabled={loading}
            onClick={handleGoogle}
            className="w-full py-3 px-4 btn-futuristic text-white text-xs font-semibold uppercase tracking-widest flex items-center justify-center gap-2"
          >
            <ShieldCheck className="w-4 h-4" /> Continue with Google
          </button>

          <div className="flex items-center gap-3 text-[11px] uppercase tracking-widest text-indigo-600/70 dark:text-cyan-300/70 font-semibold">
            <span className="h-px flex-1 bg-indigo-500/20 dark:bg-cyan-400/20" />
            <span>Or Email Authentication</span>
            <span className="h-px flex-1 bg-indigo-500/20 dark:bg-cyan-400/20" />
          </div>

          <div className="flex border border-indigo-500/20 dark:border-cyan-400/20 bg-white dark:bg-[#0D1120] p-1 gap-1">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setErrorMsg(null);
              }}
              className={`flex-1 py-2 text-xs font-semibold transition-all ${
                mode === 'login'
                  ? 'btn-prism-cyan text-white'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-indigo-500/10'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setErrorMsg(null);
              }}
              className={`flex-1 py-2 text-xs font-semibold transition-all ${
                mode === 'register'
                  ? 'btn-futuristic text-white'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-indigo-500/10'
              }`}
            >
              Register
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('reset');
                setErrorMsg(null);
              }}
              className={`flex-1 py-2 text-xs font-semibold transition-all ${
                mode === 'reset'
                  ? 'btn-prism-sunset text-white'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-indigo-500/10'
              }`}
            >
              Forgot Password
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3">
            {mode === 'register' && (
              <div>
                <label className="block text-xs font-semibold text-indigo-700 dark:text-cyan-300 mb-1">Full Name</label>
                <div className="relative">
                  <UserPlus className="w-4 h-4 text-violet-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    placeholder="Camille Laurent"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-white dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-indigo-700 dark:text-cyan-300 mb-1">Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-blue-500 dark:text-cyan-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  placeholder="collector@atelier.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-white dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                />
              </div>
            </div>

            {mode !== 'reset' && (
              <div>
                <label className="block text-xs font-semibold text-indigo-700 dark:text-cyan-300 mb-1">Password</label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-fuchsia-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    minLength={6}
                    placeholder="Minimum 6 characters"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-white dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                  />
                </div>
              </div>
            )}

            {errorMsg && (
              <p className="text-xs text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-700/60 p-2.5">
                {errorMsg}
              </p>
            )}
            {infoMsg && (
              <p className="text-xs text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-700/60 p-2.5 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 shrink-0" /> {infoMsg}
              </p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 btn-prism-cyan text-white text-xs font-semibold uppercase tracking-widest flex items-center justify-center gap-2 disabled:opacity-60"
            >
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              {mode === 'login'
                ? 'Sign In with Email'
                : mode === 'register'
                  ? 'Create Atelier Account'
                  : 'Send Reset Link'}
            </button>
          </form>

          {/* Transparent Firebase Auth Capabilities */}
          <div className="pt-3 border-t border-indigo-500/15 dark:border-cyan-400/15 text-[11px] text-slate-600 dark:text-slate-300 space-y-1">
            <p className="font-semibold text-[#090B14] dark:text-white flex items-center gap-1.5">
              <Smartphone className="w-3.5 h-3.5 text-cyan-500" /> Enterprise Identity Options
            </p>
            <p>
              Google OAuth is active now. Email Verification, Password Recovery, Phone OTP, and TOTP 2FA are handled natively via Firebase Authentication once toggled in Firebase Console.
            </p>
          </div>
        </div>
    </CinematicModal>
  );
};
