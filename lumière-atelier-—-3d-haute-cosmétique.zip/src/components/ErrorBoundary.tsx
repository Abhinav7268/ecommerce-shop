import React from 'react';

interface State {
  hasError: boolean;
  errorMessage: string;
}

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, errorMessage: error.message || 'An unexpected application error occurred.' };
  }

  componentDidCatch(error: Error) {
    console.error('ErrorBoundary caught:', error);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#F5F7FF] dark:bg-[#06070E] text-[#0A0C12] dark:text-[#F5F7FF] flex items-center justify-center p-6">
          <div className="max-w-lg w-full bg-white dark:bg-[#0D1120] border border-indigo-500/25 dark:border-cyan-400/25 prism-modal-rim shadow-2xl overflow-hidden">
            <div className="px-6 py-4 bg-gradient-to-r from-[#F43F5E] via-[#EC4899] to-[#7C3AED] text-white">
              <p className="text-[11px] uppercase tracking-[0.22em] text-amber-200 font-semibold">Application Notice</p>
              <h1 className="font-display text-2xl font-semibold text-white mt-0.5">Unable to display this view</h1>
            </div>
            <div className="prism-divider" />
            <div className="p-6">
              <p className="text-sm text-[#475569] dark:text-white/75 mb-6 leading-relaxed break-words">
                {this.state.errorMessage}
              </p>
              <button
                type="button"
                onClick={() => window.location.reload()}
                className="px-5 py-2.5 btn-futuristic text-xs font-semibold tracking-wider uppercase"
              >
                Reload Studio
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
