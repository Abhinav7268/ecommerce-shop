import React, { useState } from 'react';
import { CinematicModal } from './MotionPrimitives';
import { Loader2, Upload, X, ArrowRight } from 'lucide-react';
import { Product, ProductShade } from '../types/store';

interface AiShadeFinderModalProps {
  products: Product[];
  onClose: () => void;
  onSelectMatch: (product: Product, shade: ProductShade) => void;
}

interface ShadeRecommendation {
  productId: string;
  shadeName: string;
  reason: string;
}

interface ShadeFinderResult {
  detectedSkinTone: string;
  detectedUndertone: string;
  confidenceNote: string;
  applicationTips: string;
  recommendations: ShadeRecommendation[];
}

export const AiShadeFinderModal: React.FC<AiShadeFinderModalProps> = ({
  products,
  onClose,
  onSelectMatch,
}) => {
  const [skinTone, setSkinTone] = useState('Medium');
  const [undertone, setUndertone] = useState('Warm');
  const [occasion, setOccasion] = useState('Editorial Evening');
  const [finishPreference, setFinishPreference] = useState('Velvet Matte');
  const [concern, setConcern] = useState('Long-wear hydration & luminous coverage');
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [photoBase64, setPhotoBase64] = useState<string | null>(null);
  const [photoMime, setPhotoMime] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ShadeFinderResult | null>(null);

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result);
      setPhotoPreview(dataUrl);
      const match = /^data:([^;]+);base64,(.+)$/.exec(dataUrl);
      if (match) {
        setPhotoMime(match[1]);
        setPhotoBase64(match[2]);
      }
    };
    reader.readAsDataURL(file);
  };

  const analyzeShades = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const catalogSummary = products.map((p) => ({
        id: p.id,
        name: p.name,
        category: p.category,
        finish: p.finish,
        skinTones: p.skinTones || [],
        shades: p.shades,
      }));

      const res = await fetch('/api/ai/shade-finder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: photoBase64 || undefined,
          mimeType: photoMime || undefined,
          skinTone,
          undertone,
          occasion,
          finishPreference,
          concern,
          catalog: catalogSummary,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Shade Finder request failed.');
      }
      setResult(data as ShadeFinderResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to run shade analysis.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <CinematicModal
      onBackdropClick={onClose}
      backdropClassName="flex items-center justify-center p-4"
      panelClassName="bg-[#F5F7FF] dark:bg-[#06070E] text-[#0A0C12] dark:text-[#F5F7FF] w-full max-w-4xl border border-indigo-500/25 dark:border-cyan-400/25 prism-modal-rim shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
    >
        <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-[#5B21B6] via-[#D946EF] to-[#EC4899] text-white">
          <div>
            <p className="text-[11px] uppercase tracking-[0.22em] text-amber-200 font-semibold">
              Bespoke Colorimetry Studio
            </p>
            <h2 className="font-display text-2xl font-semibold text-white">
              AI Shade & Complexion Finder
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close AI Shade Finder"
            className="p-2 bg-white/15 hover:bg-white/25 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="prism-divider shrink-0" />

        <div className="grid grid-cols-1 lg:grid-cols-12 flex-1 overflow-y-auto">
          <form
            onSubmit={analyzeShades}
            className="lg:col-span-5 p-6 bg-white dark:bg-[#0D1120] border-b lg:border-b-0 lg:border-r border-indigo-500/20 dark:border-cyan-400/20 space-y-4"
          >
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#7C3AED] dark:text-[#22D3EE] mb-1.5">
                Selfie Photo (Optional)
              </label>
              <label className="flex items-center justify-center gap-2 border-2 border-dashed border-fuchsia-500/40 dark:border-fuchsia-400/40 bg-gradient-to-r from-violet-500/5 via-fuchsia-500/5 to-pink-500/5 dark:from-violet-500/10 dark:to-pink-500/10 p-3.5 text-xs font-semibold text-[#5B21B6] dark:text-fuchsia-200 cursor-pointer hover:border-[#EC4899] transition-colors">
                <Upload className="w-4 h-4 text-[#EC4899] dark:text-[#22D3EE]" />
                <span>{photoPreview ? 'Replace Portrait Photo' : 'Upload Daylight Selfie'}</span>
                <input type="file" accept="image/*" onChange={handlePhotoChange} className="hidden" />
              </label>
              {photoPreview && (
                <img
                  src={photoPreview}
                  alt="Complexion analysis portrait"
                  className="mt-2 h-28 w-full object-cover border-2 border-fuchsia-500/30"
                />
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[#475569] dark:text-white/75 mb-1">Skin Depth</label>
                <select
                  value={skinTone}
                  onChange={(e) => setSkinTone(e.target.value)}
                  className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm font-medium"
                >
                  {['Fair', 'Light', 'Medium', 'Tan', 'Rich', 'Deep'].map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#475569] dark:text-white/75 mb-1">Undertone</label>
                <select
                  value={undertone}
                  onChange={(e) => setUndertone(e.target.value)}
                  className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm font-medium"
                >
                  {['Warm', 'Cool', 'Neutral', 'Olive'].map((u) => (
                    <option key={u} value={u}>
                      {u}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[#475569] dark:text-white/75 mb-1">Occasion</label>
                <select
                  value={occasion}
                  onChange={(e) => setOccasion(e.target.value)}
                  className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm font-medium"
                >
                  {['Everyday Silk', 'Bridal Atelier', 'Editorial Evening', 'Studio Pro'].map((o) => (
                    <option key={o} value={o}>
                      {o}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#475569] dark:text-white/75 mb-1">Preferred Finish</label>
                <select
                  value={finishPreference}
                  onChange={(e) => setFinishPreference(e.target.value)}
                  className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm font-medium"
                >
                  {['Velvet Matte', 'Luminous Dew', 'Satin Gloss', 'Metallic Shimmer'].map((f) => (
                    <option key={f} value={f}>
                      {f}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#475569] dark:text-white/75 mb-1">
                Skin & Artistry Goal
              </label>
              <input
                type="text"
                value={concern}
                onChange={(e) => setConcern(e.target.value)}
                className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm"
                placeholder="e.g. Non-oxidizing warm foundation & berry lip"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 btn-futuristic text-xs font-semibold uppercase tracking-widest flex items-center justify-center gap-2 disabled:opacity-60"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" /> Analyzing Undertones...
                </>
              ) : (
                'Find My Exact Shades'
              )}
            </button>

            {error && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/35 text-xs font-medium text-rose-700 dark:text-rose-300">
                {error}
              </div>
            )}
          </form>

          <div className="lg:col-span-7 p-6 space-y-5 bg-[#F5F7FF] dark:bg-[#06070E]">
            {!result && !loading && (
              <div className="h-full flex flex-col items-center justify-center text-center py-12 px-6 bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 neon-card-orbit luminous-surface">
                <div className="w-12 h-12 mb-4 bg-gradient-to-br from-[#7C3AED] via-[#D946EF] to-[#F97316] flex items-center justify-center text-white font-display text-xl font-bold shadow-lg shadow-fuchsia-500/25">
                  AI
                </div>
                <p className="font-display text-2xl font-semibold gradient-heading">
                  Personalized Complexion Architecture
                </p>
                <p className="text-sm text-[#475569] dark:text-white/75 mt-2 max-w-md leading-relaxed">
                  Share your undertone profile or upload a daylight portrait. Our colorimetry engine maps your skin depth directly to active LUMIÈRE ATELIER shades.
                </p>
              </div>
            )}

            {loading && (
              <div className="h-full flex flex-col items-center justify-center py-16 bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20">
                <Loader2 className="w-8 h-8 animate-spin text-[#D946EF] dark:text-[#22D3EE] mb-3" />
                <p className="text-sm font-medium text-[#475569] dark:text-white/80">
                  Evaluating undertone balance and pigment harmony...
                </p>
              </div>
            )}

            {result && !loading && (
              <div className="space-y-5">
                <div className="neon-card-orbit luminous-surface bg-white dark:bg-[#0D1120] border-l-4 border-l-[#D946EF] border border-indigo-500/20 dark:border-cyan-400/20 p-4 shadow-sm">
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <span className="px-2.5 py-0.5 bg-gradient-to-r from-[#7C3AED] to-[#EC4899] text-white font-semibold">
                      Profile: {result.detectedSkinTone}
                    </span>
                    <span className="px-2.5 py-0.5 bg-cyan-500/15 text-[#0284C7] dark:text-[#22D3EE] font-semibold">
                      {result.detectedUndertone} Undertone
                    </span>
                  </div>
                  <p className="text-sm mt-2.5 leading-relaxed">{result.confidenceNote}</p>
                  <p className="text-xs text-[#475569] dark:text-white/75 mt-2.5 pt-2.5 border-t border-indigo-500/15 dark:border-cyan-400/15">
                    <span className="font-semibold text-[#7C3AED] dark:text-[#22D3EE]">Artistry Ritual:</span>{' '}
                    {result.applicationTips}
                  </p>
                </div>

                <div className="space-y-3">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-[#7C3AED] dark:text-[#22D3EE]">
                    Matched Formulas & Shades
                  </h3>
                  {result.recommendations.map((rec, idx) => {
                    const prod = products.find((p) => p.id === rec.productId) || products[0];
                    const matchedShade =
                      prod.shades.find(
                        (s) => s.name.toLowerCase() === rec.shadeName.toLowerCase(),
                      ) || prod.shades[0];

                    return (
                      <div
                        key={`${rec.productId}-${idx}`}
                        className="glow-border luminous-surface bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 hover:border-[#EC4899]/50 p-4 flex items-center justify-between gap-4 transition-colors"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <span
                            className="w-10 h-10 rounded-full border-2 border-white dark:border-[#141A30] ring-2 ring-fuchsia-500/35 shrink-0 shadow-sm"
                            style={{ backgroundColor: matchedShade.hex }}
                          />
                          <div className="min-w-0">
                            <p className="text-sm font-semibold truncate">{prod.name}</p>
                            <p className="text-xs text-[#EC4899] dark:text-[#22D3EE] font-semibold">
                              Shade: {matchedShade.name}
                            </p>
                            <p className="text-xs text-[#475569] dark:text-white/75 mt-1">{rec.reason}</p>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => onSelectMatch(prod, matchedShade)}
                          className="px-3.5 py-2 btn-prism-cyan text-xs font-semibold flex items-center gap-1.5 shrink-0"
                        >
                          Inspect <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
    </CinematicModal>
  );
};
