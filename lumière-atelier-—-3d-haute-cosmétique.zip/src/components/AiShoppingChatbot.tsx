import React, { useMemo, useRef, useState } from 'react';
import {
  Bot,
  ExternalLink,
  LifeBuoy,
  Loader2,
  Send,
  ShoppingBag,
  Sparkles,
  X,
} from 'lucide-react';
import { CinematicModal } from './MotionPrimitives';
import { useLocalization } from '../context/LocalizationContext';
import { CurrencyCode, formatMoney, Order, Product, ProductShade } from '../types/store';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  productIds?: string[];
  quickReplies?: string[];
  escalate?: boolean;
}

interface AiShoppingChatbotProps {
  products: Product[];
  orders: Order[];
  currency: CurrencyCode;
  whatsappPhone?: string;
  onAddToBag: (product: Product, shade: ProductShade) => void;
  onInspectProduct: (product: Product) => void;
  onOpenSupportTicket: () => void;
  onClose: () => void;
}

export const AiShoppingChatbot: React.FC<AiShoppingChatbotProps> = ({
  products,
  orders,
  currency,
  whatsappPhone = '+919820012345',
  onAddToBag,
  onInspectProduct,
  onOpenSupportTicket,
  onClose,
}) => {
  const { country, language } = useLocalization();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      text: `Bonjour & welcome to LUMIÈRE ATELIER Concierge (${country.name} · ${currency}). Ask me for shade recommendations, skin undertone matching, bundle savings, order tracking, or wholesale B2B pricing in your preferred language.`,
      quickReplies: [
        'Recommend a long-wear bridal lipstick',
        'How does Subscribe & Save work?',
        'Check my latest order status',
      ],
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const catalogSummary = useMemo(
    () =>
      products.map((p) => ({
        id: p.id,
        name: p.name,
        category: p.category,
        price: p.price,
        shades: p.shades.map((s) => s.name),
        stock: p.stock,
      })),
    [products],
  );

  const userOrdersSummary = useMemo(
    () =>
      orders.slice(0, 8).map((o) => ({
        id: o.id,
        status: o.erpStatus || o.orderStatus,
        total: o.total,
        trackingNumber: o.trackingNumber,
      })),
    [orders],
  );

  const sendMessage = async (textOverride?: string) => {
    const text = (textOverride ?? input).trim();
    if (!text || loading) return;
    setError(null);
    const userMsg: ChatMessage = { id: `u_${Date.now()}`, role: 'user', text };
    const nextHistory = [...messages, userMsg];
    setMessages(nextHistory);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          history: nextHistory.map((m) => ({ role: m.role, text: m.text })),
          language,
          currency,
          countryName: country.name,
          catalogSummary,
          userOrdersSummary,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Concierge could not respond right now.');

      const botMsg: ChatMessage = {
        id: `a_${Date.now()}`,
        role: 'assistant',
        text: data.reply || 'I am here to help with your beauty ritual and order inquiries.',
        productIds: Array.isArray(data.recommendedProductIds) ? data.recommendedProductIds : [],
        quickReplies: Array.isArray(data.suggestedQuickReplies) ? data.suggestedQuickReplies : [],
        escalate: Boolean(data.shouldEscalateToTicket),
      };
      setMessages((prev) => [...prev, botMsg]);
      setTimeout(() => {
        scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
      }, 60);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to reach AI Concierge.');
    } finally {
      setLoading(false);
    }
  };

  const whatsappHref = `https://wa.me/${whatsappPhone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
    `Hello LUMIÈRE ATELIER Support (${country.name}), I would like assistance with my beauty order.`,
  )}`;

  return (
    <CinematicModal
      zIndexClass="z-[65]"
      onBackdropClick={onClose}
      backdropClassName="flex items-end sm:items-center justify-end sm:justify-center p-2 sm:p-4"
      panelClassName="bg-[#F5F7FF] dark:bg-[#06070E] text-[#090B14] dark:text-[#F8FAFF] w-full max-w-2xl border border-cyan-500/35 dark:border-fuchsia-400/30 shadow-2xl h-[86vh] sm:h-[82vh] flex flex-col overflow-hidden prism-modal-rim"
    >
      <div className="px-5 py-3.5 bg-gradient-to-r from-[#090B1A] via-[#261252] to-[#0C2B4E] text-white flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-to-br from-cyan-400/30 to-fuchsia-500/35 border border-cyan-300/40">
            <Bot className="w-5 h-5 text-cyan-300" />
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-[0.22em] text-cyan-300 font-bold">
              Multilingual AI Concierge · {language.toUpperCase()}
            </p>
            <h2 className="font-display text-xl font-semibold gradient-heading-hero">
              LUMIÈRE Beauty &amp; Support Assistant
            </h2>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <a
            href={whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="px-2.5 py-1.5 bg-emerald-500/20 hover:bg-emerald-500/35 border border-emerald-400/40 text-emerald-200 text-[11px] font-semibold flex items-center gap-1"
          >
            WhatsApp <ExternalLink className="w-3 h-3" />
          </a>
          <button type="button" onClick={onClose} aria-label="Close AI Concierge" className="p-1.5 hover:bg-white/10">
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>
      <div className="prism-divider shrink-0" />

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
        {messages.map((msg) => {
          const matchedProducts = (msg.productIds || [])
            .map((id) => products.find((p) => p.id === id))
            .filter((p): p is Product => Boolean(p));

          return (
            <div key={msg.id} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
              <div
                className={`max-w-[88%] px-4 py-3 text-xs leading-relaxed border ${
                  msg.role === 'user'
                    ? 'bg-gradient-to-r from-indigo-600 to-fuchsia-600 text-white border-fuchsia-400/40 shadow-lg'
                    : 'bg-white dark:bg-[#0D1120] text-[#090B14] dark:text-slate-100 border-indigo-500/20 dark:border-cyan-400/20 luminous-surface'
                }`}
              >
                <p className="whitespace-pre-wrap">{msg.text}</p>
              </div>

              {matchedProducts.length > 0 && (
                <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-2 w-full max-w-[92%]">
                  {matchedProducts.map((prod) => (
                    <div
                      key={prod.id}
                      className="bg-white dark:bg-[#0D1120] border border-cyan-500/25 p-2.5 flex items-center gap-3 glow-border"
                    >
                      <img src={prod.imageUrl} alt={prod.name} className="w-12 h-12 object-cover shrink-0 border border-indigo-500/20" />
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-semibold truncate">{prod.name}</p>
                        <p className="text-[11px] font-mono font-bold text-emerald-600 dark:text-emerald-400">
                          {formatMoney(prod.price, currency)}
                        </p>
                        <div className="flex items-center gap-1.5 mt-1">
                          <button
                            type="button"
                            onClick={() => onAddToBag(prod, prod.shades[0])}
                            className="px-2 py-0.5 btn-prism-cyan text-white text-[10px] font-semibold flex items-center gap-1"
                          >
                            <ShoppingBag className="w-2.5 h-2.5" /> Add
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              onClose();
                              onInspectProduct(prod);
                            }}
                            className="px-2 py-0.5 border border-indigo-500/30 text-[10px] font-semibold hover:bg-indigo-500/10"
                          >
                            3D View
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {msg.escalate && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenSupportTicket();
                  }}
                  className="mt-2 px-3 py-1.5 bg-amber-500/15 border border-amber-500/40 text-amber-700 dark:text-amber-300 text-[11px] font-semibold flex items-center gap-1.5"
                >
                  <LifeBuoy className="w-3.5 h-3.5" /> Escalate to Live Support Ticket
                </button>
              )}

              {msg.quickReplies && msg.quickReplies.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {msg.quickReplies.map((qr) => (
                    <button
                      key={qr}
                      type="button"
                      onClick={() => void sendMessage(qr)}
                      className="px-2.5 py-1 text-[11px] border border-violet-500/30 bg-violet-500/10 text-violet-700 dark:text-cyan-200 hover:bg-violet-500 hover:text-white transition-colors"
                    >
                      {qr}
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}

        {loading && (
          <div className="flex items-center gap-2 text-xs text-cyan-600 dark:text-cyan-300">
            <Loader2 className="w-4 h-4 animate-spin" /> Consulting live catalog &amp; order telemetry…
          </div>
        )}
        {error && (
          <p className="text-xs text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/40 p-2.5 border border-rose-500/30">
            {error}
          </p>
        )}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          void sendMessage();
        }}
        className="p-3.5 bg-white dark:bg-[#0D1120] border-t border-indigo-500/20 dark:border-cyan-400/20 flex items-center gap-2 shrink-0"
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about shades, skincare, wholesale MOQ, shipping, or orders..."
          className="flex-1 px-3.5 py-2.5 text-xs border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          className="px-4 py-2.5 btn-futuristic text-white text-xs font-semibold flex items-center gap-1.5 disabled:opacity-50"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </CinematicModal>
  );
};
