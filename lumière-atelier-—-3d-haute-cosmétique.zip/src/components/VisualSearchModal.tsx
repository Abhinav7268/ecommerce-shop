import React, { useState } from 'react';
import { Camera, Loader2, ShoppingBag, Sparkles, Upload, X } from 'lucide-react';
import { CinematicModal } from './MotionPrimitives';
import { CurrencyCode, formatMoney, Product, ProductShade } from '../types/store';

interface VisualSearchModalProps {
  products: Product[];
  currency: CurrencyCode;
  onAddToBag: (product: Product, shade: ProductShade) => void;
  onInspectProduct: (product: Product) => void;
  onClose: () => void;
}

export const VisualSearchModal: React.FC<VisualSearchModalProps> = ({
  products,
  currency,
  onAddToBag,
  onInspectProduct,
  onClose,
}) => {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [note, setNote] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{
    detectedDominantHex: string;
    styleSummary: string;
    shadeAdvice: string;
    recommendedProductIds: string[];
  } | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setError('Please choose a valid image file (JPG, PNG, WEBP).');
      return;
    }
    setError(null);
    const reader = new FileReader();
    reader.onload = () => setPreviewUrl(String(reader.result));
    reader.readAsDataURL(file);
  };

  const runVisualSearch = async () => {
    if (!previewUrl) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/ai/visual-search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageDataUrl: previewUrl,
          note,
          catalogSummary: products.map((p) => ({
            id: p.id,
            name: p.name,
            category: p.category,
            finish: p.finish,
            shades: p.shades.map((s) => `${s.name} (${s.hex})`),
            price: p.price,
          })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Visual search failed.');
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to analyze image right now.');
    } finally {
      setLoading(false);
    }
  };

  const matchedProducts = (result?.recommendedProductIds || [])
    .map((id) => products.find((p) => p.id === id))
    .filter((p): p is Product => Boolean(p));

  return (
    <CinematicModal
      zIndexClass="z-[65]"
      onBackdropClick={onClose}
      backdropClassName="flex items-center justify-center p-2 sm:p-4"
      panelClassName="bg-[#F5F7FF] dark:bg-[#06070E] text-[#090B14] dark:text-[#F8FAFF] w-full max-w-3xl border border-cyan-500/35 dark:border-fuchsia-400/30 shadow-2xl max-h-[92vh] flex flex-col overflow-hidden prism-modal-rim"
    >
      <div className="px-6 py-4 bg-gradient-to-r from-[#090B1A] via-[#1B1648] to-[#3B0D44] text-white flex items-center justify-between gap-4 shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-cyan-500/20 border border-cyan-300/40">
            <Camera className="w-5 h-5 text-cyan-300" />
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-[0.22em] text-cyan-300 font-bold">
              Multimodal Computer Vision Search
            </p>
            <h2 className="font-display text-2xl font-semibold gradient-heading-hero">
              Image-Based Product &amp; Shade Search
            </h2>
          </div>
        </div>
        <button type="button" onClick={onClose} aria-label="Close Visual Search" className="p-2 hover:bg-white/10">
          <X className="w-5 h-5" />
        </button>
      </div>
      <div className="prism-divider shrink-0" />

      <div className="flex-1 overflow-y-auto p-6 space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <label className="cursor-pointer border-2 border-dashed border-cyan-500/40 dark:border-fuchsia-400/35 bg-white dark:bg-[#0D1120] p-6 flex flex-col items-center justify-center text-center gap-3 hover:border-cyan-400 transition-colors min-h-[220px]">
            {previewUrl ? (
              <img src={previewUrl} alt="Visual search preview" className="max-h-52 object-contain border border-indigo-500/20" />
            ) : (
              <>
                <Upload className="w-8 h-8 text-cyan-500" />
                <p className="text-xs font-semibold">Upload a makeup look, outfit color, or lipstick swatch</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">PNG, JPG, or WEBP · Instant AI pigment matching</p>
              </>
            )}
            <input type="file" accept="image/*" capture="environment" onChange={handleFileChange} className="hidden" />
          </label>

          <div className="flex flex-col justify-between gap-4 bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-5">
            <div className="space-y-3">
              <label className="block text-xs font-semibold text-indigo-700 dark:text-cyan-300">
                Optional Styling Hint
              </label>
              <input
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="e.g., Match lip shade for evening bridal reception..."
                className="w-full px-3 py-2 text-xs border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
              />
              <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                Our multimodal vision engine extracts the dominant pigment hex, finish texture, and undertone from your photo and ranks the closest matches in our live catalog.
              </p>
            </div>

            <button
              type="button"
              disabled={!previewUrl || loading}
              onClick={runVisualSearch}
              className="w-full py-3 btn-futuristic text-white text-xs font-semibold uppercase tracking-widest flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              {loading ? 'Analyzing Pigment & Texture…' : 'Find Matching Products'}
            </button>
          </div>
        </div>

        {error && (
          <p className="text-xs text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/40 p-3 border border-rose-500/35">
            {error}
          </p>
        )}

        {result && (
          <div className="space-y-4">
            <div className="bg-white dark:bg-[#0D1120] border border-violet-500/30 p-4 flex flex-wrap items-center gap-4 glow-border">
              <div
                className="w-12 h-12 shrink-0 border-2 border-white shadow-lg"
                style={{ backgroundColor: result.detectedDominantHex || '#9E1B32' }}
                title={result.detectedDominantHex}
              />
              <div className="flex-1 min-w-[200px] text-xs space-y-1">
                <p className="font-bold text-violet-700 dark:text-cyan-300">
                  Detected Pigment Tone: <span className="font-mono">{result.detectedDominantHex}</span>
                </p>
                <p className="text-slate-700 dark:text-slate-200">{result.styleSummary}</p>
                <p className="text-[11px] text-emerald-700 dark:text-emerald-300">{result.shadeAdvice}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {matchedProducts.map((prod) => (
                <div key={prod.id} className="bg-white dark:bg-[#0D1120] border border-cyan-500/25 p-4 flex gap-3.5 glow-border">
                  <img src={prod.imageUrl} alt={prod.name} className="w-20 h-20 object-cover shrink-0 border border-indigo-500/20" />
                  <div className="flex-1 min-w-0 space-y-1.5">
                    <p className="text-xs font-bold truncate">{prod.name}</p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">{prod.category} · {prod.finish}</p>
                    <p className="text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400">
                      {formatMoney(prod.price, currency)}
                    </p>
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => onAddToBag(prod, prod.shades[0])}
                        className="px-3 py-1 btn-prism-cyan text-white text-[11px] font-semibold flex items-center gap-1"
                      >
                        <ShoppingBag className="w-3 h-3" /> Add
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          onInspectProduct(prod);
                        }}
                        className="px-3 py-1 border border-indigo-500/30 text-[11px] font-semibold hover:bg-indigo-500/10"
                      >
                        Inspect 3D
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </CinematicModal>
  );
};
