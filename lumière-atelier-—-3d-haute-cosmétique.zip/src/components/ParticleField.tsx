import React, { useEffect, useRef } from 'react';
import { ParticleDensity } from '../types/store';
import { useMotionPreferences } from '../context/MotionContext';

interface ParticleFieldProps {
  enabled?: boolean;
  density?: ParticleDensity;
  speedMultiplier?: number;
  className?: string;
}

const DENSITY_COUNT: Record<ParticleDensity, number> = {
  off: 0,
  low: 16,
  medium: 34,
  high: 56,
};

function hexToRgba(hex: string, alpha: number): string {
  const clean = hex.replace('#', '');
  const r = parseInt(clean.slice(0, 2), 16) || 34;
  const g = parseInt(clean.slice(2, 4), 16) || 211;
  const b = parseInt(clean.slice(4, 6), 16) || 238;
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

export const ParticleField: React.FC<ParticleFieldProps> = ({
  enabled = true,
  density = 'medium',
  speedMultiplier = 1,
  className = '',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const {
    effectiveGlobalLighting,
    effectiveBackgroundLighting,
    lightPalette,
    ambientLightingScale,
    neonGlowScale,
    lightSpeedMultiplier,
  } = useMotionPreferences();

  const shouldRender = enabled && effectiveGlobalLighting && effectiveBackgroundLighting && density !== 'off';

  useEffect(() => {
    const count = shouldRender ? DENSITY_COUNT[density] : 0;
    if (count <= 0) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let rafId = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const pointer = { x: -9999, y: -9999 };
    const velocityScale = 1 / Math.max(0.5, speedMultiplier * lightSpeedMultiplier);

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = Math.max(1, Math.floor(rect.width * dpr));
      canvas.height = Math.max(1, Math.floor(rect.height * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const onPointerMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      if (
        e.clientX >= rect.left &&
        e.clientX <= rect.right &&
        e.clientY >= rect.top &&
        e.clientY <= rect.bottom
      ) {
        pointer.x = e.clientX - rect.left;
        pointer.y = e.clientY - rect.top;
      } else {
        pointer.x = -9999;
        pointer.y = -9999;
      }
    };

    resize();
    window.addEventListener('resize', resize);
    window.addEventListener('mousemove', onPointerMove, { passive: true });

    const alphaBoost = Math.min(0.92, 0.76 * ambientLightingScale);
    const paletteHexes = [lightPalette.c1, lightPalette.c2, lightPalette.c3, lightPalette.c4, '#FFFFFF'];
    const lineColorBase = lightPalette.c1;

    const particles = Array.from({ length: count }, (_, idx) => {
      const hex = paletteHexes[idx % paletteHexes.length];
      return {
        x: Math.random() * (canvas.clientWidth || 1200),
        y: Math.random() * (canvas.clientHeight || 520),
        r: 1.3 + (idx % 3) * 0.95,
        vx: (Math.random() - 0.5) * 0.34 * velocityScale,
        vy: ((Math.random() - 0.5) * 0.24 - 0.06) * velocityScale,
        hex,
        color: hex === '#FFFFFF' ? 'rgba(255, 255, 255, 0.78)' : hexToRgba(hex, alphaBoost),
        shape: idx % 5 === 0 ? 'diamond' : 'circle',
      };
    });

    const linkDist = density === 'high' ? 132 : 114;
    const haloScale = Math.min(1.4, Math.max(0.5, neonGlowScale));

    const draw = () => {
      const w = canvas.clientWidth || 1200;
      const h = canvas.clientHeight || 520;
      ctx.clearRect(0, 0, w, h);

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        // Subtle interactive cursor deflection
        const mdx = p.x - pointer.x;
        const mdy = p.y - pointer.y;
        const mDist = Math.hypot(mdx, mdy);
        if (mDist > 1 && mDist < 95) {
          const force = (1 - mDist / 95) * 0.55;
          p.x += (mdx / mDist) * force;
          p.y += (mdy / mDist) * force;
        }

        p.x += p.vx;
        p.y += p.vy;

        if (p.x < -12) p.x = w + 12;
        if (p.x > w + 12) p.x = -12;
        if (p.y < -12) p.y = h + 12;
        if (p.y > h + 12) p.y = -12;

        // Soft luminous ambient halo around each light particle
        const haloR = p.r * 4.2 * haloScale;
        const halo = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, haloR);
        halo.addColorStop(0, p.hex === '#FFFFFF' ? 'rgba(255,255,255,0.42)' : hexToRgba(p.hex, 0.36 * ambientLightingScale));
        halo.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = halo;
        ctx.beginPath();
        ctx.arc(p.x, p.y, haloR, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = p.color;
        if (p.shape === 'diamond') {
          const s = p.r * 1.5;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y - s);
          ctx.lineTo(p.x + s, p.y);
          ctx.lineTo(p.x, p.y + s);
          ctx.lineTo(p.x - s, p.y);
          ctx.closePath();
          ctx.fill();
        } else {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctx.fill();
        }

        for (let j = i + 1; j < particles.length; j++) {
          const q = particles[j];
          const dx = p.x - q.x;
          const dy = p.y - q.y;
          const dist = Math.hypot(dx, dy);
          if (dist < linkDist) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(q.x, q.y);
            ctx.strokeStyle = hexToRgba(lineColorBase, (1 - dist / linkDist) * 0.22 * ambientLightingScale);
            ctx.lineWidth = 0.75;
            ctx.stroke();
          }
        }
      }

      rafId = requestAnimationFrame(draw);
    };

    rafId = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('resize', resize);
      window.removeEventListener('mousemove', onPointerMove);
    };
  }, [shouldRender, density, speedMultiplier, lightSpeedMultiplier, lightPalette, ambientLightingScale, neonGlowScale]);

  if (!shouldRender) return null;

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className={`pointer-events-none absolute inset-0 w-full h-full z-0 ${className}`}
    />
  );
};
