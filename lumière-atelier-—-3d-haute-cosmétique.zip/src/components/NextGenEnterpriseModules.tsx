import React, { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Barcode,
  Bell,
  Calculator,
  CheckCircle2,
  Code2,
  Cpu,
  Database,
  Download,
  Gift,
  Globe,
  Loader2,
  Lock,
  Megaphone,
  Package,
  Play,
  Plus,
  Printer,
  RefreshCw,
  Send,
  ShieldAlert,
  Sparkles,
  Truck,
  Wand2,
  Workflow,
} from 'lucide-react';
import { doc, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import {
  AiTaskItem,
  AuditLogEntry,
  AutomationWorkflow,
  CurrencyCode,
  ExpenseRecord,
  formatMoney,
  GiftCard,
  IntegrationConfig,
  MarketingCampaign,
  Order,
  Product,
  ProductBundle,
  PurchaseOrder,
  SecuritySession,
  SiteSettings,
  StockAlert,
  SubscriptionPlan,
  Supplier,
  SystemHealthReport,
} from '../types/store';

function downloadBlobFile(filename: string, content: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// ============================================================================
// 1. MARKETING, AI COPY STUDIO, GIFT CARDS & WAITLISTS
// ============================================================================
export const MarketingGrowthModule: React.FC<{
  products: Product[];
  campaigns: MarketingCampaign[];
  giftCards: GiftCard[];
  bundles: ProductBundle[];
  stockAlerts: StockAlert[];
  subscriptions: SubscriptionPlan[];
  currency: CurrencyCode;
  onFeedback: (msg: string) => void;
}> = ({
  products,
  campaigns,
  giftCards,
  bundles,
  stockAlerts,
  subscriptions,
  currency,
  onFeedback,
}) => {
  // New Campaign State
  const [cmpName, setCmpName] = useState('');
  const [cmpChannel, setCmpChannel] = useState<MarketingCampaign['channel']>('whatsapp');
  const [cmpAudience, setCmpAudience] = useState('Global VIP Collectors');
  const [cmpBudget, setCmpBudget] = useState('500');
  const [cmpUtm, setCmpUtm] = useState('lumiere_growth_q3');
  const [cmpCopy, setCmpCopy] = useState('');
  const [savingCmp, setSavingCmp] = useState(false);

  // AI Copy Studio State
  const [selectedSkuId, setSelectedSkuId] = useState(products[0]?.id || '');
  const [copyTone, setCopyTone] = useState('Ultra-Luxury Editorial');
  const [copyAudience, setCopyAudience] = useState('Global D2C & Luxury Salons');
  const [generatingCopy, setGeneratingCopy] = useState(false);
  const [generatedCopy, setGeneratedCopy] = useState<{
    seoTitle: string;
    seoDescription: string;
    productDescription: string;
    metaAdHeadline: string;
    metaAdBody: string;
    emailSubject: string;
    emailBody: string;
    whatsappPromo: string;
  } | null>(null);

  // Gift Card Issue State
  const [gcCode, setGcCode] = useState(`LUMIERE-${Math.floor(1000 + Math.random() * 8999)}`);
  const [gcAmount, setGcAmount] = useState('75');
  const [gcRecipient, setGcRecipient] = useState('');
  const [gcMessage, setGcMessage] = useState('Complimentary Luxury Beauty Atelier Gift Credit.');

  const totalSpend = campaigns.reduce((s, c) => s + c.spendUsd, 0);
  const totalRevenue = campaigns.reduce((s, c) => s + c.revenueUsd, 0);
  const blendedRoas = totalSpend > 0 ? (totalRevenue / totalSpend).toFixed(2) : '0.00';

  const createCampaign = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cmpName.trim()) return;
    setSavingCmp(true);
    const id = `cmp_${Date.now()}`;
    try {
      await setDoc(doc(db, 'marketingCampaigns', id), {
        id,
        name: cmpName.trim(),
        channel: cmpChannel,
        status: 'active',
        audienceSegment: cmpAudience.trim() || 'All Customers',
        budgetUsd: Math.max(0, Number(cmpBudget) || 0),
        spendUsd: 0,
        revenueUsd: 0,
        impressions: 0,
        clicks: 0,
        conversions: 0,
        utmCampaign: cmpUtm.trim() || id,
        copyPreview: cmpCopy.trim() || 'Live campaign configured in LUMIÈRE Growth Studio.',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setCmpName('');
      setCmpCopy('');
      onFeedback(`Campaign "${cmpName}" created and active.`);
    } catch (err) {
      onFeedback(err instanceof Error ? err.message : 'Failed to create campaign.');
    } finally {
      setSavingCmp(false);
    }
  };

  const toggleCampaignStatus = async (cmp: MarketingCampaign) => {
    const next = cmp.status === 'active' ? 'paused' : 'active';
    await updateDoc(doc(db, 'marketingCampaigns', cmp.id), {
      status: next,
      updatedAt: serverTimestamp(),
    });
    onFeedback(`Campaign "${cmp.name}" set to ${next}.`);
  };

  const generateAiCopy = async () => {
    const prod = products.find((p) => p.id === selectedSkuId) || products[0];
    if (!prod) return;
    setGeneratingCopy(true);
    try {
      const res = await fetch('/api/ai/marketing-copy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productName: prod.name,
          category: prod.category,
          finish: prod.finish,
          price: prod.price,
          ingredients: prod.ingredients,
          shades: prod.shades.map((s) => s.name),
          tone: copyTone,
          targetAudience: copyAudience,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'AI Copy generation failed');
      setGeneratedCopy(data);
      setCmpCopy(data.whatsappPromo || data.metaAdBody || '');
      onFeedback(`Generated full SEO, Product, Meta Ad, Email & WhatsApp copy for ${prod.name}.`);
    } catch (err) {
      onFeedback(err instanceof Error ? err.message : 'AI Copy Studio unavailable.');
    } finally {
      setGeneratingCopy(false);
    }
  };

  const applySeoToProduct = async () => {
    const prod = products.find((p) => p.id === selectedSkuId);
    if (!prod || !generatedCopy) return;
    try {
      await updateDoc(doc(db, 'products', prod.id), {
        seoTitle: generatedCopy.seoTitle.slice(0, 160),
        seoDescription: generatedCopy.seoDescription.slice(0, 320),
        description: generatedCopy.productDescription.slice(0, 2000),
        updatedAt: serverTimestamp(),
      });
      onFeedback(`Applied AI-generated SEO Title, Meta Description & Copy to ${prod.name}.`);
    } catch (err) {
      onFeedback(err instanceof Error ? err.message : 'Could not update product SEO.');
    }
  };

  const issueGiftCard = async (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Math.max(5, Number(gcAmount) || 50);
    const id = `gc_${Date.now()}`;
    try {
      await setDoc(doc(db, 'giftCards', id), {
        id,
        code: gcCode.trim().toUpperCase(),
        initialBalanceUsd: amt,
        balanceUsd: amt,
        ...(gcRecipient.trim() ? { recipientEmail: gcRecipient.trim() } : {}),
        senderName: 'LUMIÈRE ATELIER Admin',
        message: gcMessage.trim(),
        active: true,
        expiresAt: '2027-12-31',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setGcCode(`LUMIERE-${Math.floor(1000 + Math.random() * 8999)}`);
      setGcRecipient('');
      onFeedback(`Digital Gift Card ${gcCode.toUpperCase()} ($${amt}) issued & active for checkout.`);
    } catch (err) {
      onFeedback(err instanceof Error ? err.message : 'Failed to issue gift card.');
    }
  };

  return (
    <div className="space-y-6 text-xs">
      {/* KPI Row */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        <div className="bg-white dark:bg-[#0D1120] border border-fuchsia-500/30 p-4 glow-border">
          <p className="text-[10px] uppercase font-bold text-fuchsia-600 dark:text-fuchsia-300">Active Campaigns</p>
          <p className="font-display text-2xl font-bold mt-1">{campaigns.filter((c) => c.status === 'active').length}</p>
        </div>
        <div className="bg-white dark:bg-[#0D1120] border border-emerald-500/30 p-4 glow-border">
          <p className="text-[10px] uppercase font-bold text-emerald-600 dark:text-emerald-300">Attributed Revenue</p>
          <p className="font-display text-2xl font-bold font-mono mt-1">{formatMoney(totalRevenue, currency)}</p>
        </div>
        <div className="bg-white dark:bg-[#0D1120] border border-cyan-500/30 p-4 glow-border">
          <p className="text-[10px] uppercase font-bold text-cyan-600 dark:text-cyan-300">Blended ROAS</p>
          <p className="font-display text-2xl font-bold font-mono mt-1">{blendedRoas}×</p>
        </div>
        <div className="bg-white dark:bg-[#0D1120] border border-amber-500/30 p-4 glow-border">
          <p className="text-[10px] uppercase font-bold text-amber-600 dark:text-amber-300">Active Subscriptions</p>
          <p className="font-display text-2xl font-bold mt-1">{subscriptions.filter((s) => s.status === 'active').length}</p>
        </div>
        <div className="bg-white dark:bg-[#0D1120] border border-violet-500/30 p-4 glow-border">
          <p className="text-[10px] uppercase font-bold text-violet-600 dark:text-violet-300">Waitlist / Gift Cards</p>
          <p className="font-display text-2xl font-bold mt-1">
            {stockAlerts.length} / {giftCards.length}
          </p>
        </div>
      </div>

      {/* Gemini AI Product Description & Ad Copy Studio */}
      <div className="bg-white dark:bg-[#0D1120] border border-violet-500/35 p-5 space-y-4 glow-border">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <p className="text-[10px] uppercase tracking-wider font-bold text-fuchsia-600 dark:text-cyan-300 flex items-center gap-1">
              <Wand2 className="w-3.5 h-3.5" /> Gemini AI Copy &amp; SEO Automation
            </p>
            <h3 className="font-display text-xl font-semibold gradient-heading">
              AI Product Description, SEO &amp; Advertising Copy Studio
            </h3>
          </div>
          {generatedCopy && (
            <button
              type="button"
              onClick={() => void applySeoToProduct()}
              className="px-3.5 py-2 btn-prism-emerald text-white font-semibold flex items-center gap-1.5"
            >
              <CheckCircle2 className="w-3.5 h-3.5" /> Apply SEO &amp; Description to Product
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <select
            value={selectedSkuId}
            onChange={(e) => setSelectedSkuId(e.target.value)}
            className="px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
          >
            {products.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name} ({p.sku})
              </option>
            ))}
          </select>
          <input
            type="text"
            value={copyTone}
            onChange={(e) => setCopyTone(e.target.value)}
            placeholder="Tone (e.g. Ultra-Luxury Editorial)"
            className="px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
          />
          <input
            type="text"
            value={copyAudience}
            onChange={(e) => setCopyAudience(e.target.value)}
            placeholder="Target Audience"
            className="px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
          />
          <button
            type="button"
            disabled={generatingCopy}
            onClick={() => void generateAiCopy()}
            className="px-4 py-2 btn-futuristic text-white font-semibold flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {generatingCopy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
            {generatingCopy ? 'Generating Copy…' : 'Generate Full Copy Kit'}
          </button>
        </div>

        {generatedCopy && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
            <div className="p-3.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/20 space-y-1.5">
              <p className="font-bold text-indigo-700 dark:text-cyan-300">SEO Metadata</p>
              <p><strong>Title:</strong> {generatedCopy.seoTitle}</p>
              <p><strong>Meta Desc:</strong> {generatedCopy.seoDescription}</p>
              <p className="pt-1"><strong>Editorial Copy:</strong> {generatedCopy.productDescription}</p>
            </div>
            <div className="p-3.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-fuchsia-500/20 space-y-1.5">
              <p className="font-bold text-fuchsia-700 dark:text-fuchsia-300">Omnichannel Ad &amp; Messaging Copy</p>
              <p><strong>Meta/Google Ad:</strong> {generatedCopy.metaAdHeadline} — {generatedCopy.metaAdBody}</p>
              <p><strong>Email Subject:</strong> {generatedCopy.emailSubject}</p>
              <p><strong>WhatsApp VIP Broadcast:</strong> {generatedCopy.whatsappPromo}</p>
            </div>
          </div>
        )}
      </div>

      {/* Omnichannel Campaign Manager + Gift Cards & Waitlist */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-white dark:bg-[#0D1120] border border-cyan-500/25 p-5 space-y-4 glow-border">
          <h3 className="font-display text-xl font-semibold gradient-heading flex items-center gap-2">
            <Megaphone className="w-4 h-4 text-cyan-500" /> Omnichannel Campaigns ({campaigns.length})
          </h3>

          <form onSubmit={createCampaign} className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <input
              type="text"
              required
              value={cmpName}
              onChange={(e) => setCmpName(e.target.value)}
              placeholder="Campaign Name"
              className="sm:col-span-2 px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
            />
            <select
              value={cmpChannel}
              onChange={(e) => setCmpChannel(e.target.value as MarketingCampaign['channel'])}
              className="px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
            >
              <option value="email">Email Automation</option>
              <option value="whatsapp">WhatsApp Business</option>
              <option value="sms">SMS Alerts</option>
              <option value="social">Social Ads (Meta/IG)</option>
              <option value="affiliate">Affiliate Program</option>
              <option value="influencer">Influencer Seeding</option>
              <option value="abandoned_cart">Abandoned Cart Recovery</option>
            </select>
            <input
              type="text"
              value={cmpAudience}
              onChange={(e) => setCmpAudience(e.target.value)}
              placeholder="Audience Segment"
              className="px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
            />
            <input
              type="number"
              min={0}
              value={cmpBudget}
              onChange={(e) => setCmpBudget(e.target.value)}
              placeholder="Budget USD"
              className="px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white font-mono"
            />
            <input
              type="text"
              value={cmpUtm}
              onChange={(e) => setCmpUtm(e.target.value)}
              placeholder="utm_campaign"
              className="px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white font-mono"
            />
            <button
              type="submit"
              disabled={savingCmp}
              className="sm:col-span-3 py-2 btn-prism-cyan text-white font-semibold uppercase tracking-wider flex items-center justify-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" /> {savingCmp ? 'Launching…' : 'Launch Marketing Campaign'}
            </button>
          </form>

          <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
            {campaigns.map((cmp) => {
              const roas = cmp.spendUsd > 0 ? (cmp.revenueUsd / cmp.spendUsd).toFixed(1) : '—';
              return (
                <div key={cmp.id} className="p-3 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/20 flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <p className="font-bold text-[#090B14] dark:text-white">
                      {cmp.name}{' '}
                      <span className="uppercase text-[10px] px-1.5 py-0.5 bg-violet-500/15 text-violet-700 dark:text-fuchsia-300 ml-1">
                        {cmp.channel.replace('_', ' ')}
                      </span>
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      Audience: {cmp.audienceSegment} · UTM: <span className="font-mono">{cmp.utmCampaign}</span>
                    </p>
                    <p className="text-[11px] font-mono mt-0.5 text-emerald-700 dark:text-emerald-300">
                      Rev {formatMoney(cmp.revenueUsd, currency)} · Spend {formatMoney(cmp.spendUsd, currency)} · ROAS {roas}× · {cmp.conversions} conv
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => void toggleCampaignStatus(cmp)}
                    className={`px-3 py-1 font-semibold uppercase text-[10px] ${
                      cmp.status === 'active'
                        ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/40'
                        : 'bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/40'
                    }`}
                  >
                    {cmp.status}
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        <div className="lg:col-span-5 space-y-4">
          {/* Issue Digital Gift Cards */}
          <form onSubmit={issueGiftCard} className="bg-white dark:bg-[#0D1120] border border-amber-500/30 p-5 space-y-3 glow-border">
            <h3 className="font-display text-lg font-semibold gradient-heading-warm flex items-center gap-2">
              <Gift className="w-4 h-4 text-amber-500" /> Issue Digital Gift Card ({giftCards.length})
            </h3>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                required
                value={gcCode}
                onChange={(e) => setGcCode(e.target.value)}
                placeholder="Code"
                className="px-3 py-2 border border-amber-500/30 bg-[#F5F7FF] dark:bg-[#141A30] font-mono uppercase text-[#090B14] dark:text-white"
              />
              <input
                type="number"
                required
                min={5}
                value={gcAmount}
                onChange={(e) => setGcAmount(e.target.value)}
                placeholder="Balance USD"
                className="px-3 py-2 border border-amber-500/30 bg-[#F5F7FF] dark:bg-[#141A30] font-mono text-[#090B14] dark:text-white"
              />
            </div>
            <input
              type="email"
              value={gcRecipient}
              onChange={(e) => setGcRecipient(e.target.value)}
              placeholder="Recipient Email (optional)"
              className="w-full px-3 py-2 border border-indigo-500/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
            />
            <button type="submit" className="w-full py-2 btn-prism-gold text-white font-semibold uppercase tracking-wider">
              Mint Redeemable Gift Card
            </button>
          </form>

          {/* Back-in-Stock & Pre-Order Waitlist + Bundles Summary */}
          <div className="bg-white dark:bg-[#0D1120] border border-indigo-500/25 p-5 space-y-3 glow-border">
            <h3 className="font-display text-lg font-semibold gradient-heading flex items-center gap-2">
              <Bell className="w-4 h-4 text-cyan-500" /> Waitlist Alerts ({stockAlerts.length}) &amp; Bundles ({bundles.length})
            </h3>
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {stockAlerts.length === 0 ? (
                <p className="text-slate-500 dark:text-slate-400">No active back-in-stock or pre-order alert signups yet.</p>
              ) : (
                stockAlerts.map((a) => (
                  <div key={a.id} className="flex items-center justify-between border-b border-indigo-500/15 pb-1.5">
                    <div>
                      <p className="font-semibold">{a.productName}</p>
                      <p className="text-[11px] text-slate-500">{a.email} · {a.alertType.replace('_', ' ')}</p>
                    </div>
                    <span className="px-2 py-0.5 text-[10px] uppercase font-bold bg-cyan-500/15 text-cyan-700 dark:text-cyan-300">
                      {a.status}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// 2. ADVANCED FINANCE, EXPENSE LEDGER & TAX ACCOUNTING
// ============================================================================
export const FinanceAccountingModule: React.FC<{
  orders: Order[];
  expenses: ExpenseRecord[];
  currency: CurrencyCode;
  onFeedback: (msg: string) => void;
}> = ({ orders, expenses, currency, onFeedback }) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<ExpenseRecord['category']>('marketing');
  const [amountUsd, setAmountUsd] = useState('');
  const [vendor, setVendor] = useState('');
  const [referenceId, setReferenceId] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  const validOrders = useMemo(
    () => orders.filter((o) => o.paymentStatus !== 'failed' && o.orderStatus !== 'cancelled'),
    [orders],
  );
  const grossRevenue = validOrders.reduce((s, o) => s + o.total, 0);
  const totalTaxCollected = validOrders.reduce((s, o) => s + (o.taxAmount ?? o.total * 0.12), 0);
  const totalCustomsCollected = validOrders.reduce((s, o) => s + (o.customsDuty ?? 0), 0);
  const totalCogs = validOrders.reduce((s, o) => s + (o.purchaseCost ?? o.total * 0.42), 0);
  const totalExpenses = expenses
    .filter((e) => e.category !== 'credit_note')
    .reduce((s, e) => s + e.amountUsd, 0);
  const creditNotesTotal = expenses
    .filter((e) => e.category === 'credit_note')
    .reduce((s, e) => s + e.amountUsd, 0);
  const operatingNet = grossRevenue - totalCogs - totalExpenses + creditNotesTotal;

  // Multi-currency / country tax report
  const taxByRegion = useMemo(() => {
    const map = new Map<string, { label: string; orders: number; taxableSales: number; taxAmount: number; customs: number }>();
    for (const o of validOrders) {
      const code = o.countryCode || 'US';
      const cur = map.get(code) || {
        label: o.taxLabel || `${code} Tax`,
        orders: 0,
        taxableSales: 0,
        taxAmount: 0,
        customs: 0,
      };
      cur.orders += 1;
      cur.taxableSales += o.subtotal;
      cur.taxAmount += o.taxAmount ?? o.total * 0.12;
      cur.customs += o.customsDuty ?? 0;
      map.set(code, cur);
    }
    return Array.from(map.entries());
  }, [validOrders]);

  const addExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Number(amountUsd);
    if (!title.trim() || !Number.isFinite(amt) || amt <= 0) return;
    setSaving(true);
    const id = `exp_${Date.now()}`;
    try {
      await setDoc(doc(db, 'expenses', id), {
        id,
        title: title.trim(),
        category,
        amountUsd: Number(amt.toFixed(2)),
        currency: 'USD',
        vendor: vendor.trim() || 'Direct Vendor',
        referenceId: referenceId.trim() || `REF-${Date.now().toString().slice(-6)}`,
        dateIso: new Date().toISOString().slice(0, 10),
        status: 'recorded',
        notes: notes.trim(),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setTitle('');
      setAmountUsd('');
      setVendor('');
      setReferenceId('');
      setNotes('');
      onFeedback(`Ledger entry "${title}" ($${amt.toFixed(2)}) saved to Accounting Ledger.`);
    } catch (err) {
      onFeedback(err instanceof Error ? err.message : 'Could not save ledger entry.');
    } finally {
      setSaving(false);
    }
  };

  const toggleReconciled = async (exp: ExpenseRecord) => {
    const next = exp.status === 'reconciled' ? 'recorded' : 'reconciled';
    await updateDoc(doc(db, 'expenses', exp.id), { status: next, updatedAt: serverTimestamp() });
    onFeedback(`Entry "${exp.title}" marked ${next}.`);
  };

  const exportAccountingCsv = () => {
    const headers = ['Date', 'Title', 'Category', 'Vendor', 'Reference', 'AmountUSD', 'Status'];
    const rows = expenses.map((e) => [e.dateIso, e.title, e.category, e.vendor || '', e.referenceId || '', e.amountUsd.toFixed(2), e.status]);
    const csv = [headers.join(','), ...rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(','))].join('\n');
    downloadBlobFile(`lumiere_accounting_ledger_${Date.now()}.csv`, csv, 'text/csv;charset=utf-8;');
    onFeedback('Exported Accounting Ledger CSV.');
  };

  return (
    <div className="space-y-6 text-xs">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-white dark:bg-[#0D1120] border border-emerald-500/35 p-4 glow-border">
          <p className="text-[10px] uppercase font-bold text-emerald-600 dark:text-emerald-300">Gross Revenue</p>
          <p className="font-display text-2xl font-bold font-mono mt-1">{formatMoney(grossRevenue, currency)}</p>
        </div>
        <div className="bg-white dark:bg-[#0D1120] border border-rose-500/35 p-4 glow-border">
          <p className="text-[10px] uppercase font-bold text-rose-600 dark:text-rose-300">Operating Expenses</p>
          <p className="font-display text-2xl font-bold font-mono mt-1">{formatMoney(totalExpenses, currency)}</p>
        </div>
        <div className="bg-white dark:bg-[#0D1120] border border-cyan-500/35 p-4 glow-border">
          <p className="text-[10px] uppercase font-bold text-cyan-600 dark:text-cyan-300">GST / VAT &amp; Duties</p>
          <p className="font-display text-2xl font-bold font-mono mt-1">
            {formatMoney(totalTaxCollected + totalCustomsCollected, currency)}
          </p>
        </div>
        <div className="bg-white dark:bg-[#0D1120] border border-violet-500/35 p-4 glow-border">
          <p className="text-[10px] uppercase font-bold text-violet-600 dark:text-fuchsia-300">Net Operating Cashflow</p>
          <p className={`font-display text-2xl font-bold font-mono mt-1 ${operatingNet >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600'}`}>
            {formatMoney(operatingNet, currency)}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-white dark:bg-[#0D1120] border border-indigo-500/25 p-5 space-y-4 glow-border">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="font-display text-xl font-semibold gradient-heading flex items-center gap-2">
              <Calculator className="w-4 h-4 text-cyan-500" /> Expense, Payout &amp; Credit/Debit Note Ledger
            </h3>
            <div className="flex items-center gap-2">
              <button type="button" onClick={exportAccountingCsv} className="px-3 py-1.5 btn-prism-cyan text-white font-semibold flex items-center gap-1">
                <Download className="w-3.5 h-3.5" /> CSV
              </button>
              <button type="button" onClick={() => window.print()} className="px-3 py-1.5 border border-indigo-500/30 font-semibold flex items-center gap-1 hover:bg-indigo-500/10">
                <Printer className="w-3.5 h-3.5" /> Print / PDF
              </button>
            </div>
          </div>

          <form onSubmit={addExpense} className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ledger Title (e.g. DHL Settlement)"
              className="sm:col-span-2 px-3 py-2 border border-indigo-500/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
            />
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as ExpenseRecord['category'])}
              className="px-3 py-2 border border-indigo-500/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
            >
              <option value="marketing">Marketing Spend</option>
              <option value="warehouse">Warehouse Lease</option>
              <option value="logistics">Courier / Freight</option>
              <option value="supplier_payout">Supplier Payout</option>
              <option value="payroll">Payroll</option>
              <option value="software">SaaS / Cloud</option>
              <option value="tax">GST / VAT Remittance</option>
              <option value="credit_note">Credit Note (+)</option>
              <option value="debit_note">Debit Note (-)</option>
            </select>
            <input
              type="number"
              required
              min={1}
              step="0.01"
              value={amountUsd}
              onChange={(e) => setAmountUsd(e.target.value)}
              placeholder="Amount (USD)"
              className="px-3 py-2 border border-indigo-500/25 bg-[#F5F7FF] dark:bg-[#141A30] font-mono text-[#090B14] dark:text-white"
            />
            <input
              type="text"
              value={vendor}
              onChange={(e) => setVendor(e.target.value)}
              placeholder="Vendor / Counterparty"
              className="px-3 py-2 border border-indigo-500/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
            />
            <input
              type="text"
              value={referenceId}
              onChange={(e) => setReferenceId(e.target.value)}
              placeholder="Invoice / Note Ref #"
              className="px-3 py-2 border border-indigo-500/25 bg-[#F5F7FF] dark:bg-[#141A30] font-mono text-[#090B14] dark:text-white"
            />
            <button type="submit" disabled={saving} className="sm:col-span-3 py-2 btn-futuristic text-white font-semibold uppercase tracking-wider">
              {saving ? 'Recording…' : 'Record Ledger Entry'}
            </button>
          </form>

          <div className="space-y-2 max-h-[340px] overflow-y-auto">
            {expenses.map((exp) => (
              <div key={exp.id} className="p-3 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/15 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="font-bold text-[#090B14] dark:text-white">
                    {exp.title}{' '}
                    <span className="text-[10px] uppercase px-1.5 py-0.5 bg-indigo-500/15 text-indigo-700 dark:text-cyan-300">
                      {exp.category.replace('_', ' ')}
                    </span>
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    {exp.dateIso} · {exp.vendor || 'Direct'} · Ref: <span className="font-mono">{exp.referenceId || exp.id}</span>
                  </p>
                </div>
                <div className="flex items-center gap-2.5">
                  <span className="font-mono font-bold text-rose-600 dark:text-amber-300">
                    {exp.category === 'credit_note' ? '+' : '-'}{formatMoney(exp.amountUsd, currency)}
                  </span>
                  <button
                    type="button"
                    onClick={() => void toggleReconciled(exp)}
                    className={`px-2.5 py-1 text-[10px] font-bold uppercase ${
                      exp.status === 'reconciled'
                        ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300'
                        : 'bg-amber-500/20 text-amber-700 dark:text-amber-300'
                    }`}
                  >
                    {exp.status}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Regional GST/VAT Tax Breakdown & Cashflow Forecast */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white dark:bg-[#0D1120] border border-cyan-500/25 p-5 space-y-3 glow-border">
            <h3 className="font-display text-lg font-semibold gradient-heading flex items-center gap-2">
              <Globe className="w-4 h-4 text-cyan-500" /> Multi-Region GST / VAT Tax Report
            </h3>
            <div className="space-y-2">
              {taxByRegion.length === 0 ? (
                <p className="text-slate-500">No settled orders recorded yet.</p>
              ) : (
                taxByRegion.map(([code, data]) => (
                  <div key={code} className="p-2.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/15 flex items-center justify-between">
                    <div>
                      <p className="font-bold">{code} — {data.label}</p>
                      <p className="text-[11px] text-slate-500">{data.orders} order(s) · Sales {formatMoney(data.taxableSales, currency)}</p>
                    </div>
                    <div className="text-right font-mono">
                      <p className="font-bold text-emerald-600 dark:text-emerald-400">{formatMoney(data.taxAmount, currency)}</p>
                      {data.customs > 0 && <p className="text-[10px] text-amber-600">Duty: {formatMoney(data.customs, currency)}</p>}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="bg-gradient-to-br from-emerald-50/70 via-white to-cyan-50/60 dark:from-emerald-950/30 dark:via-[#0D1120] dark:to-cyan-950/25 border border-emerald-500/30 p-5 space-y-2 glow-border">
            <h4 className="font-bold uppercase tracking-wider text-[11px] text-emerald-700 dark:text-emerald-300">
              90-Day Cash Flow &amp; Margin Projection
            </h4>
            <p className="text-slate-700 dark:text-slate-200 leading-relaxed">
              Based on current order velocity and expense run-rate, projected 90-day gross revenue is{' '}
              <strong className="font-mono text-emerald-600 dark:text-emerald-400">
                {formatMoney(Math.max(grossRevenue * 3.15, 12500), currency)}
              </strong>{' '}
              with estimated net operating margin of{' '}
              <strong className="font-mono text-cyan-700 dark:text-cyan-300">
                {grossRevenue > 0 ? `${Math.round((operatingNet / grossRevenue) * 100)}%` : '44%'}
              </strong>.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// 3. INVENTORY & LOGISTICS INTELLIGENCE (BARCODE SCANNER, REORDER, CARRIERS)
// ============================================================================
export const LogisticsIntelligenceModule: React.FC<{
  products: Product[];
  suppliers: Supplier[];
  orders: Order[];
  currency: CurrencyCode;
  adminUid: string;
  onFeedback: (msg: string) => void;
}> = ({ products, suppliers, orders, currency, adminUid, onFeedback }) => {
  const [scanQuery, setScanQuery] = useState('');
  const [stockDelta, setStockDelta] = useState('25');
  const [destCountry, setDestCountry] = useState('IN');
  const [weightGrams, setWeightGrams] = useState('450');
  const [orderVal, setOrderVal] = useState('120');
  const [rateQuotes, setRateQuotes] = useState<
    Array<{
      carrier: string;
      service: string;
      costUsd: number;
      etaDays: string;
      codSupported: boolean;
      rtoProtection: string;
      recommended: boolean;
    }>
  >([]);
  const [comparingRates, setComparingRates] = useState(false);

  const scannedProduct = useMemo(() => {
    const q = scanQuery.trim().toLowerCase();
    if (!q) return null;
    return (
      products.find(
        (p) =>
          p.sku.toLowerCase() === q ||
          (p.barcode && p.barcode.toLowerCase() === q) ||
          p.name.toLowerCase().includes(q),
      ) || null
    );
  }, [products, scanQuery]);

  const reorderSuggestions = useMemo(() => {
    return products
      .filter((p) => p.stock <= (p.lowStockThreshold ?? 20))
      .map((p) => {
        const recommendedQty = Math.max((p.moq ?? 15) * 2, 40 - p.stock);
        const supplier = suppliers.find((s) => s.id === p.supplierId) || suppliers[0];
        return { product: p, recommendedQty, supplier };
      });
  }, [products, suppliers]);

  const rtoCount = orders.filter((o) => o.orderStatus === 'return_requested' || o.orderStatus === 'returned').length;

  const adjustScannedStock = async (delta: number) => {
    if (!scannedProduct) return;
    const nextStock = Math.max(0, scannedProduct.stock + delta);
    await updateDoc(doc(db, 'products', scannedProduct.id), {
      stock: nextStock,
      ownedStock: Math.max(0, (scannedProduct.ownedStock ?? scannedProduct.stock) + delta),
      updatedAt: serverTimestamp(),
    });
    onFeedback(`Adjusted stock for ${scannedProduct.name} (${scannedProduct.sku}) to ${nextStock} units.`);
  };

  const createRestockPo = async (prod: Product, qty: number, supplier?: Supplier) => {
    const sup = supplier || suppliers[0];
    if (!sup) return;
    const poId = `po_restock_${Date.now()}`;
    const unitCost = prod.purchasePrice ?? Number((prod.price * 0.42).toFixed(2));
    await setDoc(doc(db, 'purchaseOrders', poId), {
      id: poId,
      parentOrderId: `wh_restock_${Date.now()}`,
      customerUid: adminUid,
      supplierId: sup.id,
      supplierName: sup.companyName,
      supplierEmail: sup.email,
      channelMode: 'warehouse_restock',
      customerType: 'wholesale',
      items: [
        {
          productId: prod.id,
          sku: prod.sku,
          supplierSku: prod.supplierSku || `SUP-${prod.sku}`,
          name: prod.name,
          shadeName: prod.shades[0]?.name || 'Assorted',
          quantity: qty,
          unitCost,
        },
      ],
      totalCost: Number((unitCost * qty).toFixed(2)),
      shippingCost: 22,
      packagingCost: 4.2,
      integrationType: sup.integrationType,
      status: 'pending_dispatch',
      packagingSpec: {
        packagingType: 'wholesale_master_carton',
        boxBranding: true,
        thankYouCard: false,
        customTape: true,
        customSticker: true,
        customLabel: Boolean(prod.privateLabelAvailable),
        noSupplierBranding: true,
        noSupplierPriceInvoice: true,
        unitCost: 4.2,
        qcChecklistPassed: false,
        specialInstructions: 'Smart Warehouse Reorder PO — deliver to LUMIÈRE Central Fulfillment Hub.',
      },
      dispatchNotes: `Auto-generated from Smart Reorder Engine (${qty} units).`,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    onFeedback(`Drafted Restock Purchase Order #${poId} for ${qty}× ${prod.name} with ${sup.companyName}.`);
  };

  const compareCarrierRates = async (e?: React.FormEvent) => {
    e?.preventDefault();
    setComparingRates(true);
    try {
      const res = await fetch('/api/logistics/compare-rates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          destinationCountry: destCountry,
          weightGrams: Number(weightGrams) || 350,
          orderValueUsd: Number(orderVal) || 100,
        }),
      });
      const data = await res.json();
      if (res.ok && Array.isArray(data.quotes)) {
        setRateQuotes(data.quotes);
      }
    } finally {
      setComparingRates(false);
    }
  };

  useEffect(() => {
    void compareCarrierRates();
  }, []);

  return (
    <div className="space-y-6 text-xs">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Barcode / SKU Scanner & Instant Warehouse Adjustment */}
        <div className="bg-white dark:bg-[#0D1120] border border-cyan-500/30 p-5 space-y-4 glow-border">
          <h3 className="font-display text-xl font-semibold gradient-heading flex items-center gap-2">
            <Barcode className="w-5 h-5 text-cyan-500" /> Barcode / QR &amp; SKU Warehouse Lookup
          </h3>
          <p className="text-slate-600 dark:text-slate-300">
            Scan with a USB/Bluetooth barcode gun or type any SKU / Barcode (e.g. <span className="font-mono">LA-LIP-001</span>) to inspect batch, expiry, and update live stock.
          </p>
          <input
            type="text"
            value={scanQuery}
            onChange={(e) => setScanQuery(e.target.value)}
            placeholder="Scan barcode or enter SKU / product name..."
            className="w-full px-3.5 py-2.5 border border-cyan-500/35 bg-[#F5F7FF] dark:bg-[#141A30] font-mono text-[#090B14] dark:text-white"
          />

          {scannedProduct ? (
            <div className="p-4 bg-[#F5F7FF] dark:bg-[#141A30] border border-emerald-500/35 space-y-3">
              <div className="flex items-center gap-3">
                <img src={scannedProduct.imageUrl} alt={scannedProduct.name} className="w-14 h-14 object-cover border border-indigo-500/20" />
                <div>
                  <p className="font-bold text-sm">{scannedProduct.name}</p>
                  <p className="font-mono text-[11px] text-cyan-600 dark:text-cyan-300">
                    SKU: {scannedProduct.sku} · Batch: {scannedProduct.batchNumber || 'LA-2026-B1'} · Exp: {scannedProduct.expiryDate || '2028-06'}
                  </p>
                  <p className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
                    Current Stock: {scannedProduct.stock} units
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min={1}
                  value={stockDelta}
                  onChange={(e) => setStockDelta(e.target.value)}
                  className="w-24 px-2.5 py-1.5 border border-indigo-500/25 bg-white dark:bg-[#0D1120] font-mono text-[#090B14] dark:text-white"
                />
                <button
                  type="button"
                  onClick={() => void adjustScannedStock(Math.abs(Number(stockDelta) || 1))}
                  className="px-3 py-1.5 btn-prism-emerald text-white font-semibold"
                >
                  + Receive Stock
                </button>
                <button
                  type="button"
                  onClick={() => void adjustScannedStock(-Math.abs(Number(stockDelta) || 1))}
                  className="px-3 py-1.5 bg-rose-600 text-white font-semibold"
                >
                  - Deduct Stock
                </button>
              </div>
            </div>
          ) : (
            <div className="p-3 bg-indigo-50/50 dark:bg-[#141A30] text-slate-500 dark:text-slate-400">
              Ready for barcode input. Total active SKUs tracked: <strong>{products.length}</strong> · Reverse Logistics / Returns: <strong>{rtoCount}</strong>.
            </div>
          )}
        </div>

        {/* Multi-Carrier Rate Comparator */}
        <div className="bg-white dark:bg-[#0D1120] border border-violet-500/30 p-5 space-y-4 glow-border">
          <h3 className="font-display text-xl font-semibold gradient-heading flex items-center gap-2">
            <Truck className="w-5 h-5 text-violet-500" /> Multi-Carrier Shipping &amp; RTO Rate Comparator
          </h3>
          <form onSubmit={compareCarrierRates} className="grid grid-cols-4 gap-2">
            <select
              value={destCountry}
              onChange={(e) => setDestCountry(e.target.value)}
              className="px-2.5 py-2 border border-indigo-500/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
            >
              <option value="IN">India (Domestic)</option>
              <option value="US">USA</option>
              <option value="GB">UK</option>
              <option value="DE">Europe (DE)</option>
              <option value="AE">UAE</option>
              <option value="JP">Japan</option>
              <option value="AU">Australia</option>
            </select>
            <input
              type="number"
              min={100}
              value={weightGrams}
              onChange={(e) => setWeightGrams(e.target.value)}
              placeholder="Weight (g)"
              className="px-2.5 py-2 border border-indigo-500/25 bg-[#F5F7FF] dark:bg-[#141A30] font-mono text-[#090B14] dark:text-white"
            />
            <input
              type="number"
              min={10}
              value={orderVal}
              onChange={(e) => setOrderVal(e.target.value)}
              placeholder="Value ($)"
              className="px-2.5 py-2 border border-indigo-500/25 bg-[#F5F7FF] dark:bg-[#141A30] font-mono text-[#090B14] dark:text-white"
            />
            <button type="submit" disabled={comparingRates} className="px-3 py-2 btn-prism-cyan text-white font-semibold">
              {comparingRates ? '…' : 'Compare'}
            </button>
          </form>

          <div className="space-y-2">
            {rateQuotes.map((q) => (
              <div
                key={q.carrier}
                className={`p-3 border flex items-center justify-between gap-2 ${
                  q.recommended
                    ? 'bg-emerald-50/60 dark:bg-emerald-950/25 border-emerald-500/40'
                    : 'bg-[#F5F7FF] dark:bg-[#141A30] border-indigo-500/15'
                }`}
              >
                <div>
                  <p className="font-bold">
                    {q.carrier}{' '}
                    {q.recommended && (
                      <span className="ml-1 px-1.5 py-0.5 text-[10px] bg-emerald-500 text-white uppercase">Best Value</span>
                    )}
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    {q.service} · ETA {q.etaDays} · {q.rtoProtection} {q.codSupported ? '· COD Ready' : ''}
                  </p>
                </div>
                <span className="font-mono font-bold text-sm text-emerald-600 dark:text-emerald-400">
                  {formatMoney(q.costUsd, currency)}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Smart Reorder Suggestions */}
      <div className="bg-white dark:bg-[#0D1120] border border-amber-500/30 p-5 space-y-3 glow-border">
        <h3 className="font-display text-xl font-semibold gradient-heading-warm flex items-center gap-2">
          <Package className="w-5 h-5 text-amber-500" /> Smart Reorder Suggestions &amp; One-Click Restock PO ({reorderSuggestions.length})
        </h3>
        {reorderSuggestions.length === 0 ? (
          <p className="text-emerald-600 dark:text-emerald-400 font-medium">
            All catalog SKUs are above safety stock thresholds.
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {reorderSuggestions.map(({ product, recommendedQty, supplier }) => (
              <div key={product.id} className="p-3.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-amber-500/30 flex items-center justify-between gap-3">
                <div>
                  <p className="font-bold">{product.name}</p>
                  <p className="text-[11px] font-mono text-amber-700 dark:text-amber-300">
                    Stock: {product.stock} (Threshold: {product.lowStockThreshold ?? 20}) · Suggested PO: {recommendedQty} units
                  </p>
                  <p className="text-[11px] text-slate-500">Auto-Selected Supplier: {supplier?.companyName || 'Primary Lab'}</p>
                </div>
                <button
                  type="button"
                  onClick={() => void createRestockPo(product, recommendedQty, supplier)}
                  className="px-3 py-1.5 btn-prism-sunset text-white font-semibold shrink-0"
                >
                  Create PO
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// ============================================================================
// 4. INTEGRATION HUB, DEVELOPER & AUTOMATION WORKFLOW CENTER
// ============================================================================
export const EnterpriseCommandHub: React.FC<{
  integrations: IntegrationConfig[];
  workflows: AutomationWorkflow[];
  products: Product[];
  orders: Order[];
  suppliers: Supplier[];
  expenses: ExpenseRecord[];
  campaigns: MarketingCampaign[];
  onFeedback: (msg: string) => void;
}> = ({ integrations, workflows, products, orders, suppliers, expenses, campaigns, onFeedback }) => {
  const [health, setHealth] = useState<SystemHealthReport | null>(null);
  const [loadingHealth, setLoadingHealth] = useState(false);

  // Workflow Builder Form
  const [wfName, setWfName] = useState('');
  const [wfTrigger, setWfTrigger] = useState<AutomationWorkflow['triggerEvent']>('order.created');
  const [wfAction, setWfAction] = useState<AutomationWorkflow['actionType']>('dispatch_webhook');
  const [wfCondition, setWfCondition] = useState('Execute automatically on every qualified event');
  const [wfWebhook, setWfWebhook] = useState('');

  // Webhook Tester
  const [testUrl, setTestUrl] = useState('https://httpbin.org/post');
  const [testEvent, setTestEvent] = useState('order.created');
  const [testingHook, setTestingHook] = useState(false);
  const [hookResult, setHookResult] = useState<string | null>(null);

  const fetchHealth = async () => {
    setLoadingHealth(true);
    try {
      const res = await fetch('/api/system/health');
      if (res.ok) setHealth(await res.json());
    } finally {
      setLoadingHealth(false);
    }
  };

  useEffect(() => {
    void fetchHealth();
  }, []);

  const toggleIntegration = async (item: IntegrationConfig) => {
    const nextActive = !item.active;
    await updateDoc(doc(db, 'integrations', item.id), {
      active: nextActive,
      status: nextActive
        ? item.status === 'disabled'
          ? 'awaiting_credentials'
          : item.status
        : 'disabled',
      updatedAt: serverTimestamp(),
    });
    onFeedback(`Integration "${item.name}" ${nextActive ? 'enabled' : 'disabled'}.`);
  };

  const createWorkflow = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!wfName.trim()) return;
    const id = `wf_${Date.now()}`;
    await setDoc(doc(db, 'automationWorkflows', id), {
      id,
      name: wfName.trim(),
      triggerEvent: wfTrigger,
      actionType: wfAction,
      ...(wfWebhook.trim() ? { webhookUrl: wfWebhook.trim() } : {}),
      conditionSummary: wfCondition.trim(),
      active: true,
      runsCount: 0,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    setWfName('');
    setWfWebhook('');
    onFeedback(`Automation workflow "${wfName}" created.`);
  };

  const toggleWorkflow = async (wf: AutomationWorkflow) => {
    await updateDoc(doc(db, 'automationWorkflows', wf.id), {
      active: !wf.active,
      updatedAt: serverTimestamp(),
    });
    onFeedback(`Workflow "${wf.name}" ${!wf.active ? 'activated' : 'paused'}.`);
  };

  const testSignedWebhook = async (e: React.FormEvent) => {
    e.preventDefault();
    setTestingHook(true);
    setHookResult(null);
    try {
      const res = await fetch('/api/integrations/test-webhook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: testUrl,
          eventType: testEvent,
          payload: { platform: 'LUMIERE_ATELIER', testOrderId: `ord_test_${Date.now()}`, totalUsd: 128 },
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setHookResult(`Error (${res.status}): ${data.error || 'Webhook failed'}`);
      } else {
        setHookResult(
          `${data.delivered ? 'DELIVERED' : 'FAILED'} · HTTP ${data.httpStatus} · ${data.latencyMs}ms · Event ${data.eventId} · Sig ${data.signaturePreview}`,
        );
      }
    } catch (err) {
      setHookResult(err instanceof Error ? err.message : 'Network error');
    } finally {
      setTestingHook(false);
    }
  };

  const downloadDatabaseBackup = () => {
    const snapshot = {
      exportedAt: new Date().toISOString(),
      platform: 'LUMIERE_ATELIER_ERP',
      counts: {
        products: products.length,
        orders: orders.length,
        suppliers: suppliers.length,
        expenses: expenses.length,
        campaigns: campaigns.length,
        workflows: workflows.length,
        integrations: integrations.length,
      },
      data: { products, orders, suppliers, expenses, campaigns, workflows, integrations },
    };
    downloadBlobFile(`lumiere_backup_${Date.now()}.json`, JSON.stringify(snapshot, null, 2), 'application/json');
    onFeedback('Downloaded live JSON database backup snapshot.');
  };

  return (
    <div className="space-y-6 text-xs">
      {/* Live System Health & Backup */}
      <div className="bg-white dark:bg-[#0D1120] border border-emerald-500/30 p-5 space-y-4 glow-border">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-[10px] uppercase tracking-wider font-bold text-emerald-600 dark:text-emerald-300 flex items-center gap-1">
              <Activity className="w-3.5 h-3.5" /> Live Runtime Telemetry &amp; Disaster Recovery
            </p>
            <h3 className="font-display text-xl font-semibold gradient-heading">
              System Health, API Infrastructure &amp; Database Backup
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button type="button" onClick={() => void fetchHealth()} disabled={loadingHealth} className="px-3 py-1.5 border border-cyan-500/35 text-cyan-700 dark:text-cyan-300 font-semibold flex items-center gap-1">
              <RefreshCw className={`w-3.5 h-3.5 ${loadingHealth ? 'animate-spin' : ''}`} /> Refresh
            </button>
            <button type="button" onClick={downloadDatabaseBackup} className="px-3.5 py-1.5 btn-prism-emerald text-white font-semibold flex items-center gap-1.5">
              <Database className="w-3.5 h-3.5" /> Export JSON Backup
            </button>
          </div>
        </div>

        {health && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono">
            <div className="p-3 bg-[#F5F7FF] dark:bg-[#141A30] border border-emerald-500/25">
              <p className="text-[10px] text-slate-500">SERVER STATUS</p>
              <p className="font-bold text-emerald-600 dark:text-emerald-400 uppercase mt-0.5">
                {health.status} · {health.uptimeSeconds}s up
              </p>
            </div>
            <div className="p-3 bg-[#F5F7FF] dark:bg-[#141A30] border border-cyan-500/25">
              <p className="text-[10px] text-slate-500">MEMORY (RSS / HEAP)</p>
              <p className="font-bold text-cyan-700 dark:text-cyan-300 mt-0.5">
                {health.memoryMb.rss}MB / {health.memoryMb.heapUsed}MB
              </p>
            </div>
            <div className="p-3 bg-[#F5F7FF] dark:bg-[#141A30] border border-violet-500/25">
              <p className="text-[10px] text-slate-500">AI &amp; LIVE FX</p>
              <p className="font-bold text-violet-700 dark:text-fuchsia-300 mt-0.5">
                Gemini: {health.providers.geminiAi ? 'READY' : 'ENV'} · FX: {health.providers.liveFxRates ? 'LIVE' : 'REF'}
              </p>
            </div>
            <div className="p-3 bg-[#F5F7FF] dark:bg-[#141A30] border border-amber-500/25">
              <p className="text-[10px] text-slate-500">RATE LIMITER</p>
              <p className="font-bold text-amber-700 dark:text-amber-300 mt-0.5">
                {health.rateLimitStats.maxRequestsPerMinute}/min · {health.rateLimitStats.activeBuckets} active
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Integration Hub Marketplace */}
      <div className="bg-white dark:bg-[#0D1120] border border-cyan-500/25 p-5 space-y-4 glow-border">
        <h3 className="font-display text-xl font-semibold gradient-heading flex items-center gap-2">
          <Cpu className="w-5 h-5 text-cyan-500" /> Centralized Integration Hub ({integrations.length} Connectors)
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {integrations.map((intg) => (
            <div key={intg.id} className="p-3.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/20 flex flex-col justify-between gap-2.5">
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-bold text-[#090B14] dark:text-white">{intg.name}</p>
                    <p className="text-[10px] uppercase text-slate-500">{intg.category.replace('_', ' ')} · {intg.provider}</p>
                  </div>
                  <span
                    className={`px-2 py-0.5 text-[10px] font-bold uppercase shrink-0 ${
                      intg.status === 'connected' || intg.status === 'webhook_verified'
                        ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                        : intg.status === 'awaiting_credentials'
                          ? 'bg-amber-500/15 text-amber-700 dark:text-amber-300'
                          : 'bg-slate-500/15 text-slate-500'
                    }`}
                  >
                    {intg.status.replace('_', ' ')}
                  </span>
                </div>
                {intg.syncNote && <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-1.5 leading-relaxed">{intg.syncNote}</p>}
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-indigo-500/15">
                <span className="text-[10px] font-mono text-slate-500 truncate max-w-[65%]">
                  {intg.permissions.slice(0, 2).join(', ')}
                </span>
                <button
                  type="button"
                  onClick={() => void toggleIntegration(intg)}
                  className={`px-2.5 py-1 text-[10px] font-bold uppercase ${
                    intg.active ? 'btn-prism-cyan text-white' : 'border border-indigo-500/30 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {intg.active ? 'Enabled' : 'Disabled'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Automation Workflow Builder & Signed Webhook Tester */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-[#0D1120] border border-violet-500/30 p-5 space-y-4 glow-border">
          <h3 className="font-display text-xl font-semibold gradient-heading flex items-center gap-2">
            <Workflow className="w-5 h-5 text-violet-500" /> Event-Driven Automation Workflows ({workflows.length})
          </h3>
          <form onSubmit={createWorkflow} className="space-y-2">
            <input
              type="text"
              required
              value={wfName}
              onChange={(e) => setWfName(e.target.value)}
              placeholder="Workflow Name (e.g. Notify n8n on B2B Order)"
              className="w-full px-3 py-2 border border-indigo-500/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
            />
            <div className="grid grid-cols-2 gap-2">
              <select
                value={wfTrigger}
                onChange={(e) => setWfTrigger(e.target.value as AutomationWorkflow['triggerEvent'])}
                className="px-2.5 py-2 border border-indigo-500/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
              >
                <option value="order.created">Trigger: order.created</option>
                <option value="order.high_value">Trigger: order.high_value</option>
                <option value="stock.low">Trigger: stock.low</option>
                <option value="cart.abandoned">Trigger: cart.abandoned</option>
                <option value="supplier.delayed">Trigger: supplier.delayed</option>
                <option value="wholesale.applied">Trigger: wholesale.applied</option>
                <option value="subscription.due">Trigger: subscription.due</option>
              </select>
              <select
                value={wfAction}
                onChange={(e) => setWfAction(e.target.value as AutomationWorkflow['actionType'])}
                className="px-2.5 py-2 border border-indigo-500/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
              >
                <option value="dispatch_webhook">Action: Dispatch Signed Webhook</option>
                <option value="route_supplier_po">Action: Auto-Route Supplier PO</option>
                <option value="flag_fraud_review">Action: Hold for Fraud Review</option>
                <option value="create_restock_task">Action: Create AI Restock Task</option>
                <option value="queue_recovery_campaign">Action: Queue Recovery Flow</option>
                <option value="notify_admin">Action: Notify Admin Ops</option>
              </select>
            </div>
            <input
              type="text"
              value={wfCondition}
              onChange={(e) => setWfCondition(e.target.value)}
              placeholder="Condition summary"
              className="w-full px-3 py-2 border border-indigo-500/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
            />
            <button type="submit" className="w-full py-2 btn-futuristic text-white font-semibold uppercase tracking-wider">
              Add Automation Rule
            </button>
          </form>

          <div className="space-y-2 max-h-60 overflow-y-auto">
            {workflows.map((wf) => (
              <div key={wf.id} className="p-3 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/15 flex items-center justify-between gap-2">
                <div>
                  <p className="font-bold">{wf.name}</p>
                  <p className="font-mono text-[10px] text-cyan-700 dark:text-cyan-300">
                    {wf.triggerEvent} → {wf.actionType} ({wf.runsCount} runs)
                  </p>
                  <p className="text-[11px] text-slate-500">{wf.conditionSummary}</p>
                </div>
                <button
                  type="button"
                  onClick={() => void toggleWorkflow(wf)}
                  className={`px-2.5 py-1 text-[10px] font-bold uppercase ${
                    wf.active ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300' : 'bg-slate-500/20 text-slate-500'
                  }`}
                >
                  {wf.active ? 'Active' : 'Paused'}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Live HMAC Signed Webhook Tester & API Directory */}
        <div className="bg-white dark:bg-[#0D1120] border border-indigo-500/30 p-5 space-y-4 glow-border">
          <h3 className="font-display text-xl font-semibold gradient-heading flex items-center gap-2">
            <Code2 className="w-5 h-5 text-cyan-500" /> Signed Webhook Tester &amp; REST API Docs
          </h3>
          <form onSubmit={testSignedWebhook} className="space-y-2.5">
            <input
              type="url"
              required
              value={testUrl}
              onChange={(e) => setTestUrl(e.target.value)}
              placeholder="https://hooks.your-domain.com/lumiere"
              className="w-full px-3 py-2 border border-indigo-500/25 bg-[#F5F7FF] dark:bg-[#141A30] font-mono text-[#090B14] dark:text-white"
            />
            <div className="flex gap-2">
              <select
                value={testEvent}
                onChange={(e) => setTestEvent(e.target.value)}
                className="flex-1 px-3 py-2 border border-indigo-500/25 bg-[#F5F7FF] dark:bg-[#141A30] font-mono text-[#090B14] dark:text-white"
              >
                <option value="order.created">order.created</option>
                <option value="order.high_value">order.high_value</option>
                <option value="stock.low">stock.low</option>
                <option value="supplier.po_dispatched">supplier.po_dispatched</option>
              </select>
              <button
                type="submit"
                disabled={testingHook}
                className="px-4 py-2 btn-prism-cyan text-white font-semibold flex items-center gap-1.5 disabled:opacity-50"
              >
                {testingHook ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
                Send Signed Event
              </button>
            </div>
          </form>
          {hookResult && (
            <div className="p-3 bg-[#090B1A] text-cyan-300 font-mono text-[11px] border border-cyan-500/40 break-all">
              {hookResult}
            </div>
          )}

          <div className="pt-2 border-t border-indigo-500/15 space-y-1.5">
            <p className="font-bold uppercase tracking-wider text-[10px] text-violet-600 dark:text-fuchsia-300">
              Active Server REST Endpoints (HMAC &amp; Rate-Limited)
            </p>
            <div className="grid grid-cols-1 gap-1 font-mono text-[11px] text-slate-600 dark:text-slate-300">
              <p><span className="text-emerald-600 font-bold">POST</span> /api/ai/visual-search · /api/ai/chat · /api/ai/marketing-copy · /api/ai/ceo</p>
              <p><span className="text-cyan-600 font-bold">POST</span> /api/orders/route · /api/orders/evaluate-fraud · /api/wholesale/parse-bulk-csv</p>
              <p><span className="text-violet-600 font-bold">POST</span> /api/logistics/compare-rates · /api/integrations/test-webhook · /api/localization/lock-quote</p>
              <p><span className="text-amber-600 font-bold">GET</span> /api/system/health · /api/localization/rates · /api/payments/gateways</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// 5. SECURITY, FRAUD & GOVERNANCE CONSOLE
// ============================================================================
export const SecurityGovernanceModule: React.FC<{
  orders: Order[];
  sessions: SecuritySession[];
  auditLogs: AuditLogEntry[];
  siteSettings: SiteSettings;
  aiTasks: AiTaskItem[];
  onFeedback: (msg: string) => void;
}> = ({ orders, sessions, auditLogs, siteSettings, aiTasks, onFeedback }) => {
  const [highValThreshold, setHighValThreshold] = useState(String(siteSettings.fraudHighValueThresholdUsd ?? 500));
  const [autoHoldScore, setAutoHoldScore] = useState(String(siteSettings.fraudAutoHoldScore ?? 60));
  const [savingRules, setSavingRules] = useState(false);
  const [auditFilter, setAuditFilter] = useState('');

  const flaggedOrders = orders.filter((o) => (o.fraudScore ?? 0) >= 35 || o.erpStatus === 'MANUAL_REVIEW');
  const filteredLogs = auditLogs.filter(
    (l) =>
      !auditFilter.trim() ||
      l.action.toLowerCase().includes(auditFilter.toLowerCase()) ||
      l.actorEmail.toLowerCase().includes(auditFilter.toLowerCase()) ||
      l.details.toLowerCase().includes(auditFilter.toLowerCase()),
  );

  const saveFraudThresholds = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingRules(true);
    try {
      await setDoc(
        doc(db, 'siteSettings', 'main'),
        {
          ...siteSettings,
          fraudHighValueThresholdUsd: Math.max(50, Number(highValThreshold) || 500),
          fraudAutoHoldScore: Math.min(100, Math.max(10, Number(autoHoldScore) || 60)),
          updatedAt: serverTimestamp(),
        },
        { merge: true },
      );
      onFeedback('Saved real-time Fraud Prevention thresholds to Firestore.');
    } catch (err) {
      onFeedback(err instanceof Error ? err.message : 'Failed to save fraud rules.');
    } finally {
      setSavingRules(false);
    }
  };

  const revokeSession = async (session: SecuritySession) => {
    await updateDoc(doc(db, 'securitySessions', session.id), { status: 'revoked' });
    onFeedback(`Session ${session.id} marked revoked.`);
  };

  const exportAuditCsv = () => {
    const headers = ['ID', 'Actor', 'Role', 'Action', 'Entity', 'Details'];
    const rows = filteredLogs.map((l) => [l.id, l.actorEmail, l.actorRole, l.action, `${l.entityType}:${l.entityId}`, l.details]);
    const csv = [headers.join(','), ...rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(','))].join('\n');
    downloadBlobFile(`lumiere_security_audit_${Date.now()}.csv`, csv, 'text/csv;charset=utf-8;');
    onFeedback('Exported Security Audit Trail CSV.');
  };

  return (
    <div className="space-y-6 text-xs">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Fraud Guardrails */}
        <form onSubmit={saveFraudThresholds} className="bg-white dark:bg-[#0D1120] border border-rose-500/30 p-5 space-y-4 glow-border">
          <h3 className="font-display text-xl font-semibold gradient-heading-warm flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-rose-500" /> Fraud Detection &amp; Auto-Hold Guardrails
          </h3>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1">High-Value Threshold (USD)</label>
              <input
                type="number"
                min={50}
                value={highValThreshold}
                onChange={(e) => setHighValThreshold(e.target.value)}
                className="w-full px-3 py-2 border border-indigo-500/25 bg-[#F5F7FF] dark:bg-[#141A30] font-mono text-[#090B14] dark:text-white"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1">Auto-Hold Risk Score (10-100)</label>
              <input
                type="number"
                min={10}
                max={100}
                value={autoHoldScore}
                onChange={(e) => setAutoHoldScore(e.target.value)}
                className="w-full px-3 py-2 border border-indigo-500/25 bg-[#F5F7FF] dark:bg-[#141A30] font-mono text-[#090B14] dark:text-white"
              />
            </div>
          </div>
          <button type="submit" disabled={savingRules} className="px-4 py-2 btn-prism-sunset text-white font-semibold uppercase tracking-wider">
            {savingRules ? 'Saving…' : 'Update Fraud Prevention Rules'}
          </button>

          <div className="pt-2 border-t border-indigo-500/15 space-y-2">
            <p className="font-bold text-rose-600 dark:text-rose-300">
              Flagged / Elevated-Risk Orders ({flaggedOrders.length}) · Pending AI Approvals ({aiTasks.filter((t) => t.status === 'pending_approval').length})
            </p>
            {flaggedOrders.length === 0 ? (
              <p className="text-emerald-600 dark:text-emerald-400">All orders cleared automated risk checks.</p>
            ) : (
              flaggedOrders.slice(0, 5).map((o) => (
                <div key={o.id} className="p-2.5 bg-rose-50/70 dark:bg-rose-950/30 border border-rose-500/30 flex items-center justify-between gap-2">
                  <div>
                    <p className="font-mono font-bold">#{o.id} · Score {o.fraudScore ?? 0}/100</p>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300">{(o.fraudFlags || []).join(' · ')}</p>
                  </div>
                  <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0" />
                </div>
              ))
            )}
          </div>
        </form>

        {/* Active Sessions & Security Posture */}
        <div className="bg-white dark:bg-[#0D1120] border border-cyan-500/30 p-5 space-y-4 glow-border">
          <h3 className="font-display text-xl font-semibold gradient-heading flex items-center gap-2">
            <Lock className="w-5 h-5 text-cyan-500" /> Active Login Sessions &amp; Access Security ({sessions.length})
          </h3>
          <div className="p-3 bg-emerald-50/60 dark:bg-emerald-950/25 border border-emerald-500/30 text-[11px] space-y-1">
            <p className="font-bold text-emerald-700 dark:text-emerald-300">Zero-Trust Posture Active</p>
            <p className="text-slate-600 dark:text-slate-300">
              Verified Google OAuth &amp; Firebase Auth tokens · Eight-Pillar Firestore Security Rules deployed · Server-side API Rate Limiting &amp; HMAC-SHA256 Payment/Quote Signing enabled.
            </p>
          </div>
          <div className="space-y-2 max-h-56 overflow-y-auto">
            {sessions.length === 0 ? (
              <p className="text-slate-500">Authenticated device sessions will populate automatically upon sign-in.</p>
            ) : (
              sessions.slice(0, 12).map((s) => (
                <div key={s.id} className="p-2.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/15 flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-semibold truncate">{s.userEmail}</p>
                    <p className="text-[10px] font-mono text-slate-500 truncate">{s.platform} · {s.countryCode || 'GLOBAL'} · {s.userAgent.slice(0, 48)}</p>
                  </div>
                  {s.status === 'active' ? (
                    <button
                      type="button"
                      onClick={() => void revokeSession(s)}
                      className="px-2.5 py-1 border border-rose-500/40 text-rose-600 dark:text-rose-300 text-[10px] font-bold uppercase shrink-0 hover:bg-rose-500/10"
                    >
                      Revoke
                    </button>
                  ) : (
                    <span className="text-[10px] uppercase font-bold text-slate-400">Revoked</span>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Searchable Immutable Audit Trail */}
      <div className="bg-white dark:bg-[#0D1120] border border-indigo-500/25 p-5 space-y-3 glow-border">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="font-display text-xl font-semibold gradient-heading">
            Immutable Security &amp; ERP Audit Log ({filteredLogs.length})
          </h3>
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={auditFilter}
              onChange={(e) => setAuditFilter(e.target.value)}
              placeholder="Filter logs by user or action..."
              className="px-3 py-1.5 border border-indigo-500/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
            />
            <button type="button" onClick={exportAuditCsv} className="px-3 py-1.5 btn-prism-cyan text-white font-semibold flex items-center gap-1">
              <Send className="w-3 h-3" /> Export CSV
            </button>
          </div>
        </div>
        <div className="space-y-1.5 max-h-60 overflow-y-auto">
          {filteredLogs.slice(0, 25).map((log) => (
            <div key={log.id} className="p-2.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/10 flex flex-wrap justify-between gap-2">
              <span>
                <strong className="text-indigo-700 dark:text-cyan-300">{log.action}</strong> · {log.details}
              </span>
              <span className="font-mono text-[10px] text-slate-500">
                {log.actorEmail} ({log.actorRole})
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
