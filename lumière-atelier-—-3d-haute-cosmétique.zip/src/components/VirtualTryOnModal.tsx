import React, { useEffect, useRef, useState } from 'react';
import { CinematicModal, MorphingLightField } from './MotionPrimitives';
import { Camera, Sliders, Upload, X, Check } from 'lucide-react';
import { Product, ProductShade } from '../types/store';

interface VirtualTryOnModalProps {
  product: Product;
  initialShade: ProductShade;
  onClose: () => void;
  onAddToBag: (product: Product, shade: ProductShade) => void;
}

const STUDIO_SKIN_PRESETS = [
  { id: 'fair', label: 'Fair Ivory', base: '#F2D6C6', shadow: '#D8B3A0', lipBase: '#C88D88' },
  { id: 'medium', label: 'Warm Olive', base: '#D6A684', shadow: '#B5825E', lipBase: '#A96B63' },
  { id: 'rich', label: 'Rich Amber', base: '#8B563A', shadow: '#6B3E26', lipBase: '#7D443D' },
  { id: 'deep', label: 'Deep Espresso', base: '#543222', shadow: '#3D2216', lipBase: '#572C28' },
];

export const VirtualTryOnModal: React.FC<VirtualTryOnModalProps> = ({
  product,
  initialShade,
  onClose,
  onAddToBag,
}) => {
  const [selectedShade, setSelectedShade] = useState<ProductShade>(initialShade);
  const [intensity, setIntensity] = useState(0.68);
  const [splitPercent, setSplitPercent] = useState(100);
  const [mode, setMode] = useState<'studio' | 'camera' | 'photo'>('studio');
  const [skinPreset, setSkinPreset] = useState(STUDIO_SKIN_PRESETS[1]);
  const [uploadedUrl, setUploadedUrl] = useState<string | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [addedFeedback, setAddedFeedback] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
  };

  useEffect(() => {
    return () => stopCamera();
  }, []);

  const startCamera = async () => {
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
      streamRef.current = stream;
      setMode('camera');
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
    } catch {
      setCameraError('Camera access was blocked or unavailable. Studio Portrait & Photo Upload modes remain active.');
      setMode('studio');
    }
  };

  useEffect(() => {
    let raf = 0;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const drawMakeupOverlay = (w: number, h: number, splitX: number) => {
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, splitX, h);
      ctx.clip();

      const cat = product.category.toLowerCase();
      ctx.globalCompositeOperation = 'multiply';
      ctx.globalAlpha = intensity * 0.78;
      ctx.fillStyle = selectedShade.hex;

      if (cat.includes('lip')) {
        // Upper & lower lip contour
        ctx.beginPath();
        ctx.moveTo(w * 0.42, h * 0.67);
        ctx.quadraticCurveTo(w * 0.47, h * 0.635, w * 0.5, h * 0.655);
        ctx.quadraticCurveTo(w * 0.53, h * 0.635, w * 0.58, h * 0.67);
        ctx.quadraticCurveTo(w * 0.54, h * 0.725, w * 0.5, h * 0.725);
        ctx.quadraticCurveTo(w * 0.46, h * 0.725, w * 0.42, h * 0.67);
        ctx.closePath();
        ctx.fill();

        if (product.finish === 'Satin Gloss' || product.finish === 'Luminous Dew') {
          ctx.globalCompositeOperation = 'screen';
          ctx.globalAlpha = intensity * 0.35;
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.ellipse(w * 0.5, h * 0.695, w * 0.045, h * 0.012, 0, 0, Math.PI * 2);
          ctx.fill();
        }
      } else if (cat.includes('blush') || cat.includes('highlight')) {
        // Cheekbone blush / highlighter glow
        for (const cx of [w * 0.34, w * 0.66]) {
          const grad = ctx.createRadialGradient(cx, h * 0.54, 4, cx, h * 0.54, w * 0.09);
          grad.addColorStop(0, selectedShade.hex);
          grad.addColorStop(1, 'rgba(0,0,0,0)');
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.arc(cx, h * 0.54, w * 0.09, 0, Math.PI * 2);
          ctx.fill();
        }
      } else if (cat.includes('eye')) {
        // Eyelid gradient wash
        for (const ex of [w * 0.39, w * 0.61]) {
          const grad = ctx.createRadialGradient(ex, h * 0.41, 4, ex, h * 0.41, w * 0.065);
          grad.addColorStop(0, selectedShade.hex);
          grad.addColorStop(1, 'rgba(0,0,0,0)');
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.ellipse(ex, h * 0.41, w * 0.065, h * 0.032, 0, 0, Math.PI * 2);
          ctx.fill();
        }
      } else {
        // Complexion foundation / primer tint over face oval
        ctx.globalAlpha = intensity * 0.45;
        ctx.beginPath();
        ctx.ellipse(w * 0.5, h * 0.49, w * 0.21, h * 0.29, 0, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    };

    const drawStudioPortrait = (w: number, h: number) => {
      const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
      bgGrad.addColorStop(0, '#1B171D');
      bgGrad.addColorStop(1, '#2D2428');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, w, h);

      // Neck & shoulders
      ctx.fillStyle = skinPreset.shadow;
      ctx.beginPath();
      ctx.moveTo(w * 0.42, h * 0.7);
      ctx.lineTo(w * 0.58, h * 0.7);
      ctx.lineTo(w * 0.64, h);
      ctx.lineTo(w * 0.36, h);
      ctx.closePath();
      ctx.fill();

      // Face silhouette
      const faceGrad = ctx.createRadialGradient(w * 0.48, h * 0.44, 20, w * 0.5, h * 0.49, w * 0.28);
      faceGrad.addColorStop(0, skinPreset.base);
      faceGrad.addColorStop(1, skinPreset.shadow);
      ctx.fillStyle = faceGrad;
      ctx.beginPath();
      ctx.ellipse(w * 0.5, h * 0.49, w * 0.21, h * 0.29, 0, 0, Math.PI * 2);
      ctx.fill();

      // Subtle brow & eyes
      ctx.strokeStyle = 'rgba(30,20,18,0.65)';
      ctx.lineWidth = 3;
      for (const [ex, dir] of [
        [w * 0.39, -1],
        [w * 0.61, 1],
      ] as const) {
        ctx.beginPath();
        ctx.moveTo(ex - 26, h * 0.37);
        ctx.quadraticCurveTo(ex, h * 0.345, ex + 26, h * 0.375);
        ctx.stroke();

        ctx.fillStyle = '#fff';
        ctx.beginPath();
        ctx.ellipse(ex, h * 0.43, 20, 9, dir * 0.04, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#2A1D1B';
        ctx.beginPath();
        ctx.arc(ex, h * 0.43, 7, 0, Math.PI * 2);
        ctx.fill();
      }

      // Natural lips
      ctx.fillStyle = skinPreset.lipBase;
      ctx.beginPath();
      ctx.moveTo(w * 0.42, h * 0.67);
      ctx.quadraticCurveTo(w * 0.47, h * 0.635, w * 0.5, h * 0.655);
      ctx.quadraticCurveTo(w * 0.53, h * 0.635, w * 0.58, h * 0.67);
      ctx.quadraticCurveTo(w * 0.54, h * 0.725, w * 0.5, h * 0.725);
      ctx.quadraticCurveTo(w * 0.46, h * 0.725, w * 0.42, h * 0.67);
      ctx.closePath();
      ctx.fill();
    };

    const renderFrame = () => {
      const w = canvas.width;
      const h = canvas.height;
      const splitX = (splitPercent / 100) * w;

      if (mode === 'camera' && videoRef.current && videoRef.current.readyState >= 2) {
        ctx.drawImage(videoRef.current, 0, 0, w, h);
        drawMakeupOverlay(w, h, splitX);
      } else if (mode === 'photo' && uploadedUrl) {
        const img = new Image();
        img.src = uploadedUrl;
        if (img.complete) {
          ctx.drawImage(img, 0, 0, w, h);
          drawMakeupOverlay(w, h, splitX);
        }
      } else {
        drawStudioPortrait(w, h);
        drawMakeupOverlay(w, h, splitX);
      }

      if (splitPercent > 0 && splitPercent < 100) {
        ctx.strokeStyle = 'rgba(255,255,255,0.8)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(splitX, 0);
        ctx.lineTo(splitX, h);
        ctx.stroke();
      }

      if (mode === 'camera') {
        raf = requestAnimationFrame(renderFrame);
      }
    };

    renderFrame();
    return () => cancelAnimationFrame(raf);
  }, [mode, skinPreset, selectedShade, intensity, splitPercent, uploadedUrl, product]);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    stopCamera();
    const reader = new FileReader();
    reader.onload = () => {
      setUploadedUrl(String(reader.result));
      setMode('photo');
    };
    reader.readAsDataURL(file);
  };

  return (
    <CinematicModal
      onBackdropClick={onClose}
      backdropClassName="flex items-center justify-center p-4"
      panelClassName="bg-[#F5F7FF] dark:bg-[#06070E] text-[#0A0C12] dark:text-[#F5F7FF] w-full max-w-4xl border border-indigo-500/25 dark:border-cyan-400/25 prism-modal-rim shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
    >
        <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-[#EC4899] via-[#7C3AED] to-[#2563EB] text-white">
          <div>
            <p className="text-[11px] uppercase tracking-[0.22em] text-cyan-200 font-semibold">
              Virtual Beauty Studio · AR Try-On
            </p>
            <h2 className="font-display text-2xl font-semibold text-white">{product.name}</h2>
          </div>
          <button
            type="button"
            onClick={() => {
              stopCamera();
              onClose();
            }}
            aria-label="Close Virtual Try-On"
            className="p-2 bg-white/15 hover:bg-white/25 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="prism-divider shrink-0" />

        <div className="grid grid-cols-1 lg:grid-cols-12 flex-1 overflow-y-auto">
          <div className="lg:col-span-7 bg-[#06070E] relative overflow-hidden flex flex-col items-center justify-center p-4">
            <MorphingLightField variant="panel" />
            <video ref={videoRef} className="hidden" playsInline muted />
            <canvas
              ref={canvasRef}
              width={540}
              height={540}
              className="relative z-10 w-full max-w-[440px] aspect-square object-cover border-2 border-fuchsia-500/45 neon-image-halo neon-card-orbit shadow-xl shadow-violet-900/40"
            />

            <div className="relative z-10 flex flex-wrap items-center gap-2 mt-4">
              <button
                type="button"
                onClick={() => {
                  stopCamera();
                  setMode('studio');
                }}
                className={`px-3.5 py-1.5 text-xs font-semibold transition-all whitespace-nowrap ${
                  mode === 'studio' ? 'btn-prism-cyan' : 'bg-white/10 text-white hover:bg-white/20 border border-white/15'
                }`}
              >
                Studio Model
              </button>
              <button
                type="button"
                onClick={startCamera}
                className={`px-3.5 py-1.5 text-xs font-semibold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                  mode === 'camera' ? 'btn-futuristic' : 'bg-white/10 text-white hover:bg-white/20 border border-white/15'
                }`}
              >
                <Camera className="w-3.5 h-3.5" /> Live Camera
              </button>
              <label
                className={`px-3.5 py-1.5 text-xs font-semibold cursor-pointer flex items-center gap-1.5 whitespace-nowrap transition-all ${
                  mode === 'photo' ? 'btn-prism-sunset' : 'bg-white/10 text-white hover:bg-white/20 border border-white/15'
                }`}
              >
                <Upload className="w-3.5 h-3.5" /> Upload Portrait
                <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
              </label>
            </div>
            {cameraError && <p className="text-xs text-amber-300 mt-2 text-center max-w-sm">{cameraError}</p>}
          </div>

          <div className="lg:col-span-5 p-6 flex flex-col justify-between gap-6 bg-white dark:bg-[#0D1120] border-l border-indigo-500/20 dark:border-cyan-400/20">
            <div className="space-y-5">
              {mode === 'studio' && (
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-[#7C3AED] dark:text-[#22D3EE] mb-2">
                    Model Complexion Tone
                  </p>
                  <div className="grid grid-cols-2 gap-2">
                    {STUDIO_SKIN_PRESETS.map((tone) => (
                      <button
                        key={tone.id}
                        type="button"
                        onClick={() => setSkinPreset(tone)}
                        className={`flex items-center gap-2 px-3 py-2 border text-xs font-semibold transition-all ${
                          skinPreset.id === tone.id
                            ? 'border-[#EC4899] dark:border-[#22D3EE] bg-gradient-to-r from-pink-500/10 to-violet-500/10 dark:from-cyan-500/15 dark:to-violet-500/15 text-[#0A0C12] dark:text-white'
                            : 'border-indigo-500/20 dark:border-cyan-400/20 hover:border-[#EC4899]/60'
                        }`}
                      >
                        <span
                          className="w-4 h-4 rounded-full border border-black/15 dark:border-white/25 shrink-0"
                          style={{ backgroundColor: tone.base }}
                        />
                        <span className="truncate">{tone.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-[#7C3AED] dark:text-[#22D3EE] mb-2">
                  Select Shade — <span className="text-[#EC4899] dark:text-amber-300">{selectedShade.name}</span>
                </p>
                <div className="flex flex-wrap gap-2.5">
                  {product.shades.map((shade) => (
                    <button
                      key={shade.id}
                      type="button"
                      onClick={() => setSelectedShade(shade)}
                      title={shade.name}
                      className={`w-9 h-9 rounded-full border-2 transition-transform ${
                        selectedShade.id === shade.id
                          ? 'border-[#EC4899] dark:border-[#22D3EE] scale-110 ring-2 ring-fuchsia-500/45'
                          : 'border-black/15 dark:border-white/25 hover:scale-105'
                      }`}
                      style={{ backgroundColor: shade.hex }}
                    />
                  ))}
                </div>
              </div>

              <div className="space-y-4 pt-3 border-t border-indigo-500/15 dark:border-cyan-400/15">
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-semibold flex items-center gap-1.5">
                      <Sliders className="w-3.5 h-3.5 text-[#EC4899] dark:text-[#22D3EE]" /> Pigment Intensity
                    </span>
                    <span className="font-mono tabular-nums font-semibold text-[#7C3AED] dark:text-[#22D3EE]">
                      {Math.round(intensity * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.15}
                    max={1}
                    step={0.05}
                    value={intensity}
                    onChange={(e) => setIntensity(Number(e.target.value))}
                    className="w-full accent-[#EC4899]"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-semibold">Before / After Split</span>
                    <span className="font-mono tabular-nums font-semibold text-[#2563EB] dark:text-amber-300">
                      {splitPercent}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    step={2}
                    value={splitPercent}
                    onChange={(e) => setSplitPercent(Number(e.target.value))}
                    className="w-full accent-[#06B6D4]"
                  />
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-indigo-500/15 dark:border-cyan-400/15">
              <button
                type="button"
                onClick={() => {
                  onAddToBag(product, selectedShade);
                  setAddedFeedback(true);
                  setTimeout(() => setAddedFeedback(false), 1800);
                }}
                className={`w-full py-3 text-xs font-semibold uppercase tracking-widest flex items-center justify-center gap-2 ${
                  addedFeedback ? 'btn-prism-emerald' : 'btn-prism-sunset'
                }`}
              >
                {addedFeedback ? (
                  <>
                    <Check className="w-4 h-4" /> Added {selectedShade.name} to Bag
                  </>
                ) : (
                  `Add ${selectedShade.name} to Bag`
                )}
              </button>
            </div>
          </div>
        </div>
    </CinematicModal>
  );
};
