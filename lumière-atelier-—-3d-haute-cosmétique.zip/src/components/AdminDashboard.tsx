import React, { useState } from 'react';
import {
  AlertTriangle,
  ArrowDown,
  ArrowUp,
  BarChart3,
  Barcode,
  Bot,
  Building2,
  Calculator,
  Copy,
  Cpu,
  Download,
  Eye,
  FileText,
  Layers,
  Megaphone,
  Package,
  Plus,
  RefreshCw,
  RotateCcw,
  Shield,
  ShieldAlert,
  Sliders,
  Sun,
  Tag,
  Trash2,
  Truck,
  Upload,
  Users,
  Warehouse as WarehouseIcon,
  X,
  Zap,
} from 'lucide-react';
import {
  deleteDoc,
  doc,
  serverTimestamp,
  setDoc,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { SEED_SITE_SETTINGS } from '../data/seedCatalog';
import { getProductErpDefaults } from '../data/seedErp';
import { motion } from 'motion/react';
import {
  AiTaskItem,
  AnimationIntensity,
  AuditLogEntry,
  AutomationRule,
  AutomationWorkflow,
  BlogPost,
  Category,
  CmsPage,
  Coupon,
  CurrencyCode,
  ExpenseRecord,
  formatMoney,
  GiftCard,
  IntegrationConfig,
  LightColorPreset,
  LightingIntensity,
  LightSpeed,
  MarketingCampaign,
  ModelType,
  MotionSpeed,
  NeonGlowLevel,
  Order,
  OrderStatus,
  PageTransitionStyle,
  ParticleDensity,
  Product,
  ProductBundle,
  ProductCollection,
  ProductFinish,
  ProductShade,
  PurchaseOrder,
  Review,
  SecuritySession,
  ShippingZone,
  SiteSettings,
  StockAlert,
  SubscriptionPlan,
  Supplier,
  SupportTicket,
  Transaction,
  UserProfile,
  Warehouse,
  WholesaleAccount,
  WholesaleQuote,
} from '../types/store';
import { AiCeoModal } from './AiCeoModal';
import { ConfirmDialog } from './ConfirmDialog';
import {
  AnimatedBarChart3D,
  AnimatedCounter,
  CinematicModal,
  MagneticButton,
} from './MotionPrimitives';
import { CHART_BAR_GRADIENTS, KPI_COLOR_THEMES } from '../lib/themePalette';
import {
  ErpFinanceRbacAuditSection,
  ErpOrdersRoutingSection,
  ErpOverviewSection,
  ErpSuppliersPosSection,
  ErpWarehouseInventorySection,
  ErpWholesaleB2BSection,
} from './ErpModules';
import {
  EnterpriseCommandHub,
  FinanceAccountingModule,
  LogisticsIntelligenceModule,
  MarketingGrowthModule,
  SecurityGovernanceModule,
} from './NextGenEnterpriseModules';

interface AdminDashboardProps {
  products: Product[];
  categories: Category[];
  orders: Order[];
  transactions: Transaction[];
  coupons: Coupon[];
  reviews: Review[];
  customers: UserProfile[];
  blogPosts: BlogPost[];
  cmsPages: CmsPage[];
  supportTickets: SupportTicket[];
  shippingZones: ShippingZone[];
  siteSettings: SiteSettings;
  suppliers: Supplier[];
  purchaseOrders: PurchaseOrder[];
  warehouses: Warehouse[];
  wholesaleAccounts: WholesaleAccount[];
  wholesaleQuotes: WholesaleQuote[];
  auditLogs: AuditLogEntry[];
  bundles?: ProductBundle[];
  giftCards?: GiftCard[];
  subscriptions?: SubscriptionPlan[];
  stockAlerts?: StockAlert[];
  marketingCampaigns?: MarketingCampaign[];
  expenses?: ExpenseRecord[];
  automationWorkflows?: AutomationWorkflow[];
  integrations?: IntegrationConfig[];
  aiTasks?: AiTaskItem[];
  securitySessions?: SecuritySession[];
  adminUid?: string;
  adminEmail?: string;
  currency: CurrencyCode;
  onViewProduct?: (product: Product) => void;
  onApplyTheme?: (mode: 'light' | 'dark') => void;
  onPreviewSiteSettings?: (partial: Partial<SiteSettings>) => void;
  onClose: () => void;
}

function downloadCsv(filename: string, headers: string[], rows: string[][]) {
  const escape = (v: string) => `"${v.replace(/"/g, '""')}"`;
  const csv = [headers.map(escape).join(','), ...rows.map((r) => r.map(escape).join(','))].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  products,
  categories,
  orders,
  transactions,
  coupons,
  reviews,
  customers,
  blogPosts,
  cmsPages,
  supportTickets,
  shippingZones,
  siteSettings,
  suppliers,
  purchaseOrders,
  warehouses,
  wholesaleAccounts,
  wholesaleQuotes,
  auditLogs,
  bundles = [],
  giftCards = [],
  subscriptions = [],
  stockAlerts = [],
  marketingCampaigns = [],
  expenses = [],
  automationWorkflows = [],
  integrations = [],
  aiTasks = [],
  securitySessions = [],
  adminUid = 'admin',
  adminEmail = 'achabhinav2006@gmail.com',
  currency,
  onViewProduct,
  onApplyTheme,
  onPreviewSiteSettings,
  onClose,
}) => {
  const [tab, setTab] = useState<
    | 'erp_overview'
    | 'erp_orders'
    | 'erp_warehouses'
    | 'erp_suppliers'
    | 'erp_wholesale'
    | 'erp_rbac'
    | 'marketing'
    | 'finance_ledger'
    | 'logistics_intel'
    | 'integrations_dev'
    | 'security_gov'
    | 'analytics'
    | 'products'
    | 'categories'
    | 'orders'
    | 'coupons'
    | 'reviews'
    | 'customers'
    | 'cms'
    | 'customize'
  >('erp_overview');
  const [feedback, setFeedback] = useState<string | null>(null);
  const [aiCeoOpen, setAiCeoOpen] = useState(false);
  const [confirmState, setConfirmState] = useState<{
    title: string;
    message: string;
    confirmLabel: string;
    destructive?: boolean;
    onConfirm: () => Promise<void> | void;
  } | null>(null);

  // CRM State
  const [customerSearch, setCustomerSearch] = useState('');
  const [crmEdits, setCrmEdits] = useState<
    Record<string, { customerSegment: NonNullable<UserProfile['customerSegment']>; loyaltyPoints: string }>
  >({});

  // Product Form State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [prodName, setProdName] = useState('');
  const [prodBrand, setProdBrand] = useState('LUMIÈRE ATELIER');
  const [prodCategory, setProdCategory] = useState(categories[0]?.name || 'Lipsticks, Gloss & Liners');
  const [prodSubcategory, setProdSubcategory] = useState('');
  const [prodCollection, setProdCollection] = useState<ProductCollection>('Signature');
  const [prodPrice, setProdPrice] = useState('48');
  const [prodStock, setProdStock] = useState('50');
  const [prodLowStock, setProdLowStock] = useState('15');
  const [prodSku, setProdSku] = useState('LA-NEW-101');
  const [prodBarcode, setProdBarcode] = useState('');
  const [prodFinish, setProdFinish] = useState<ProductFinish>('Velvet Matte');
  const [prodModelType, setProdModelType] = useState<ModelType>('lipstick');
  const [prodImageUrl, setProdImageUrl] = useState('/src/assets/images/cat_lipsticks_gloss_1794984607329.jpg');
  const [prodVideoUrl, setProdVideoUrl] = useState('');
  const [prodDesc, setProdDesc] = useState('');
  const [prodIngredients, setProdIngredients] = useState('');
  const [prodSeoTitle, setProdSeoTitle] = useState('');
  const [prodSeoDesc, setProdSeoDesc] = useState('');
  const [prodFeatured, setProdFeatured] = useState(true);
  const [prodTrending, setProdTrending] = useState(false);
  const [prodNewArrival, setProdNewArrival] = useState(false);
  const [prodBestSeller, setProdBestSeller] = useState(false);
  const [prodShades, setProdShades] = useState<ProductShade[]>([
    { id: 'atelier-ruby', name: 'Atelier Ruby', hex: '#9E1B32', undertone: 'Cool' },
  ]);
  const [newShadeName, setNewShadeName] = useState('');
  const [newShadeHex, setNewShadeHex] = useState('#B55A5D');
  const [newShadeUndertone, setNewShadeUndertone] = useState<'Warm' | 'Cool' | 'Neutral' | 'Universal'>('Neutral');
  const [uploadingMedia, setUploadingMedia] = useState(false);

  // Bulk CSV Import
  const [csvInput, setCsvInput] = useState(
    'name,category,collection,price,stock,sku,finish,modelType,shadeName,shadeHex\nVelvet Silk Lip Balm,Lipsticks Gloss & Liners,Signature,34,45,LA-BALM-01,Satin Gloss,lipstick,Rose Silk,#C97A80',
  );
  const [importingCsv, setImportingCsv] = useState(false);

  // Nested Category Form
  const [catName, setCatName] = useState('');
  const [catParentId, setCatParentId] = useState('');
  const [catDiscount, setCatDiscount] = useState('0');
  const [catDesc, setCatDesc] = useState('');

  // Coupon Form
  const [couponCode, setCouponCode] = useState('');
  const [couponPercent, setCouponPercent] = useState('15');
  const [couponMin, setCouponMin] = useState('40');

  // CMS / Blog / Support / Shipping State
  const [blogTitle, setBlogTitle] = useState('');
  const [blogCategory, setBlogCategory] = useState('Shade Science');
  const [blogExcerpt, setBlogExcerpt] = useState('');
  const [blogContent, setBlogContent] = useState('');
  const [editingPageId, setEditingPageId] = useState<string>(cmsPages[0]?.id || '');
  const [pageTitle, setPageTitle] = useState(cmsPages[0]?.title || '');
  const [pageContent, setPageContent] = useState(cmsPages[0]?.content || '');
  const [ticketReplies, setTicketReplies] = useState<Record<string, string>>({});
  const [zoneName, setZoneName] = useState('');
  const [zoneRegion, setZoneRegion] = useState('');
  const [zoneRate, setZoneRate] = useState('8');
  const [zoneThreshold, setZoneThreshold] = useState('60');
  const [zoneDays, setZoneDays] = useState('2–4 Business Days');

  // Site Customization, Settings & Automation Form
  const [logoText, setLogoText] = useState(siteSettings.logoText || 'LUMIÈRE ATELIER');
  const [heroTitle, setHeroTitle] = useState(siteSettings.heroTitle);
  const [heroSubtitle, setHeroSubtitle] = useState(siteSettings.heroSubtitle);
  const [promoText, setPromoText] = useState(siteSettings.promoBannerText || '');
  const [promoActive, setPromoActive] = useState(siteSettings.promoBannerActive);
  const [flashActive, setFlashActive] = useState(siteSettings.flashSaleActive);
  const [flashDiscount, setFlashDiscount] = useState(String(siteSettings.flashSaleDiscount || 10));
  const [accentColor, setAccentColor] = useState(siteSettings.accentColor || '#2563EB');
  const [defaultTheme, setDefaultTheme] = useState<'light' | 'dark'>(siteSettings.defaultTheme || 'light');
  const [seasonalTheme, setSeasonalTheme] = useState<'atelier' | 'bridal' | 'festival' | 'obsidian'>(
    siteSettings.seasonalTheme || 'atelier',
  );
  const [enable3D, setEnable3D] = useState(siteSettings.enable3DEffects !== false);
  const [enableAnim, setEnableAnim] = useState(siteSettings.enableAnimations !== false);
  const [animationIntensity, setAnimationIntensity] = useState<AnimationIntensity>(
    siteSettings.animationIntensity || 'cinematic',
  );
  const [motionSpeed, setMotionSpeed] = useState<MotionSpeed>(siteSettings.motionSpeed || 'normal');
  const [backgroundEffects, setBackgroundEffects] = useState(siteSettings.backgroundEffects !== false);
  const [particleDensity, setParticleDensity] = useState<ParticleDensity>(
    siteSettings.particleDensity || 'medium',
  );
  const [hoverEffects, setHoverEffects] = useState(siteSettings.hoverEffects !== false);
  const [pageTransitionStyle, setPageTransitionStyle] = useState<PageTransitionStyle>(
    siteSettings.pageTransitionStyle || 'cinematic',
  );
  const [mobileOptimization, setMobileOptimization] = useState(siteSettings.mobileOptimization !== false);
  const [reducedMotionMode, setReducedMotionMode] = useState(Boolean(siteSettings.reducedMotionMode));
  // 360° Global Lighting Control Panel State
  const [globalLightingEnabled, setGlobalLightingEnabled] = useState(siteSettings.globalLightingEnabled !== false);
  const [ambientLightingIntensity, setAmbientLightingIntensity] = useState<LightingIntensity>(
    siteSettings.ambientLightingIntensity || 'cinematic',
  );
  const [neonGlowIntensity, setNeonGlowIntensity] = useState<NeonGlowLevel>(
    siteSettings.neonGlowIntensity || 'medium',
  );
  const [lightAnimationSpeed, setLightAnimationSpeed] = useState<LightSpeed>(
    siteSettings.lightAnimationSpeed || 'normal',
  );
  const [lightColorPreset, setLightColorPreset] = useState<LightColorPreset>(
    siteSettings.lightColorPreset || 'rainbow',
  );
  const [borderGlowEnabled, setBorderGlowEnabled] = useState(siteSettings.borderGlowEnabled !== false);
  const [backgroundLightEffects, setBackgroundLightEffects] = useState(siteSettings.backgroundLightEffects !== false);
  const [mouseFollowLighting, setMouseFollowLighting] = useState(siteSettings.mouseFollowLighting !== false);
  const [mobileLightingOptimization, setMobileLightingOptimization] = useState(
    siteSettings.mobileLightingOptimization !== false,
  );
  const [autoRouteDropship, setAutoRouteDropship] = useState(siteSettings.autoRouteDropship !== false);
  const [autoDispatchPo, setAutoDispatchPo] = useState(siteSettings.autoDispatchPo !== false);
  const [lowStockAlertEnabled, setLowStockAlertEnabled] = useState(siteSettings.lowStockAlertEnabled !== false);
  const [codEnabled, setCodEnabled] = useState(siteSettings.codEnabled !== false);
  const [emailNotificationsEnabled, setEmailNotificationsEnabled] = useState(
    siteSettings.emailNotificationsEnabled !== false,
  );
  const [whatsappAlertsEnabled, setWhatsappAlertsEnabled] = useState(Boolean(siteSettings.whatsappAlertsEnabled));
  const [defaultTaxRate, setDefaultTaxRate] = useState(String(siteSettings.defaultTaxRate ?? 8));
  const [freeShippingThreshold, setFreeShippingThreshold] = useState(
    String(siteSettings.freeShippingThreshold ?? 75),
  );
  const [defaultCurrency, setDefaultCurrency] = useState<CurrencyCode>(siteSettings.defaultCurrency || 'USD');
  const [supportEmail, setSupportEmail] = useState(siteSettings.supportEmail || 'concierge@lumiereatelier.com');
  const [automationRules, setAutomationRules] = useState<AutomationRule[]>(
    siteSettings.automationRules && siteSettings.automationRules.length > 0
      ? siteSettings.automationRules
      : SEED_SITE_SETTINGS.automationRules || [],
  );
  const [newRuleName, setNewRuleName] = useState('');
  const [newRuleTrigger, setNewRuleTrigger] = useState('When order payment is verified');
  const [newRuleAction, setNewRuleAction] = useState('Route dropship lines & notify supplier');

  const uploadMediaFile = async (e: React.ChangeEvent<HTMLInputElement>, target: 'image' | 'video') => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingMedia(true);
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
      const res = await fetch('/api/uploads/media', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dataUrl, filename: `admin_${target}` }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Upload failed');
      if (target === 'image') setProdImageUrl(data.url);
      else setProdVideoUrl(data.url);
      setFeedback(`Uploaded ${target} asset.`);
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Media upload error.');
    } finally {
      setUploadingMedia(false);
    }
  };

  const loadProductIntoForm = (p: Product) => {
    setEditingId(p.id);
    setProdName(p.name);
    setProdBrand(p.brand);
    setProdCategory(p.category);
    setProdSubcategory(p.subcategory || '');
    setProdCollection(p.collection);
    setProdPrice(String(p.price));
    setProdStock(String(p.stock));
    setProdLowStock(String(p.lowStockThreshold ?? 15));
    setProdSku(p.sku);
    setProdBarcode(p.barcode || '');
    setProdFinish(p.finish);
    setProdModelType(p.modelType);
    setProdImageUrl(p.imageUrl);
    setProdVideoUrl(p.videoUrl || '');
    setProdDesc(p.description);
    setProdIngredients(p.ingredients);
    setProdSeoTitle(p.seoTitle || '');
    setProdSeoDesc(p.seoDescription || '');
    setProdFeatured(Boolean(p.featured));
    setProdTrending(Boolean(p.trending));
    setProdNewArrival(Boolean(p.newArrival));
    setProdBestSeller(Boolean(p.bestSeller));
    setProdShades(p.shades);
  };

  const resetProductForm = () => {
    setEditingId(null);
    setProdName('');
    setProdBrand('LUMIÈRE ATELIER');
    setProdCategory(categories[0]?.name || 'Lipsticks, Gloss & Liners');
    setProdSubcategory('');
    setProdCollection('Signature');
    setProdPrice('48');
    setProdStock('50');
    setProdLowStock('15');
    setProdSku(`LA-NEW-${Math.floor(100 + Math.random() * 899)}`);
    setProdBarcode('');
    setProdFinish('Velvet Matte');
    setProdModelType('lipstick');
    setProdImageUrl('/src/assets/images/cat_lipsticks_gloss_1794984607329.jpg');
    setProdVideoUrl('');
    setProdDesc('');
    setProdIngredients('');
    setProdSeoTitle('');
    setProdSeoDesc('');
    setProdFeatured(true);
    setProdTrending(false);
    setProdNewArrival(false);
    setProdBestSeller(false);
    setProdShades([{ id: 'atelier-ruby', name: 'Atelier Ruby', hex: '#9E1B32', undertone: 'Cool' }]);
  };

  const duplicateProduct = async (p: Product) => {
    const copyId = `prod_copy_${Date.now()}`;
    try {
      await setDoc(doc(db, 'products', copyId), {
        ...p,
        id: copyId,
        name: `${p.name} (Copy)`.slice(0, 140),
        sku: `${p.sku}-COPY`.slice(0, 60),
        reviewCount: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setFeedback(`Duplicated "${p.name}" as a new catalog SKU.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `products/${copyId}`);
    }
  };

  const saveCustomerCrm = async (customer: UserProfile) => {
    const edit = crmEdits[customer.uid];
    const nextSegment = edit?.customerSegment || customer.customerSegment || 'retail';
    const nextPoints = Math.max(0, Math.round(Number(edit?.loyaltyPoints ?? customer.loyaltyPoints ?? 0) || 0));
    try {
      await updateDoc(doc(db, 'users', customer.uid), {
        customerSegment: nextSegment,
        loyaltyPoints: nextPoints,
        updatedAt: serverTimestamp(),
      });
      setFeedback(`Updated CRM profile for ${customer.displayName} (${nextSegment}, ${nextPoints} pts).`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${customer.uid}`);
    }
  };

  const saveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    const id = editingId || `prod_${Date.now()}`;
    const existing = products.find((p) => p.id === id);
    const priceNum = Number(prodPrice) || 40;
    const stockNum = Math.max(0, Math.round(Number(prodStock) || 0));
    const erpDefaults = getProductErpDefaults(
      {
        ...(existing || ({} as Product)),
        id,
        sku: prodSku.trim(),
        price: priceNum,
        stock: stockNum,
      },
      products.length,
    );
    try {
      await setDoc(doc(db, 'products', id), {
        id,
        name: prodName.trim(),
        brand: prodBrand.trim(),
        category: prodCategory,
        ...(prodSubcategory.trim() ? { subcategory: prodSubcategory.trim() } : {}),
        collection: prodCollection,
        price: priceNum,
        stock: stockNum,
        lowStockThreshold: Math.max(0, Math.round(Number(prodLowStock) || 15)),
        sku: prodSku.trim(),
        ...(prodBarcode.trim() ? { barcode: prodBarcode.trim() } : {}),
        description: prodDesc.trim() || 'Luxury cosmetic formulation.',
        ingredients: prodIngredients.trim() || 'Clean botanical cosmetic base.',
        finish: prodFinish,
        modelType: prodModelType,
        imageUrl: prodImageUrl.trim(),
        ...(prodVideoUrl.trim() ? { videoUrl: prodVideoUrl.trim() } : {}),
        ...(prodSeoTitle.trim() ? { seoTitle: prodSeoTitle.trim() } : {}),
        ...(prodSeoDesc.trim() ? { seoDescription: prodSeoDesc.trim() } : {}),
        shades:
          prodShades.length > 0
            ? prodShades
            : [{ id: 'default', name: 'Signature', hex: '#9E1B32', undertone: 'Universal' }],
        skinTones: ['Fair', 'Light', 'Medium', 'Tan', 'Rich', 'Deep'],
        rating: existing?.rating ?? 5,
        reviewCount: existing?.reviewCount ?? 0,
        featured: prodFeatured,
        trending: prodTrending,
        newArrival: prodNewArrival,
        bestSeller: prodBestSeller,
        purchasePrice: existing?.purchasePrice ?? erpDefaults.purchasePrice,
        wholesalePrice: existing?.wholesalePrice ?? erpDefaults.wholesalePrice,
        dealerPrice: existing?.dealerPrice ?? erpDefaults.dealerPrice,
        distributorPrice: existing?.distributorPrice ?? erpDefaults.distributorPrice,
        moq: existing?.moq ?? erpDefaults.moq,
        supplierId: existing?.supplierId ?? erpDefaults.supplierId,
        supplierSku: existing?.supplierSku ?? erpDefaults.supplierSku,
        warehouseId: existing?.warehouseId ?? erpDefaults.warehouseId,
        fulfillmentMethod: existing?.fulfillmentMethod ?? erpDefaults.fulfillmentMethod,
        packagingType: existing?.packagingType ?? erpDefaults.packagingType,
        privateLabelAvailable: existing?.privateLabelAvailable ?? erpDefaults.privateLabelAvailable,
        ownedStock: existing?.ownedStock ?? stockNum,
        supplierStock: existing?.supplierStock ?? erpDefaults.supplierStock,
        reservedStock: existing?.reservedStock ?? 0,
        incomingStock: existing?.incomingStock ?? erpDefaults.incomingStock,
        damagedStock: existing?.damagedStock ?? 0,
        returnedStock: existing?.returnedStock ?? 0,
        createdAt: existing?.createdAt || serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setEditingId(null);
      setProdName('');
      setProdDesc('');
      setProdIngredients('');
      setFeedback(`Product "${prodName}" saved to Firestore.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `products/${id}`);
    }
  };

  const handleBulkCsvImport = async () => {
    if (!csvInput.trim()) return;
    setImportingCsv(true);
    try {
      const res = await fetch('/api/products/parse-csv', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ csvText: csvInput }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'CSV import failed');

      const batch = writeBatch(db);
      for (const row of data.products as Array<{
        id: string;
        name: string;
        brand: string;
        category: string;
        collection: ProductCollection;
        price: number;
        stock: number;
        sku: string;
        description: string;
        ingredients: string;
        finish: ProductFinish;
        modelType: ModelType;
        imageUrl: string;
        shadeName: string;
        shadeHex: string;
      }>) {
        const cleanId = row.id.replace(/[^a-zA-Z0-9_-]/g, '_');
        batch.set(doc(db, 'products', cleanId), {
          id: cleanId,
          name: row.name,
          brand: row.brand,
          category: row.category,
          collection: ['Signature', 'Bridal', 'Party', 'Professional'].includes(row.collection)
            ? row.collection
            : 'Signature',
          price: row.price,
          stock: row.stock,
          lowStockThreshold: 15,
          sku: row.sku,
          description: row.description,
          ingredients: row.ingredients,
          finish: ['Velvet Matte', 'Satin Gloss', 'Luminous Dew', 'Metallic Shimmer', 'Precision'].includes(row.finish)
            ? row.finish
            : 'Velvet Matte',
          modelType: ['lipstick', 'bottle', 'compact', 'palette', 'brush'].includes(row.modelType)
            ? row.modelType
            : 'lipstick',
          imageUrl: row.imageUrl,
          shades: [{ id: `shade_${cleanId}`, name: row.shadeName, hex: row.shadeHex, undertone: 'Universal' }],
          skinTones: ['Fair', 'Light', 'Medium', 'Tan', 'Rich', 'Deep'],
          rating: 5,
          reviewCount: 0,
          newArrival: true,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
      await batch.commit();
      setFeedback(`Imported ${data.count} product(s) from CSV to Firestore.`);
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Bulk import failed.');
    } finally {
      setImportingCsv(false);
    }
  };

  const deleteProduct = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'products', id));
      setFeedback('Product deleted.');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `products/${id}`);
    }
  };

  const updateOrderStatus = async (order: Order, nextStatus: OrderStatus) => {
    try {
      await updateDoc(doc(db, 'orders', order.id), {
        orderStatus: nextStatus,
        updatedAt: serverTimestamp(),
      });
      const notifId = `notif_${Date.now()}`;
      await setDoc(doc(db, 'users', order.userId, 'notifications', notifId), {
        id: notifId,
        userId: order.userId,
        title: `Order #${order.id} Update`,
        message: `Your order status is now: ${nextStatus.replace(/_/g, ' ')}.`,
        read: false,
        createdAt: serverTimestamp(),
      });
      setFeedback(`Order #${order.id} updated to ${nextStatus}.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${order.id}`);
    }
  };

  const issueRefund = async (order: Order, mode: 'full' | 'partial') => {
    const refundAmt = mode === 'full' ? order.total : Number((order.total * 0.5).toFixed(2));
    try {
      const tx = transactions.find((t) => t.orderId === order.id && t.status === 'succeeded');
      const res = await fetch('/api/payments/refund', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId: order.id,
          gateway: order.paymentGateway,
          gatewayPaymentId: tx?.gatewayPaymentId,
          refundAmount: refundAmt,
          totalAmount: order.total,
          reason: `Admin ${mode} refund processed`,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Refund failed');

      await updateDoc(doc(db, 'orders', order.id), {
        paymentStatus: mode === 'full' ? 'refunded' : 'partially_refunded',
        refundStatus: mode,
        refundAmount: refundAmt,
        orderStatus: mode === 'full' ? 'returned' : order.orderStatus,
        updatedAt: serverTimestamp(),
      });

      if (tx) {
        await updateDoc(doc(db, 'transactions', tx.id), {
          status: mode === 'full' ? 'refunded' : 'partially_refunded',
          refundAmount: refundAmt,
          updatedAt: serverTimestamp(),
        });
      }

      const notifId = `notif_rfnd_${Date.now()}`;
      await setDoc(doc(db, 'users', order.userId, 'notifications', notifId), {
        id: notifId,
        userId: order.userId,
        title: `Refund Processed (${mode})`,
        message: `${formatMoney(refundAmt, currency)} refunded for Order #${order.id} (${data.refundId}).`,
        read: false,
        createdAt: serverTimestamp(),
      });
      setFeedback(`Processed ${mode} refund (${data.refundId}) for Order #${order.id}.`);
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Refund error.');
    }
  };

  const saveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!catName.trim()) return;
    const id = `cat_${Date.now()}`;
    try {
      await setDoc(doc(db, 'categories', id), {
        id,
        name: catName.trim(),
        slug: catName.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-'),
        ...(catParentId ? { parentId: catParentId } : {}),
        description: catDesc.trim(),
        imageUrl: '/src/assets/images/cat_bridal_kits_1794984609940.jpg',
        discountPercent: Math.max(0, Math.min(90, Number(catDiscount) || 0)),
        visible: true,
        sortOrder: categories.length + 1,
      });
      setCatName('');
      setCatDesc('');
      setCatParentId('');
      setCatDiscount('0');
      setFeedback('Category / Subcategory created.');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `categories/${id}`);
    }
  };

  const moveCategoryOrder = async (index: number, dir: -1 | 1) => {
    const targetIdx = index + dir;
    if (targetIdx < 0 || targetIdx >= categories.length) return;
    const a = categories[index];
    const b = categories[targetIdx];
    try {
      const batch = writeBatch(db);
      batch.update(doc(db, 'categories', a.id), { sortOrder: b.sortOrder });
      batch.update(doc(db, 'categories', b.id), { sortOrder: a.sortOrder });
      await batch.commit();
      setFeedback(`Reordered "${a.name}".`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `categories/${a.id}`);
    }
  };

  const saveCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponCode.trim()) return;
    const id = `coupon_${Date.now()}`;
    try {
      await setDoc(doc(db, 'coupons', id), {
        id,
        code: couponCode.trim().toUpperCase(),
        discountPercent: Math.min(90, Math.max(1, Number(couponPercent) || 10)),
        minOrderAmount: Math.max(0, Number(couponMin) || 0),
        active: true,
        expiresAt: '2027-12-31T23:59:59Z',
      });
      setCouponCode('');
      setFeedback('Coupon created.');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `coupons/${id}`);
    }
  };

  const publishBlogPost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!blogTitle.trim() || !blogContent.trim()) return;
    const id = `blog_${Date.now()}`;
    try {
      await setDoc(doc(db, 'blogPosts', id), {
        id,
        title: blogTitle.trim(),
        slug: blogTitle.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-'),
        category: blogCategory,
        excerpt: blogExcerpt.trim() || blogContent.trim().slice(0, 140),
        content: blogContent.trim(),
        coverImage: '/src/assets/images/cat_lipsticks_gloss_1794984607329.jpg',
        author: 'LUMIÈRE ATELIER Editorial Desk',
        published: true,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setBlogTitle('');
      setBlogExcerpt('');
      setBlogContent('');
      setFeedback('Blog article published.');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `blogPosts/${id}`);
    }
  };

  const saveCmsPage = async (e: React.FormEvent) => {
    e.preventDefault();
    const target = cmsPages.find((p) => p.id === editingPageId);
    if (!target) return;
    try {
      await setDoc(doc(db, 'cmsPages', target.id), {
        ...target,
        title: pageTitle.trim() || target.title,
        content: pageContent.trim(),
        updatedAt: serverTimestamp(),
      });
      setFeedback(`Updated CMS page "${pageTitle}".`);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `cmsPages/${target.id}`);
    }
  };

  const resolveTicket = async (ticket: SupportTicket, nextStatus: SupportTicket['status']) => {
    const replyText = ticketReplies[ticket.id] ?? ticket.adminReply ?? '';
    try {
      await updateDoc(doc(db, 'supportTickets', ticket.id), {
        status: nextStatus,
        ...(replyText.trim() ? { adminReply: replyText.trim() } : {}),
        updatedAt: serverTimestamp(),
      });
      setFeedback(`Support ticket #${ticket.id} updated.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `supportTickets/${ticket.id}`);
    }
  };

  const addShippingZone = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!zoneName.trim() || !zoneRegion.trim()) return;
    const id = `zone_${Date.now()}`;
    try {
      await setDoc(doc(db, 'shippingZones', id), {
        id,
        name: zoneName.trim(),
        region: zoneRegion.trim(),
        baseRate: Math.max(0, Number(zoneRate) || 0),
        freeThreshold: Math.max(0, Number(zoneThreshold) || 50),
        estimatedDays: zoneDays.trim() || '3–5 Business Days',
        codAvailable: true,
        active: true,
      });
      setZoneName('');
      setZoneRegion('');
      setFeedback('Shipping zone saved.');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `shippingZones/${id}`);
    }
  };

  const saveSiteCustomization = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await setDoc(
        doc(db, 'siteSettings', 'main'),
        {
          logoText: logoText.trim() || 'LUMIÈRE ATELIER',
          heroTitle: heroTitle.trim(),
          heroSubtitle: heroSubtitle.trim(),
          heroImageUrl: siteSettings.heroImageUrl || '/src/assets/images/hero_cosmetics_atelier_1794984606857.jpg',
          promoBannerText: promoText.trim(),
          promoBannerActive: promoActive,
          flashSaleActive: flashActive,
          flashSaleDiscount: Math.min(80, Math.max(0, Number(flashDiscount) || 0)),
          accentColor,
          defaultTheme,
          seasonalTheme,
          enable3DEffects: enable3D,
          enableAnimations: enableAnim,
          animationIntensity,
          motionSpeed,
          backgroundEffects,
          particleDensity,
          hoverEffects,
          pageTransitionStyle,
          mobileOptimization,
          reducedMotionMode,
          globalLightingEnabled,
          ambientLightingIntensity,
          neonGlowIntensity,
          lightAnimationSpeed,
          lightColorPreset,
          borderGlowEnabled,
          backgroundLightEffects,
          mouseFollowLighting,
          mobileLightingOptimization,
          autoRouteDropship,
          autoDispatchPo,
          lowStockAlertEnabled,
          codEnabled,
          emailNotificationsEnabled,
          whatsappAlertsEnabled,
          defaultTaxRate: Math.min(50, Math.max(0, Number(defaultTaxRate) || 0)),
          freeShippingThreshold: Math.min(10000, Math.max(0, Number(freeShippingThreshold) || 0)),
          defaultCurrency,
          supportEmail: supportEmail.trim() || 'concierge@lumiereatelier.com',
          automationRules: automationRules.slice(0, 20),
          updatedAt: serverTimestamp(),
        },
        { merge: true },
      );
      setFeedback('Storefront settings, 360° Lighting Control Panel & automation rules saved live to Firestore.');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'siteSettings/main');
    }
  };

  const resetSiteSettingsToDefaults = async () => {
    const d = SEED_SITE_SETTINGS;
    setLogoText(d.logoText || 'LUMIÈRE ATELIER');
    setHeroTitle(d.heroTitle);
    setHeroSubtitle(d.heroSubtitle);
    setPromoText(d.promoBannerText || '');
    setPromoActive(d.promoBannerActive);
    setFlashActive(d.flashSaleActive);
    setFlashDiscount(String(d.flashSaleDiscount || 0));
    setAccentColor(d.accentColor || '#2563EB');
    setDefaultTheme(d.defaultTheme || 'light');
    setSeasonalTheme(d.seasonalTheme || 'atelier');
    setEnable3D(d.enable3DEffects !== false);
    setEnableAnim(d.enableAnimations !== false);
    setAnimationIntensity(d.animationIntensity || 'cinematic');
    setMotionSpeed(d.motionSpeed || 'normal');
    setBackgroundEffects(d.backgroundEffects !== false);
    setParticleDensity(d.particleDensity || 'medium');
    setHoverEffects(d.hoverEffects !== false);
    setPageTransitionStyle(d.pageTransitionStyle || 'cinematic');
    setMobileOptimization(d.mobileOptimization !== false);
    setReducedMotionMode(Boolean(d.reducedMotionMode));
    setGlobalLightingEnabled(d.globalLightingEnabled !== false);
    setAmbientLightingIntensity(d.ambientLightingIntensity || 'cinematic');
    setNeonGlowIntensity(d.neonGlowIntensity || 'medium');
    setLightAnimationSpeed(d.lightAnimationSpeed || 'normal');
    setLightColorPreset(d.lightColorPreset || 'rainbow');
    setBorderGlowEnabled(d.borderGlowEnabled !== false);
    setBackgroundLightEffects(d.backgroundLightEffects !== false);
    setMouseFollowLighting(d.mouseFollowLighting !== false);
    setMobileLightingOptimization(d.mobileLightingOptimization !== false);
    setAutoRouteDropship(d.autoRouteDropship !== false);
    setAutoDispatchPo(d.autoDispatchPo !== false);
    setLowStockAlertEnabled(d.lowStockAlertEnabled !== false);
    setCodEnabled(d.codEnabled !== false);
    setEmailNotificationsEnabled(d.emailNotificationsEnabled !== false);
    setWhatsappAlertsEnabled(Boolean(d.whatsappAlertsEnabled));
    setDefaultTaxRate(String(d.defaultTaxRate ?? 8));
    setFreeShippingThreshold(String(d.freeShippingThreshold ?? 75));
    setDefaultCurrency(d.defaultCurrency || 'USD');
    setSupportEmail(d.supportEmail || 'concierge@lumiereatelier.com');
    setAutomationRules(d.automationRules || []);
    onPreviewSiteSettings?.(d);
    try {
      await setDoc(doc(db, 'siteSettings', 'main'), {
        ...d,
        updatedAt: serverTimestamp(),
      });
      setFeedback('Restored default storefront settings, 360° lighting controls & automation workflows.');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'siteSettings/main');
    }
  };

  // Analytics Computations
  const totalRevenue = orders
    .filter((o) => o.paymentStatus !== 'failed' && o.orderStatus !== 'cancelled')
    .reduce((sum, o) => sum + o.total, 0);
  const avgOrder = orders.length > 0 ? totalRevenue / orders.length : 0;
  const lowStockProducts = products.filter((p) => p.stock <= (p.lowStockThreshold ?? 15));
  const gatewayBreakdown = ['Razorpay', 'Stripe', 'PayPal', 'Cashfree', 'PayU', 'CCAvenue', 'COD'].map((gw) => ({
    gw,
    count: orders.filter((o) => o.paymentGateway === gw).length,
    amount: orders.filter((o) => o.paymentGateway === gw).reduce((s, o) => s + o.total, 0),
  }));
  const maxGwAmount = Math.max(1, ...gatewayBreakdown.map((g) => g.amount));

  const filteredCustomers = customers.filter((c) => {
    const q = customerSearch.trim().toLowerCase();
    if (!q) return true;
    return (
      c.displayName.toLowerCase().includes(q) ||
      c.uid.toLowerCase().includes(q) ||
      (c.customerSegment || 'retail').toLowerCase().includes(q)
    );
  });

  return (
    <CinematicModal
      backdropClassName="flex items-center justify-center p-2 sm:p-4"
      panelClassName="bg-[#F5F7FF] dark:bg-[#06070E] text-[#0B1020] dark:text-[#F8FAFC] w-full max-w-7xl border border-indigo-500/30 dark:border-cyan-400/30 prism-modal-rim max-h-[95vh] flex flex-col overflow-hidden"
    >
        <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-[#070B1A] via-[#1B123A] via-55% to-[#2A1034] text-white">
          <div>
            <p className="text-[11px] uppercase tracking-[0.2em] text-[#22D3EE] font-bold">
              Unified Commerce & ERP Control Center
            </p>
            <h2 className="font-display text-2xl font-bold gradient-heading-hero">
              Admin Operations, Routing, Wholesale & Automation
            </h2>
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setAiCeoOpen(true)}
              className="px-3.5 py-2 btn-prism-sunset text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5 whitespace-nowrap"
            >
              <Bot className="w-3.5 h-3.5" /> AI CEO Advisor
            </button>
            <button type="button" onClick={onClose} aria-label="Close Admin Console" className="p-2 hover:bg-white/15">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
        <div className="prism-divider" />

        <div className="px-6 py-2.5 bg-white dark:bg-[#0D1120] border-b border-indigo-500/20 dark:border-cyan-400/20 neon-header-glow flex items-center gap-1.5 overflow-x-auto">
          {(
            [
              { id: 'erp_overview', label: 'ERP P&L & Reports', icon: BarChart3, active: 'btn-prism-cyan' },
              { id: 'erp_orders', label: `Routing & Channels (${orders.length})`, icon: Truck, active: 'btn-futuristic' },
              { id: 'erp_warehouses', label: `Warehouses & Stock (${warehouses.length})`, icon: WarehouseIcon, active: 'btn-prism-gold' },
              { id: 'erp_suppliers', label: `Suppliers & POs (${purchaseOrders.length})`, icon: Package, active: 'btn-prism-emerald' },
              { id: 'erp_wholesale', label: `Wholesale B2B (${wholesaleAccounts.length})`, icon: Building2, active: 'btn-prism-sunset' },
              { id: 'erp_rbac', label: `RBAC & Audit (${auditLogs.length})`, icon: Shield, active: 'btn-futuristic' },
              { id: 'marketing', label: `Marketing & AI Studio (${marketingCampaigns.length})`, icon: Megaphone, active: 'btn-prism-sunset' },
              { id: 'finance_ledger', label: `Finance & Tax (${expenses.length})`, icon: Calculator, active: 'btn-prism-emerald' },
              { id: 'logistics_intel', label: 'Logistics & Barcode', icon: Barcode, active: 'btn-prism-gold' },
              { id: 'integrations_dev', label: `Integrations & Dev (${integrations.length})`, icon: Cpu, active: 'btn-prism-cyan' },
              { id: 'security_gov', label: `Security & Fraud (${securitySessions.length})`, icon: ShieldAlert, active: 'btn-futuristic' },
              { id: 'analytics', label: 'Gateways & Alerts', icon: BarChart3, active: 'btn-prism-cyan' },
              { id: 'products', label: `Products & CSV (${products.length})`, icon: Package, active: 'btn-futuristic' },
              { id: 'categories', label: `Categories (${categories.length})`, icon: Layers, active: 'btn-prism-sunset' },
              { id: 'orders', label: `Refunds & Status (${orders.length})`, icon: RefreshCw, active: 'btn-prism-gold' },
              { id: 'coupons', label: `Coupons (${coupons.length})`, icon: Tag, active: 'btn-prism-emerald' },
              { id: 'reviews', label: `Reviews (${reviews.length})`, icon: Users, active: 'btn-prism-cyan' },
              { id: 'customers', label: `Customers CRM (${customers.length})`, icon: Users, active: 'btn-futuristic' },
              { id: 'cms', label: `CMS, Blog & Support (${supportTickets.length})`, icon: FileText, active: 'btn-prism-sunset' },
              { id: 'customize', label: 'Settings & Automation', icon: Sliders, active: 'btn-prism-emerald' },
            ] as const
          ).map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setTab(item.id)}
                className={`px-3.5 py-2 text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-all ${
                  tab === item.id
                    ? `${item.active} text-white`
                    : 'text-[#334155] dark:text-slate-200 hover:bg-indigo-50 dark:hover:bg-white/10'
                }`}
              >
                <Icon className="w-3.5 h-3.5" /> {item.label}
              </button>
            );
          })}
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {feedback && (
            <div className="bg-gradient-to-r from-blue-50 via-cyan-50 to-purple-50 dark:from-[#0C1933] dark:via-[#121630] dark:to-[#1F1233] border border-[#2563EB]/40 dark:border-[#22D3EE]/45 px-4 py-2.5 text-xs font-semibold flex justify-between items-center">
              <span className="text-[#1D4ED8] dark:text-[#67E8F9]">{feedback}</span>
              <button
                type="button"
                onClick={() => setFeedback(null)}
                className="text-[#434C66] dark:text-slate-300 hover:text-[#F43F5E]"
              >
                Dismiss
              </button>
            </div>
          )}

          {tab === 'erp_overview' && (
            <ErpOverviewSection
              products={products}
              orders={orders}
              suppliers={suppliers}
              purchaseOrders={purchaseOrders}
              warehouses={warehouses}
              wholesaleAccounts={wholesaleAccounts}
              wholesaleQuotes={wholesaleQuotes}
              auditLogs={auditLogs}
              currency={currency}
              onFeedback={setFeedback}
            />
          )}

          {tab === 'erp_orders' && (
            <ErpOrdersRoutingSection
              products={products}
              orders={orders}
              suppliers={suppliers}
              purchaseOrders={purchaseOrders}
              warehouses={warehouses}
              wholesaleAccounts={wholesaleAccounts}
              wholesaleQuotes={wholesaleQuotes}
              auditLogs={auditLogs}
              currency={currency}
              onFeedback={setFeedback}
            />
          )}

          {tab === 'erp_warehouses' && (
            <ErpWarehouseInventorySection
              products={products}
              orders={orders}
              suppliers={suppliers}
              purchaseOrders={purchaseOrders}
              warehouses={warehouses}
              wholesaleAccounts={wholesaleAccounts}
              wholesaleQuotes={wholesaleQuotes}
              auditLogs={auditLogs}
              currency={currency}
              onFeedback={setFeedback}
            />
          )}

          {tab === 'erp_suppliers' && (
            <ErpSuppliersPosSection
              products={products}
              orders={orders}
              suppliers={suppliers}
              purchaseOrders={purchaseOrders}
              warehouses={warehouses}
              wholesaleAccounts={wholesaleAccounts}
              wholesaleQuotes={wholesaleQuotes}
              auditLogs={auditLogs}
              currency={currency}
              onFeedback={setFeedback}
            />
          )}

          {tab === 'erp_wholesale' && (
            <ErpWholesaleB2BSection
              products={products}
              orders={orders}
              suppliers={suppliers}
              purchaseOrders={purchaseOrders}
              warehouses={warehouses}
              wholesaleAccounts={wholesaleAccounts}
              wholesaleQuotes={wholesaleQuotes}
              auditLogs={auditLogs}
              currency={currency}
              onFeedback={setFeedback}
            />
          )}

          {tab === 'erp_rbac' && (
            <ErpFinanceRbacAuditSection
              products={products}
              orders={orders}
              suppliers={suppliers}
              purchaseOrders={purchaseOrders}
              warehouses={warehouses}
              wholesaleAccounts={wholesaleAccounts}
              wholesaleQuotes={wholesaleQuotes}
              auditLogs={auditLogs}
              currency={currency}
              onFeedback={setFeedback}
            />
          )}

          {tab === 'marketing' && (
            <MarketingGrowthModule
              products={products}
              campaigns={marketingCampaigns}
              giftCards={giftCards}
              bundles={bundles}
              stockAlerts={stockAlerts}
              subscriptions={subscriptions}
              currency={currency}
              onFeedback={setFeedback}
            />
          )}

          {tab === 'finance_ledger' && (
            <FinanceAccountingModule
              orders={orders}
              expenses={expenses}
              currency={currency}
              onFeedback={setFeedback}
            />
          )}

          {tab === 'logistics_intel' && (
            <LogisticsIntelligenceModule
              products={products}
              suppliers={suppliers}
              orders={orders}
              currency={currency}
              adminUid={adminUid}
              onFeedback={setFeedback}
            />
          )}

          {tab === 'integrations_dev' && (
            <EnterpriseCommandHub
              integrations={integrations}
              workflows={automationWorkflows}
              products={products}
              orders={orders}
              suppliers={suppliers}
              expenses={expenses}
              campaigns={marketingCampaigns}
              onFeedback={setFeedback}
            />
          )}

          {tab === 'security_gov' && (
            <SecurityGovernanceModule
              orders={orders}
              sessions={securitySessions}
              auditLogs={auditLogs}
              siteSettings={siteSettings}
              aiTasks={aiTasks}
              onFeedback={setFeedback}
            />
          )}

          {tab === 'analytics' && (
            <motion.div
              key="tab-analytics"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {(
                  [
                    { label: 'Gross Revenue', val: totalRevenue, money: true, tone: KPI_COLOR_THEMES.revenue },
                    { label: 'Total Orders', val: orders.length, money: false, tone: KPI_COLOR_THEMES.orders },
                    { label: 'Average Order Value', val: avgOrder, money: true, tone: KPI_COLOR_THEMES.profit },
                    { label: 'Low-Stock Alerts', val: lowStockProducts.length, money: false, tone: KPI_COLOR_THEMES.notifications },
                  ] as const
                ).map((card) => (
                  <div
                    key={card.label}
                    className={`neon-card-orbit ${card.tone.cardBg} border ${card.tone.border} overflow-hidden glow-border holographic-card`}
                  >
                    <div className={`h-1 w-full ${card.tone.topBar}`} />
                    <div className="p-5">
                      <p className={`text-xs font-bold uppercase tracking-wider ${card.tone.subText}`}>{card.label}</p>
                      <p className={`font-mono text-2xl font-bold tabular-nums mt-1.5 ${card.tone.valueText}`}>
                        <AnimatedCounter
                          value={card.val}
                          formatter={(v) => (card.money ? formatMoney(v, currency) : String(Math.round(v)))}
                        />
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <AnimatedBarChart3D
                title="3D Gateway Volume Telemetry"
                subtitle="Live revenue volume across Razorpay, Stripe, PayPal, Cashfree, PayU, CCAvenue & COD"
                data={gatewayBreakdown.map((g) => ({
                  label: g.gw,
                  value: g.amount,
                  formattedValue: formatMoney(g.amount, currency),
                }))}
              />

              {lowStockProducts.length > 0 && (
                <div className="bg-gradient-to-r from-amber-50 via-orange-50/70 to-rose-50/80 dark:from-[#2B1B09] dark:via-[#261412] dark:to-[#290F1A] border border-amber-500/45 p-5 space-y-2">
                  <p className="text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 text-[#D97706] dark:text-[#FBBF24]">
                    <AlertTriangle className="w-4 h-4" /> Low-Stock Replenishment Alerts
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 text-xs">
                    {lowStockProducts.map((p) => (
                      <div
                        key={p.id}
                        className="p-2.5 bg-white dark:bg-[#0D1120] border border-amber-500/30 flex justify-between items-center"
                      >
                        <span className="truncate font-medium">{p.name}</span>
                        <span className="font-mono font-bold text-[#F43F5E] dark:text-[#FB7185] shrink-0">
                          {p.stock} left
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="bg-white dark:bg-[#0D1120] border border-cyan-500/25 dark:border-cyan-400/25 p-6 space-y-4 glow-border">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <h3 className="font-display text-xl font-bold gradient-heading">Revenue by Payment Gateway</h3>
                  <button
                    type="button"
                    onClick={() =>
                      downloadCsv(
                        'lumiere_transactions.csv',
                        ['TxID', 'OrderID', 'Gateway', 'Method', 'Amount', 'Currency', 'Status'],
                        transactions.map((t) => [
                          t.id,
                          t.orderId,
                          t.gateway,
                          t.method,
                          String(t.amount),
                          t.currency,
                          t.status,
                        ]),
                      )
                    }
                    className="px-3.5 py-2 btn-prism-cyan text-xs font-semibold flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" /> Export Transactions CSV
                  </button>
                </div>
                <div className="space-y-3">
                  {gatewayBreakdown.map((g, idx) => (
                    <div key={g.gw} className="grid grid-cols-12 items-center gap-3 text-xs">
                      <span className="col-span-3 sm:col-span-2 font-semibold">{g.gw}</span>
                      <div className="col-span-6 sm:col-span-7 bg-[#EEF2FF] dark:bg-[#141A30] h-5 border border-indigo-500/15 dark:border-cyan-400/20 overflow-hidden">
                        <div
                          className={`h-full bg-gradient-to-r ${CHART_BAR_GRADIENTS[idx % CHART_BAR_GRADIENTS.length]}`}
                          style={{ width: `${Math.max(4, (g.amount / maxGwAmount) * 100)}%` }}
                        />
                      </div>
                      <span className="col-span-3 text-right font-mono font-semibold tabular-nums">
                        {formatMoney(g.amount, currency)} ({g.count})
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {tab === 'products' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-5 space-y-5">
                <form onSubmit={saveProduct} className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-5 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="font-display text-xl font-semibold">
                      {editingId ? 'Edit Formula' : 'Add Cosmetic Product'}
                    </h3>
                    {editingId && (
                      <button type="button" onClick={() => setEditingId(null)} className="text-xs font-semibold text-[#EC4899] dark:text-[#22D3EE] hover:underline">
                        New Product
                      </button>
                    )}
                  </div>

                  <input
                    type="text"
                    required
                    placeholder="Product Title"
                    value={prodName}
                    onChange={(e) => setProdName(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm"
                  />

                  <div className="grid grid-cols-2 gap-2">
                    <select
                      value={prodCategory}
                      onChange={(e) => setProdCategory(e.target.value)}
                      className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                    >
                      {categories.map((c) => (
                        <option key={c.id} value={c.name}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                    <input
                      type="text"
                      placeholder="Subcategory (optional)"
                      value={prodSubcategory}
                      onChange={(e) => setProdSubcategory(e.target.value)}
                      className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                    />
                  </div>

                  <div className="grid grid-cols-4 gap-2">
                    <input
                      type="number"
                      required
                      min={1}
                      placeholder="USD"
                      value={prodPrice}
                      onChange={(e) => setProdPrice(e.target.value)}
                      className="px-2.5 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs font-mono"
                    />
                    <input
                      type="number"
                      required
                      min={0}
                      placeholder="Stock"
                      value={prodStock}
                      onChange={(e) => setProdStock(e.target.value)}
                      className="px-2.5 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs font-mono"
                    />
                    <input
                      type="text"
                      required
                      placeholder="SKU"
                      value={prodSku}
                      onChange={(e) => setProdSku(e.target.value)}
                      className="px-2.5 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs font-mono"
                    />
                    <input
                      type="text"
                      placeholder="Barcode"
                      value={prodBarcode}
                      onChange={(e) => setProdBarcode(e.target.value)}
                      className="px-2.5 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs font-mono"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <select
                      value={prodCollection}
                      onChange={(e) => setProdCollection(e.target.value as ProductCollection)}
                      className="px-2.5 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                    >
                      {['Signature', 'Bridal', 'Party', 'Professional'].map((col) => (
                        <option key={col} value={col}>
                          {col}
                        </option>
                      ))}
                    </select>
                    <select
                      value={prodFinish}
                      onChange={(e) => setProdFinish(e.target.value as ProductFinish)}
                      className="px-2.5 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                    >
                      {['Velvet Matte', 'Satin Gloss', 'Luminous Dew', 'Metallic Shimmer', 'Precision'].map((f) => (
                        <option key={f} value={f}>
                          {f}
                        </option>
                      ))}
                    </select>
                    <select
                      value={prodModelType}
                      onChange={(e) => setProdModelType(e.target.value as ModelType)}
                      className="px-2.5 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                    >
                      {['lipstick', 'bottle', 'compact', 'palette', 'brush'].map((m) => (
                        <option key={m} value={m}>
                          3D: {m}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <label className="flex items-center justify-center gap-1.5 border border-dashed border-indigo-500/35 dark:border-cyan-400/35 p-2 text-xs font-medium cursor-pointer bg-[#F5F7FF] dark:bg-[#141A30] hover:border-[#2563EB] dark:hover:border-[#22D3EE] transition-colors">
                      <Upload className="w-3.5 h-3.5 text-[#2563EB] dark:text-[#22D3EE]" />
                      <span>{uploadingMedia ? 'Uploading...' : 'Upload Image'}</span>
                      <input type="file" accept="image/*" onChange={(e) => uploadMediaFile(e, 'image')} className="hidden" />
                    </label>
                    <label className="flex items-center justify-center gap-1.5 border border-dashed border-fuchsia-500/35 dark:border-fuchsia-400/35 p-2 text-xs font-medium cursor-pointer bg-[#F5F7FF] dark:bg-[#141A30] hover:border-[#D946EF] transition-colors">
                      <Upload className="w-3.5 h-3.5 text-[#D946EF] dark:text-fuchsia-300" />
                      <span>Upload Video</span>
                      <input type="file" accept="video/mp4,video/webm" onChange={(e) => uploadMediaFile(e, 'video')} className="hidden" />
                    </label>
                  </div>

                  <textarea
                    rows={2}
                    placeholder="Product description..."
                    value={prodDesc}
                    onChange={(e) => setProdDesc(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                  />
                  <textarea
                    rows={2}
                    placeholder="Ingredients (INCI)..."
                    value={prodIngredients}
                    onChange={(e) => setProdIngredients(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                  />

                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="SEO Title"
                      value={prodSeoTitle}
                      onChange={(e) => setProdSeoTitle(e.target.value)}
                      className="px-2.5 py-1.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                    />
                    <input
                      type="text"
                      placeholder="SEO Description"
                      value={prodSeoDesc}
                      onChange={(e) => setProdSeoDesc(e.target.value)}
                      className="px-2.5 py-1.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                    />
                  </div>

                  <div className="flex flex-wrap gap-3 text-xs pt-1">
                    <label className="flex items-center gap-1.5">
                      <input type="checkbox" checked={prodFeatured} onChange={(e) => setProdFeatured(e.target.checked)} />
                      Featured
                    </label>
                    <label className="flex items-center gap-1.5">
                      <input type="checkbox" checked={prodTrending} onChange={(e) => setProdTrending(e.target.checked)} />
                      Trending
                    </label>
                    <label className="flex items-center gap-1.5">
                      <input type="checkbox" checked={prodNewArrival} onChange={(e) => setProdNewArrival(e.target.checked)} />
                      New Arrival
                    </label>
                    <label className="flex items-center gap-1.5">
                      <input type="checkbox" checked={prodBestSeller} onChange={(e) => setProdBestSeller(e.target.checked)} />
                      Best Seller
                    </label>
                  </div>

                  {/* Shade Manager */}
                  <div className="border-t border-black/10 dark:border-white/10 pt-3 space-y-2">
                    <p className="text-xs font-semibold">Shades ({prodShades.length})</p>
                    <div className="flex flex-wrap gap-1.5">
                      {prodShades.map((s) => (
                        <span
                          key={s.id}
                          className="inline-flex items-center gap-1.5 px-2 py-1 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-[11px]"
                        >
                          <span className="w-3 h-3 rounded-full" style={{ backgroundColor: s.hex }} />
                          {s.name}
                          <button
                            type="button"
                            onClick={() => setProdShades(prodShades.filter((x) => x.id !== s.id))}
                            className="text-red-700 ml-1"
                          >
                            ×
                          </button>
                        </span>
                      ))}
                    </div>
                    <div className="flex gap-1.5">
                      <input
                        type="color"
                        value={newShadeHex}
                        onChange={(e) => setNewShadeHex(e.target.value)}
                        className="w-9 h-8 border border-black/15 cursor-pointer"
                      />
                      <input
                        type="text"
                        placeholder="Shade Name"
                        value={newShadeName}
                        onChange={(e) => setNewShadeName(e.target.value)}
                        className="flex-1 px-2 py-1 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                      />
                      <select
                        value={newShadeUndertone}
                        onChange={(e) => setNewShadeUndertone(e.target.value as 'Warm' | 'Cool' | 'Neutral' | 'Universal')}
                        className="px-2 py-1 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                      >
                        <option value="Warm">Warm</option>
                        <option value="Cool">Cool</option>
                        <option value="Neutral">Neutral</option>
                        <option value="Universal">Universal</option>
                      </select>
                      <button
                        type="button"
                        onClick={() => {
                          if (!newShadeName.trim()) return;
                          setProdShades([
                            ...prodShades,
                            {
                              id: `shade_${Date.now()}`,
                              name: newShadeName.trim(),
                              hex: newShadeHex,
                              undertone: newShadeUndertone,
                            },
                          ]);
                          setNewShadeName('');
                        }}
                        className="px-2.5 btn-futuristic text-white text-xs"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="submit"
                      className="flex-1 py-2.5 btn-futuristic text-xs font-semibold uppercase tracking-wider"
                    >
                      {editingId ? 'Update Product' : 'Publish Product'}
                    </button>
                    <button
                      type="button"
                      onClick={resetProductForm}
                      className="px-4 py-2.5 border border-black/15 dark:border-white/15 hover:bg-black/5 dark:hover:bg-white/10 text-xs font-medium flex items-center gap-1"
                    >
                      <RotateCcw className="w-3.5 h-3.5" /> Reset
                    </button>
                  </div>
                </form>

                {/* Bulk CSV Import / Export */}
                <div className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-5 space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="font-display text-lg font-semibold">Bulk CSV Import / Export</h4>
                    <button
                      type="button"
                      onClick={() =>
                        downloadCsv(
                          'lumiere_catalog.csv',
                          ['id', 'name', 'category', 'collection', 'price', 'stock', 'sku', 'finish', 'modelType'],
                          products.map((p) => [
                            p.id,
                            p.name,
                            p.category,
                            p.collection,
                            String(p.price),
                            String(p.stock),
                            p.sku,
                            p.finish,
                            p.modelType,
                          ]),
                        )
                      }
                      className="text-xs font-medium text-[#EC4899] dark:text-[#F472B6] flex items-center gap-1"
                    >
                      <Download className="w-3.5 h-3.5" /> Export CSV
                    </button>
                  </div>
                  <textarea
                    rows={3}
                    value={csvInput}
                    onChange={(e) => setCsvInput(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-[11px] font-mono"
                  />
                  <button
                    type="button"
                    disabled={importingCsv}
                    onClick={handleBulkCsvImport}
                    className="w-full py-2 btn-futuristic text-white text-xs font-semibold uppercase tracking-wider"
                  >
                    {importingCsv ? 'Importing...' : 'Import CSV Rows'}
                  </button>
                </div>
              </div>

              <div className="lg:col-span-7 space-y-2.5">
                {products.map((p) => (
                  <div
                    key={p.id}
                    className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-3.5 flex items-center justify-between gap-4"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img src={p.imageUrl} alt={p.name} referrerPolicy="no-referrer" className="w-12 h-12 object-cover shrink-0" />
                      <div className="min-w-0">
                        <p className="text-sm font-semibold truncate">{p.name}</p>
                        <p className="text-xs text-[#434C66] dark:text-slate-300">
                          {p.category} · Stock: <span className="font-mono">{p.stock}</span> · {formatMoney(p.price, currency)}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      {onViewProduct && (
                        <button
                          type="button"
                          onClick={() => onViewProduct(p)}
                          title="Preview product in storefront"
                          aria-label={`View ${p.name}`}
                          className="p-1.5 border border-black/15 dark:border-white/15 hover:border-[#2563EB] hover:text-[#2563EB] dark:hover:text-[#22D3EE]"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => duplicateProduct(p)}
                        title="Duplicate product"
                        aria-label={`Duplicate ${p.name}`}
                        className="p-1.5 border border-black/15 dark:border-white/15 hover:border-[#7C3AED] hover:text-[#7C3AED] dark:hover:text-[#A78BFA]"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => loadProductIntoForm(p)}
                        className="px-3 py-1.5 border border-black/15 dark:border-white/15 text-xs font-medium hover:bg-black/5 dark:hover:bg-white/10"
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          setConfirmState({
                            title: `Delete "${p.name}"?`,
                            message: 'This product will be permanently removed from the catalog and Firestore.',
                            confirmLabel: 'Delete Product',
                            destructive: true,
                            onConfirm: () => deleteProduct(p.id),
                          })
                        }
                        aria-label="Delete product"
                        className="p-1.5 text-[#434C66] dark:text-slate-300 hover:text-red-600 dark:hover:text-red-400"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === 'categories' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <form
                onSubmit={saveCategory}
                className="lg:col-span-4 bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-5 space-y-3 h-fit"
              >
                <h3 className="font-display text-xl font-semibold">Add Category / Subcategory</h3>
                <input
                  type="text"
                  required
                  placeholder="Category Name"
                  value={catName}
                  onChange={(e) => setCatName(e.target.value)}
                  className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm"
                />
                <select
                  value={catParentId}
                  onChange={(e) => setCatParentId(e.target.value)}
                  className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                >
                  <option value="">Top-Level Category</option>
                  {categories
                    .filter((c) => !c.parentId)
                    .map((c) => (
                      <option key={c.id} value={c.id}>
                        Subcategory of: {c.name}
                      </option>
                    ))}
                </select>
                <input
                  type="number"
                  min={0}
                  max={90}
                  placeholder="Category Discount %"
                  value={catDiscount}
                  onChange={(e) => setCatDiscount(e.target.value)}
                  className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs font-mono"
                />
                <textarea
                  rows={2}
                  placeholder="Category description..."
                  value={catDesc}
                  onChange={(e) => setCatDesc(e.target.value)}
                  className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm"
                />
                <button
                  type="submit"
                  className="w-full py-2.5 btn-futuristic text-white text-xs font-semibold uppercase tracking-wider"
                >
                  Create Category
                </button>
              </form>
              <div className="lg:col-span-8 space-y-2.5">
                {categories.map((cat, idx) => (
                  <div
                    key={cat.id}
                    className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-4 flex justify-between items-center gap-3"
                  >
                    <div>
                      <p className="font-semibold text-sm">
                        {cat.parentId ? `↳ ${cat.name}` : cat.name}
                        {cat.discountPercent ? ` (${cat.discountPercent}% off)` : ''}
                      </p>
                      <p className="text-xs text-[#434C66] dark:text-slate-300 mt-0.5">{cat.description}</p>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => moveCategoryOrder(idx, -1)}
                        aria-label="Move up"
                        className="p-1.5 border border-black/15 dark:border-white/15"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => moveCategoryOrder(idx, 1)}
                        aria-label="Move down"
                        className="p-1.5 border border-black/15 dark:border-white/15"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          updateDoc(doc(db, 'categories', cat.id), { visible: cat.visible === false })
                        }
                        className="px-2.5 py-1 border border-black/15 dark:border-white/15 text-xs"
                      >
                        {cat.visible === false ? 'Hidden' : 'Visible'}
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          setConfirmState({
                            title: `Delete Category "${cat.name}"?`,
                            message: 'Removing this category hides it from navigation menus immediately.',
                            confirmLabel: 'Delete Category',
                            destructive: true,
                            onConfirm: async () => {
                              await deleteDoc(doc(db, 'categories', cat.id));
                              setFeedback(`Category "${cat.name}" deleted.`);
                            },
                          })
                        }
                        className="px-2.5 py-1 text-xs text-red-600 dark:text-red-400 hover:underline"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === 'orders' && (
            <div className="space-y-3">
              {orders.map((order) => (
                <div
                  key={order.id}
                  className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-4 flex flex-wrap items-center justify-between gap-4"
                >
                  <div className="space-y-1 text-xs">
                    <p className="font-mono font-semibold text-sm">
                      #{order.id} · {formatMoney(order.total, currency)}
                    </p>
                    <p className="text-[#434C66] dark:text-slate-300">
                      {order.customerName || order.shippingAddress.fullName} ({order.customerEmail}) · {order.paymentGateway} /{' '}
                      {order.paymentMethod}
                    </p>
                    <p className="text-[#EC4899] dark:text-[#F472B6] font-medium capitalize">
                      Payment: {order.paymentStatus} · Order: {order.orderStatus.replace(/_/g, ' ')}
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <select
                      value={order.orderStatus}
                      onChange={(e) => updateOrderStatus(order, e.target.value as OrderStatus)}
                      className="px-2.5 py-1.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                    >
                      {[
                        'processing',
                        'confirmed',
                        'packed',
                        'shipped',
                        'out_for_delivery',
                        'delivered',
                        'return_requested',
                        'returned',
                        'cancelled',
                      ].map((s) => (
                        <option key={s} value={s}>
                          {s.replace(/_/g, ' ')}
                        </option>
                      ))}
                    </select>
                    {order.paymentStatus === 'paid' && (
                      <>
                        <button
                          type="button"
                          onClick={() =>
                            setConfirmState({
                              title: `Issue 50% Partial Refund for #${order.id}?`,
                              message: `Refund ${formatMoney(Number((order.total * 0.5).toFixed(2)), currency)} via ${order.paymentGateway} and notify the customer.`,
                              confirmLabel: 'Issue 50% Refund',
                              destructive: true,
                              onConfirm: () => issueRefund(order, 'partial'),
                            })
                          }
                          className="px-3 py-1.5 border border-black/15 dark:border-white/15 text-xs hover:border-[#2563EB]"
                        >
                          50% Partial Refund
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setConfirmState({
                              title: `Issue Full Refund for #${order.id}?`,
                              message: `Refund ${formatMoney(order.total, currency)} via ${order.paymentGateway} and mark the order as returned.`,
                              confirmLabel: 'Issue Full Refund',
                              destructive: true,
                              onConfirm: () => issueRefund(order, 'full'),
                            })
                          }
                          className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-medium"
                        >
                          Full Refund
                        </button>
                      </>
                    )}
                  </div>
                </div>
              ))}
              {orders.length === 0 && (
                <p className="text-sm text-[#475569] dark:text-white/75 bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-6">
                  No customer orders yet.
                </p>
              )}
            </div>
          )}

          {tab === 'coupons' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <form
                onSubmit={saveCoupon}
                className="lg:col-span-4 bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-5 space-y-3 h-fit"
              >
                <h3 className="font-display text-xl font-semibold">Create Promo Coupon</h3>
                <input
                  type="text"
                  required
                  placeholder="Code (e.g. VOGUE25)"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm uppercase font-mono"
                />
                <input
                  type="number"
                  required
                  min={1}
                  max={90}
                  placeholder="Discount %"
                  value={couponPercent}
                  onChange={(e) => setCouponPercent(e.target.value)}
                  className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm font-mono"
                />
                <input
                  type="number"
                  min={0}
                  placeholder="Min Order USD"
                  value={couponMin}
                  onChange={(e) => setCouponMin(e.target.value)}
                  className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm font-mono"
                />
                <button
                  type="submit"
                  className="w-full py-2.5 btn-futuristic text-white text-xs font-semibold uppercase tracking-wider"
                >
                  Add Coupon
                </button>
              </form>
              <div className="lg:col-span-8 space-y-2.5">
                {coupons.map((c) => (
                  <div
                    key={c.id}
                    className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-4 flex items-center justify-between"
                  >
                    <div>
                      <p className="font-mono font-semibold text-sm">{c.code}</p>
                      <p className="text-xs text-[#434C66] dark:text-slate-300">
                        {c.discountPercent}% off · Min order ${c.minOrderAmount || 0}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => updateDoc(doc(db, 'coupons', c.id), { active: !c.active })}
                        className={`px-3 py-1 text-xs border font-semibold ${
                          c.active ? 'btn-prism-emerald border-transparent text-white' : 'border-indigo-500/25 dark:border-white/25'
                        }`}
                      >
                        {c.active ? 'Active' : 'Paused'}
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          setConfirmState({
                            title: `Delete Coupon "${c.code}"?`,
                            message: 'Customers will no longer be able to redeem this promo code at checkout.',
                            confirmLabel: 'Delete Coupon',
                            destructive: true,
                            onConfirm: async () => {
                              await deleteDoc(doc(db, 'coupons', c.id));
                              setFeedback(`Coupon "${c.code}" deleted.`);
                            },
                          })
                        }
                        aria-label={`Delete coupon ${c.code}`}
                        className="p-1.5 text-[#434C66] dark:text-slate-300 hover:text-red-600 dark:hover:text-red-400"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === 'reviews' && (
            <div className="space-y-3">
              {reviews.map((rev) => (
                <div
                  key={rev.id}
                  className="bg-white dark:bg-[#0D1120] border-l-4 border-l-[#F59E0B] border border-indigo-500/20 dark:border-cyan-400/20 p-4 flex justify-between items-start gap-4"
                >
                  <div className="space-y-1 text-xs">
                    <p className="font-semibold text-sm flex items-center gap-2">
                      <span>{rev.title}</span>
                      <span className="px-2 py-0.5 bg-amber-500/15 text-amber-700 dark:text-amber-300 font-mono text-[11px]">
                        ★ {rev.rating}/5
                      </span>
                    </p>
                    <p className="text-[#475569] dark:text-white/65">
                      By {rev.authorName} · Product {rev.productId}
                    </p>
                    <p>{rev.comment}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      setConfirmState({
                        title: 'Delete Customer Review?',
                        message: `Remove "${rev.title}" by ${rev.authorName} permanently from the storefront.`,
                        confirmLabel: 'Delete Review',
                        destructive: true,
                        onConfirm: async () => {
                          await deleteDoc(doc(db, 'reviews', rev.id));
                          setFeedback('Review deleted.');
                        },
                      })
                    }
                    className="px-3 py-1 border border-rose-500/35 text-rose-600 dark:text-rose-400 hover:bg-rose-600 hover:text-white text-xs font-semibold transition-colors"
                  >
                    Delete
                  </button>
                </div>
              ))}
            </div>
          )}

          {tab === 'customers' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="font-display text-xl font-semibold gradient-heading">Customer CRM & Tier Management</h3>
                  <p className="text-xs text-[#475569] dark:text-white/65">
                    Assign retail, wholesale, dealer, distributor, or enterprise segments and adjust loyalty balances.
                  </p>
                </div>
                <input
                  type="text"
                  placeholder="Search by name, UID, or tier..."
                  value={customerSearch}
                  onChange={(e) => setCustomerSearch(e.target.value)}
                  className="px-3 py-2 bg-white dark:bg-[#0D1120] border border-indigo-500/25 dark:border-cyan-400/25 text-xs w-64"
                />
              </div>

              <div className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-indigo-500/20 dark:border-cyan-400/20 bg-gradient-to-r from-indigo-500/5 via-cyan-500/5 to-fuchsia-500/5 text-[#2563EB] dark:text-[#22D3EE] uppercase tracking-wider">
                      <th className="p-3.5">Client Name & UID</th>
                      <th className="p-3.5">Skin ID</th>
                      <th className="p-3.5">CRM Segment</th>
                      <th className="p-3.5">Loyalty Points</th>
                      <th className="p-3.5">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-indigo-500/15 dark:divide-cyan-400/15">
                    {filteredCustomers.map((c) => {
                      const edit = crmEdits[c.uid];
                      const segValue = edit?.customerSegment || c.customerSegment || 'retail';
                      const ptsValue = edit?.loyaltyPoints ?? String(c.loyaltyPoints ?? 0);
                      return (
                        <tr key={c.uid} className="hover:bg-indigo-500/[0.03] dark:hover:bg-cyan-400/[0.04]">
                          <td className="p-3.5">
                            <p className="font-semibold">{c.displayName}</p>
                            <p className="font-mono text-[11px] text-[#475569] dark:text-white/55">{c.uid}</p>
                          </td>
                          <td className="p-3.5">
                            {c.skinTone || '—'} {c.undertone ? `· ${c.undertone}` : ''}
                          </td>
                          <td className="p-3.5">
                            <select
                              aria-label={`Segment for ${c.displayName}`}
                              value={segValue}
                              onChange={(e) =>
                                setCrmEdits((prev) => ({
                                  ...prev,
                                  [c.uid]: {
                                    customerSegment: e.target.value as NonNullable<UserProfile['customerSegment']>,
                                    loyaltyPoints: ptsValue,
                                  },
                                }))
                              }
                              className="px-2.5 py-1.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs capitalize font-medium"
                            >
                              {(['retail', 'wholesale', 'dealer', 'distributor', 'enterprise'] as const).map((seg) => (
                                <option key={seg} value={seg}>
                                  {seg}
                                </option>
                              ))}
                            </select>
                          </td>
                          <td className="p-3.5">
                            <input
                              type="number"
                              min={0}
                              aria-label={`Loyalty points for ${c.displayName}`}
                              value={ptsValue}
                              onChange={(e) =>
                                setCrmEdits((prev) => ({
                                  ...prev,
                                  [c.uid]: {
                                    customerSegment: segValue,
                                    loyaltyPoints: e.target.value,
                                  },
                                }))
                              }
                              className="w-24 px-2 py-1.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs font-mono tabular-nums"
                            />
                          </td>
                          <td className="p-3.5">
                            <button
                              type="button"
                              onClick={() => saveCustomerCrm(c)}
                              className="px-3 py-1.5 btn-prism-cyan text-xs font-semibold"
                            >
                              Save CRM
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                    {filteredCustomers.length === 0 && (
                      <tr>
                        <td colSpan={5} className="p-6 text-center text-[#475569] dark:text-white/65">
                          No matching customers found.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {tab === 'cms' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Blog Publisher */}
              <div className="lg:col-span-6 space-y-5">
                <form
                  onSubmit={publishBlogPost}
                  className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-5 space-y-3"
                >
                  <h3 className="font-display text-xl font-semibold">Publish Beauty Journal Article</h3>
                  <input
                    type="text"
                    required
                    placeholder="Article Headline"
                    value={blogTitle}
                    onChange={(e) => setBlogTitle(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm"
                  />
                  <input
                    type="text"
                    placeholder="Category (e.g. Shade Science, Bridal)"
                    value={blogCategory}
                    onChange={(e) => setBlogCategory(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                  />
                  <input
                    type="text"
                    placeholder="Short Excerpt"
                    value={blogExcerpt}
                    onChange={(e) => setBlogExcerpt(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                  />
                  <textarea
                    rows={4}
                    required
                    placeholder="Full article body..."
                    value={blogContent}
                    onChange={(e) => setBlogContent(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                  />
                  <button
                    type="submit"
                    className="px-5 py-2.5 btn-prism-sunset text-white text-xs font-semibold uppercase tracking-wider"
                  >
                    Publish Article
                  </button>
                </form>

                {/* CMS Policy & Company Page Editor */}
                <form
                  onSubmit={saveCmsPage}
                  className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-5 space-y-3"
                >
                  <h3 className="font-display text-xl font-semibold">Edit Policy & Company Page</h3>
                  <select
                    value={editingPageId}
                    onChange={(e) => {
                      const next = cmsPages.find((p) => p.id === e.target.value);
                      setEditingPageId(e.target.value);
                      if (next) {
                        setPageTitle(next.title);
                        setPageContent(next.content);
                      }
                    }}
                    className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                  >
                    {cmsPages.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.title} ({p.group})
                      </option>
                    ))}
                  </select>
                  <input
                    type="text"
                    value={pageTitle}
                    onChange={(e) => setPageTitle(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm"
                  />
                  <textarea
                    rows={4}
                    value={pageContent}
                    onChange={(e) => setPageContent(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                  />
                  <button
                    type="submit"
                    className="px-5 py-2.5 btn-futuristic text-white text-xs font-semibold uppercase tracking-wider"
                  >
                    Save CMS Page
                  </button>
                </form>
              </div>

              {/* Support Tickets + Shipping Zones */}
              <div className="lg:col-span-6 space-y-5">
                <div className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-5 space-y-3">
                  <h3 className="font-display text-xl font-semibold">
                    Customer Support Tickets ({supportTickets.length})
                  </h3>
                  {supportTickets.length === 0 ? (
                    <p className="text-xs text-[#434C66] dark:text-slate-300">No open support tickets.</p>
                  ) : (
                    supportTickets.map((t) => (
                      <div
                        key={t.id}
                        className="p-3.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/20 dark:border-cyan-400/20 space-y-2 text-xs"
                      >
                        <div className="flex justify-between">
                          <span className="font-semibold">
                            {t.subject} — {t.name} ({t.email})
                          </span>
                          <span className="capitalize font-mono text-[#EC4899] dark:text-[#F472B6]">{t.status}</span>
                        </div>
                        <p className="text-[#475569] dark:text-white/75">{t.message}</p>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            placeholder="Write concierge reply..."
                            value={ticketReplies[t.id] ?? t.adminReply ?? ''}
                            onChange={(e) => setTicketReplies({ ...ticketReplies, [t.id]: e.target.value })}
                            className="flex-1 px-2.5 py-1.5 bg-white dark:bg-[#0D1120] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                          />
                          <button
                            type="button"
                            onClick={() => resolveTicket(t, 'resolved')}
                            className="px-3 py-1.5 btn-prism-emerald text-white text-xs font-semibold"
                          >
                            Reply & Resolve
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>

                <form
                  onSubmit={addShippingZone}
                  className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-5 space-y-3"
                >
                  <h3 className="font-display text-xl font-semibold">Shipping Zones ({shippingZones.length})</h3>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      required
                      placeholder="Zone Name"
                      value={zoneName}
                      onChange={(e) => setZoneName(e.target.value)}
                      className="px-2.5 py-1.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                    />
                    <input
                      type="text"
                      required
                      placeholder="Region"
                      value={zoneRegion}
                      onChange={(e) => setZoneRegion(e.target.value)}
                      className="px-2.5 py-1.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                    />
                    <input
                      type="number"
                      placeholder="Rate USD"
                      value={zoneRate}
                      onChange={(e) => setZoneRate(e.target.value)}
                      className="px-2.5 py-1.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs font-mono"
                    />
                    <input
                      type="text"
                      placeholder="Estimated Days"
                      value={zoneDays}
                      onChange={(e) => setZoneDays(e.target.value)}
                      className="px-2.5 py-1.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-4 py-2 btn-futuristic text-white text-xs font-semibold uppercase tracking-wider"
                  >
                    Add Shipping Zone
                  </button>
                </form>
              </div>
            </div>
          )}

          {tab === 'customize' && (
            <form onSubmit={saveSiteCustomization} className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Column: Branding, Theme & Commerce Configuration */}
              <div className="lg:col-span-6 bg-white dark:bg-[#0D1120] border-t-4 border-t-[#2563EB] border border-indigo-500/20 dark:border-cyan-400/20 p-6 space-y-4 shadow-sm">
                <h3 className="font-display text-2xl font-semibold gradient-heading">
                  Storefront Branding & Commerce Settings
                </h3>

                <div>
                  <label className="block text-xs font-semibold text-[#475569] dark:text-white/75 mb-1">Brand Logo Text</label>
                  <input
                    type="text"
                    value={logoText}
                    onChange={(e) => setLogoText(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#475569] dark:text-white/75 mb-1">Hero Headline</label>
                  <input
                    type="text"
                    value={heroTitle}
                    onChange={(e) => setHeroTitle(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#475569] dark:text-white/75 mb-1">Hero Editorial Subtitle</label>
                  <textarea
                    rows={2}
                    value={heroSubtitle}
                    onChange={(e) => setHeroSubtitle(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#475569] dark:text-white/75 mb-1">Top Promo Banner Text</label>
                  <input
                    type="text"
                    value={promoText}
                    onChange={(e) => setPromoText(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-[#475569] dark:text-white/75 mb-1">Appearance Mode</label>
                    <select
                      value={defaultTheme}
                      onChange={(e) => setDefaultTheme(e.target.value as 'light' | 'dark')}
                      className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm"
                    >
                      <option value="light">Colorful Light Mode</option>
                      <option value="dark">Colorful Dark Mode</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#475569] dark:text-white/75 mb-1">Seasonal Preset</label>
                    <select
                      value={seasonalTheme}
                      onChange={(e) =>
                        setSeasonalTheme(e.target.value as 'atelier' | 'bridal' | 'festival' | 'obsidian')
                      }
                      className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm"
                    >
                      <option value="atelier">Atelier Classic</option>
                      <option value="bridal">Bridal Rose Gold</option>
                      <option value="festival">Festival Luminance</option>
                      <option value="obsidian">Obsidian Runway</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-[#475569] dark:text-white/75 mb-1">Default Tax %</label>
                    <input
                      type="number"
                      min={0}
                      max={50}
                      step="0.5"
                      value={defaultTaxRate}
                      onChange={(e) => setDefaultTaxRate(e.target.value)}
                      className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#475569] dark:text-white/75 mb-1">Free Shipping ($)</label>
                    <input
                      type="number"
                      min={0}
                      max={10000}
                      value={freeShippingThreshold}
                      onChange={(e) => setFreeShippingThreshold(e.target.value)}
                      className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#475569] dark:text-white/75 mb-1">Base Currency</label>
                    <select
                      value={defaultCurrency}
                      onChange={(e) => setDefaultCurrency(e.target.value as CurrencyCode)}
                      className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm font-mono"
                    >
                      <option value="USD">USD ($)</option>
                      <option value="INR">INR (₹)</option>
                      <option value="GBP">GBP (£)</option>
                      <option value="EUR">EUR (€)</option>
                      <option value="CNY">CNY (¥)</option>
                      <option value="JPY">JPY (¥)</option>
                      <option value="CAD">CAD (C$)</option>
                      <option value="AUD">AUD (A$)</option>
                      <option value="AED">AED (د.إ)</option>
                      <option value="SGD">SGD (S$)</option>
                      <option value="CHF">CHF (CHF)</option>
                      <option value="SAR">SAR (﷼)</option>
                      <option value="KRW">KRW (₩)</option>
                      <option value="BRL">BRL (R$)</option>
                      <option value="MXN">MXN (MX$)</option>
                      <option value="NZD">NZD (NZ$)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-[#475569] dark:text-white/75 mb-1">Flash Sale Discount %</label>
                    <input
                      type="number"
                      min={0}
                      max={80}
                      value={flashDiscount}
                      onChange={(e) => setFlashDiscount(e.target.value)}
                      className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#475569] dark:text-white/75 mb-1">Primary Accent Color</label>
                    <input
                      type="color"
                      value={accentColor}
                      onChange={(e) => setAccentColor(e.target.value)}
                      className="w-full h-10 border border-indigo-500/25 dark:border-cyan-400/25 cursor-pointer"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#475569] dark:text-white/75 mb-1">Concierge Support Email</label>
                  <input
                    type="email"
                    value={supportEmail}
                    onChange={(e) => setSupportEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm"
                  />
                </div>
              </div>

              {/* Right Column: 360° Global Lighting Control Panel, Animation Control Center & Automation */}
              <div className="lg:col-span-6 space-y-5">
                {/* 360° Global Lighting & Neon Illumination Control Panel (10 Live Controls) */}
                <div className="neon-card-orbit bg-white dark:bg-[#0D1120] border-t-4 border-t-[#22D3EE] border border-cyan-500/30 dark:border-cyan-400/30 p-6 space-y-4 shadow-sm">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h3 className="font-display text-2xl font-semibold gradient-heading flex items-center gap-2">
                      <Sun className="w-5 h-5 text-[#06B6D4] dark:text-[#22D3EE]" /> 360° Lighting & Neon Control Panel
                    </h3>
                    <span className="px-2.5 py-0.5 bg-gradient-to-r from-[#06B6D4] via-[#7C3AED] to-[#EC4899] text-white text-[10px] font-mono font-semibold uppercase">
                      Live 360° Engine
                    </span>
                  </div>

                  {/* 5 Interactive Light Color Palette Swatches */}
                  <div className="space-y-1.5">
                    <p className="text-[11px] font-semibold uppercase tracking-wider text-[#475569] dark:text-white/75">
                      Light Color Spectrum Preset
                    </p>
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                      {(
                        [
                          { id: 'rainbow', label: 'Rainbow Prism', grad: 'from-[#22D3EE] via-[#7C3AED] to-[#EC4899]' },
                          { id: 'cyber_cyan', label: 'Cyber Cyan', grad: 'from-[#2563EB] via-[#06B6D4] to-[#22D3EE]' },
                          { id: 'royal_magenta', label: 'Royal Magenta', grad: 'from-[#5B21B6] via-[#D946EF] to-[#EC4899]' },
                          { id: 'emerald_aqua', label: 'Emerald Aqua', grad: 'from-[#10B981] via-[#14B8A6] to-[#22D3EE]' },
                          { id: 'solar_gold', label: 'Solar Gold', grad: 'from-[#F59E0B] via-[#F97316] to-[#EC4899]' },
                        ] as const
                      ).map((presetItem) => (
                        <button
                          key={presetItem.id}
                          type="button"
                          onClick={() => {
                            setLightColorPreset(presetItem.id);
                            onPreviewSiteSettings?.({ lightColorPreset: presetItem.id });
                          }}
                          className={`p-2 text-left border transition-all ${
                            lightColorPreset === presetItem.id
                              ? 'border-[#2563EB] dark:border-[#22D3EE] ring-2 ring-[#22D3EE]/50 bg-indigo-50/70 dark:bg-white/10'
                              : 'border-indigo-500/20 dark:border-white/15 hover:border-[#22D3EE]/60'
                          }`}
                        >
                          <div className={`h-2.5 w-full bg-gradient-to-r ${presetItem.grad} mb-1.5`} />
                          <p className="text-[10px] font-semibold truncate">{presetItem.label}</p>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* 6 Lighting & Accessibility Switches */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs font-medium">
                    {[
                      {
                        label: 'Global 360° Lighting ON/OFF',
                        val: globalLightingEnabled,
                        onChange: (checked: boolean) => {
                          setGlobalLightingEnabled(checked);
                          onPreviewSiteSettings?.({ globalLightingEnabled: checked });
                        },
                      },
                      {
                        label: 'Circulating Neon Border Glow',
                        val: borderGlowEnabled,
                        onChange: (checked: boolean) => {
                          setBorderGlowEnabled(checked);
                          onPreviewSiteSettings?.({ borderGlowEnabled: checked });
                        },
                      },
                      {
                        label: 'Background Light Beams & Orbs',
                        val: backgroundLightEffects,
                        onChange: (checked: boolean) => {
                          setBackgroundLightEffects(checked);
                          onPreviewSiteSettings?.({ backgroundLightEffects: checked });
                        },
                      },
                      {
                        label: 'Desktop Mouse-Follow Spotlight',
                        val: mouseFollowLighting,
                        onChange: (checked: boolean) => {
                          setMouseFollowLighting(checked);
                          onPreviewSiteSettings?.({ mouseFollowLighting: checked });
                        },
                      },
                      {
                        label: 'Mobile Lighting Optimization',
                        val: mobileLightingOptimization,
                        onChange: (checked: boolean) => {
                          setMobileLightingOptimization(checked);
                          onPreviewSiteSettings?.({ mobileLightingOptimization: checked });
                        },
                      },
                      {
                        label: 'Reduced-Motion Safe Mode',
                        val: reducedMotionMode,
                        onChange: (checked: boolean) => {
                          setReducedMotionMode(checked);
                          onPreviewSiteSettings?.({ reducedMotionMode: checked });
                        },
                      },
                    ].map((sw) => (
                      <label
                        key={sw.label}
                        className="flex items-center gap-2.5 p-2.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-cyan-500/20 dark:border-cyan-400/25 cursor-pointer hover:border-[#22D3EE] transition-colors"
                      >
                        <input
                          type="checkbox"
                          checked={sw.val}
                          onChange={(e) => sw.onChange(e.target.checked)}
                          className="accent-[#06B6D4]"
                        />
                        <span>{sw.label}</span>
                      </label>
                    ))}
                  </div>

                  {/* 3 Precision Lighting Intensity & Speed Controls */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div>
                      <label className="block text-[11px] font-semibold text-[#475569] dark:text-white/75 mb-1">
                        Ambient Intensity
                      </label>
                      <select
                        value={ambientLightingIntensity}
                        onChange={(e) => {
                          const val = e.target.value as LightingIntensity;
                          setAmbientLightingIntensity(val);
                          onPreviewSiteSettings?.({ ambientLightingIntensity: val });
                        }}
                        className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-cyan-500/25 dark:border-cyan-400/25 text-xs"
                      >
                        <option value="subtle">Subtle (45%)</option>
                        <option value="balanced">Balanced (72%)</option>
                        <option value="cinematic">Cinematic (92%)</option>
                        <option value="ultra">Ultra Radiant (115%)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-[#475569] dark:text-white/75 mb-1">
                        Neon Glow Intensity
                      </label>
                      <select
                        value={neonGlowIntensity}
                        onChange={(e) => {
                          const val = e.target.value as NeonGlowLevel;
                          setNeonGlowIntensity(val);
                          onPreviewSiteSettings?.({ neonGlowIntensity: val });
                        }}
                        className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-cyan-500/25 dark:border-cyan-400/25 text-xs"
                      >
                        <option value="low">Low (Soft Edge)</option>
                        <option value="medium">Medium (Balanced Neon)</option>
                        <option value="high">High (Vivid Halo)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-[#475569] dark:text-white/75 mb-1">
                        Light Animation Speed
                      </label>
                      <select
                        value={lightAnimationSpeed}
                        onChange={(e) => {
                          const val = e.target.value as LightSpeed;
                          setLightAnimationSpeed(val);
                          onPreviewSiteSettings?.({ lightAnimationSpeed: val });
                        }}
                        className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-cyan-500/25 dark:border-cyan-400/25 text-xs"
                      >
                        <option value="slow">Slow & Hypnotic</option>
                        <option value="normal">Normal Cinematic</option>
                        <option value="dynamic">Dynamic Flow</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Animation Control Center (10 Live Controls) */}
                <div className="neon-card-orbit bg-white dark:bg-[#0D1120] border-t-4 border-t-[#D946EF] border border-fuchsia-500/25 dark:border-cyan-400/25 p-6 space-y-4 shadow-sm">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-display text-2xl font-semibold gradient-heading flex items-center gap-2">
                      <Sliders className="w-5 h-5 text-[#D946EF] dark:text-[#22D3EE]" /> Animation Control Center
                    </h3>
                    <span className="px-2.5 py-0.5 bg-gradient-to-r from-[#2563EB] to-[#06B6D4] text-white text-[10px] font-mono font-semibold uppercase">
                      60 FPS GPU Engine
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs font-medium">
                    {[
                      {
                        label: 'Enable Website Animations',
                        val: enableAnim,
                        set: (v: boolean) => {
                          setEnableAnim(v);
                          onPreviewSiteSettings?.({ enableAnimations: v });
                        },
                      },
                      {
                        label: 'Enable 3D Card Tilt & Depth',
                        val: enable3D,
                        set: (v: boolean) => {
                          setEnable3D(v);
                          onPreviewSiteSettings?.({ enable3DEffects: v });
                        },
                      },
                      {
                        label: 'Background Light Beams & Mesh',
                        val: backgroundEffects,
                        set: (v: boolean) => {
                          setBackgroundEffects(v);
                          onPreviewSiteSettings?.({ backgroundEffects: v });
                        },
                      },
                      {
                        label: 'Magnetic & Glow Hover Effects',
                        val: hoverEffects,
                        set: (v: boolean) => {
                          setHoverEffects(v);
                          onPreviewSiteSettings?.({ hoverEffects: v });
                        },
                      },
                      {
                        label: 'Mobile Animation Optimization',
                        val: mobileOptimization,
                        set: (v: boolean) => {
                          setMobileOptimization(v);
                          onPreviewSiteSettings?.({ mobileOptimization: v });
                        },
                      },
                      {
                        label: 'Reduced-Motion Accessibility',
                        val: reducedMotionMode,
                        set: (v: boolean) => {
                          setReducedMotionMode(v);
                          onPreviewSiteSettings?.({ reducedMotionMode: v });
                        },
                      },
                    ].map((sw) => (
                      <label
                        key={sw.label}
                        className="flex items-center gap-2.5 p-2.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/20 dark:border-cyan-400/20 cursor-pointer hover:border-[#D946EF]/50 transition-colors"
                      >
                        <input
                          type="checkbox"
                          checked={sw.val}
                          onChange={(e) => sw.set(e.target.checked)}
                          className="accent-[#7C3AED]"
                        />
                        <span>{sw.label}</span>
                      </label>
                    ))}
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="block text-[11px] font-semibold text-[#475569] dark:text-white/75 mb-1">
                        Animation Intensity
                      </label>
                      <select
                        value={animationIntensity}
                        onChange={(e) => setAnimationIntensity(e.target.value as AnimationIntensity)}
                        className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                      >
                        <option value="subtle">Subtle (Minimal Motion)</option>
                        <option value="balanced">Balanced (Studio Default)</option>
                        <option value="cinematic">Cinematic (Maximum Depth)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-[#475569] dark:text-white/75 mb-1">
                        Motion Speed
                      </label>
                      <select
                        value={motionSpeed}
                        onChange={(e) => setMotionSpeed(e.target.value as MotionSpeed)}
                        className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                      >
                        <option value="slow">Slow & Graceful (1.38x)</option>
                        <option value="normal">Normal (1.0x)</option>
                        <option value="snappy">Snappy & Crisp (0.72x)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-[#475569] dark:text-white/75 mb-1">
                        Particle Density
                      </label>
                      <select
                        value={particleDensity}
                        onChange={(e) => setParticleDensity(e.target.value as ParticleDensity)}
                        className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                      >
                        <option value="off">Off (0 Particles)</option>
                        <option value="low">Low (16 Lightweight)</option>
                        <option value="medium">Medium (34 Balanced)</option>
                        <option value="high">High (56 Constellation)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-[#475569] dark:text-white/75 mb-1">
                        Page & Modal Transition Style
                      </label>
                      <select
                        value={pageTransitionStyle}
                        onChange={(e) => setPageTransitionStyle(e.target.value as PageTransitionStyle)}
                        className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                      >
                        <option value="cinematic">Cinematic Depth + Scale</option>
                        <option value="slide">Vertical Slide Reveal</option>
                        <option value="scale">Precision Spring Scale</option>
                        <option value="fade">Minimal Crossfade</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="bg-white dark:bg-[#0D1120] border-t-4 border-t-[#10B981] border border-indigo-500/20 dark:border-cyan-400/20 p-6 space-y-4 shadow-sm">
                  <h3 className="font-display text-2xl font-semibold gradient-heading-emerald flex items-center gap-2">
                    <Zap className="w-5 h-5 text-[#10B981] dark:text-[#2DD4BF]" /> Platform Switches & Automation
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-medium">
                    {[
                      { label: 'Show Top Promo Strip', val: promoActive, set: setPromoActive },
                      { label: 'Enable Atelier Flash Sale', val: flashActive, set: setFlashActive },
                      { label: 'Auto-Route Dropship Orders', val: autoRouteDropship, set: setAutoRouteDropship },
                      { label: 'Auto-Dispatch Supplier POs', val: autoDispatchPo, set: setAutoDispatchPo },
                      { label: 'Low-Stock Reorder Alerts', val: lowStockAlertEnabled, set: setLowStockAlertEnabled },
                      { label: 'Enable Cash on Delivery (COD)', val: codEnabled, set: setCodEnabled },
                      { label: 'Email Order Notifications', val: emailNotificationsEnabled, set: setEmailNotificationsEnabled },
                      { label: 'WhatsApp B2B Dispatch Alerts', val: whatsappAlertsEnabled, set: setWhatsappAlertsEnabled },
                    ].map((sw) => (
                      <label
                        key={sw.label}
                        className="flex items-center gap-2.5 p-2.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/20 dark:border-cyan-400/20 hover:border-[#10B981]/50 cursor-pointer transition-colors"
                      >
                        <input
                          type="checkbox"
                          checked={sw.val}
                          onChange={(e) => sw.set(e.target.checked)}
                          className="accent-[#10B981]"
                        />
                        <span>{sw.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Automation Workflow Rules */}
                <div className="bg-white dark:bg-[#0D1120] border-t-4 border-t-[#F97316] border border-indigo-500/20 dark:border-cyan-400/20 p-6 space-y-4 shadow-sm">
                  <div className="flex items-center justify-between">
                    <h4 className="font-display text-xl font-semibold gradient-heading-warm">
                      Automation Workflow Rules ({automationRules.length}/20)
                    </h4>
                  </div>

                  <div className="space-y-2">
                    {automationRules.map((rule) => (
                      <div
                        key={rule.id}
                        className="p-3 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/20 dark:border-cyan-400/20 flex items-center justify-between gap-3 text-xs"
                      >
                        <div className="min-w-0">
                          <p className="font-semibold truncate">{rule.name}</p>
                          <p className="text-[#475569] dark:text-white/70 truncate">
                            If: {rule.trigger} → Then: {rule.action}
                          </p>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() =>
                              setAutomationRules((prev) =>
                                prev.map((r) => (r.id === rule.id ? { ...r, active: !r.active } : r)),
                              )
                            }
                            className={`px-2.5 py-1 text-[11px] font-semibold transition-all ${
                              rule.active
                                ? 'bg-gradient-to-r from-[#10B981] to-[#14B8A6] text-white'
                                : 'border border-indigo-500/25 dark:border-cyan-400/25 text-[#475569] dark:text-white/65'
                            }`}
                          >
                            {rule.active ? 'Active' : 'Paused'}
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setAutomationRules((prev) => prev.filter((r) => r.id !== rule.id))
                            }
                            aria-label={`Remove rule ${rule.name}`}
                            className="p-1 text-[#475569] dark:text-white/65 hover:text-rose-500"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="pt-2 border-t border-indigo-500/15 dark:border-cyan-400/15 space-y-2">
                    <p className="text-xs font-semibold uppercase tracking-wider text-[#F97316] dark:text-amber-300">
                      Add Automation Rule
                    </p>
                    <input
                      type="text"
                      placeholder="Rule Name (e.g. VIP Wholesale Priority)"
                      value={newRuleName}
                      onChange={(e) => setNewRuleName(e.target.value)}
                      className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                    />
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <input
                        type="text"
                        placeholder="Trigger event..."
                        value={newRuleTrigger}
                        onChange={(e) => setNewRuleTrigger(e.target.value)}
                        className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                      />
                      <input
                        type="text"
                        placeholder="Automated action..."
                        value={newRuleAction}
                        onChange={(e) => setNewRuleAction(e.target.value)}
                        className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        if (!newRuleName.trim() || automationRules.length >= 20) return;
                        setAutomationRules((prev) => [
                          ...prev,
                          {
                            id: `rule_${Date.now()}`,
                            name: newRuleName.trim(),
                            trigger: newRuleTrigger.trim() || 'Order event triggered',
                            action: newRuleAction.trim() || 'Execute workflow',
                            active: true,
                          },
                        ]);
                        setNewRuleName('');
                      }}
                      className="px-3.5 py-2 btn-prism-gold text-xs font-semibold flex items-center gap-1.5"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add Rule to List
                    </button>
                  </div>
                </div>

                {/* Save / Apply / Reset Footer Controls */}
                <div className="flex flex-wrap items-center gap-3">
                  <MagneticButton
                    type="submit"
                    className="flex-1 py-3 px-6 btn-futuristic text-xs font-semibold uppercase tracking-widest whitespace-nowrap"
                  >
                    Save All Settings & Animation Controls
                  </MagneticButton>
                  {onApplyTheme && (
                    <button
                      type="button"
                      onClick={() => {
                        onApplyTheme(defaultTheme);
                        setFeedback(`Applied ${defaultTheme} appearance mode immediately.`);
                      }}
                      className="px-4 py-3 btn-prism-cyan text-xs font-semibold uppercase tracking-wider whitespace-nowrap"
                    >
                      Apply Theme Now
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() =>
                      setConfirmState({
                        title: 'Reset All Settings to Defaults?',
                        message:
                          'This will restore default branding, animation controls, tax/shipping thresholds, feature switches, and automation rules.',
                        confirmLabel: 'Reset Defaults',
                        destructive: true,
                        onConfirm: resetSiteSettingsToDefaults,
                      })
                    }
                    className="px-4 py-3 border border-rose-500/45 text-rose-600 dark:text-rose-400 hover:bg-gradient-to-r hover:from-[#F43F5E] hover:to-[#F97316] hover:text-white text-xs font-semibold uppercase tracking-wider whitespace-nowrap transition-all"
                  >
                    Reset Defaults
                  </button>
                </div>
              </div>
            </form>
          )}
        </div>

      {aiCeoOpen && (
        <AiCeoModal
          products={products}
          orders={orders}
          suppliers={suppliers}
          purchaseOrders={purchaseOrders}
          wholesaleAccounts={wholesaleAccounts}
          aiTasks={aiTasks}
          adminEmail={adminEmail}
          onClose={() => setAiCeoOpen(false)}
        />
      )}

      <ConfirmDialog
        open={Boolean(confirmState)}
        title={confirmState?.title || ''}
        message={confirmState?.message || ''}
        confirmLabel={confirmState?.confirmLabel || 'Confirm'}
        destructive={confirmState?.destructive}
        onConfirm={async () => {
          const action = confirmState?.onConfirm;
          setConfirmState(null);
          if (action) await action();
        }}
        onCancel={() => setConfirmState(null)}
      />
    </CinematicModal>
  );
};
