import React, { useMemo, useState } from 'react';
import { CinematicModal } from './MotionPrimitives';
import {
  Bot,
  CheckCircle2,
  ClipboardCheck,
  Copy,
  Loader2,
  PlusCircle,
  ShieldCheck,
  Sparkles,
  X,
  XCircle,
} from 'lucide-react';
import { doc, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { AiTaskItem, Order, Product, PurchaseOrder, Supplier, WholesaleAccount } from '../types/store';

interface AiCeoModalProps {
  products: Product[];
  orders: Order[];
  suppliers: Supplier[];
  purchaseOrders: PurchaseOrder[];
  wholesaleAccounts: WholesaleAccount[];
  aiTasks?: AiTaskItem[];
  adminEmail?: string;
  onClose: () => void;
}

const AGENT_ROLES = [
  'AI CEO Supervisor',
  'Sales Agent',
  'Marketing Agent',
  'Customer Support Agent',
  'Supplier Agent',
  'Order Operations Agent',
  'Inventory Agent',
  'Finance Analyst Agent',
  'Product Research Agent',
  'Data Analytics Agent',
  'AI Fraud Detection Agent',
  'AI Business Strategy Agent',
] as const;

interface SuggestedTask {
  title: string;
  description: string;
  category: AiTaskItem['category'];
  impactSummary: string;
  requiresApproval: boolean;
}

export const AiCeoModal: React.FC<AiCeoModalProps> = ({
  products,
  orders,
  suppliers,
  purchaseOrders,
  wholesaleAccounts,
  aiTasks = [],
  adminEmail = 'admin@lumiereatelier.com',
  onClose,
}) => {
  const [view, setView] = useState<'briefing' | 'queue'>('briefing');
  const [agentRole, setAgentRole] = useState<string>('AI CEO Supervisor');
  const [question, setQuestion] = useState(
    'Deliver an executive daily briefing: compare online retail vs wholesale profitability, flag fraud/RTO anomalies, forecast 30-day stockout risks, and propose human-approval operational tasks.',
  );
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [taskNotice, setTaskNotice] = useState<string | null>(null);
  const [savingTaskIdx, setSavingTaskIdx] = useState<number | null>(null);
  const [result, setResult] = useState<{
    agentRole: string;
    summary: string;
    priorities: string[];
    riskAlerts: string[];
    draftMessage: string;
    suggestedTasks?: SuggestedTask[];
    advisoryDisclaimer: string;
  } | null>(null);

  const metricsSnapshot = useMemo(() => {
    const validOrders = orders.filter((o) => o.paymentStatus !== 'failed' && o.orderStatus !== 'cancelled');
    const totalRevenue = validOrders.reduce((s, o) => s + o.total, 0);
    const totalNetProfit = validOrders.reduce((s, o) => s + (o.netProfit ?? o.total * 0.45), 0);
    const wholesaleRevenue = validOrders
      .filter((o) => o.salesChannel === 'WHOLESALE_B2B')
      .reduce((s, o) => s + o.total, 0);
    const highRiskOrders = orders.filter((o) => (o.fraudScore ?? 0) >= 60).length;
    const lowStockSkus = products
      .filter((p) => p.stock <= (p.lowStockThreshold ?? 15))
      .map((p) => ({ sku: p.sku, name: p.name, stock: p.stock }));

    return {
      totalOrders: validOrders.length,
      totalRevenueUsd: Number(totalRevenue.toFixed(2)),
      estimatedNetProfitUsd: Number(totalNetProfit.toFixed(2)),
      wholesaleRevenueUsd: Number(wholesaleRevenue.toFixed(2)),
      highFraudRiskOrders: highRiskOrders,
      activeProductsCount: products.length,
      lowStockSkus,
      pendingPurchaseOrders: purchaseOrders.filter((po) => po.status === 'pending_dispatch' || po.status === 'sent').length,
      delayedPurchaseOrders: purchaseOrders.filter((po) => po.status === 'delayed').length,
      pendingWholesaleAccounts: wholesaleAccounts.filter((w) => w.status === 'pending').length,
      pendingApprovalAiTasks: aiTasks.filter((t) => t.status === 'pending_approval').length,
      supplierCount: suppliers.length,
    };
  }, [products, orders, suppliers, purchaseOrders, wholesaleAccounts, aiTasks]);

  const askAiCeo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;
    setLoading(true);
    setError(null);
    setTaskNotice(null);
    try {
      const res = await fetch('/api/ai/ceo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ agentRole, question, metricsSnapshot }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'AI CEO request failed.');
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to reach AI CEO service.');
    } finally {
      setLoading(false);
    }
  };

  const queueSuggestedTask = async (task: SuggestedTask, idx: number) => {
    setSavingTaskIdx(idx);
    const id = `aitask_${Date.now()}_${idx}`;
    try {
      await setDoc(doc(db, 'aiTasks', id), {
        id,
        agentRole: result?.agentRole || agentRole,
        title: task.title.slice(0, 180),
        description: task.description.slice(0, 1200),
        category: task.category,
        impactSummary: task.impactSummary.slice(0, 300),
        requiresApproval: true,
        status: 'pending_approval',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setTaskNotice(`Queued "${task.title}" into the Human Approval Queue.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not save AI task.');
    } finally {
      setSavingTaskIdx(null);
    }
  };

  const updateTaskStatus = async (task: AiTaskItem, nextStatus: AiTaskItem['status']) => {
    try {
      await updateDoc(doc(db, 'aiTasks', task.id), {
        status: nextStatus,
        approvedBy: adminEmail,
        updatedAt: serverTimestamp(),
      });
      setTaskNotice(`Task "${task.title}" marked as ${nextStatus.replace('_', ' ')}.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not update task status.');
    }
  };

  const pendingCount = aiTasks.filter((t) => t.status === 'pending_approval').length;

  return (
    <CinematicModal
      zIndexClass="z-[60]"
      backdropClassName="flex items-center justify-center p-2 sm:p-4"
      panelClassName="bg-[#F5F7FF] dark:bg-[#06070E] text-[#090B14] dark:text-[#F8FAFF] w-full max-w-5xl border border-violet-500/35 dark:border-fuchsia-400/30 shadow-2xl max-h-[92vh] flex flex-col overflow-hidden prism-modal-rim"
    >
      <div className="px-6 py-4 bg-gradient-to-r from-[#0B0820] via-[#2B1055] to-[#4A0D4E] text-white flex items-center justify-between gap-4 shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-to-br from-cyan-400/25 to-fuchsia-500/30 border border-cyan-300/40">
            <Bot className="w-5 h-5 text-cyan-300" />
          </div>
          <div>
            <p className="text-[11px] uppercase tracking-[0.22em] text-fuchsia-300 font-semibold">
              12-Agent Autonomous Executive Advisory &amp; Governance
            </p>
            <h2 className="font-display text-2xl font-semibold gradient-heading-hero">
              AI CEO &amp; Operations Command
            </h2>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setView('briefing')}
            className={`px-3 py-1.5 text-xs font-semibold transition-all ${
              view === 'briefing' ? 'btn-prism-cyan text-white' : 'bg-white/10 text-white/85 hover:bg-white/20'
            }`}
          >
            12-Agent Desk
          </button>
          <button
            type="button"
            onClick={() => setView('queue')}
            className={`px-3 py-1.5 text-xs font-semibold flex items-center gap-1.5 transition-all ${
              view === 'queue' ? 'btn-prism-sunset text-white' : 'bg-white/10 text-white/85 hover:bg-white/20'
            }`}
          >
            <ClipboardCheck className="w-3.5 h-3.5" /> Approval Queue ({pendingCount})
          </button>
          <button type="button" onClick={onClose} aria-label="Close AI CEO" className="p-2 hover:bg-white/10 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>
      <div className="prism-divider shrink-0" />

      <div className="flex-1 overflow-y-auto p-6 space-y-5">
        <div className="glow-border luminous-surface bg-gradient-to-r from-emerald-50 via-white to-cyan-50 dark:from-emerald-950/35 dark:via-[#0D1120] dark:to-cyan-950/35 border border-emerald-500/30 p-3 text-[11px] flex flex-wrap items-center justify-between gap-2 text-slate-700 dark:text-slate-200">
          <span className="flex items-center gap-1.5 font-semibold text-emerald-700 dark:text-emerald-300">
            <ShieldCheck className="w-3.5 h-3.5" /> Human-in-the-Loop Governance (Sensitive actions require Admin approval)
          </span>
          <span className="font-mono font-semibold text-indigo-700 dark:text-cyan-300 tabular-nums">
            {metricsSnapshot.totalOrders} Orders · ${metricsSnapshot.totalRevenueUsd} Rev · {metricsSnapshot.lowStockSkus.length} Low-Stock · {metricsSnapshot.highFraudRiskOrders} Fraud Flags
          </span>
        </div>

        {taskNotice && (
          <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-500/40 px-4 py-2.5 text-xs text-emerald-800 dark:text-emerald-200 flex justify-between items-center">
            <span>{taskNotice}</span>
            <button type="button" onClick={() => setTaskNotice(null)} className="font-semibold hover:underline">
              Dismiss
            </button>
          </div>
        )}
        {error && (
          <p className="text-xs text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/40 p-3 border border-rose-300 dark:border-rose-700/60">
            {error}
          </p>
        )}

        {view === 'briefing' && (
          <>
            <form onSubmit={askAiCeo} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-violet-700 dark:text-fuchsia-300 mb-1">
                    Select Specialist Agent (12 Active)
                  </label>
                  <select
                    value={agentRole}
                    onChange={(e) => setAgentRole(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-indigo-500/25 dark:border-cyan-400/25 bg-white dark:bg-[#141A30] text-[#090B14] dark:text-white"
                  >
                    {AGENT_ROLES.map((r) => (
                      <option key={r} value={r}>
                        {r}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="sm:col-span-2 flex items-end gap-2 flex-wrap">
                  {[
                    {
                      label: '30-Day Sales & Demand Forecast',
                      role: 'Data Analytics Agent',
                      color: 'border-emerald-500/40 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-500 hover:text-white',
                    },
                    {
                      label: 'Fraud & RTO Risk Audit',
                      role: 'AI Fraud Detection Agent',
                      color: 'border-rose-500/40 text-rose-700 dark:text-rose-300 hover:bg-rose-500 hover:text-white',
                    },
                    {
                      label: 'Q3 Margin & Growth Strategy',
                      role: 'AI Business Strategy Agent',
                      color: 'border-orange-500/40 text-orange-700 dark:text-amber-300 hover:bg-orange-500 hover:text-white',
                    },
                    {
                      label: 'Supplier Delay Follow-Up',
                      role: 'Supplier Agent',
                      color: 'border-cyan-500/40 text-blue-700 dark:text-cyan-300 hover:bg-cyan-500 hover:text-white',
                    },
                  ].map((preset) => (
                    <button
                      key={preset.label}
                      type="button"
                      onClick={() => {
                        setAgentRole(preset.role);
                        setQuestion(`Execute a thorough ${preset.label} grounded in current live ERP metrics and propose approval-gated tasks.`);
                      }}
                      className={`px-2.5 py-2 text-[11px] font-semibold border bg-white dark:bg-[#0D1120] transition-colors ${preset.color}`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>

              <textarea
                rows={3}
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Issue an executive command or ask any of the 12 specialist agents..."
                className="w-full p-3 text-xs border border-indigo-500/25 dark:border-cyan-400/25 bg-white dark:bg-[#141A30] text-[#090B14] dark:text-white"
              />

              <button
                type="submit"
                disabled={loading}
                className="px-6 py-2.5 btn-futuristic text-white text-xs font-semibold uppercase tracking-widest flex items-center gap-2 disabled:opacity-50"
              >
                {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                {loading ? 'Analyzing Live ERP Telemetry...' : `Run ${agentRole}`}
              </button>
            </form>

            {result && (
              <div className="neon-card-orbit luminous-surface bg-white dark:bg-[#0D1120] border border-violet-500/30 p-5 space-y-4 text-xs glow-border">
                <div className="border-b border-indigo-500/15 dark:border-cyan-400/15 pb-3">
                  <p className="text-[11px] uppercase tracking-wider text-fuchsia-600 dark:text-cyan-300 font-bold">
                    {result.agentRole} Briefing
                  </p>
                  <p className="text-sm leading-relaxed mt-1 text-[#090B14] dark:text-slate-100">{result.summary}</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-emerald-50/70 dark:bg-emerald-950/25 border border-emerald-500/25">
                    <p className="font-bold uppercase tracking-wider text-[11px] text-emerald-700 dark:text-emerald-300 mb-2">
                      Recommended Priorities
                    </p>
                    <ul className="space-y-1.5 list-disc pl-4 text-slate-700 dark:text-slate-200">
                      {result.priorities.map((p, i) => (
                        <li key={i}>{p}</li>
                      ))}
                    </ul>
                  </div>
                  <div className="p-4 bg-amber-50/70 dark:bg-amber-950/25 border border-amber-500/30">
                    <p className="font-bold uppercase tracking-wider text-[11px] text-orange-700 dark:text-amber-300 mb-2">
                      Risk Alerts
                    </p>
                    <ul className="space-y-1.5 list-disc pl-4 text-slate-700 dark:text-slate-200">
                      {result.riskAlerts.map((r, i) => (
                        <li key={i}>{r}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                {result.suggestedTasks && result.suggestedTasks.length > 0 && (
                  <div className="space-y-2.5">
                    <p className="font-bold uppercase tracking-wider text-[11px] text-cyan-700 dark:text-cyan-300">
                      Proposed Operational Tasks (Send to Human Approval Queue)
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {result.suggestedTasks.map((t, idx) => (
                        <div key={idx} className="p-3.5 bg-[#F5F7FF] dark:bg-[#141A30] border border-cyan-500/25 space-y-1.5">
                          <div className="flex items-start justify-between gap-2">
                            <p className="font-semibold text-[#090B14] dark:text-white">{t.title}</p>
                            <span className="px-2 py-0.5 text-[10px] uppercase font-bold bg-violet-500/15 text-violet-700 dark:text-fuchsia-300">
                              {t.category}
                            </span>
                          </div>
                          <p className="text-slate-600 dark:text-slate-300 leading-relaxed">{t.description}</p>
                          <p className="text-[11px] font-medium text-emerald-700 dark:text-emerald-300">
                            Impact: {t.impactSummary}
                          </p>
                          <button
                            type="button"
                            disabled={savingTaskIdx === idx}
                            onClick={() => void queueSuggestedTask(t, idx)}
                            className="mt-1 px-3 py-1.5 btn-prism-cyan text-white text-[11px] font-semibold flex items-center gap-1.5 disabled:opacity-50"
                          >
                            <PlusCircle className="w-3.5 h-3.5" />
                            {savingTaskIdx === idx ? 'Queueing…' : 'Queue for Admin Approval'}
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {result.draftMessage && (
                  <div className="bg-gradient-to-br from-violet-50/80 via-[#F5F7FF] to-cyan-50/70 dark:from-violet-950/30 dark:via-[#141A30] dark:to-cyan-950/25 border border-violet-500/25 p-4 space-y-2">
                    <div className="flex justify-between items-center">
                      <p className="font-bold uppercase tracking-wider text-[11px] text-violet-700 dark:text-fuchsia-300">
                        Ready-to-Send Draft Message
                      </p>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard?.writeText(result.draftMessage);
                          setCopied(true);
                          setTimeout(() => setCopied(false), 1800);
                        }}
                        className="flex items-center gap-1 text-[11px] font-semibold text-blue-600 dark:text-cyan-300 hover:underline"
                      >
                        <Copy className="w-3 h-3" /> {copied ? 'Copied' : 'Copy Draft'}
                      </button>
                    </div>
                    <p className="whitespace-pre-wrap leading-relaxed text-slate-700 dark:text-slate-200">
                      {result.draftMessage}
                    </p>
                  </div>
                )}

                <p className="text-[11px] text-slate-500 dark:text-slate-400 italic">{result.advisoryDisclaimer}</p>
              </div>
            )}
          </>
        )}

        {view === 'queue' && (
          <div className="space-y-3">
            <h3 className="font-display text-xl font-semibold gradient-heading">
              Human-Approval AI Task Queue ({aiTasks.length})
            </h3>
            {aiTasks.length === 0 ? (
              <div className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 p-6 text-xs text-slate-600 dark:text-slate-300">
                No AI-proposed tasks queued yet. Run any of the 12 agents to generate actionable approval-gated proposals.
              </div>
            ) : (
              <div className="space-y-3">
                {aiTasks.map((task) => (
                  <div
                    key={task.id}
                    className="bg-white dark:bg-[#0D1120] border border-indigo-500/25 dark:border-cyan-400/20 p-4 space-y-2 text-xs glow-border"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <p className="text-[10px] uppercase tracking-wider font-bold text-cyan-600 dark:text-cyan-300">
                          {task.agentRole} · {task.category}
                        </p>
                        <h4 className="font-semibold text-sm text-[#090B14] dark:text-white">{task.title}</h4>
                      </div>
                      <span
                        className={`px-2.5 py-0.5 text-[10px] font-bold uppercase ${
                          task.status === 'approved' || task.status === 'executed'
                            ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                            : task.status === 'rejected'
                              ? 'bg-rose-500/15 text-rose-700 dark:text-rose-300'
                              : 'bg-amber-500/15 text-amber-700 dark:text-amber-300'
                        }`}
                      >
                        {task.status.replace('_', ' ')}
                      </span>
                    </div>
                    <p className="text-slate-600 dark:text-slate-300 leading-relaxed">{task.description}</p>
                    <p className="text-[11px] font-semibold text-emerald-700 dark:text-emerald-300">
                      Expected Impact: {task.impactSummary}
                    </p>
                    <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-indigo-500/15">
                      {task.status === 'pending_approval' && (
                        <>
                          <button
                            type="button"
                            onClick={() => void updateTaskStatus(task, 'approved')}
                            className="px-3 py-1.5 btn-prism-emerald text-white font-semibold flex items-center gap-1"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" /> Approve
                          </button>
                          <button
                            type="button"
                            onClick={() => void updateTaskStatus(task, 'rejected')}
                            className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold flex items-center gap-1"
                          >
                            <XCircle className="w-3.5 h-3.5" /> Reject
                          </button>
                        </>
                      )}
                      {task.status === 'approved' && (
                        <button
                          type="button"
                          onClick={() => void updateTaskStatus(task, 'executed')}
                          className="px-3 py-1.5 btn-prism-cyan text-white font-semibold flex items-center gap-1"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" /> Mark Executed
                        </button>
                      )}
                      {task.approvedBy && (
                        <span className="text-[11px] text-slate-500 dark:text-slate-400">
                          Reviewed by {task.approvedBy}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </CinematicModal>
  );
};
