import React, { useState } from 'react';
import { AnimatedOrderTimeline, CinematicModal } from './MotionPrimitives';
import {
  Bell,
  Check,
  Copy,
  CreditCard,
  Gift,
  Heart,
  KeyRound,
  LogOut,
  MapPin,
  MessageSquare,
  Package,
  Printer,
  Repeat,
  RotateCcw,
  Share2,
  Trash2,
  User,
  X,
} from 'lucide-react';
import {
  deleteDoc,
  doc,
  serverTimestamp,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import { sendPasswordResetEmail } from 'firebase/auth';
import { auth, db, handleFirestoreError, OperationType } from '../lib/firebase';
import {
  CurrencyCode,
  formatMoney,
  GiftCard,
  NotificationItem,
  Order,
  Product,
  ProductShade,
  ReferralRecord,
  SavedAddress,
  SubscriptionPlan,
  SupportTicket,
  Transaction,
  UserPrivateInfo,
  UserProfile,
  WishlistItem,
} from '../types/store';
import { ConfirmDialog } from './ConfirmDialog';

interface CustomerDashboardProps {
  userUid: string;
  userEmail: string;
  profile: UserProfile | null;
  privateInfo: UserPrivateInfo | null;
  orders: Order[];
  transactions: Transaction[];
  wishlist: WishlistItem[];
  notifications: NotificationItem[];
  tickets: SupportTicket[];
  products: Product[];
  subscriptions?: SubscriptionPlan[];
  referrals?: ReferralRecord[];
  giftCards?: GiftCard[];
  currency: CurrencyCode;
  isAdmin: boolean;
  onOpenAdmin: () => void;
  onOpenSupport: () => void;
  onSignOut: () => void;
  onAddToBag: (product: Product, shade: ProductShade) => void;
  onClose: () => void;
}

const ORDER_STEPS = ['processing', 'confirmed', 'packed', 'shipped', 'out_for_delivery', 'delivered'] as const;

export const CustomerDashboard: React.FC<CustomerDashboardProps> = ({
  userUid,
  userEmail,
  profile,
  privateInfo,
  orders,
  transactions,
  wishlist,
  notifications,
  tickets,
  products,
  subscriptions = [],
  referrals = [],
  giftCards = [],
  currency,
  isAdmin,
  onOpenAdmin,
  onOpenSupport,
  onSignOut,
  onAddToBag,
  onClose,
}) => {
  const [tab, setTab] = useState<
    'orders' | 'subscriptions' | 'rewards' | 'profile' | 'addresses' | 'wishlist' | 'payments' | 'notifications' | 'tickets'
  >('orders');
  const [refereeEmail, setRefereeEmail] = useState('');
  const [copiedRef, setCopiedRef] = useState(false);
  const [displayName, setDisplayName] = useState(profile?.displayName || '');
  const [skinTone, setSkinTone] = useState(profile?.skinTone || 'Medium');
  const [undertone, setUndertone] = useState(profile?.undertone || 'Warm');
  const [phone, setPhone] = useState(privateInfo?.phone || '');
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [returnOrderId, setReturnOrderId] = useState<string | null>(null);
  const [returnReason, setReturnReason] = useState('');
  const [invoiceOrder, setInvoiceOrder] = useState<Order | null>(null);
  const [confirmState, setConfirmState] = useState<{
    title: string;
    message: string;
    confirmLabel: string;
    onConfirm: () => Promise<void> | void;
  } | null>(null);

  const referralCode = `LUMIERE-${userUid.slice(0, 6).toUpperCase()}`;
  const totalClv = orders
    .filter((o) => o.paymentStatus !== 'failed' && o.orderStatus !== 'cancelled')
    .reduce((s, o) => s + o.total, 0);
  const loyaltyPts = profile?.loyaltyPoints ?? 120;
  const loyaltyTier = loyaltyPts >= 1500 ? 'Obsidian Noir VIP' : loyaltyPts >= 500 ? 'Rose Gold Atelier' : 'Signature Collector';

  const updateSubscriptionStatus = async (sub: SubscriptionPlan, nextStatus: SubscriptionPlan['status']) => {
    try {
      await updateDoc(doc(db, 'subscriptions', sub.id), {
        status: nextStatus,
        updatedAt: serverTimestamp(),
      });
      setStatusMsg(`Subscription for ${sub.productName} updated to ${nextStatus}.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `subscriptions/${sub.id}`);
    }
  };

  const submitReferralInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!refereeEmail.trim() || !refereeEmail.includes('@')) return;
    const refId = `ref_${Date.now()}`;
    try {
      await setDoc(doc(db, 'referrals', refId), {
        id: refId,
        referrerUid: userUid,
        referralCode,
        refereeEmail: refereeEmail.trim(),
        rewardPoints: 250,
        status: 'pending',
        createdAt: serverTimestamp(),
      });
      setRefereeEmail('');
      setStatusMsg(`Referral invitation logged! You earn +250 loyalty points once your friend completes their first order.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `referrals/${refId}`);
    }
  };

  const [newAddr, setNewAddr] = useState<SavedAddress>({
    id: '',
    label: 'Home',
    fullName: profile?.displayName || '',
    phone: privateInfo?.phone || '',
    line1: '',
    city: '',
    state: '',
    postalCode: '',
    country: 'India',
    isDefault: true,
  });

  const addresses = privateInfo?.addresses || [];

  const saveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMsg(null);
    try {
      await setDoc(
        doc(db, 'users', userUid),
        {
          uid: userUid,
          displayName: displayName.trim() || 'Atelier Member',
          skinTone,
          undertone,
          loyaltyPoints: profile?.loyaltyPoints ?? 120,
          createdAt: profile?.createdAt || serverTimestamp(),
          updatedAt: serverTimestamp(),
        },
        { merge: true },
      );

      await setDoc(
        doc(db, 'users', userUid, 'private', 'info'),
        {
          uid: userUid,
          email: userEmail,
          phone: phone.trim(),
          addresses,
          updatedAt: serverTimestamp(),
        },
        { merge: true },
      );
      setStatusMsg('Profile and Skin ID saved.');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${userUid}`);
    }
  };

  const addAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAddr.line1 || !newAddr.city || !newAddr.postalCode) return;
    const entry: SavedAddress = { ...newAddr, id: `addr_${Date.now()}` };
    const updated = newAddr.isDefault
      ? [...addresses.map((a) => ({ ...a, isDefault: false })), entry]
      : [...addresses, entry];
    try {
      await setDoc(
        doc(db, 'users', userUid, 'private', 'info'),
        {
          uid: userUid,
          email: userEmail,
          phone: phone || privateInfo?.phone || '',
          addresses: updated,
          updatedAt: serverTimestamp(),
        },
        { merge: true },
      );
      setNewAddr({ ...newAddr, line1: '', city: '', state: '', postalCode: '' });
      setStatusMsg('Address added.');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${userUid}/private/info`);
    }
  };

  const deleteAddress = async (addrId: string) => {
    const updated = addresses.filter((a) => a.id !== addrId);
    try {
      await updateDoc(doc(db, 'users', userUid, 'private', 'info'), {
        addresses: updated,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${userUid}/private/info`);
    }
  };

  const retryPayment = async (order: Order) => {
    try {
      const res = await fetch('/api/payments/retry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId: order.id,
          gateway: order.paymentGateway,
          method: order.paymentMethod,
          amount: order.total,
          currency: order.currency,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.verified) throw new Error(data.error || 'Retry failed');

      await updateDoc(doc(db, 'orders', order.id), {
        paymentStatus: 'paid',
        orderStatus: 'confirmed',
        updatedAt: serverTimestamp(),
      });

      const txId = `tx_retry_${Date.now()}`;
      await setDoc(doc(db, 'transactions', txId), {
        id: txId,
        orderId: order.id,
        userId: userUid,
        gateway: order.paymentGateway,
        method: order.paymentMethod,
        amount: order.total,
        currency: order.currency,
        status: 'succeeded',
        gatewayOrderId: data.gatewayOrderId,
        gatewayPaymentId: data.gatewayPaymentId,
        signatureVerified: true,
        webhookReceived: true,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setStatusMsg(`Payment retry succeeded for Order #${order.id}.`);
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Retry failed.');
    }
  };

  const requestReturn = async (order: Order) => {
    if (!returnReason.trim()) return;
    try {
      await updateDoc(doc(db, 'orders', order.id), {
        orderStatus: 'return_requested',
        refundStatus: 'requested',
        returnReason: returnReason.trim().slice(0, 500),
        updatedAt: serverTimestamp(),
      });
      setReturnOrderId(null);
      setReturnReason('');
      setStatusMsg(`Return requested for Order #${order.id}.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${order.id}`);
    }
  };

  const cancelOrder = async (order: Order) => {
    try {
      await updateDoc(doc(db, 'orders', order.id), {
        orderStatus: 'cancelled',
        updatedAt: serverTimestamp(),
      });
      setStatusMsg(`Order #${order.id} cancelled.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${order.id}`);
    }
  };

  const markNotificationRead = async (notifId: string) => {
    try {
      await updateDoc(doc(db, 'users', userUid, 'notifications', notifId), {
        read: true,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${userUid}/notifications/${notifId}`);
    }
  };

  const markAllNotificationsRead = async () => {
    const unread = notifications.filter((n) => !n.read);
    if (unread.length === 0) return;
    try {
      await Promise.all(
        unread.map((n) =>
          updateDoc(doc(db, 'users', userUid, 'notifications', n.id), {
            read: true,
          }),
        ),
      );
      setStatusMsg(`Marked ${unread.length} notifications as read.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${userUid}/notifications`);
    }
  };

  const removeWishlist = async (productId: string) => {
    try {
      await deleteDoc(doc(db, 'users', userUid, 'wishlist', productId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `users/${userUid}/wishlist/${productId}`);
    }
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <CinematicModal
      backdropClassName="flex items-center justify-center p-2 sm:p-6"
      panelClassName="bg-[#F5F7FF] dark:bg-[#06070E] text-[#090B14] dark:text-[#F8FAFF] w-full max-w-6xl border border-indigo-500/25 dark:border-cyan-400/25 shadow-2xl max-h-[94vh] flex flex-col overflow-hidden prism-modal-rim"
    >
        <div className="flex flex-wrap items-center justify-between gap-4 px-6 py-4 bg-gradient-to-r from-[#090B1A] via-[#1B1344] to-[#0D2A4A] text-white">
          <div>
            <p className="text-[11px] uppercase tracking-[0.22em] text-cyan-300 font-semibold">
              Client Atelier · {profile?.loyaltyPoints ?? 120} Loyalty Pts
            </p>
            <h2 className="font-display text-2xl font-semibold gradient-heading-hero">
              {profile?.displayName || userEmail}
            </h2>
          </div>

          <div className="flex items-center gap-3">
            {isAdmin && (
              <button
                type="button"
                onClick={onOpenAdmin}
                className="px-4 py-2 btn-futuristic text-xs font-semibold uppercase tracking-wider whitespace-nowrap"
              >
                Admin ERP Console
              </button>
            )}
            <button
              type="button"
              onClick={onSignOut}
              className="px-3.5 py-2 border border-white/25 bg-white/10 text-white text-xs font-medium flex items-center gap-1.5 hover:bg-rose-500/30 hover:border-rose-400/60 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" /> Sign Out
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close Dashboard"
              className="p-2 hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
        <div className="prism-divider shrink-0" />

        {/* Navigation Tabs */}
        <div className="px-6 py-2.5 bg-white dark:bg-[#0D1120] border-b border-indigo-500/15 dark:border-cyan-400/15 flex items-center gap-1.5 overflow-x-auto">
          {(
            [
              { id: 'orders', label: `Orders & Tracking (${orders.length})`, icon: Package, active: 'btn-prism-cyan' },
              { id: 'subscriptions', label: `Auto-Replenish (${subscriptions.length})`, icon: Repeat, active: 'btn-futuristic' },
              { id: 'rewards', label: 'Loyalty, Gift Cards & Referrals', icon: Gift, active: 'btn-prism-gold' },
              { id: 'profile', label: 'Profile & Security', icon: User, active: 'btn-futuristic' },
              { id: 'addresses', label: `Addresses (${addresses.length})`, icon: MapPin, active: 'btn-prism-emerald' },
              { id: 'wishlist', label: `Wishlist (${wishlist.length})`, icon: Heart, active: 'btn-prism-sunset' },
              { id: 'payments', label: `Payments (${transactions.length})`, icon: CreditCard, active: 'btn-prism-gold' },
              { id: 'tickets', label: `Support (${tickets.length})`, icon: MessageSquare, active: 'btn-futuristic' },
              { id: 'notifications', label: `Alerts (${unreadCount})`, icon: Bell, active: 'btn-prism-sunset' },
            ] as const
          ).map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id)}
                className={`px-3.5 py-2 text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-all ${
                  tab === t.id
                    ? `${t.active} text-white`
                    : 'text-slate-600 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-cyan-300 hover:bg-indigo-500/10'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {t.label}
              </button>
            );
          })}
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {statusMsg && (
            <div className="bg-gradient-to-r from-cyan-50 via-white to-violet-50 dark:from-cyan-950/40 dark:via-[#0D1120] dark:to-violet-950/40 border border-cyan-500/40 px-4 py-2.5 text-xs font-medium flex items-center justify-between">
              <span className="text-slate-800 dark:text-cyan-100">{statusMsg}</span>
              <button
                type="button"
                onClick={() => setStatusMsg(null)}
                className="text-indigo-600 dark:text-cyan-300 font-semibold hover:underline"
              >
                Dismiss
              </button>
            </div>
          )}

          {tab === 'orders' && (
            <div className="space-y-4">
              {orders.length === 0 ? (
                <div className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-10 text-center text-sm text-slate-600 dark:text-slate-300">
                  No orders yet. Your atelier acquisitions and live shipment tracking will appear here.
                </div>
              ) : (
                orders.map((order) => {
                  const activeStepIdx = ORDER_STEPS.indexOf(order.orderStatus as typeof ORDER_STEPS[number]);
                  return (
                    <div
                      key={order.id}
                      className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-5 space-y-4 glow-border"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-indigo-500/15 dark:border-cyan-400/15 pb-3">
                        <div className="text-xs text-slate-600 dark:text-slate-300 flex flex-wrap items-center gap-2">
                          <span className="font-mono font-bold text-blue-600 dark:text-cyan-300">#{order.id}</span>
                          <span aria-hidden="true">·</span>
                          <span>{order.paymentGateway} ({order.paymentMethod})</span>
                          <span aria-hidden="true">·</span>
                          <span className="capitalize font-semibold text-emerald-600 dark:text-emerald-400">
                            Payment: {order.paymentStatus.replace('_', ' ')}
                          </span>
                          {order.trackingNumber && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="font-mono text-violet-600 dark:text-fuchsia-300">Tracking: {order.trackingNumber}</span>
                            </>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-sm text-emerald-600 dark:text-emerald-400 tabular-nums">
                            {formatMoney(order.total, currency)}
                          </span>
                          <button
                            type="button"
                            onClick={() => setInvoiceOrder(order)}
                            className="px-2.5 py-1 btn-prism-outline text-xs font-medium flex items-center gap-1"
                          >
                            <Printer className="w-3 h-3" /> Invoice
                          </button>
                        </div>
                      </div>

                      {/* Animated Live Tracking Timeline */}
                      {activeStepIdx >= 0 ? (
                        <AnimatedOrderTimeline currentStatus={order.orderStatus} />
                      ) : (
                        <AnimatedOrderTimeline currentStatus={order.orderStatus} />
                      )}

                      <div className="space-y-1.5 text-sm">
                        {order.items.map((item, i) => (
                          <div key={i} className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span
                                className="w-3 h-3 rounded-full border border-indigo-500/30 dark:border-white/30"
                                style={{ backgroundColor: item.shadeHex }}
                              />
                              <span>
                                {item.name} ({item.shadeName}) × {item.quantity}
                              </span>
                            </div>
                            <span className="font-mono text-xs tabular-nums">
                              {formatMoney(item.unitPrice * item.quantity, currency)}
                            </span>
                          </div>
                        ))}
                      </div>

                      <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-indigo-500/15 dark:border-cyan-400/15">
                        {order.paymentStatus === 'failed' && (
                          <button
                            type="button"
                            onClick={() => retryPayment(order)}
                            className="px-3.5 py-1.5 btn-prism-sunset text-xs font-semibold flex items-center gap-1.5"
                          >
                            <RotateCcw className="w-3.5 h-3.5" /> Retry Failed Payment
                          </button>
                        )}
                        {order.orderStatus === 'processing' && (
                          <button
                            type="button"
                            onClick={() =>
                              setConfirmState({
                                title: `Cancel Order #${order.id}?`,
                                message:
                                  'This will cancel your processing order immediately. Any authorized payment will be released or eligible for refund.',
                                confirmLabel: 'Cancel Order',
                                onConfirm: () => cancelOrder(order),
                              })
                            }
                            className="px-3.5 py-1.5 border border-rose-500/40 text-rose-600 dark:text-rose-400 text-xs font-semibold hover:bg-rose-500 hover:text-white transition-colors"
                          >
                            Cancel Order
                          </button>
                        )}
                        {order.orderStatus === 'delivered' && (
                          <button
                            type="button"
                            onClick={() => setReturnOrderId(order.id)}
                            className="px-3.5 py-1.5 btn-prism-outline text-xs font-semibold"
                          >
                            Request Return / Refund
                          </button>
                        )}
                        {order.refundStatus && order.refundStatus !== 'none' && (
                          <span className="text-xs text-violet-600 dark:text-fuchsia-300 font-semibold capitalize">
                            Refund Status: {order.refundStatus}
                            {order.refundAmount ? ` (${formatMoney(order.refundAmount, currency)})` : ''}
                          </span>
                        )}
                      </div>

                      {returnOrderId === order.id && (
                        <div className="bg-[#F5F7FF] dark:bg-[#141A30] p-3 border border-indigo-500/20 dark:border-cyan-400/20 flex flex-col sm:flex-row gap-2">
                          <input
                            type="text"
                            placeholder="Reason for return or shade exchange..."
                            value={returnReason}
                            onChange={(e) => setReturnReason(e.target.value)}
                            className="flex-1 px-3 py-1.5 bg-white dark:bg-[#0D1120] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                          />
                          <button
                            type="button"
                            onClick={() => requestReturn(order)}
                            className="px-4 py-1.5 btn-futuristic text-xs font-semibold"
                          >
                            Submit Return
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setReturnOrderId(null);
                              setReturnReason('');
                            }}
                            className="px-3 py-1.5 btn-prism-outline text-xs"
                          >
                            Cancel
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          )}

          {tab === 'profile' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <form onSubmit={saveProfile} className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-6 space-y-4 glow-border">
                <h3 className="font-display text-xl font-semibold gradient-heading">Profile &amp; Complexion ID</h3>
                <div>
                  <label className="block text-xs font-semibold text-indigo-700 dark:text-cyan-300 mb-1">Display Name</label>
                  <input
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-indigo-700 dark:text-cyan-300 mb-1">Email</label>
                  <input
                    type="email"
                    disabled
                    value={userEmail}
                    className="w-full px-3 py-2 bg-indigo-500/5 dark:bg-white/5 border border-indigo-500/15 dark:border-white/10 text-sm text-slate-500 dark:text-slate-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-indigo-700 dark:text-cyan-300 mb-1">Phone Number</label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-indigo-700 dark:text-cyan-300 mb-1">Skin Depth</label>
                    <select
                      value={skinTone}
                      onChange={(e) => setSkinTone(e.target.value)}
                      className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                    >
                      {['Fair', 'Light', 'Medium', 'Tan', 'Rich', 'Deep'].map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-indigo-700 dark:text-cyan-300 mb-1">Undertone</label>
                    <select
                      value={undertone}
                      onChange={(e) => setUndertone(e.target.value)}
                      className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                    >
                      {['Warm', 'Cool', 'Neutral', 'Olive'].map((u) => (
                        <option key={u} value={u}>
                          {u}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <button
                  type="submit"
                  className="px-5 py-2.5 btn-futuristic text-xs font-semibold uppercase tracking-wider"
                >
                  Save Profile
                </button>
              </form>

              <div className="bg-gradient-to-br from-violet-50 via-white to-amber-50/70 dark:from-violet-950/35 dark:via-[#0D1120] dark:to-amber-950/25 border border-violet-500/30 p-6 space-y-4 h-fit glow-border">
                <h3 className="font-display text-xl font-semibold flex items-center gap-2 gradient-heading-warm">
                  <KeyRound className="w-4 h-4 text-amber-500 dark:text-amber-300" /> Security &amp; Loyalty
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  Atelier Loyalty Balance:{' '}
                  <span className="font-mono font-bold text-base text-amber-600 dark:text-amber-300">
                    {profile?.loyaltyPoints ?? 120} pts
                  </span>
                </p>
                <div className="flex flex-wrap gap-2 pt-2">
                  <button
                    type="button"
                    onClick={async () => {
                      try {
                        await sendPasswordResetEmail(auth, userEmail);
                        setStatusMsg(`Password reset email dispatched to ${userEmail}.`);
                      } catch (err) {
                        setStatusMsg(err instanceof Error ? err.message : 'Unable to send reset email.');
                      }
                    }}
                    className="px-4 py-2 btn-prism-outline text-xs font-semibold"
                  >
                    Send Password Reset Email
                  </button>
                </div>
              </div>
            </div>
          )}

          {tab === 'addresses' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-6 space-y-3">
                {addresses.length === 0 && (
                  <div className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-6 text-sm text-slate-600 dark:text-slate-300">
                    No saved addresses yet. Add a shipping destination on the right.
                  </div>
                )}
                {addresses.map((addr) => (
                  <div
                    key={addr.id}
                    className="bg-white dark:bg-[#0D1120] border border-emerald-500/25 p-4 flex justify-between items-start gap-4 glow-border"
                  >
                    <div className="text-sm space-y-0.5">
                      <p className="font-semibold">
                        {addr.label}{' '}
                        {addr.isDefault && (
                          <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">· Default</span>
                        )}
                      </p>
                      <p>{addr.fullName}</p>
                      <p className="text-xs text-slate-600 dark:text-slate-300">
                        {addr.line1}, {addr.city}, {addr.state} {addr.postalCode}, {addr.country}
                      </p>
                      <p className="text-xs font-mono text-indigo-600 dark:text-cyan-300">{addr.phone}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        setConfirmState({
                          title: `Delete "${addr.label}" Address?`,
                          message: 'This address will be permanently removed from your saved shipping destinations.',
                          confirmLabel: 'Delete Address',
                          onConfirm: () => deleteAddress(addr.id),
                        })
                      }
                      aria-label="Delete address"
                      className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-rose-600 dark:hover:text-rose-400"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
              <form
                onSubmit={addAddress}
                className="lg:col-span-6 bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-5 space-y-3 h-fit glow-border"
              >
                <h3 className="font-display text-xl font-semibold gradient-heading-emerald">Add Shipping Address</h3>
                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="text"
                    required
                    placeholder="Label (Home, Studio)"
                    value={newAddr.label}
                    onChange={(e) => setNewAddr({ ...newAddr, label: e.target.value })}
                    className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                  />
                  <input
                    type="text"
                    required
                    placeholder="Recipient Name"
                    value={newAddr.fullName}
                    onChange={(e) => setNewAddr({ ...newAddr, fullName: e.target.value })}
                    className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                  />
                  <input
                    type="tel"
                    required
                    placeholder="Phone"
                    value={newAddr.phone}
                    onChange={(e) => setNewAddr({ ...newAddr, phone: e.target.value })}
                    className="col-span-2 px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                  />
                  <input
                    type="text"
                    required
                    placeholder="Street Address"
                    value={newAddr.line1}
                    onChange={(e) => setNewAddr({ ...newAddr, line1: e.target.value })}
                    className="col-span-2 px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                  />
                  <input
                    type="text"
                    required
                    placeholder="City"
                    value={newAddr.city}
                    onChange={(e) => setNewAddr({ ...newAddr, city: e.target.value })}
                    className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                  />
                  <input
                    type="text"
                    required
                    placeholder="State"
                    value={newAddr.state}
                    onChange={(e) => setNewAddr({ ...newAddr, state: e.target.value })}
                    className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                  />
                  <input
                    type="text"
                    required
                    placeholder="Postal Code"
                    value={newAddr.postalCode}
                    onChange={(e) => setNewAddr({ ...newAddr, postalCode: e.target.value })}
                    className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                  />
                  <input
                    type="text"
                    required
                    placeholder="Country"
                    value={newAddr.country}
                    onChange={(e) => setNewAddr({ ...newAddr, country: e.target.value })}
                    className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                  />
                </div>
                <button
                  type="submit"
                  className="px-5 py-2.5 btn-prism-emerald text-xs font-semibold uppercase tracking-wider"
                >
                  Save Address
                </button>
              </form>
            </div>
          )}

          {tab === 'wishlist' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {wishlist.length === 0 ? (
                <p className="text-sm text-slate-600 dark:text-slate-300 bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-6 col-span-full">
                  Your wishlist is empty.
                </p>
              ) : (
                wishlist.map((w) => {
                  const prod = products.find((p) => p.id === w.productId);
                  if (!prod) return null;
                  const shade = prod.shades.find((s) => s.id === w.shadeId) || prod.shades[0];
                  return (
                    <div
                      key={w.productId}
                      className="bg-white dark:bg-[#0D1120] border border-pink-500/25 p-4 flex flex-col justify-between gap-3 glow-border"
                    >
                      <div>
                        <img
                          src={prod.imageUrl}
                          alt={prod.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-40 object-cover mb-3"
                        />
                        <p className="font-display text-lg font-semibold">{prod.name}</p>
                        <p className="text-xs text-fuchsia-600 dark:text-pink-300 font-medium">Shade: {shade.name}</p>
                        <p className="font-mono text-sm font-bold text-blue-600 dark:text-cyan-300 mt-1 tabular-nums">{formatMoney(prod.price, currency)}</p>
                      </div>
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => onAddToBag(prod, shade)}
                          className="flex-1 py-2 btn-prism-cyan text-xs font-semibold"
                        >
                          Move to Bag
                        </button>
                        <button
                          type="button"
                          onClick={() => removeWishlist(w.productId)}
                          className="px-3 py-2 border border-rose-500/35 text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-500 hover:text-white transition-colors"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {tab === 'payments' && (
            <div className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 overflow-x-auto glow-border">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-indigo-500/20 dark:border-cyan-400/20 text-indigo-700 dark:text-cyan-300 uppercase tracking-wider">
                    <th className="p-3.5">Transaction</th>
                    <th className="p-3.5">Order</th>
                    <th className="p-3.5">Gateway &amp; Method</th>
                    <th className="p-3.5">Amount</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5">HMAC</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-indigo-500/10 dark:divide-cyan-400/10">
                  {transactions.map((tx) => (
                    <tr key={tx.id}>
                      <td className="p-3.5 font-mono text-blue-600 dark:text-cyan-300">{tx.id}</td>
                      <td className="p-3.5 font-mono">{tx.orderId}</td>
                      <td className="p-3.5">
                        {tx.gateway} · {tx.method}
                      </td>
                      <td className="p-3.5 font-mono font-semibold text-emerald-600 dark:text-emerald-400 tabular-nums">
                        {tx.currency} {tx.amount}
                      </td>
                      <td className="p-3.5 capitalize font-semibold">{tx.status.replace('_', ' ')}</td>
                      <td className="p-3.5 text-emerald-600 dark:text-emerald-400 font-medium">{tx.signatureVerified ? 'Verified' : 'Unverified'}</td>
                    </tr>
                  ))}
                  {transactions.length === 0 && (
                    <tr>
                      <td colSpan={6} className="p-6 text-center text-slate-500 dark:text-slate-400">
                        No transactions recorded yet.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}

          {tab === 'tickets' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="font-display text-xl font-semibold gradient-heading">Concierge Support Tickets</h3>
                <button
                  type="button"
                  onClick={onOpenSupport}
                  className="px-4 py-2 btn-futuristic text-xs font-semibold uppercase tracking-wider"
                >
                  New Support Inquiry
                </button>
              </div>
              {tickets.length === 0 ? (
                <p className="text-sm text-slate-600 dark:text-slate-300 bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-6">
                  No support tickets submitted yet.
                </p>
              ) : (
                tickets.map((t) => (
                  <div
                    key={t.id}
                    className="bg-white dark:bg-[#0D1120] border border-violet-500/25 p-5 space-y-2 text-xs glow-border"
                  >
                    <div className="flex justify-between items-center">
                      <span className="font-mono font-semibold text-indigo-700 dark:text-cyan-300">#{t.id} · {t.subject}</span>
                      <span className="capitalize font-semibold text-fuchsia-600 dark:text-fuchsia-300">
                        {t.status.replace('_', ' ')}
                      </span>
                    </div>
                    <p className="text-slate-700 dark:text-slate-200">{t.message}</p>
                    {t.adminReply && (
                      <div className="p-3 bg-gradient-to-r from-cyan-50 to-violet-50 dark:from-cyan-950/35 dark:to-violet-950/35 border border-cyan-500/30 mt-2">
                        <p className="font-semibold text-indigo-700 dark:text-cyan-300">Atelier Concierge Reply:</p>
                        <p className="mt-1">{t.adminReply}</p>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          )}

          {tab === 'notifications' && (
            <div className="space-y-3">
              {unreadCount > 0 && (
                <div className="flex items-center justify-between">
                  <p className="text-xs font-semibold text-pink-600 dark:text-pink-300">
                    {unreadCount} unread notification{unreadCount === 1 ? '' : 's'}
                  </p>
                  <button
                    type="button"
                    onClick={markAllNotificationsRead}
                    className="px-3.5 py-1.5 btn-prism-cyan text-xs font-semibold"
                  >
                    Mark All Read
                  </button>
                </div>
              )}
              {notifications.length === 0 ? (
                <p className="text-sm text-slate-600 dark:text-slate-300 bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-6">
                  No notifications at this time.
                </p>
              ) : (
                notifications.map((n) => (
                  <div
                    key={n.id}
                    className={`bg-white dark:bg-[#0D1120] border p-4 flex items-center justify-between gap-4 ${
                      n.read
                        ? 'border-indigo-500/15 dark:border-white/10 opacity-75'
                        : 'border-pink-500/45 bg-gradient-to-r from-pink-50/50 via-white to-violet-50/50 dark:from-pink-950/25 dark:via-[#0D1120] dark:to-violet-950/25'
                    }`}
                  >
                    <div>
                      <p className="text-sm font-semibold text-[#090B14] dark:text-white">{n.title}</p>
                      <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">{n.message}</p>
                    </div>
                    {!n.read && (
                      <button
                        type="button"
                        onClick={() => markNotificationRead(n.id)}
                        className="px-3 py-1.5 btn-prism-outline text-xs font-semibold flex items-center gap-1 shrink-0"
                      >
                        <Check className="w-3.5 h-3.5" /> Mark Read
                      </button>
                    )}
                  </div>
                ))
              )}
            </div>
          )}

          {tab === 'subscriptions' && (
            <div className="space-y-4">
              <div className="bg-gradient-to-r from-violet-50 via-white to-cyan-50 dark:from-violet-950/35 dark:via-[#0D1120] dark:to-cyan-950/30 border border-violet-500/30 p-4 text-xs flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="font-bold text-violet-700 dark:text-fuchsia-300">Auto-Replenish Beauty Subscriptions</p>
                  <p className="text-slate-600 dark:text-slate-300">
                    Enjoy 12% savings on recurring 30, 60, or 90-day deliveries. Pause, resume, or cancel anytime.
                  </p>
                </div>
                <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                  {subscriptions.filter((s) => s.status === 'active').length} Active Plan(s)
                </span>
              </div>
              {subscriptions.length === 0 ? (
                <div className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 p-8 text-center text-xs text-slate-600 dark:text-slate-300">
                  No recurring subscriptions yet. Choose &ldquo;Subscribe &amp; Save 12%&rdquo; on any product detail sheet to enroll.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {subscriptions.map((sub) => (
                    <div key={sub.id} className="bg-white dark:bg-[#0D1120] border border-indigo-500/25 p-4 space-y-2.5 text-xs glow-border">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="w-4 h-4 rounded-full border border-white/50 shrink-0" style={{ backgroundColor: sub.shadeHex }} />
                          <div>
                            <p className="font-bold text-[#090B14] dark:text-white">{sub.productName}</p>
                            <p className="text-[11px] text-slate-500 dark:text-slate-400">
                              Shade: {sub.shadeName} · Every {sub.intervalDays} Days · Qty {sub.quantity}
                            </p>
                          </div>
                        </div>
                        <span
                          className={`px-2 py-0.5 text-[10px] font-bold uppercase ${
                            sub.status === 'active'
                              ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                              : sub.status === 'paused'
                                ? 'bg-amber-500/15 text-amber-700 dark:text-amber-300'
                                : 'bg-rose-500/15 text-rose-700 dark:text-rose-300'
                          }`}
                        >
                          {sub.status}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[11px] text-slate-600 dark:text-slate-300">
                        <span>Next Dispatch: <strong className="font-mono">{sub.nextBillingDate}</strong></span>
                        <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                          {formatMoney(sub.unitPriceUsd * sub.quantity, currency)} (-{sub.discountPercent}%)
                        </span>
                      </div>
                      {sub.status !== 'cancelled' && (
                        <div className="flex items-center gap-2 pt-2 border-t border-indigo-500/15">
                          {sub.status === 'active' ? (
                            <button
                              type="button"
                              onClick={() => void updateSubscriptionStatus(sub, 'paused')}
                              className="px-3 py-1 border border-amber-500/40 text-amber-700 dark:text-amber-300 font-semibold hover:bg-amber-500/10"
                            >
                              Pause
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => void updateSubscriptionStatus(sub, 'active')}
                              className="px-3 py-1 btn-prism-emerald text-white font-semibold"
                            >
                              Resume
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => void updateSubscriptionStatus(sub, 'cancelled')}
                            className="px-3 py-1 border border-rose-500/40 text-rose-700 dark:text-rose-300 font-semibold hover:bg-rose-500/10"
                          >
                            Cancel
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {tab === 'rewards' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="bg-gradient-to-br from-amber-50 via-white to-orange-50 dark:from-amber-950/35 dark:via-[#0D1120] dark:to-orange-950/25 border border-amber-500/35 p-4 glow-border">
                  <p className="uppercase tracking-wider text-[10px] font-bold text-amber-700 dark:text-amber-300">Loyalty Tier</p>
                  <p className="font-display text-2xl font-bold mt-1">{loyaltyTier}</p>
                  <p className="font-mono text-emerald-600 dark:text-emerald-400 font-semibold mt-1">{loyaltyPts} Points Available</p>
                </div>
                <div className="bg-gradient-to-br from-cyan-50 via-white to-blue-50 dark:from-cyan-950/35 dark:via-[#0D1120] dark:to-blue-950/25 border border-cyan-500/35 p-4 glow-border">
                  <p className="uppercase tracking-wider text-[10px] font-bold text-cyan-700 dark:text-cyan-300">Lifetime Spend (CLV)</p>
                  <p className="font-display text-2xl font-bold font-mono mt-1">{formatMoney(totalClv, currency)}</p>
                  <p className="text-slate-600 dark:text-slate-300 mt-1">{orders.length} Total Atelier Orders</p>
                </div>
                <div className="bg-gradient-to-br from-fuchsia-50 via-white to-violet-50 dark:from-fuchsia-950/35 dark:via-[#0D1120] dark:to-violet-950/25 border border-fuchsia-500/35 p-4 glow-border">
                  <p className="uppercase tracking-wider text-[10px] font-bold text-fuchsia-700 dark:text-fuchsia-300">Personal Referral Code</p>
                  <div className="flex items-center justify-between gap-2 mt-1">
                    <span className="font-mono text-lg font-bold text-indigo-700 dark:text-cyan-300">{referralCode}</span>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard?.writeText(referralCode);
                        setCopiedRef(true);
                        setTimeout(() => setCopiedRef(false), 1800);
                      }}
                      className="px-2.5 py-1 btn-prism-cyan text-white text-[11px] font-semibold flex items-center gap-1"
                    >
                      <Copy className="w-3 h-3" /> {copiedRef ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-1">Earn +250 pts per invited friend</p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white dark:bg-[#0D1120] border border-indigo-500/25 p-5 space-y-3 text-xs glow-border">
                  <h3 className="font-display text-xl font-semibold gradient-heading flex items-center gap-2">
                    <Share2 className="w-4 h-4 text-cyan-500" /> Invite a Friend (Referral Program)
                  </h3>
                  <form onSubmit={submitReferralInvite} className="flex gap-2">
                    <input
                      type="email"
                      required
                      value={refereeEmail}
                      onChange={(e) => setRefereeEmail(e.target.value)}
                      placeholder="friend@example.com"
                      className="flex-1 px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
                    />
                    <button type="submit" className="px-4 py-2 btn-futuristic text-white font-semibold">
                      Send Invite
                    </button>
                  </form>
                  <div className="space-y-2 pt-2">
                    {referrals.length === 0 ? (
                      <p className="text-slate-500 dark:text-slate-400">No referrals logged yet.</p>
                    ) : (
                      referrals.map((r) => (
                        <div key={r.id} className="flex items-center justify-between border-b border-indigo-500/15 pb-1.5">
                          <span>{r.refereeEmail || r.referralCode}</span>
                          <span className="font-mono font-semibold text-emerald-600 dark:text-emerald-400">
                            +{r.rewardPoints} pts ({r.status})
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <div className="bg-white dark:bg-[#0D1120] border border-amber-500/25 p-5 space-y-3 text-xs glow-border">
                  <h3 className="font-display text-xl font-semibold gradient-heading-warm flex items-center gap-2">
                    <Gift className="w-4 h-4 text-amber-500" /> Active Digital Gift Cards
                  </h3>
                  <p className="text-slate-600 dark:text-slate-300">
                    Apply any active gift card code during Checkout alongside promotional coupons.
                  </p>
                  <div className="space-y-2">
                    {giftCards.filter((g) => g.active && g.balanceUsd > 0).length === 0 ? (
                      <p className="text-slate-500 dark:text-slate-400">No active gift cards available.</p>
                    ) : (
                      giftCards
                        .filter((g) => g.active && g.balanceUsd > 0)
                        .map((gc) => (
                          <div key={gc.id} className="p-3 bg-[#F5F7FF] dark:bg-[#141A30] border border-amber-500/30 flex items-center justify-between gap-2">
                            <div>
                              <p className="font-mono font-bold text-indigo-700 dark:text-cyan-300">{gc.code}</p>
                              <p className="text-[11px] text-slate-500 dark:text-slate-400">{gc.message || 'Atelier Gift Credit'}</p>
                            </div>
                            <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                              {formatMoney(gc.balanceUsd, currency)}
                            </span>
                          </div>
                        ))
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

      {/* Printable Invoice Modal */}
      {invoiceOrder && (
        <div className="fixed inset-0 z-[60] bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#0D1120] text-[#090B14] dark:text-[#F8FAFF] w-full max-w-lg border border-indigo-500/30 dark:border-cyan-400/30 p-8 space-y-5 shadow-2xl prism-modal-rim">
            <div className="flex items-start justify-between border-b border-indigo-500/15 dark:border-cyan-400/15 pb-4">
              <div>
                <p className="font-display text-2xl font-semibold gradient-heading">LUMIÈRE ATELIER</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Official Tax Invoice · #{invoiceOrder.id}</p>
              </div>
              <button
                type="button"
                onClick={() => setInvoiceOrder(null)}
                aria-label="Close Invoice"
                className="p-1 hover:bg-indigo-500/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="text-xs space-y-1 text-slate-600 dark:text-slate-300">
              <p className="font-semibold text-[#090B14] dark:text-white">{invoiceOrder.shippingAddress.fullName}</p>
              <p>{invoiceOrder.shippingAddress.line1}</p>
              <p>
                {invoiceOrder.shippingAddress.city}, {invoiceOrder.shippingAddress.state}{' '}
                {invoiceOrder.shippingAddress.postalCode}
              </p>
              <p>
                Gateway: {invoiceOrder.paymentGateway} ({invoiceOrder.paymentMethod})
              </p>
            </div>
            <div className="divide-y divide-indigo-500/15 dark:divide-cyan-400/15 border-y border-indigo-500/15 dark:border-cyan-400/15 text-xs">
              {invoiceOrder.items.map((item, idx) => (
                <div key={idx} className="py-2 flex justify-between">
                  <span>
                    {item.name} ({item.shadeName}) × {item.quantity}
                  </span>
                  <span className="font-mono tabular-nums">
                    {formatMoney(item.unitPrice * item.quantity, currency)}
                  </span>
                </div>
              ))}
            </div>
            <div className="flex justify-between font-bold text-sm">
              <span>Total</span>
              <span className="font-mono text-emerald-600 dark:text-emerald-400 tabular-nums">{formatMoney(invoiceOrder.total, currency)}</span>
            </div>
            <button
              type="button"
              onClick={() => window.print()}
              className="w-full py-2.5 btn-futuristic text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2"
            >
              <Printer className="w-4 h-4" /> Print / Save PDF
            </button>
          </div>
        </div>
      )}

      <ConfirmDialog
        open={Boolean(confirmState)}
        title={confirmState?.title || ''}
        message={confirmState?.message || ''}
        confirmLabel={confirmState?.confirmLabel || 'Confirm'}
        destructive
        onConfirm={async () => {
          const action = confirmState?.onConfirm;
          setConfirmState(null);
          if (action) await action();
        }}
        onCancel={() => setConfirmState(null)}
      />
    </CinematicModal>
  );
};
