import React, { useEffect, useRef, useState } from 'react';
import { motion, useScroll, useSpring } from 'motion/react';
import { ArrowUp, MessageSquare, ShoppingBag, Sparkles, Sun, X } from 'lucide-react';
import { useMotionPreferences } from '../context/MotionContext';
import {
  LightColorPreset,
  LightingIntensity,
  PageTransitionStyle,
  SiteSettings,
} from '../types/store';
import { CHART_BAR_GRADIENTS } from '../lib/themePalette';

/* -------------------------------------------------------------------------- */
/* 1. ScrollProgressBeam — 3px zero-height top glowing progress indicator     */
/* -------------------------------------------------------------------------- */
export const ScrollProgressBeam: React.FC = () => {
  const { effectiveReducedMotion, effectiveGlobalLighting, lightPalette } = useMotionPreferences();
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 180,
    damping: 30,
    restDelta: 0.001,
  });

  if (effectiveReducedMotion) return null;

  return (
    <motion.div
      aria-hidden="true"
      style={{
        scaleX,
        background: `linear-gradient(90deg, ${lightPalette.c2}, ${lightPalette.c1}, ${lightPalette.c3}, ${lightPalette.c4})`,
        boxShadow: effectiveGlobalLighting ? `0 0 16px ${lightPalette.c1}` : undefined,
      }}
      className="fixed top-0 left-0 right-0 h-[3px] origin-left z-[76] pointer-events-none"
    />
  );
};

/* -------------------------------------------------------------------------- */
/* 2. MorphingLightField — Zero-flow GPU radial & SVG beam backdrop           */
/* -------------------------------------------------------------------------- */
export const MorphingLightField: React.FC<{ variant?: 'hero' | 'panel' }> = ({ variant = 'hero' }) => {
  const {
    effectiveBackgroundLighting,
    ambientLightingScale,
    lightPalette,
    lightSpeedMultiplier,
    intensityScale,
  } = useMotionPreferences();

  if (!effectiveBackgroundLighting) {
    return <div aria-hidden="true" className="pointer-events-none absolute inset-0 hero-lighting-mesh opacity-45" />;
  }

  const { c1, c2, c3, c4 } = lightPalette;
  const s = Math.max(0.5, lightSpeedMultiplier);

  return (
    <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden z-0">
      {/* Liquid animated mesh base */}
      <div
        className="absolute inset-0 hero-lighting-mesh liquid-gradient-drift"
        style={{ opacity: Math.min(1, Math.max(0.45, ambientLightingScale)) }}
      />

      {/* Sweeping futuristic light beam */}
      <div
        className="light-beam-sweep"
        style={{ opacity: variant === 'hero' ? 0.42 * ambientLightingScale : 0.24 * ambientLightingScale }}
      />

      {/* Geometric precision SVG mesh & morphing wave arcs */}
      <svg
        viewBox="0 0 1440 560"
        preserveAspectRatio="none"
        className="absolute inset-0 w-full h-full"
        style={{ opacity: variant === 'hero' ? 0.34 * ambientLightingScale * intensityScale : 0.18 * ambientLightingScale }}
      >
        <defs>
          <linearGradient id="beamGradA" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor={c2} stopOpacity="0" />
            <stop offset="25%" stopColor={c1} stopOpacity="0.95" />
            <stop offset="52%" stopColor={c3} stopOpacity="0.88" />
            <stop offset="78%" stopColor={c4} stopOpacity="0.9" />
            <stop offset="100%" stopColor={c1} stopOpacity="0" />
          </linearGradient>
          <linearGradient id="beamGradB" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={c4} stopOpacity="0" />
            <stop offset="35%" stopColor={c3} stopOpacity="0.85" />
            <stop offset="68%" stopColor={c1} stopOpacity="0.85" />
            <stop offset="100%" stopColor={c2} stopOpacity="0" />
          </linearGradient>
        </defs>
        <motion.path
          d="M-60,420 C260,300 540,490 920,330 C1180,220 1320,300 1500,210"
          fill="none"
          stroke="url(#beamGradA)"
          strokeWidth="1.8"
          animate={{
            d: [
              'M-60,420 C260,300 540,490 920,330 C1180,220 1320,300 1500,210',
              'M-60,360 C310,460 600,260 940,390 C1210,470 1340,240 1500,290',
              'M-60,420 C260,300 540,490 920,330 C1180,220 1320,300 1500,210',
            ],
          }}
          transition={{ duration: 14 * s, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.path
          d="M-40,150 C340,240 620,60 980,190 C1220,270 1360,130 1500,170"
          fill="none"
          stroke="url(#beamGradB)"
          strokeWidth="1.4"
          animate={{
            d: [
              'M-40,150 C340,240 620,60 980,190 C1220,270 1360,130 1500,170',
              'M-40,210 C300,110 660,250 1010,120 C1260,40 1380,210 1500,130',
              'M-40,150 C340,240 620,60 980,190 C1220,270 1360,130 1500,170',
            ],
          }}
          transition={{ duration: 18 * s, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.circle
          cx="1180"
          cy="140"
          r="92"
          fill="none"
          stroke="url(#beamGradA)"
          strokeWidth="1.1"
          strokeDasharray="6 8"
          animate={{ rotate: 360 }}
          style={{ originX: '1180px', originY: '140px' }}
          transition={{ duration: 34 * s, repeat: Infinity, ease: 'linear' }}
        />
      </svg>
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* 3. MagneticButton — Magnetic cursor pull + radial glow + click ripple      */
/* -------------------------------------------------------------------------- */
interface MagneticButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  magneticStrength?: number;
}

export const MagneticButton: React.FC<MagneticButtonProps> = ({
  children,
  className = '',
  magneticStrength = 0.18,
  onClick,
  onMouseMove,
  onMouseLeave,
  ...rest
}) => {
  const { hoverEffects, intensityScale } = useMotionPreferences();
  const btnRef = useRef<HTMLButtonElement | null>(null);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [ripple, setRipple] = useState<{ x: number; y: number; key: number } | null>(null);

  const handleMove = (e: React.MouseEvent<HTMLButtonElement>) => {
    onMouseMove?.(e);
    if (!hoverEffects || !btnRef.current) return;
    const rect = btnRef.current.getBoundingClientRect();
    const dx = e.clientX - (rect.left + rect.width / 2);
    const dy = e.clientY - (rect.top + rect.height / 2);
    const strength = magneticStrength * intensityScale;
    setOffset({
      x: Math.max(-7, Math.min(7, dx * strength)),
      y: Math.max(-5, Math.min(5, dy * strength)),
    });
  };

  const handleLeave = (e: React.MouseEvent<HTMLButtonElement>) => {
    onMouseLeave?.(e);
    setOffset({ x: 0, y: 0 });
  };

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (hoverEffects && btnRef.current) {
      const rect = btnRef.current.getBoundingClientRect();
      setRipple({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
        key: Date.now(),
      });
    }
    onClick?.(e);
  };

  return (
    <button
      ref={btnRef}
      {...rest}
      onMouseMove={handleMove}
      onMouseLeave={handleLeave}
      onClick={handleClick}
      style={{
        transform: hoverEffects ? `translate3d(${offset.x}px, ${offset.y}px, 0)` : undefined,
        transition: 'transform 180ms cubic-bezier(0.16, 1, 0.3, 1)',
      }}
      className={`relative overflow-hidden ${className}`}
    >
      {children}
      {ripple && (
        <span
          key={ripple.key}
          aria-hidden="true"
          className="ripple-burst pointer-events-none absolute rounded-full bg-white/35"
          style={{
            left: ripple.x - 10,
            top: ripple.y - 10,
            width: 20,
            height: 20,
          }}
        />
      )}
    </button>
  );
};

/* -------------------------------------------------------------------------- */
/* 4. Tilt3DCard — Interactive cursor-tracking 3D tilt + holographic sheen    */
/* -------------------------------------------------------------------------- */
interface Tilt3DCardProps {
  children: React.ReactNode;
  className?: string;
}

export const Tilt3DCard: React.FC<Tilt3DCardProps> = ({ children, className = '' }) => {
  const { enable3DEffects, hoverEffects, intensityScale, lightPalette, effectiveBorderGlow } = useMotionPreferences();
  const cardRef = useRef<HTMLElement | null>(null);
  const [tilt, setTilt] = useState({ rx: 0, ry: 0, gx: 50, gy: 50, active: false });

  const canTilt = enable3DEffects && hoverEffects;

  const handleMove = (e: React.MouseEvent<HTMLElement>) => {
    if (!canTilt || !cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width;
    const py = (e.clientY - rect.top) / rect.height;
    const maxDeg = 5.5 * intensityScale;
    setTilt({
      rx: (0.5 - py) * maxDeg * 2,
      ry: (px - 0.5) * maxDeg * 2,
      gx: px * 100,
      gy: py * 100,
      active: true,
    });
  };

  const handleLeave = () => {
    if (!canTilt) return;
    setTilt((prev) => ({ ...prev, rx: 0, ry: 0, active: false }));
  };

  return (
    <article
      ref={cardRef}
      onMouseMove={handleMove}
      onMouseLeave={handleLeave}
      style={{
        transform: canTilt
          ? `perspective(1050px) rotateX(${tilt.rx.toFixed(2)}deg) rotateY(${tilt.ry.toFixed(2)}deg) translateY(${tilt.active ? '-4px' : '0px'})`
          : undefined,
        transition: tilt.active
          ? 'transform 90ms ease-out, box-shadow 220ms ease'
          : 'transform 320ms cubic-bezier(0.16, 1, 0.3, 1), box-shadow 260ms ease',
      }}
      className={`relative will-change-transform ${effectiveBorderGlow ? 'neon-card-orbit' : ''} ${className}`}
    >
      {/* Dynamic holographic specular light reflection synced with lighting palette */}
      {canTilt && (
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 z-10 transition-opacity duration-200"
          style={{
            opacity: tilt.active ? 0.65 * intensityScale : 0,
            background: `radial-gradient(340px circle at ${tilt.gx}% ${tilt.gy}%, ${lightPalette.c1}36, ${lightPalette.c4}1E 42%, transparent 74%)`,
          }}
        />
      )}
      {children}
    </article>
  );
};

/* -------------------------------------------------------------------------- */
/* 5. CinematicSection — Scroll-triggered entrance reveal (never traps hidden)*/
/* -------------------------------------------------------------------------- */
interface CinematicSectionProps {
  children: React.ReactNode;
  className?: string;
  id?: string;
  delay?: number;
}

export const CinematicSection: React.FC<CinematicSectionProps> = ({
  children,
  className = '',
  id,
  delay = 0,
}) => {
  const { effectiveReducedMotion, speedMultiplier, intensityScale } = useMotionPreferences();

  if (effectiveReducedMotion) {
    return (
      <section id={id} className={className}>
        {children}
      </section>
    );
  }

  return (
    <motion.section
      id={id}
      initial={{ opacity: 0, y: 20 * intensityScale }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.08 }}
      transition={{
        duration: 0.5 * speedMultiplier,
        delay: delay * speedMultiplier,
        ease: [0.16, 1, 0.3, 1],
      }}
      className={className}
    >
      {children}
    </motion.section>
  );
};

/* -------------------------------------------------------------------------- */
/* 6. CinematicModal — Unified transition shell respecting Admin style choice */
/* -------------------------------------------------------------------------- */
function getModalMotionVariants(style: PageTransitionStyle, intensityScale: number) {
  switch (style) {
    case 'slide':
      return {
        initial: { opacity: 0, y: 36 * intensityScale },
        animate: { opacity: 1, y: 0 },
        exit: { opacity: 0, y: 24 * intensityScale },
      };
    case 'scale':
      return {
        initial: { opacity: 0, scale: 0.92 },
        animate: { opacity: 1, scale: 1 },
        exit: { opacity: 0, scale: 0.94 },
      };
    case 'fade':
      return {
        initial: { opacity: 0 },
        animate: { opacity: 1 },
        exit: { opacity: 0 },
      };
    case 'cinematic':
    default:
      return {
        initial: { opacity: 0, y: 22 * intensityScale, scale: 0.965 },
        animate: { opacity: 1, y: 0, scale: 1 },
        exit: { opacity: 0, y: 14 * intensityScale, scale: 0.975 },
      };
  }
}

interface CinematicModalProps {
  children: React.ReactNode;
  onBackdropClick?: () => void;
  backdropClassName?: string;
  panelClassName?: string;
  zIndexClass?: string;
}

export const CinematicModal: React.FC<CinematicModalProps> = ({
  children,
  onBackdropClick,
  backdropClassName = 'p-4 flex items-center justify-center',
  panelClassName = '',
  zIndexClass = 'z-50',
}) => {
  const {
    pageTransitionStyle,
    speedMultiplier,
    intensityScale,
    effectiveReducedMotion,
    effectiveGlobalLighting,
    effectiveBorderGlow,
    lightPalette,
  } = useMotionPreferences();
  const variants = getModalMotionVariants(pageTransitionStyle, intensityScale);
  const duration = effectiveReducedMotion ? 0.01 : 0.28 * speedMultiplier;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: duration * 0.85 }}
      onClick={(e) => {
        if (onBackdropClick && e.target === e.currentTarget) onBackdropClick();
      }}
      className={`fixed inset-0 ${zIndexClass} bg-black/72 backdrop-blur-sm ${backdropClassName}`}
    >
      {/* Subtle 360° 4-Corner Ambient Backdrop Illumination around every Modal/Portal */}
      {effectiveGlobalLighting && (
        <div
          aria-hidden="true"
          className="pointer-events-none fixed inset-0 overflow-hidden"
          style={{
            background: `radial-gradient(560px 340px at 10% 12%, ${lightPalette.c1}2C, transparent 70%), radial-gradient(520px 320px at 90% 14%, ${lightPalette.c3}26, transparent 70%), radial-gradient(560px 340px at 88% 88%, ${lightPalette.c4}2C, transparent 70%), radial-gradient(500px 300px at 12% 88%, ${lightPalette.c2}24, transparent 70%)`,
          }}
        />
      )}
      <motion.div
        initial={effectiveReducedMotion ? false : variants.initial}
        animate={variants.animate}
        exit={effectiveReducedMotion ? undefined : variants.exit}
        transition={{ duration, ease: [0.16, 1, 0.3, 1] }}
        className={`relative ${effectiveGlobalLighting ? 'neon-modal-frame luminous-surface' : ''} ${effectiveBorderGlow ? 'neon-card-orbit' : ''} ${panelClassName}`}
      >
        {children}
      </motion.div>
    </motion.div>
  );
};

/* -------------------------------------------------------------------------- */
/* 7. AnimatedCounter — Smooth rAF numeric counter for KPIs & Finance         */
/* -------------------------------------------------------------------------- */
interface AnimatedCounterProps {
  value: number;
  formatter?: (val: number) => string;
  durationMs?: number;
  className?: string;
}

export const AnimatedCounter: React.FC<AnimatedCounterProps> = ({
  value,
  formatter = (v) => Math.round(v).toLocaleString(),
  durationMs = 700,
  className = '',
}) => {
  const { effectiveReducedMotion, speedMultiplier } = useMotionPreferences();
  const [displayValue, setDisplayValue] = useState(value);
  const prevValueRef = useRef(0);

  useEffect(() => {
    if (effectiveReducedMotion || !Number.isFinite(value)) {
      setDisplayValue(value);
      prevValueRef.current = value;
      return;
    }

    const startVal = prevValueRef.current;
    const delta = value - startVal;
    const totalDuration = Math.max(180, durationMs * speedMultiplier);
    const startTime = performance.now();
    let rafId = 0;

    const tick = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(1, elapsed / totalDuration);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplayValue(startVal + delta * eased);
      if (progress < 1) {
        rafId = requestAnimationFrame(tick);
      } else {
        prevValueRef.current = value;
      }
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [value, durationMs, effectiveReducedMotion, speedMultiplier]);

  return <span className={`tabular-nums ${className}`}>{formatter(displayValue)}</span>;
};

/* -------------------------------------------------------------------------- */
/* 8. AnimatedProgressBar — Glowing bar with live light shimmer               */
/* -------------------------------------------------------------------------- */
interface AnimatedProgressBarProps {
  percent: number;
  label?: string;
  valueLabel?: string;
  tone?: 'brand' | 'emerald' | 'amber' | 'rose' | 'cyan' | 'violet' | 'orange';
  heightClass?: string;
}

export const AnimatedProgressBar: React.FC<AnimatedProgressBarProps> = ({
  percent,
  label,
  valueLabel,
  tone = 'brand',
  heightClass = 'h-2',
}) => {
  const { effectiveReducedMotion, speedMultiplier } = useMotionPreferences();
  const clamped = Math.max(0, Math.min(100, percent));

  const fillGradient =
    tone === 'emerald'
      ? 'from-[#10B981] via-[#14B8A6] to-[#22D3EE]'
      : tone === 'amber'
        ? 'from-[#F59E0B] via-[#F97316] to-[#FACC15]'
        : tone === 'orange'
          ? 'from-[#F97316] via-[#FB7185] to-[#EC4899]'
          : tone === 'rose'
            ? 'from-[#F43F5E] via-[#EC4899] to-[#D946EF]'
            : tone === 'cyan'
              ? 'from-[#2563EB] via-[#06B6D4] to-[#2DD4BF]'
              : tone === 'violet'
                ? 'from-[#5B21B6] via-[#7C3AED] to-[#D946EF]'
                : 'from-[#2563EB] via-[#7C3AED] via-60% to-[#EC4899]';

  return (
    <div className="space-y-1.5 w-full">
      {(label || valueLabel) && (
        <div className="flex items-center justify-between text-xs">
          {label && <span className="text-[#434C66] dark:text-slate-300 truncate">{label}</span>}
          {valueLabel && <span className="font-mono font-semibold tabular-nums shrink-0 text-[#0B1020] dark:text-white">{valueLabel}</span>}
        </div>
      )}
      <div className={`w-full ${heightClass} bg-black/10 dark:bg-white/10 overflow-hidden relative`}>
        <motion.div
          initial={effectiveReducedMotion ? false : { width: 0 }}
          animate={{ width: `${clamped}%` }}
          transition={{ duration: 0.65 * speedMultiplier, ease: [0.16, 1, 0.3, 1] }}
          className={`h-full bg-gradient-to-r ${fillGradient} relative overflow-hidden`}
        >
          {!effectiveReducedMotion && <div className="progress-beam-shimmer absolute inset-0" />}
        </motion.div>
      </div>
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* 9. AnimatedOrderTimeline — Sequential animated order fulfillment rail      */
/* -------------------------------------------------------------------------- */
const DEFAULT_STAGES = ['Confirmed', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered'];

interface AnimatedOrderTimelineProps {
  currentStatus: string;
}

export const AnimatedOrderTimeline: React.FC<AnimatedOrderTimelineProps> = ({ currentStatus }) => {
  const { effectiveReducedMotion, speedMultiplier } = useMotionPreferences();
  const normalized = currentStatus.toLowerCase();

  let activeIndex = 0;
  if (normalized.includes('deliver') && !normalized.includes('out')) activeIndex = 4;
  else if (normalized.includes('out_for_delivery') || normalized.includes('out for')) activeIndex = 3;
  else if (normalized.includes('ship') || normalized.includes('transit')) activeIndex = 2;
  else if (normalized.includes('pack')) activeIndex = 1;
  else if (normalized.includes('cancel') || normalized.includes('return') || normalized.includes('refund')) {
    activeIndex = -1;
  }

  if (activeIndex === -1) {
    return (
      <div className="px-3 py-2 border border-rose-500/30 bg-rose-500/10 text-xs text-rose-700 dark:text-rose-300 font-medium capitalize">
        Order Status: {currentStatus.replace(/_/g, ' ')}
      </div>
    );
  }

  const fillPct = (activeIndex / (DEFAULT_STAGES.length - 1)) * 100;

  return (
    <div className="py-2 space-y-2">
      <div className="relative flex items-center justify-between">
        <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-0.5 bg-black/10 dark:bg-white/15" />
        <motion.div
          initial={effectiveReducedMotion ? false : { width: 0 }}
          animate={{ width: `${fillPct}%` }}
          transition={{ duration: 0.7 * speedMultiplier, ease: [0.16, 1, 0.3, 1] }}
          className="absolute left-0 top-1/2 -translate-y-1/2 h-0.5 bg-gradient-to-r from-[#2563EB] via-[#22D3EE] to-[#D946EF]"
        />
        {DEFAULT_STAGES.map((stage, idx) => {
          const completed = idx <= activeIndex;
          const isCurrent = idx === activeIndex;
          return (
            <div key={stage} className="relative z-10 flex flex-col items-center">
              <motion.div
                initial={effectiveReducedMotion ? false : { scale: 0.6, opacity: 0 }}
                animate={{ scale: isCurrent ? 1.15 : 1, opacity: 1 }}
                transition={{ delay: idx * 0.08 * speedMultiplier, duration: 0.25 }}
                className={`w-3.5 h-3.5 rounded-full border-2 transition-colors ${
                  completed
                    ? 'bg-[#2563EB] border-[#22D3EE] shadow-[0_0_10px_rgba(34,211,238,0.7)]'
                    : 'bg-white dark:bg-[#0D1120] border-indigo-500/30 dark:border-cyan-400/30'
                }`}
              />
            </div>
          );
        })}
      </div>
      <div className="grid grid-cols-5 text-[10px] text-[#475569] dark:text-white/70">
        {DEFAULT_STAGES.map((stage, idx) => (
          <span
            key={stage}
            className={`${idx === 0 ? 'text-left' : idx === 4 ? 'text-right' : 'text-center'} ${
              idx <= activeIndex ? 'font-semibold text-[#2563EB] dark:text-[#22D3EE]' : ''
            } truncate`}
          >
            {stage}
          </span>
        ))}
      </div>
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* 10. AnimatedBarChart3D — 3D Isometric-Depth Glowing Analytics Chart        */
/* -------------------------------------------------------------------------- */
export interface BarDatum {
  label: string;
  value: number;
  secondaryValue?: number;
  formattedValue: string;
  secondaryFormatted?: string;
}

interface AnimatedBarChart3DProps {
  title: string;
  subtitle?: string;
  data: BarDatum[];
}

export const AnimatedBarChart3D: React.FC<AnimatedBarChart3DProps> = ({ title, subtitle, data }) => {
  const { effectiveReducedMotion, enable3DEffects, speedMultiplier } = useMotionPreferences();
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  const maxVal = Math.max(1, ...data.map((d) => d.value));

  return (
    <div className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-5 space-y-4 overflow-hidden glow-border">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h4 className="font-semibold text-sm gradient-heading">{title}</h4>
          {subtitle && <p className="text-xs text-[#434C66] dark:text-slate-300">{subtitle}</p>}
        </div>
        {hoveredIdx !== null && data[hoveredIdx] && (
          <div className="px-3 py-1 bg-gradient-to-r from-[#0B1020] via-[#1B1338] to-[#0B1020] text-white text-xs font-mono flex items-center gap-2 border border-cyan-400/40">
            <span className="text-[#22D3EE] font-semibold">{data[hoveredIdx].label}</span>
            <span className="text-[#FDE047]">{data[hoveredIdx].formattedValue}</span>
            {data[hoveredIdx].secondaryFormatted && (
              <span className="text-[#34D399]">· Net {data[hoveredIdx].secondaryFormatted}</span>
            )}
          </div>
        )}
      </div>

      <div
        className="h-52 pt-6 pb-2 flex items-end justify-between gap-2 sm:gap-4 border-b border-indigo-500/15 dark:border-cyan-400/15"
        style={enable3DEffects ? { perspective: '900px' } : undefined}
      >
        {data.map((item, idx) => {
          const pct = Math.max(8, Math.round((item.value / maxVal) * 100));
          const isHovered = hoveredIdx === idx;
          const barGradient = CHART_BAR_GRADIENTS[idx % CHART_BAR_GRADIENTS.length];
          return (
            <div
              key={item.label}
              onMouseEnter={() => setHoveredIdx(idx)}
              onMouseLeave={() => setHoveredIdx(null)}
              className="flex-1 h-full flex flex-col items-center justify-end gap-2 group cursor-pointer"
            >
              <span className="text-[10px] font-mono tabular-nums text-[#434C66] dark:text-slate-300 opacity-90 group-hover:text-[#2563EB] dark:group-hover:text-[#22D3EE] font-semibold transition-colors truncate max-w-full">
                {item.formattedValue}
              </span>
              <div className="w-full max-w-[46px] flex-1 flex items-end justify-center relative">
                <motion.div
                  initial={effectiveReducedMotion ? false : { height: '4%', opacity: 0.3 }}
                  animate={{
                    height: `${pct}%`,
                    opacity: 1,
                    scaleY: isHovered ? 1.04 : 1,
                  }}
                  transition={{
                    duration: 0.65 * speedMultiplier,
                    delay: idx * 0.06 * speedMultiplier,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                  style={
                    enable3DEffects
                      ? {
                          transformOrigin: 'bottom center',
                          boxShadow: isHovered
                            ? '6px -4px 0 rgba(217, 70, 239, 0.36), 0 0 24px rgba(34, 211, 238, 0.5)'
                            : '4px -3px 0 rgba(37, 99, 235, 0.25)',
                        }
                      : undefined
                  }
                  className={`w-full bg-gradient-to-t ${barGradient} relative overflow-hidden`}
                >
                  <div className="absolute inset-x-0 top-0 h-1.5 bg-white/45" />
                  {!effectiveReducedMotion && <div className="progress-beam-shimmer absolute inset-0 opacity-65" />}
                </motion.div>
              </div>
              <span className="text-[11px] font-medium text-[#334155] dark:text-slate-200 truncate max-w-full">
                {item.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* 11. FloatingQuickDock — Compact floating action dock + Live 360° Studio    */
/* -------------------------------------------------------------------------- */
interface FloatingQuickDockProps {
  bagCount: number;
  bagPulseKey: number;
  onOpenBag: () => void;
  onOpenShadeFinder: () => void;
  onOpenChatbot?: () => void;
  onPreviewSiteSettings?: (partial: Partial<SiteSettings>) => void;
}

const QUICK_LIGHT_PRESETS: Array<{ id: LightColorPreset; label: string; grad: string }> = [
  { id: 'rainbow', label: 'Rainbow', grad: 'from-[#22D3EE] via-[#7C3AED] to-[#EC4899]' },
  { id: 'cyber_cyan', label: 'Cyan', grad: 'from-[#2563EB] via-[#06B6D4] to-[#22D3EE]' },
  { id: 'royal_magenta', label: 'Magenta', grad: 'from-[#5B21B6] via-[#D946EF] to-[#EC4899]' },
  { id: 'emerald_aqua', label: 'Emerald', grad: 'from-[#10B981] via-[#14B8A6] to-[#22D3EE]' },
  { id: 'solar_gold', label: 'Solar', grad: 'from-[#F59E0B] via-[#F97316] to-[#EC4899]' },
];

export const FloatingQuickDock: React.FC<FloatingQuickDockProps> = ({
  bagCount,
  bagPulseKey,
  onOpenBag,
  onOpenShadeFinder,
  onOpenChatbot,
  onPreviewSiteSettings,
}) => {
  const [showTop, setShowTop] = useState(false);
  const [lightingMenuOpen, setLightingMenuOpen] = useState(false);
  const prefs = useMotionPreferences();

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 360);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <div className="fixed bottom-5 right-5 z-40 flex flex-col items-end gap-2">
      {lightingMenuOpen && onPreviewSiteSettings && (
        <motion.div
          initial={{ opacity: 0, y: 12, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 8, scale: 0.96 }}
          transition={{ duration: 0.2 }}
          className="w-72 p-4 bg-white/95 dark:bg-[#0B1022]/95 backdrop-blur-xl border border-indigo-500/30 dark:border-cyan-400/35 neon-modal-frame neon-card-orbit text-[#0B1020] dark:text-white space-y-3 shadow-2xl"
        >
          <div className="flex items-center justify-between gap-2 pb-2 border-b border-indigo-500/15 dark:border-cyan-400/20">
            <div className="flex items-center gap-1.5">
              <Sun className="w-4 h-4 text-[#06B6D4] dark:text-[#22D3EE]" />
              <span className="text-xs font-bold uppercase tracking-wider gradient-heading">
                360° Neon Studio
              </span>
            </div>
            <button
              type="button"
              onClick={() => setLightingMenuOpen(false)}
              aria-label="Close lighting quick studio"
              className="p-1 text-slate-400 hover:text-rose-500 transition-colors"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Color Spectrum Swatches */}
          <div className="space-y-1.5">
            <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Light Color Spectrum
            </p>
            <div className="grid grid-cols-5 gap-1.5">
              {QUICK_LIGHT_PRESETS.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  title={preset.label}
                  onClick={() => onPreviewSiteSettings({ lightColorPreset: preset.id })}
                  className={`p-1 border transition-all text-center ${
                    prefs.lightColorPreset === preset.id
                      ? 'border-[#2563EB] dark:border-[#22D3EE] ring-1 ring-[#22D3EE]/60'
                      : 'border-indigo-500/20 dark:border-white/15 hover:border-[#22D3EE]/60'
                  }`}
                >
                  <span className={`block h-3 w-full bg-gradient-to-r ${preset.grad}`} />
                  <span className="block text-[9px] font-semibold mt-0.5 truncate">{preset.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Quick Intensity Selector */}
          <div className="space-y-1">
            <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Ambient Intensity
            </p>
            <div className="grid grid-cols-4 gap-1">
              {(['subtle', 'balanced', 'cinematic', 'ultra'] as LightingIntensity[]).map((lvl) => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => onPreviewSiteSettings({ ambientLightingIntensity: lvl })}
                  className={`py-1 text-[10px] font-semibold capitalize border transition-all ${
                    prefs.ambientLightingIntensity === lvl
                      ? 'btn-prism-cyan border-transparent text-white'
                      : 'border-indigo-500/20 dark:border-white/15 text-slate-600 dark:text-slate-300 hover:border-[#22D3EE]'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>
          </div>

          {/* Quick Toggles */}
          <div className="grid grid-cols-2 gap-1.5 text-[11px] font-semibold pt-1">
            <button
              type="button"
              onClick={() => onPreviewSiteSettings({ globalLightingEnabled: !prefs.globalLightingEnabled })}
              className={`px-2 py-1.5 border transition-all ${
                prefs.globalLightingEnabled
                  ? 'border-emerald-500/40 bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                  : 'border-slate-300 dark:border-white/15 text-slate-500 dark:text-slate-400'
              }`}
            >
              360° Light: {prefs.globalLightingEnabled ? 'ON' : 'OFF'}
            </button>
            <button
              type="button"
              onClick={() => onPreviewSiteSettings({ borderGlowEnabled: !prefs.borderGlowEnabled })}
              className={`px-2 py-1.5 border transition-all ${
                prefs.borderGlowEnabled
                  ? 'border-cyan-500/40 bg-cyan-500/15 text-cyan-700 dark:text-cyan-300'
                  : 'border-slate-300 dark:border-white/15 text-slate-500 dark:text-slate-400'
              }`}
            >
              Borders: {prefs.borderGlowEnabled ? 'ON' : 'OFF'}
            </button>
            <button
              type="button"
              onClick={() => onPreviewSiteSettings({ mouseFollowLighting: !prefs.mouseFollowLighting })}
              className={`px-2 py-1.5 border transition-all ${
                prefs.mouseFollowLighting
                  ? 'border-violet-500/40 bg-violet-500/15 text-violet-700 dark:text-violet-300'
                  : 'border-slate-300 dark:border-white/15 text-slate-500 dark:text-slate-400'
              }`}
            >
              Cursor Glow: {prefs.mouseFollowLighting ? 'ON' : 'OFF'}
            </button>
            <button
              type="button"
              onClick={() => onPreviewSiteSettings({ reducedMotionMode: !prefs.reducedMotionMode })}
              className={`px-2 py-1.5 border transition-all ${
                prefs.reducedMotionMode
                  ? 'border-amber-500/40 bg-amber-500/15 text-amber-800 dark:text-amber-300'
                  : 'border-slate-300 dark:border-white/15 text-slate-500 dark:text-slate-400'
              }`}
            >
              Calm Mode: {prefs.reducedMotionMode ? 'ON' : 'OFF'}
            </button>
          </div>
        </motion.div>
      )}

      {showTop && (
        <motion.button
          type="button"
          initial={{ opacity: 0, scale: 0.85, y: 8 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.85 }}
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          aria-label="Scroll to top"
          title="Back to top"
          className="w-10 h-10 btn-prism-cyan shadow-lg flex items-center justify-center"
        >
          <ArrowUp className="w-4 h-4 text-white" />
        </motion.button>
      )}

      {onPreviewSiteSettings && (
        <button
          type="button"
          onClick={() => setLightingMenuOpen((v) => !v)}
          aria-label="Toggle 360° Neon Lighting Controls"
          title="360° Neon Lighting Studio"
          className="w-10 h-10 btn-prism-emerald shadow-lg flex items-center justify-center"
        >
          <Sun className="w-4 h-4 text-white" />
        </button>
      )}

      {onOpenChatbot && (
        <button
          type="button"
          onClick={onOpenChatbot}
          aria-label="Open AI Beauty Concierge Chatbot"
          title="AI Beauty Concierge"
          className="w-10 h-10 btn-prism-cyan shadow-lg flex items-center justify-center"
        >
          <MessageSquare className="w-4 h-4 text-white" />
        </button>
      )}

      <button
        type="button"
        onClick={onOpenShadeFinder}
        aria-label="Open AI Shade Finder"
        title="AI Shade Finder"
        className="w-10 h-10 btn-prism-sunset shadow-lg flex items-center justify-center"
      >
        <Sparkles className="w-4 h-4 text-white" />
      </button>

      <motion.button
        key={bagPulseKey}
        type="button"
        initial={bagPulseKey > 0 ? { scale: 1.2 } : false}
        animate={{ scale: 1 }}
        transition={{ type: 'spring', stiffness: 360, damping: 18 }}
        onClick={onOpenBag}
        aria-label={`Open shopping bag (${bagCount} items)`}
        title="Shopping Bag"
        className="w-11 h-11 btn-futuristic shadow-xl flex items-center justify-center relative"
      >
        <ShoppingBag className="w-4 h-4" />
        {bagCount > 0 && (
          <span className="absolute -top-1.5 -right-1.5 min-w-[20px] h-5 px-1 bg-gradient-to-r from-[#F97316] to-[#EC4899] text-white text-[10px] font-mono font-bold flex items-center justify-center border border-white/80 shadow">
            {bagCount}
          </span>
        )}
      </motion.button>
    </div>
  );
};
