import React, { useEffect, useMemo, useState } from 'react';
import {
  Check,
  Globe,
  Languages,
  RefreshCw,
  Search,
  ShieldCheck,
  Truck,
  X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { CinematicModal } from './MotionPrimitives';
import { useLocalization } from '../context/LocalizationContext';
import {
  ALL_CURRENCIES,
  CountryCode,
  CURRENCY_RATES,
  CurrencyCode,
  formatMoney,
  LanguageCode,
} from '../types/store';
import {
  ALL_COUNTRIES,
  COUNTRY_CONFIGS,
  FEATURED_COUNTRIES,
  SUPPORTED_LANGUAGES,
} from '../lib/localization';

export const CountryCurrencyTrigger: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const { country, currency, language, setSelectorOpen } = useLocalization();

  return (
    <button
      type="button"
      onClick={() => setSelectorOpen(true)}
      aria-label="Change Country, Currency, and Language"
      title={`Shipping to ${country.name} · ${currency} · ${language.toUpperCase()}`}
      className="glow-border px-2.5 py-1.5 border border-indigo-500/25 dark:border-cyan-400/30 bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-cyan-500/10 dark:from-cyan-500/15 dark:via-indigo-500/15 dark:to-fuchsia-500/15 hover:border-[#2563EB] dark:hover:border-[#22D3EE] transition-all flex items-center gap-1.5 text-xs font-semibold text-[#0B1020] dark:text-white whitespace-nowrap shrink-0"
    >
      <span className="text-sm leading-none" aria-hidden="true">
        {country.flag}
      </span>
      <span className="font-mono text-[11px] font-bold text-[#2563EB] dark:text-[#22D3EE]">
        {country.code}
      </span>
      <span className="text-slate-400" aria-hidden="true">
        ·
      </span>
      <span className="font-mono text-[11px] font-bold text-[#7C3AED] dark:text-[#F0ABFC]">
        {currency}
      </span>
      {!compact && (
        <span className="hidden xl:inline text-[10px] uppercase tracking-wider px-1 py-0.5 bg-indigo-500/10 dark:bg-white/10 text-slate-600 dark:text-slate-300">
          {language}
        </span>
      )}
    </button>
  );
};

export const CountryConsentBanner: React.FC = () => {
  const {
    detectedSuggestion,
    countryCode,
    acceptDetectedCountry,
    dismissDetectedCountry,
    setSelectorOpen,
    t,
  } = useLocalization();

  if (!detectedSuggestion || detectedSuggestion.countryCode === countryCode) {
    return null;
  }

  const suggested = detectedSuggestion.country;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 24, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.96 }}
        transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
        role="region"
        aria-label="Regional Localization Consent"
        className="fixed bottom-4 left-4 right-4 sm:right-auto sm:max-w-md z-40 neon-card-orbit bg-white/95 dark:bg-[#0B1022]/95 backdrop-blur-xl border border-indigo-500/35 dark:border-cyan-400/35 shadow-2xl p-4 text-[#0B1020] dark:text-white"
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <span className="text-2xl leading-none mt-0.5" aria-hidden="true">
              {suggested.flag}
            </span>
            <div className="space-y-1">
              <p className="text-xs font-bold uppercase tracking-wider text-[#2563EB] dark:text-[#22D3EE] flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5" />
                {t('loc.consentTitle')} {suggested.name}?
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                Switch to <strong className="text-[#0B1020] dark:text-white">{suggested.currency}</strong>{' '}
                ({CURRENCY_RATES[suggested.currency].symbol}),{' '}
                <strong className="text-[#0B1020] dark:text-white">{suggested.shippingCarrier}</strong>{' '}
                delivery ({suggested.estimatedDelivery}), and local {suggested.taxLabel}.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={dismissDetectedCountry}
            aria-label="Dismiss region suggestion"
            className="p-1 text-slate-400 hover:text-rose-500 transition-colors shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={acceptDetectedCountry}
            className="px-3 py-1.5 btn-futuristic text-xs font-semibold text-white flex items-center gap-1.5"
          >
            <Check className="w-3.5 h-3.5" /> {t('loc.consentAccept')} ({suggested.code} · {suggested.currency})
          </button>
          <button
            type="button"
            onClick={() => setSelectorOpen(true)}
            className="px-2.5 py-1.5 border border-indigo-500/30 dark:border-cyan-400/30 text-xs font-semibold text-indigo-700 dark:text-cyan-300 hover:bg-indigo-50 dark:hover:bg-cyan-500/10 transition-colors"
          >
            {t('loc.consentCustomize')}
          </button>
          <button
            type="button"
            onClick={dismissDetectedCountry}
            className="px-2 py-1.5 text-xs text-slate-500 dark:text-slate-400 hover:text-[#0B1020] dark:hover:text-white transition-colors"
          >
            {t('loc.consentKeep')}
          </button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export const CountryCurrencySelectorModal: React.FC = () => {
  const {
    selectorOpen,
    setSelectorOpen,
    countryCode,
    currency,
    language,
    rates,
    rateSource,
    ratesFetchedAt,
    ratesLoading,
    applyPreferences,
    refreshRates,
    t,
  } = useLocalization();

  const [draftCountry, setDraftCountry] = useState<CountryCode>(countryCode);
  const [draftCurrency, setDraftCurrency] = useState<CurrencyCode>(currency);
  const [draftLanguage, setDraftLanguage] = useState<LanguageCode>(language);
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState<'country' | 'currency' | 'language'>('country');

  useEffect(() => {
    if (selectorOpen) {
      setDraftCountry(countryCode);
      setDraftCurrency(currency);
      setDraftLanguage(language);
      setSearch('');
    }
  }, [selectorOpen, countryCode, currency, language]);

  const previewCountry = COUNTRY_CONFIGS[draftCountry] || COUNTRY_CONFIGS.US;

  const filteredCountries = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return ALL_COUNTRIES;
    return ALL_COUNTRIES.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.nativeName.toLowerCase().includes(q) ||
        c.code.toLowerCase().includes(q) ||
        c.currency.toLowerCase().includes(q) ||
        c.region.toLowerCase().includes(q),
    );
  }, [search]);

  if (!selectorOpen) return null;

  return (
    <CinematicModal
      onBackdropClick={() => setSelectorOpen(false)}
      backdropClassName="flex items-center justify-center p-2 sm:p-6"
      panelClassName="bg-[#F5F7FF] dark:bg-[#06070E] text-[#090B14] dark:text-[#F8FAFF] w-full max-w-4xl border border-indigo-500/30 dark:border-cyan-400/30 shadow-2xl max-h-[92vh] flex flex-col overflow-hidden prism-modal-rim"
    >
      {/* Header */}
      <div className="px-6 py-4 bg-gradient-to-r from-[#0B1026] via-[#261447] to-[#0D2E4D] text-white flex items-center justify-between gap-4 shrink-0">
        <div>
          <div className="flex items-center gap-2">
            <Globe className="w-5 h-5 text-[#22D3EE]" />
            <h2 className="font-display text-xl sm:text-2xl font-bold">{t('loc.title')}</h2>
          </div>
          <p className="text-xs text-slate-300 mt-0.5 max-w-2xl">{t('loc.subtitle')}</p>
        </div>
        <button
          type="button"
          onClick={() => setSelectorOpen(false)}
          aria-label="Close Localization Modal"
          className="p-1.5 hover:bg-white/10 transition-colors shrink-0"
        >
          <X className="w-5 h-5" />
        </button>
      </div>
      <div className="prism-divider shrink-0" />

      {/* Live FX Rate Strip */}
      <div className="px-6 py-2.5 bg-white dark:bg-[#0D1120] border-b border-indigo-500/15 dark:border-cyan-400/15 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex flex-wrap items-center gap-2">
          <span
            className={`px-2 py-0.5 font-mono text-[11px] font-bold ${
              rateSource === 'live'
                ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30'
                : 'bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-500/30'
            }`}
          >
            {rateSource === 'live' ? t('loc.liveRates') : t('loc.refRates')}
          </span>
          <span className="font-mono text-slate-600 dark:text-slate-300">
            1 USD = {rates[draftCurrency]?.toFixed(CURRENCY_RATES[draftCurrency].decimals === 0 ? 2 : 4)} {draftCurrency}
          </span>
          {ratesFetchedAt && (
            <span className="text-[11px] text-slate-500 dark:text-slate-400">
              · Updated {new Date(ratesFetchedAt).toLocaleTimeString()}
            </span>
          )}
        </div>
        <button
          type="button"
          onClick={() => void refreshRates()}
          disabled={ratesLoading}
          className="px-2.5 py-1 border border-indigo-500/25 dark:border-cyan-400/25 text-[11px] font-semibold text-indigo-700 dark:text-cyan-300 hover:bg-indigo-50 dark:hover:bg-cyan-500/10 flex items-center gap-1.5 disabled:opacity-50"
        >
          <RefreshCw className={`w-3 h-3 ${ratesLoading ? 'animate-spin' : ''}`} />
          Refresh FX Rates
        </button>
      </div>

      {/* Mode Tabs */}
      <div className="px-6 pt-3 bg-[#F5F7FF] dark:bg-[#06070E] flex items-center gap-2 border-b border-indigo-500/15 dark:border-cyan-400/15 shrink-0">
        {(
          [
            { id: 'country', label: `${previewCountry.flag} ${t('loc.country')}` },
            { id: 'currency', label: `${CURRENCY_RATES[draftCurrency].symbol} ${t('loc.currency')} (${draftCurrency})` },
            { id: 'language', label: `${t('loc.language')} (${draftLanguage.toUpperCase()})` },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id)}
            className={`px-3.5 py-2 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === tab.id
                ? 'border-[#2563EB] dark:border-[#22D3EE] text-[#2563EB] dark:text-[#22D3EE]'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-[#0B1020] dark:hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 space-y-4">
          {activeTab === 'country' && (
            <>
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search country, ISO code, or currency (India, USA, UK, EU, China, Japan, UAE...)"
                  className="w-full pl-9 pr-3 py-2 bg-white dark:bg-[#0D1120] border border-indigo-500/25 dark:border-cyan-400/25 text-xs"
                />
              </div>

              {!search.trim() && (
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-wider text-indigo-700 dark:text-cyan-300 mb-2">
                    Primary Global Markets
                  </p>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {FEATURED_COUNTRIES.map((c) => {
                      const active = draftCountry === c.code;
                      return (
                        <button
                          key={c.code}
                          type="button"
                          onClick={() => {
                            setDraftCountry(c.code);
                            setDraftCurrency(c.currency);
                            setDraftLanguage(c.defaultLanguage);
                          }}
                          className={`p-2.5 text-left border transition-all flex items-center justify-between gap-2 ${
                            active
                              ? 'border-[#2563EB] dark:border-[#22D3EE] bg-gradient-to-r from-blue-500/15 to-cyan-500/15 shadow-sm'
                              : 'bg-white dark:bg-[#0D1120] border-indigo-500/15 dark:border-white/15 hover:border-indigo-500/40'
                          }`}
                        >
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5">
                              <span className="text-base leading-none">{c.flag}</span>
                              <span className="text-xs font-semibold truncate">{c.name}</span>
                            </div>
                            <p className="text-[10px] font-mono text-slate-500 dark:text-slate-400 mt-0.5">
                              {c.currency} ({CURRENCY_RATES[c.currency].symbol}) · {c.taxRatePercent}% tax
                            </p>
                          </div>
                          {active && <Check className="w-4 h-4 text-[#2563EB] dark:text-[#22D3EE] shrink-0" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              <div>
                <p className="text-[11px] font-bold uppercase tracking-wider text-purple-700 dark:text-fuchsia-300 mb-2">
                  {search.trim() ? `Matching Markets (${filteredCountries.length})` : 'Worldwide Additional Markets'}
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {(search.trim() ? filteredCountries : ALL_COUNTRIES.filter((c) => !c.featured)).map((c) => {
                    const active = draftCountry === c.code;
                    return (
                      <button
                        key={c.code}
                        type="button"
                        onClick={() => {
                          setDraftCountry(c.code);
                          setDraftCurrency(c.currency);
                          setDraftLanguage(c.defaultLanguage);
                        }}
                        className={`p-2.5 text-left border transition-all flex items-center justify-between gap-2 ${
                          active
                            ? 'border-[#2563EB] dark:border-[#22D3EE] bg-gradient-to-r from-blue-500/15 to-cyan-500/15'
                            : 'bg-white dark:bg-[#0D1120] border-indigo-500/15 dark:border-white/15 hover:border-indigo-500/40'
                        }`}
                      >
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="text-base leading-none">{c.flag}</span>
                            <span className="text-xs font-semibold truncate">{c.name}</span>
                          </div>
                          <p className="text-[10px] font-mono text-slate-500 dark:text-slate-400 mt-0.5">
                            {c.currency} · {c.estimatedDelivery}
                          </p>
                        </div>
                        {active && <Check className="w-4 h-4 text-[#2563EB] dark:text-[#22D3EE] shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            </>
          )}

          {activeTab === 'currency' && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {ALL_CURRENCIES.map((code) => {
                const meta = CURRENCY_RATES[code];
                const liveRate = rates[code] ?? meta.rate;
                const active = draftCurrency === code;
                return (
                  <button
                    key={code}
                    type="button"
                    onClick={() => setDraftCurrency(code)}
                    className={`p-3 text-left border transition-all ${
                      active
                        ? 'border-[#2563EB] dark:border-[#22D3EE] bg-gradient-to-r from-blue-500/15 to-purple-500/15'
                        : 'bg-white dark:bg-[#0D1120] border-indigo-500/15 dark:border-white/15 hover:border-indigo-500/40'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-sm font-bold text-[#2563EB] dark:text-[#22D3EE]">
                        {meta.code} ({meta.symbol.trim()})
                      </span>
                      {active && <Check className="w-4 h-4 text-[#2563EB] dark:text-[#22D3EE]" />}
                    </div>
                    <p className="text-xs text-slate-700 dark:text-slate-200 mt-0.5 truncate">{meta.name}</p>
                    <p className="text-[10px] font-mono text-slate-500 dark:text-slate-400 mt-1">
                      1 USD ≈ {liveRate.toFixed(meta.decimals === 0 ? 1 : 3)} {code}
                    </p>
                  </button>
                );
              })}
            </div>
          )}

          {activeTab === 'language' && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {SUPPORTED_LANGUAGES.map((lang) => {
                const active = draftLanguage === lang.code;
                return (
                  <button
                    key={lang.code}
                    type="button"
                    onClick={() => setDraftLanguage(lang.code)}
                    className={`p-3.5 text-left border transition-all flex items-center justify-between ${
                      active
                        ? 'border-[#7C3AED] dark:border-[#22D3EE] bg-gradient-to-r from-purple-500/15 to-cyan-500/15'
                        : 'bg-white dark:bg-[#0D1120] border-indigo-500/15 dark:border-white/15 hover:border-purple-500/40'
                    }`}
                  >
                    <div>
                      <p className="text-sm font-bold">{lang.nativeLabel}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-0.5">
                        <Languages className="w-3 h-3" /> {lang.label} ({lang.code.toUpperCase()})
                      </p>
                    </div>
                    {active && <Check className="w-4 h-4 text-[#7C3AED] dark:text-[#22D3EE]" />}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Right: Regional Policy & Defaults Preview */}
        <div className="lg:col-span-4 space-y-3">
          <div className="neon-card-orbit luminous-surface p-4 bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/25 space-y-3">
            <div className="flex items-center gap-2 border-b border-indigo-500/15 dark:border-white/10 pb-2.5">
              <span className="text-2xl">{previewCountry.flag}</span>
              <div>
                <p className="text-sm font-bold leading-tight">{previewCountry.name}</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  {previewCountry.nativeName} · {previewCountry.region}
                </p>
              </div>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex items-start gap-2">
                <Truck className="w-4 h-4 text-[#2563EB] dark:text-[#22D3EE] shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold">{previewCountry.shippingCarrier}</p>
                  <p className="text-slate-600 dark:text-slate-300">
                    Est. {previewCountry.estimatedDelivery} · Free shipping over{' '}
                    <span className="font-mono font-semibold">
                      {formatMoney(previewCountry.freeShippingThresholdUsd, draftCurrency)}
                    </span>
                  </p>
                </div>
              </div>

              <div className="p-2.5 bg-indigo-500/5 dark:bg-cyan-500/10 border border-indigo-500/15 dark:border-cyan-400/20 space-y-1">
                <p className="font-semibold text-indigo-800 dark:text-cyan-200">
                  Tax &amp; Customs Duty Transparency
                </p>
                <p className="text-[11px] text-slate-700 dark:text-slate-300">
                  • {previewCountry.taxLabel}
                </p>
                <p className="text-[11px] text-slate-600 dark:text-slate-300">
                  • {previewCountry.customsNote}
                </p>
              </div>

              <div className="space-y-1 pt-1">
                <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Regional Size &amp; Compliance
                </p>
                <p className="text-slate-700 dark:text-slate-200">
                  Units: <span className="font-mono font-semibold">{previewCountry.sizeStandard}</span>
                </p>
                <p className="text-[11px] text-emerald-700 dark:text-emerald-300 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 shrink-0" /> {previewCountry.complianceBadge}
                </p>
              </div>

              <div className="space-y-1 pt-1">
                <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Local Payment Options
                </p>
                <div className="flex flex-wrap gap-1">
                  {previewCountry.localPaymentMethods.map((m) => (
                    <span
                      key={m}
                      className="px-2 py-0.5 text-[10px] font-semibold bg-slate-100 dark:bg-white/10 text-slate-700 dark:text-slate-200"
                    >
                      {m}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="p-3 bg-amber-500/10 border border-amber-500/30 text-[11px] text-amber-900 dark:text-amber-200 leading-relaxed">
            <strong>Price Accuracy Guarantee:</strong> Storefront prices in FX-converted currencies are live estimates. Confirmed transaction totals, exchange rates, taxes, and customs duties are locked server-side at checkout.
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="px-6 py-3.5 bg-white dark:bg-[#0D1120] border-t border-indigo-500/15 dark:border-cyan-400/15 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <p className="text-xs text-slate-600 dark:text-slate-300">
          Selected: <strong>{previewCountry.flag} {previewCountry.name}</strong> ·{' '}
          <strong className="font-mono">{draftCurrency}</strong> ·{' '}
          <strong className="uppercase">{draftLanguage}</strong>
        </p>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setSelectorOpen(false)}
            className="px-4 py-2 border border-indigo-500/20 dark:border-white/20 text-xs font-semibold"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => {
              applyPreferences({
                countryCode: draftCountry,
                currency: draftCurrency,
                language: draftLanguage,
              });
              setSelectorOpen(false);
            }}
            className="px-5 py-2 btn-futuristic text-xs font-semibold text-white uppercase tracking-wider"
          >
            {t('loc.save')}
          </button>
        </div>
      </div>
    </CinematicModal>
  );
};
