import React, { useMemo, useState } from 'react';
import {
  ArrowRightLeft,
  Building2,
  CheckCircle2,
  Download,
  FileSpreadsheet,
  PackagePlus,
  Plus,
  Send,
  Shield,
  Truck,
  Warehouse as WarehouseIcon,
} from 'lucide-react';
import { doc, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../lib/firebase';
import { getProductErpDefaults } from '../data/seedErp';
import { motion } from 'motion/react';
import {
  AuditLogEntry,
  CurrencyCode,
  CustomerType,
  ErpLifecycleStatus,
  ErpRole,
  formatMoney,
  GatewayName,
  Order,
  OrderChannel,
  Product,
  PurchaseOrder,
  Supplier,
  SupplierIntegrationType,
  Warehouse,
  WholesaleAccount,
  WholesaleQuote,
} from '../types/store';
import {
  AnimatedBarChart3D,
  AnimatedCounter,
  AnimatedProgressBar,
} from './MotionPrimitives';
import { KPI_COLOR_THEMES, KpiTone } from '../lib/themePalette';

async function writeAuditLog(action: string, entityType: string, entityId: string, details: string) {
  const user = auth.currentUser;
  if (!user) return;
  const id = `audit_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
  try {
    await setDoc(doc(db, 'auditLogs', id), {
      id,
      actorUid: user.uid,
      actorEmail: user.email || '',
      actorRole: 'super_admin',
      action,
      entityType,
      entityId,
      details,
      createdAt: serverTimestamp(),
    });
  } catch {
    // Non-blocking audit record
  }
}

export interface ErpSharedProps {
  products: Product[];
  orders: Order[];
  suppliers: Supplier[];
  purchaseOrders: PurchaseOrder[];
  warehouses: Warehouse[];
  wholesaleAccounts: WholesaleAccount[];
  wholesaleQuotes: WholesaleQuote[];
  auditLogs: AuditLogEntry[];
  currency: CurrencyCode;
  onFeedback: (msg: string) => void;
}

// ============================================================================
// 1. EXECUTIVE MULTI-CHANNEL OVERVIEW & CSV REPORT EXPORTS
// ============================================================================
export const ErpOverviewSection: React.FC<ErpSharedProps> = ({
  products,
  orders,
  suppliers,
  purchaseOrders,
  wholesaleAccounts,
  currency,
  onFeedback,
}) => {
  const stats = useMemo(() => {
    const valid = orders.filter((o) => o.paymentStatus !== 'failed' && o.orderStatus !== 'cancelled');
    const totalRev = valid.reduce((s, o) => s + o.total, 0);
    const onlineRev = valid
      .filter((o) => (o.salesChannel || 'D2C_ONLINE') === 'D2C_ONLINE')
      .reduce((s, o) => s + o.total, 0);
    const wholesaleRev = valid
      .filter((o) => o.salesChannel === 'WHOLESALE_B2B')
      .reduce((s, o) => s + o.total, 0);
    const offlineRev = valid
      .filter((o) => o.salesChannel === 'OFFLINE_DIRECT' || o.salesChannel === 'MARKETPLACE')
      .reduce((s, o) => s + o.total, 0);
    const netProfit = valid.reduce((s, o) => s + (o.netProfit ?? o.total * 0.45), 0);
    const supplierPayables = purchaseOrders
      .filter((p) => p.status !== 'rejected')
      .reduce((s, p) => s + p.totalCost + p.shippingCost + p.packagingCost, 0);
    const customerReceivables = valid
      .filter((o) => o.paymentStatus === 'pending')
      .reduce((s, o) => s + o.total, 0);
    const inventoryValuation = products.reduce((s, p, idx) => {
      const erp = getProductErpDefaults(p, idx);
      const owned = p.ownedStock ?? erp.ownedStock;
      return s + owned * (p.purchasePrice ?? erp.purchasePrice);
    }, 0);
    const pendingPos = purchaseOrders.filter((p) => p.status === 'pending_dispatch' || p.status === 'sent').length;
    const pendingB2B = wholesaleAccounts.filter((w) => w.status === 'pending').length;
    return {
      totalRev,
      onlineRev,
      wholesaleRev,
      offlineRev,
      netProfit,
      supplierPayables,
      customerReceivables,
      inventoryValuation,
      pendingActions: pendingPos + pendingB2B,
    };
  }, [orders, purchaseOrders, products, wholesaleAccounts]);

  const exportReport = async (reportType: 'pnl' | 'channels' | 'suppliers' | 'inventory') => {
    try {
      const res = await fetch('/api/erp/export-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reportType, orders, products, suppliers }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Export failed');
      const blob = new Blob([data.csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = data.filename;
      a.click();
      URL.revokeObjectURL(url);
      onFeedback(`Exported ${data.filename} (${data.rowCount} rows).`);
    } catch (err) {
      onFeedback(err instanceof Error ? err.message : 'Report export error.');
    }
  };

  const channelShareMax = Math.max(1, stats.totalRev);

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.28 }}
      className="space-y-5"
    >
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {(
          [
            { label: 'Total Gross Revenue', num: stats.totalRev, money: true, tone: 'revenue' as KpiTone },
            { label: 'Online D2C Revenue', num: stats.onlineRev, money: true, tone: 'payments' as KpiTone },
            { label: 'Wholesale B2B Revenue', num: stats.wholesaleRev, money: true, tone: 'wholesale' as KpiTone },
            { label: 'Offline & Field Revenue', num: stats.offlineRev, money: true, tone: 'orders' as KpiTone },
            { label: 'Estimated Net Profit', num: stats.netProfit, money: true, tone: 'profit' as KpiTone },
            { label: 'Owned Warehouse Valuation', num: stats.inventoryValuation, money: true, tone: 'inventory' as KpiTone },
            { label: 'Supplier Payables (POs)', num: stats.supplierPayables, money: true, tone: 'suppliers' as KpiTone },
            { label: 'Pending Approvals / POs', num: stats.pendingActions, money: false, tone: 'notifications' as KpiTone },
          ]
        ).map((kpi, idx) => {
          const theme = KPI_COLOR_THEMES[kpi.tone];
          return (
            <motion.div
              key={kpi.label}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25, delay: idx * 0.03 }}
              className={`neon-card-orbit ${theme.cardBg} border ${theme.border} overflow-hidden glow-border holographic-card`}
            >
              <div className={`h-1 w-full ${theme.topBar}`} />
              <div className="p-4">
                <p className={`text-[11px] uppercase tracking-wider font-bold ${theme.subText}`}>{kpi.label}</p>
                <p className={`font-mono text-xl font-bold tabular-nums mt-1.5 ${theme.valueText}`}>
                  <AnimatedCounter
                    value={kpi.num}
                    formatter={(v) => (kpi.money ? formatMoney(v, currency) : String(Math.round(v)))}
                  />
                </p>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* 3D Interactive Revenue & Margin Visualization + Live Channel Mix */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-7">
          <AnimatedBarChart3D
            title="3D Multi-Channel Revenue & P&L Telemetry"
            subtitle="Hover bars to inspect channel gross revenue and estimated net profit"
            data={[
              {
                label: 'Online D2C',
                value: stats.onlineRev,
                formattedValue: formatMoney(stats.onlineRev, currency),
                secondaryFormatted: formatMoney(stats.onlineRev * 0.46, currency),
              },
              {
                label: 'Wholesale B2B',
                value: stats.wholesaleRev,
                formattedValue: formatMoney(stats.wholesaleRev, currency),
                secondaryFormatted: formatMoney(stats.wholesaleRev * 0.34, currency),
              },
              {
                label: 'Offline / Field',
                value: stats.offlineRev,
                formattedValue: formatMoney(stats.offlineRev, currency),
                secondaryFormatted: formatMoney(stats.offlineRev * 0.42, currency),
              },
              {
                label: 'Net Profit',
                value: stats.netProfit,
                formattedValue: formatMoney(stats.netProfit, currency),
              },
              {
                label: 'PO Payables',
                value: stats.supplierPayables,
                formattedValue: formatMoney(stats.supplierPayables, currency),
              },
            ]}
          />
        </div>
        <div className="neon-card-orbit lg:col-span-5 bg-white dark:bg-[#0D1120] border border-purple-500/25 dark:border-fuchsia-400/25 p-5 space-y-4 flex flex-col justify-between glow-border">
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold text-sm gradient-heading-warm">Real-Time Channel Mix & Receivables</h4>
              <p className="text-xs text-[#434C66] dark:text-slate-300">
                Unified retail, B2B dealer, offline, and profit margin health
              </p>
            </div>
            <AnimatedProgressBar
              label="Online D2C Storefront Share"
              valueLabel={`${Math.round((stats.onlineRev / channelShareMax) * 100)}%`}
              percent={(stats.onlineRev / channelShareMax) * 100}
              tone="cyan"
            />
            <AnimatedProgressBar
              label="Wholesale & Distributor Share"
              valueLabel={`${Math.round((stats.wholesaleRev / channelShareMax) * 100)}%`}
              percent={(stats.wholesaleRev / channelShareMax) * 100}
              tone="orange"
            />
            <AnimatedProgressBar
              label="Offline, WhatsApp & Field Sales"
              valueLabel={`${Math.round((stats.offlineRev / channelShareMax) * 100)}%`}
              percent={(stats.offlineRev / channelShareMax) * 100}
              tone="violet"
            />
            <AnimatedProgressBar
              label="Net Profit Margin Ratio"
              valueLabel={`${stats.totalRev > 0 ? Math.round((stats.netProfit / stats.totalRev) * 100) : 0}%`}
              percent={stats.totalRev > 0 ? (stats.netProfit / stats.totalRev) * 100 : 0}
              tone="emerald"
            />
          </div>
          <div className="pt-3 border-t border-indigo-500/15 dark:border-cyan-400/15 flex justify-between text-xs">
            <span className="text-[#434C66] dark:text-slate-300 font-medium">Open Customer Receivables</span>
            <span className="font-mono font-bold text-[#F97316] dark:text-[#FBBF24]">
              {formatMoney(stats.customerReceivables, currency)}
            </span>
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-50 via-purple-50/70 to-emerald-50/80 dark:from-[#0C1429] dark:via-[#141028] dark:to-[#0A1E22] border border-indigo-500/20 dark:border-cyan-400/25 p-4 flex flex-wrap items-center justify-between gap-3">
        <p className="text-xs font-bold gradient-heading">Executive ERP Reports & Ledger Exports</p>
        <div className="flex flex-wrap gap-2">
          {(
            [
              ['pnl', 'P&L Statement CSV', 'btn-prism-emerald'],
              ['channels', 'Channel Breakdown CSV', 'btn-prism-cyan'],
              ['inventory', 'Warehouse Stock CSV', 'btn-prism-gold'],
              ['suppliers', 'Supplier Scorecard CSV', 'btn-futuristic'],
            ] as const
          ).map(([type, label, btnClass]) => (
            <button
              key={type}
              type="button"
              onClick={() => exportReport(type)}
              className={`px-3 py-1.5 ${btnClass} text-xs font-semibold flex items-center gap-1.5`}
            >
              <Download className="w-3.5 h-3.5" /> {label}
            </button>
          ))}
        </div>
      </div>
    </motion.div>
  );
};

// ============================================================================
// 2. MULTI-CHANNEL ORDER ENGINE, MANUAL ORDER ENTRY & LIFECYCLE WORKFLOW
// ============================================================================
const ORDER_CHANNELS: OrderChannel[] = [
  'Offline Sales',
  'WhatsApp Orders',
  'Phone Orders',
  'Field Sales',
  'Retailer Orders',
  'Dealer Orders',
  'Distributor Orders',
  'Social Media Orders',
  'Marketplace Orders',
  'Admin Created Orders',
];

const ERP_LIFECYCLE: ErpLifecycleStatus[] = [
  'NEW',
  'PAYMENT_PENDING',
  'PAYMENT_CONFIRMED',
  'ORDER_VERIFIED',
  'ROUTING',
  'SUPPLIER_ASSIGNED',
  'PURCHASE_ORDER_CREATED',
  'SUPPLIER_ACCEPTED',
  'PROCESSING',
  'PACKED',
  'SHIPPED',
  'IN_TRANSIT',
  'OUT_FOR_DELIVERY',
  'DELIVERED',
  'ON_HOLD',
  'MANUAL_REVIEW',
  'SUPPLIER_DELAYED',
  'RETURN_REQUESTED',
  'RETURNED',
  'REFUNDED',
  'CANCELLED',
];

export const ErpOrdersRoutingSection: React.FC<ErpSharedProps> = ({
  products,
  orders,
  suppliers,
  currency,
  onFeedback,
}) => {
  const [channelFilter, setChannelFilter] = useState<
    'all' | 'online' | 'offline' | 'wholesale' | 'dropship' | 'own' | 'pending' | 'returns'
  >('all');
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);

  // Manual Offline / Wholesale Order Creator State
  const [orderSource, setOrderSource] = useState<OrderChannel>('Offline Sales');
  const [customerType, setCustomerType] = useState<CustomerType>('wholesale');
  const [custName, setCustName] = useState('');
  const [custEmail, setCustEmail] = useState('');
  const [custPhone, setCustPhone] = useState('');
  const [selectedProdId, setSelectedProdId] = useState(products[0]?.id || '');
  const [qty, setQty] = useState('12');
  const [gateway, setGateway] = useState<GatewayName>('COD');
  const [salesRep, setSalesRep] = useState('Aarav Mehta');
  const [creating, setCreating] = useState(false);

  const filteredOrders = useMemo(() => {
    return orders.filter((o) => {
      if (channelFilter === 'online') return (o.salesChannel || 'D2C_ONLINE') === 'D2C_ONLINE';
      if (channelFilter === 'offline') return o.salesChannel === 'OFFLINE_DIRECT';
      if (channelFilter === 'wholesale') return o.salesChannel === 'WHOLESALE_B2B' || (o.customerType && o.customerType !== 'retail');
      if (channelFilter === 'dropship') return o.fulfillmentType === 'dropshipping' || o.fulfillmentType === 'private_label' || o.fulfillmentType === 'mixed_split';
      if (channelFilter === 'own') return (o.fulfillmentType || 'own_inventory') === 'own_inventory';
      if (channelFilter === 'pending') return o.paymentStatus === 'pending' || o.erpStatus === 'ON_HOLD' || o.erpStatus === 'MANUAL_REVIEW';
      if (channelFilter === 'returns') return o.orderStatus === 'cancelled' || o.orderStatus === 'returned' || o.orderStatus === 'return_requested';
      return true;
    });
  }, [orders, channelFilter]);

  const createManualOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    const prodIdx = products.findIndex((p) => p.id === selectedProdId);
    const prod = products[prodIdx] || products[0];
    if (!prod) return;

    const uid = auth.currentUser?.uid || 'admin_manual';
    const orderId = `ord_erp_${Date.now()}`;
    const erp = getProductErpDefaults(prod, Math.max(0, prodIdx));
    const unitQty = Math.max(1, Math.round(Number(qty) || 1));
    const unitPrice =
      customerType === 'distributor'
        ? prod.distributorPrice ?? erp.distributorPrice
        : customerType === 'dealer'
          ? prod.dealerPrice ?? erp.dealerPrice
          : customerType === 'wholesale'
            ? prod.wholesalePrice ?? erp.wholesalePrice
            : prod.price;

    setCreating(true);
    try {
      const routeRes = await fetch('/api/orders/route', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId,
          orderSource,
          customerType,
          paymentGateway: gateway,
          discount: 0,
          shippingCost: 12,
          requestedPackagingType: customerType === 'retail' ? 'custom_brand_box' : 'wholesale_master_carton',
          items: [
            {
              productId: prod.id,
              name: prod.name,
              sku: prod.sku,
              shadeName: prod.shades[0]?.name || 'Signature',
              shadeHex: prod.shades[0]?.hex || '#9E1B32',
              quantity: unitQty,
              unitPrice,
              purchasePrice: erp.purchasePrice,
              supplierId: erp.supplierId,
              supplierSku: erp.supplierSku,
              warehouseId: erp.warehouseId,
              fulfillmentMethod: erp.fulfillmentMethod,
              ownedStock: erp.ownedStock,
              supplierStock: erp.supplierStock,
            },
          ],
          suppliers: suppliers.map((s) => ({
            id: s.id,
            companyName: s.companyName,
            email: s.email,
            integrationType: s.integrationType,
            leadTimeDays: s.leadTimeDays,
            privateLabelCapable: s.privateLabelCapable,
          })),
        }),
      });
      const routed = await routeRes.json();
      if (!routeRes.ok) throw new Error(routed.error || 'Routing failed');

      const poIds = (routed.purchaseOrders || []).map((p: { id: string }) => p.id);
      const subtotal = Number((unitPrice * unitQty).toFixed(2));

      await setDoc(doc(db, 'orders', orderId), {
        id: orderId,
        userId: uid,
        customerName: custName.trim() || 'Manual B2B Client',
        customerEmail: custEmail.trim() || auth.currentUser?.email || '',
        items: [
          {
            productId: prod.id,
            name: prod.name,
            shadeName: prod.shades[0]?.name || 'Signature',
            shadeHex: prod.shades[0]?.hex || '#9E1B32',
            quantity: unitQty,
            unitPrice,
            purchaseCost: Number((erp.purchasePrice * unitQty).toFixed(2)),
            supplierId: erp.supplierId,
            fulfillmentMethod: erp.fulfillmentMethod,
          },
        ],
        subtotal,
        discount: 0,
        total: Number((subtotal + 12).toFixed(2)),
        currency,
        paymentGateway: gateway,
        paymentMethod: gateway === 'COD' ? 'Offline / Net Invoice' : gateway,
        paymentStatus: gateway === 'COD' ? 'pending' : 'paid',
        orderStatus: 'confirmed',
        trackingNumber: `ERP-${Math.floor(100000 + Math.random() * 899999)}`,
        shippingAddress: {
          id: 'manual_addr',
          label: orderSource,
          fullName: custName.trim() || 'Manual B2B Client',
          phone: custPhone.trim() || '+91 98200 00000',
          line1: 'Commercial Dispatch Desk',
          city: 'Mumbai',
          state: 'MH',
          postalCode: '400051',
          country: 'India',
        },
        refundStatus: 'none',
        refundAmount: 0,
        orderSource,
        salesChannel: routed.salesChannel,
        customerType,
        fulfillmentType: routed.fulfillmentType,
        erpStatus: routed.erpStatus,
        warehouseId: routed.warehouseId,
        ...(poIds.length > 0 ? { supplierOrderIds: poIds } : {}),
        purchaseCost: routed.financials?.purchaseCost ?? 0,
        shippingCost: 12,
        packagingCost: routed.financials?.packagingCost ?? 1.85,
        gatewayFee: routed.financials?.gatewayFee ?? 0,
        taxAmount: routed.financials?.taxAmount ?? 0,
        grossProfit: routed.financials?.grossProfit ?? 0,
        netProfit: routed.financials?.netProfit ?? 0,
        salesRepName: salesRep.trim(),
        timeline: routed.timeline || [],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      for (const po of routed.purchaseOrders || []) {
        await setDoc(doc(db, 'purchaseOrders', po.id), {
          ...po,
          customerUid: uid,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }

      await writeAuditLog('CREATE_MANUAL_ORDER', 'order', orderId, `${orderSource} (${customerType}) routed via ${routed.fulfillmentType}`);
      setCustName('');
      setCustEmail('');
      onFeedback(`Created & routed ${orderSource} order #${orderId} (${routed.fulfillmentType}).`);
    } catch (err) {
      onFeedback(err instanceof Error ? err.message : 'Could not create manual order.');
    } finally {
      setCreating(false);
    }
  };

  const updateErpStatus = async (order: Order, nextErp: ErpLifecycleStatus) => {
    try {
      const nextTimeline = [
        ...(order.timeline || []),
        {
          stage: nextErp,
          timestamp: new Date().toISOString(),
          actor: auth.currentUser?.email || 'Admin ERP',
          note: `Transitioned lifecycle to ${nextErp}`,
        },
      ].slice(-30);

      await updateDoc(doc(db, 'orders', order.id), {
        erpStatus: nextErp,
        timeline: nextTimeline,
        updatedAt: serverTimestamp(),
      });
      await writeAuditLog('UPDATE_ORDER_LIFECYCLE', 'order', order.id, `ERP status -> ${nextErp}`);
      onFeedback(`Order #${order.id} ERP lifecycle -> ${nextErp}.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${order.id}`);
    }
  };

  const detailOrder = orders.find((o) => o.id === selectedOrderId) || null;

  return (
    <div className="space-y-6">
      {/* Manual Offline / Field / Phone / WhatsApp Order Creator */}
      <form
        onSubmit={createManualOrder}
        className="bg-white dark:bg-[#0D1120] border border-violet-500/25 dark:border-purple-400/25 p-5 space-y-3 glow-border"
      >
        <div className="flex items-center justify-between">
          <h3 className="font-display text-lg font-bold gradient-heading">Create Manual / Offline / Field / Wholesale Order</h3>
          <span className="text-[11px] font-mono font-semibold text-[#7C3AED] dark:text-[#22D3EE]">Auto-Routed via ERP Engine</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 text-xs">
          <select
            value={orderSource}
            onChange={(e) => setOrderSource(e.target.value as OrderChannel)}
            className="px-2.5 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#0B1020] dark:text-white"
          >
            {ORDER_CHANNELS.map((ch) => (
              <option key={ch} value={ch}>
                {ch}
              </option>
            ))}
          </select>
          <select
            value={customerType}
            onChange={(e) => setCustomerType(e.target.value as CustomerType)}
            className="px-2.5 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#0B1020] dark:text-white"
          >
            <option value="retail">Retail Tier</option>
            <option value="wholesale">Wholesale Tier</option>
            <option value="dealer">Dealer Tier</option>
            <option value="distributor">Distributor Tier</option>
            <option value="enterprise">Enterprise Tier</option>
          </select>
          <input
            type="text"
            required
            placeholder="Client / Business Name"
            value={custName}
            onChange={(e) => setCustName(e.target.value)}
            className="px-2.5 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#0B1020] dark:text-white"
          />
          <input
            type="text"
            placeholder="Sales Rep Name"
            value={salesRep}
            onChange={(e) => setSalesRep(e.target.value)}
            className="px-2.5 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#0B1020] dark:text-white"
          />
          <select
            value={selectedProdId}
            onChange={(e) => setSelectedProdId(e.target.value)}
            className="sm:col-span-2 px-2.5 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#0B1020] dark:text-white"
          >
            {products.map((p) => (
              <option key={p.id} value={p.id}>
                {p.sku} — {p.name}
              </option>
            ))}
          </select>
          <div className="flex gap-2">
            <input
              type="number"
              min={1}
              value={qty}
              onChange={(e) => setQty(e.target.value)}
              placeholder="Qty"
              className="w-24 px-2.5 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#0B1020] dark:text-white font-mono"
            />
            <select
              value={gateway}
              onChange={(e) => setGateway(e.target.value as GatewayName)}
              className="flex-1 px-2.5 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#0B1020] dark:text-white"
            >
              <option value="COD">Invoice / COD</option>
              <option value="Razorpay">Razorpay</option>
              <option value="Stripe">Stripe</option>
            </select>
          </div>
          <button
            type="submit"
            disabled={creating}
            className="px-4 py-2 btn-prism-sunset text-white font-semibold uppercase tracking-wider"
          >
            {creating ? 'Routing...' : 'Create & Route Order'}
          </button>
        </div>
      </form>

      {/* Channel Tabs */}
      <div className="flex flex-wrap gap-1.5">
        {(
          [
            ['all', `All (${orders.length})`, 'btn-futuristic'],
            ['online', 'Online Store', 'btn-prism-cyan'],
            ['offline', 'Offline / Field', 'btn-prism-sunset'],
            ['wholesale', 'Wholesale / B2B', 'btn-prism-gold'],
            ['dropship', 'Dropship & Private Label', 'btn-prism-emerald'],
            ['own', 'Own Warehouse', 'btn-prism-cyan'],
            ['pending', 'Pending / Hold', 'btn-prism-gold'],
            ['returns', 'Returns / Cancelled', 'btn-prism-sunset'],
          ] as const
        ).map(([id, label, activeBtn]) => (
          <button
            key={id}
            type="button"
            onClick={() => setChannelFilter(id)}
            className={`px-3 py-1.5 text-xs border transition-all ${
              channelFilter === id
                ? `${activeBtn} border-transparent text-white font-semibold`
                : 'bg-white dark:bg-[#0D1120] border-indigo-500/20 dark:border-cyan-400/20 text-[#334155] dark:text-slate-200 hover:border-[#7C3AED]'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* High-Density Orders Table */}
      <div className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="border-b border-indigo-500/20 dark:border-cyan-400/20 text-[#1E293B] dark:text-cyan-200 uppercase tracking-wider font-bold">
              <th className="py-3 px-3">Order ID</th>
              <th className="py-3 px-3">Source & Tier</th>
              <th className="py-3 px-3">Fulfillment</th>
              <th className="py-3 px-3 text-right">Total</th>
              <th className="py-3 px-3 text-right">Net Profit</th>
              <th className="py-3 px-3">ERP Lifecycle</th>
              <th className="py-3 px-3 text-right">Inspect</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-indigo-500/10 dark:divide-cyan-400/10">
            {filteredOrders.map((ord) => (
              <tr key={ord.id}>
                <td className="py-2.5 px-3 font-mono font-bold text-[#2563EB] dark:text-[#38BDF8]">{ord.id}</td>
                <td className="py-2.5 px-3">
                  <p className="font-semibold text-[#0B1020] dark:text-white">{ord.orderSource || 'Online Store'}</p>
                  <p className="text-[11px] text-[#7C3AED] dark:text-[#C4B5FD] uppercase font-medium">{ord.customerType || 'retail'}</p>
                </td>
                <td className="py-2.5 px-3 text-[11px]">
                  <p className="capitalize font-medium">{(ord.fulfillmentType || 'own_inventory').replace(/_/g, ' ')}</p>
                  {ord.supplierOrderIds && ord.supplierOrderIds.length > 0 && (
                    <p className="font-mono text-[#14B8A6] dark:text-[#2DD4BF] font-semibold">
                      {ord.supplierOrderIds.length} PO(s)
                    </p>
                  )}
                </td>
                <td className="py-2.5 px-3 text-right font-mono font-semibold tabular-nums">{formatMoney(ord.total, currency)}</td>
                <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-[#059669] dark:text-[#34D399]">
                  {formatMoney(ord.netProfit ?? ord.total * 0.45, currency)}
                </td>
                <td className="py-2.5 px-3">
                  <select
                    value={ord.erpStatus || 'PAYMENT_CONFIRMED'}
                    onChange={(e) => updateErpStatus(ord, e.target.value as ErpLifecycleStatus)}
                    className="px-2 py-1 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[11px] font-mono"
                  >
                    {ERP_LIFECYCLE.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                </td>
                <td className="py-2.5 px-3 text-right">
                  <button
                    type="button"
                    onClick={() => setSelectedOrderId(selectedOrderId === ord.id ? null : ord.id)}
                    className="px-2.5 py-1 btn-prism-outline text-[#2563EB] dark:text-[#22D3EE] font-semibold"
                  >
                    {selectedOrderId === ord.id ? 'Hide' : 'Details'}
                  </button>
                </td>
              </tr>
            ))}
            {filteredOrders.length === 0 && (
              <tr>
                <td colSpan={7} className="p-6 text-center text-[#434C66] dark:text-slate-400">
                  No orders matching this channel filter.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {detailOrder && (
        <div className="bg-gradient-to-br from-blue-50/80 via-white to-fuchsia-50/70 dark:from-[#0C152B] dark:via-[#0D1120] dark:to-[#1B1028] border border-[#2563EB]/40 dark:border-[#22D3EE]/40 p-5 grid grid-cols-1 md:grid-cols-2 gap-5 text-xs glow-border">
          <div className="space-y-2">
            <p className="font-mono font-bold text-sm gradient-heading">Profitability & Routing Breakdown · #{detailOrder.id}</p>
            <div className="grid grid-cols-2 gap-1.5 font-mono tabular-nums bg-white/90 dark:bg-[#0A0E1B] p-3 border border-indigo-500/20 dark:border-cyan-400/20">
              <span>Revenue: <strong className="text-[#2563EB] dark:text-[#38BDF8]">{formatMoney(detailOrder.total, currency)}</strong></span>
              <span>COGS: {formatMoney(detailOrder.purchaseCost ?? 0, currency)}</span>
              <span>Packaging: {formatMoney(detailOrder.packagingCost ?? 0, currency)}</span>
              <span>Shipping: {formatMoney(detailOrder.shippingCost ?? 0, currency)}</span>
              <span>Gateway Fee: {formatMoney(detailOrder.gatewayFee ?? 0, currency)}</span>
              <span className="font-bold text-[#059669] dark:text-[#34D399]">
                Net Profit: {formatMoney(detailOrder.netProfit ?? 0, currency)}
              </span>
            </div>
            {detailOrder.supplierOrderIds && detailOrder.supplierOrderIds.length > 0 && (
              <p className="font-mono text-[11px] text-[#7C3AED] dark:text-[#C4B5FD]">Child PO IDs: {detailOrder.supplierOrderIds.join(', ')}</p>
            )}
          </div>
          <div className="space-y-1.5">
            <p className="font-bold uppercase tracking-wider text-[11px] text-[#EC4899] dark:text-[#F472B6]">Order Audit Timeline</p>
            {(detailOrder.timeline || []).length === 0 ? (
              <p className="text-[#434C66] dark:text-slate-400">Initial checkout confirmed.</p>
            ) : (
              detailOrder.timeline!.map((t, i) => (
                <div key={i} className="border-b border-indigo-500/10 dark:border-white/10 pb-1">
                  <span className="font-mono font-bold text-[#2563EB] dark:text-[#22D3EE]">{t.stage}</span> · {t.actor}
                  {t.note && <p className="text-[#434C66] dark:text-slate-300">{t.note}</p>}
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// 3. MULTI-WAREHOUSE SEPARATED STOCK POOLS & PURCHASE RECEIVING
// ============================================================================
export const ErpWarehouseInventorySection: React.FC<ErpSharedProps> = ({
  products,
  warehouses,
  currency,
  onFeedback,
}) => {
  const [whName, setWhName] = useState('');
  const [whCode, setWhCode] = useState('');
  const [whCity, setWhCity] = useState('');
  const [whCountry, setWhCountry] = useState('India');
  const [whManager, setWhManager] = useState('');

  const addWarehouse = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!whName.trim() || !whCode.trim()) return;
    const id = `wh_${Date.now()}`;
    try {
      await setDoc(doc(db, 'warehouses', id), {
        id,
        name: whName.trim(),
        code: whCode.trim().toUpperCase(),
        city: whCity.trim() || 'Mumbai',
        country: whCountry.trim(),
        managerName: whManager.trim() || 'Operations Lead',
        capacityUnits: 30000,
        active: true,
        updatedAt: serverTimestamp(),
      });
      await writeAuditLog('CREATE_WAREHOUSE', 'warehouse', id, `Added warehouse ${whCode}`);
      setWhName('');
      setWhCode('');
      onFeedback(`Warehouse ${whCode.toUpperCase()} added.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `warehouses/${id}`);
    }
  };

  const adjustPool = async (prod: Product, idx: number, action: 'receive_incoming' | 'transfer_wh' | 'mark_damaged') => {
    const erp = getProductErpDefaults(prod, idx);
    const owned = prod.ownedStock ?? erp.ownedStock;
    const incoming = prod.incomingStock ?? erp.incomingStock;
    const damaged = prod.damagedStock ?? erp.damagedStock;

    try {
      if (action === 'receive_incoming') {
        const delta = Math.min(20, Math.max(10, incoming));
        await updateDoc(doc(db, 'products', prod.id), {
          ownedStock: owned + delta,
          stock: prod.stock + delta,
          incomingStock: Math.max(0, incoming - delta),
          updatedAt: serverTimestamp(),
        });
        await writeAuditLog('RECEIVE_STOCK', 'product', prod.id, `Received +${delta} units into owned warehouse stock`);
        onFeedback(`Received +${delta} units of ${prod.sku} into Owned Stock.`);
      } else if (action === 'transfer_wh') {
        const nextWh = warehouses.find((w) => w.id !== (prod.warehouseId || erp.warehouseId))?.id || 'wh_paris_atelier';
        await updateDoc(doc(db, 'products', prod.id), {
          warehouseId: nextWh,
          updatedAt: serverTimestamp(),
        });
        await writeAuditLog('TRANSFER_WAREHOUSE', 'product', prod.id, `Transferred hub -> ${nextWh}`);
        onFeedback(`Transferred ${prod.sku} allocation to warehouse ${nextWh}.`);
      } else {
        await updateDoc(doc(db, 'products', prod.id), {
          ownedStock: Math.max(0, owned - 1),
          stock: Math.max(0, prod.stock - 1),
          damagedStock: damaged + 1,
          updatedAt: serverTimestamp(),
        });
        await writeAuditLog('MARK_DAMAGED', 'product', prod.id, 'Moved 1 unit to damaged stock pool');
        onFeedback(`Moved 1 unit of ${prod.sku} to Damaged Stock pool.`);
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `products/${prod.id}`);
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {warehouses.map((w, idx) => {
          const topBar = [
            'bg-gradient-to-r from-[#F59E0B] to-[#F97316]',
            'bg-gradient-to-r from-[#06B6D4] to-[#2563EB]',
            'bg-gradient-to-r from-[#10B981] to-[#14B8A6]',
          ][idx % 3];
          return (
            <div key={w.id} className="bg-white dark:bg-[#0D1120] border border-amber-500/25 dark:border-amber-400/25 overflow-hidden glow-border text-xs">
              <div className={`h-1 w-full ${topBar}`} />
              <div className="p-4 space-y-1">
                <div className="flex justify-between items-center">
                  <span className="font-mono font-bold text-[#D97706] dark:text-[#FBBF24] flex items-center gap-1.5">
                    <WarehouseIcon className="w-3.5 h-3.5" /> {w.code}
                  </span>
                  <span className="font-mono font-bold text-[#10B981] dark:text-[#34D399]">{w.active ? 'ACTIVE' : 'INACTIVE'}</span>
                </div>
                <p className="font-semibold text-sm text-[#0B1020] dark:text-white">{w.name}</p>
                <p className="text-[#434C66] dark:text-slate-300">
                  {w.city}, {w.country} · Lead: {w.managerName}
                </p>
                <p className="font-mono tabular-nums text-[11px] text-[#2563EB] dark:text-[#22D3EE] font-semibold">
                  Capacity: {w.capacityUnits.toLocaleString()} units
                </p>
              </div>
            </div>
          );
        })}
      </div>

      <form onSubmit={addWarehouse} className="bg-white dark:bg-[#0D1120] border border-amber-500/25 dark:border-amber-400/25 p-4 grid grid-cols-2 sm:grid-cols-6 gap-2 text-xs">
        <input type="text" required placeholder="Warehouse Name" value={whName} onChange={(e) => setWhName(e.target.value)} className="sm:col-span-2 px-2.5 py-1.5 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30]" />
        <input type="text" required placeholder="Code (BLR-01)" value={whCode} onChange={(e) => setWhCode(e.target.value)} className="px-2.5 py-1.5 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] font-mono uppercase" />
        <input type="text" placeholder="City" value={whCity} onChange={(e) => setWhCity(e.target.value)} className="px-2.5 py-1.5 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30]" />
        <input type="text" placeholder="Manager" value={whManager} onChange={(e) => setWhManager(e.target.value)} className="px-2.5 py-1.5 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30]" />
        <button type="submit" className="btn-prism-gold text-white font-semibold uppercase tracking-wider px-3 py-1.5">
          + Warehouse
        </button>
      </form>

      {/* Separated Stock Pools Matrix */}
      <div className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="border-b border-indigo-500/20 dark:border-cyan-400/20 text-[#1E293B] dark:text-cyan-200 uppercase tracking-wider font-bold">
              <th className="py-3 px-3">SKU & Hub</th>
              <th className="py-3 px-2 text-right">Purchase / B2B</th>
              <th className="py-3 px-2 text-right">Owned</th>
              <th className="py-3 px-2 text-right">Supplier</th>
              <th className="py-3 px-2 text-right">Reserved</th>
              <th className="py-3 px-2 text-right">Incoming</th>
              <th className="py-3 px-2 text-right">Damaged</th>
              <th className="py-3 px-3 text-right">Warehouse Ops</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-indigo-500/10 dark:divide-cyan-400/10">
            {products.map((p, idx) => {
              const erp = getProductErpDefaults(p, idx);
              return (
                <tr key={p.id}>
                  <td className="py-2.5 px-3">
                    <p className="font-semibold text-[#0B1020] dark:text-white">{p.name}</p>
                    <p className="font-mono text-[11px] text-[#434C66] dark:text-slate-300">
                      {p.sku} · Hub: {p.warehouseId || erp.warehouseId} · {erp.fulfillmentMethod}
                    </p>
                  </td>
                  <td className="py-2.5 px-2 text-right font-mono tabular-nums text-[11px]">
                    Cost {formatMoney(p.purchasePrice ?? erp.purchasePrice, currency)} / Dlr{' '}
                    {formatMoney(p.dealerPrice ?? erp.dealerPrice, currency)}
                  </td>
                  <td className="py-2.5 px-2 text-right font-mono tabular-nums font-bold text-[#059669] dark:text-[#34D399]">
                    {p.ownedStock ?? erp.ownedStock}
                  </td>
                  <td className="py-2.5 px-2 text-right font-mono tabular-nums font-semibold text-[#2563EB] dark:text-[#22D3EE]">
                    {p.supplierStock ?? erp.supplierStock}
                  </td>
                  <td className="py-2.5 px-2 text-right font-mono tabular-nums text-[#7C3AED] dark:text-[#C4B5FD]">{p.reservedStock ?? erp.reservedStock}</td>
                  <td className="py-2.5 px-2 text-right font-mono tabular-nums text-[#D97706] dark:text-[#FBBF24]">{p.incomingStock ?? erp.incomingStock}</td>
                  <td className="py-2.5 px-2 text-right font-mono tabular-nums text-[#F43F5E] dark:text-[#FB7185]">{p.damagedStock ?? erp.damagedStock}</td>
                  <td className="py-2.5 px-3 text-right space-x-1 whitespace-nowrap">
                    <button
                      type="button"
                      onClick={() => adjustPool(p, idx, 'receive_incoming')}
                      className="px-2 py-1 border border-emerald-500/35 bg-emerald-500/10 text-[#059669] dark:text-[#34D399] hover:bg-emerald-500 hover:text-white font-semibold transition-colors"
                      title="Receive Incoming Stock into Owned Warehouse"
                    >
                      <PackagePlus className="w-3 h-3 inline mr-1" />Receive
                    </button>
                    <button
                      type="button"
                      onClick={() => adjustPool(p, idx, 'transfer_wh')}
                      className="px-2 py-1 border border-cyan-500/35 bg-cyan-500/10 text-[#0284C7] dark:text-[#22D3EE] hover:bg-cyan-500 hover:text-white font-semibold transition-colors"
                      title="Transfer Warehouse Hub"
                    >
                      <ArrowRightLeft className="w-3 h-3 inline mr-1" />Transfer
                    </button>
                    <button
                      type="button"
                      onClick={() => adjustPool(p, idx, 'mark_damaged')}
                      className="px-2 py-1 border border-rose-500/35 bg-rose-500/10 text-[#E11D48] dark:text-[#FB7185] hover:bg-rose-500 hover:text-white font-semibold transition-colors"
                    >
                      -1 Dmg
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ============================================================================
// 4. SUPPLIER MANAGEMENT, AUTOMATED PO DISPATCH & WHITE-LABEL PACKAGING
// ============================================================================
export const ErpSuppliersPosSection: React.FC<ErpSharedProps> = ({
  suppliers,
  purchaseOrders,
  currency,
  onFeedback,
}) => {
  const [companyName, setCompanyName] = useState('');
  const [contactName, setContactName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [country, setCountry] = useState('India');
  const [supplierType, setSupplierType] = useState<Supplier['supplierType']>('dropship');
  const [integrationType, setIntegrationType] = useState<SupplierIntegrationType>('API');
  const [moq, setMoq] = useState('15');
  const [leadDays, setLeadDays] = useState('3');
  const [dispatchPreview, setDispatchPreview] = useState<string | null>(null);

  const addSupplier = async (e: React.FormEvent) => {
    e.preventDefault();
    const id = `sup_${Date.now()}`;
    try {
      await setDoc(doc(db, 'suppliers', id), {
        id,
        companyName: companyName.trim(),
        contactName: contactName.trim(),
        email: email.trim(),
        phone: phone.trim(),
        country: country.trim(),
        supplierType,
        integrationType,
        moq: Math.max(1, Math.round(Number(moq) || 10)),
        paymentTerms: 'Net 30',
        leadTimeDays: Math.max(1, Math.round(Number(leadDays) || 3)),
        performanceScore: 95,
        privateLabelCapable: true,
        brandingOptions: ['Custom Brand Box', 'Thank You Card', 'Zero Supplier Invoice'],
        verified: true,
        active: true,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await writeAuditLog('CREATE_SUPPLIER', 'supplier', id, `${companyName} (${integrationType})`);
      setCompanyName('');
      setContactName('');
      setEmail('');
      setPhone('');
      onFeedback(`Supplier ${companyName} added to directory.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `suppliers/${id}`);
    }
  };

  const dispatchPo = async (po: PurchaseOrder) => {
    const sup = suppliers.find((s) => s.id === po.supplierId);
    try {
      const res = await fetch('/api/suppliers/dispatch-po', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          poId: po.id,
          supplierName: po.supplierName,
          supplierEmail: po.supplierEmail,
          integrationType: sup?.integrationType || po.integrationType,
          webhookUrl: sup?.webhookUrl,
          items: po.items,
          packagingSpec: po.packagingSpec,
          channelMode: po.channelMode,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Dispatch error');

      await updateDoc(doc(db, 'purchaseOrders', po.id), {
        status: data.status,
        dispatchNotes: data.dispatchNotes,
        updatedAt: serverTimestamp(),
      });
      await writeAuditLog('DISPATCH_PO', 'purchaseOrder', po.id, `Dispatched via ${data.integrationType}; awaiting supplier acceptance`);
      setDispatchPreview(data.dispatchPayload);
      onFeedback(data.dispatchNotes);
    } catch (err) {
      onFeedback(err instanceof Error ? err.message : 'PO dispatch failed.');
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      <div className="lg:col-span-5 space-y-5">
        <form onSubmit={addSupplier} className="bg-white dark:bg-[#0D1120] border border-teal-500/25 dark:border-teal-400/25 p-5 space-y-3 text-xs glow-border">
          <h3 className="font-display text-lg font-bold gradient-heading-emerald">Add Dropship / Private-Label Supplier</h3>
          <input type="text" required placeholder="Company Name" value={companyName} onChange={(e) => setCompanyName(e.target.value)} className="w-full px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30]" />
          <div className="grid grid-cols-2 gap-2">
            <input type="text" required placeholder="Contact Name" value={contactName} onChange={(e) => setContactName(e.target.value)} className="px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30]" />
            <input type="email" required placeholder="Fulfillment Email" value={email} onChange={(e) => setEmail(e.target.value)} className="px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30]" />
            <input type="tel" required placeholder="Phone / WhatsApp" value={phone} onChange={(e) => setPhone(e.target.value)} className="px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30]" />
            <input type="text" required placeholder="Country" value={country} onChange={(e) => setCountry(e.target.value)} className="px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30]" />
            <select value={supplierType} onChange={(e) => setSupplierType(e.target.value as Supplier['supplierType'])} className="px-2.5 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30]">
              <option value="dropship">Dropship Supplier</option>
              <option value="private_label">Private Label Manufacturer</option>
              <option value="manufacturer">Direct Manufacturer</option>
              <option value="wholesale_distributor">Wholesale Distributor</option>
            </select>
            <select value={integrationType} onChange={(e) => setIntegrationType(e.target.value as SupplierIntegrationType)} className="px-2.5 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30]">
              {['API', 'Shopify', 'CSV', 'Email', 'WhatsApp', 'Manual', 'Portal'].map((it) => (
                <option key={it} value={it}>{it} Integration</option>
              ))}
            </select>
            <input type="number" min={1} placeholder="MOQ" value={moq} onChange={(e) => setMoq(e.target.value)} className="px-2.5 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] font-mono" />
            <input type="number" min={1} placeholder="Lead Days" value={leadDays} onChange={(e) => setLeadDays(e.target.value)} className="px-2.5 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] font-mono" />
          </div>
          <button type="submit" className="w-full py-2.5 btn-prism-emerald text-white font-semibold uppercase tracking-wider">
            <Plus className="w-3.5 h-3.5 inline mr-1" /> Register Supplier
          </button>
        </form>

        <div className="space-y-2.5">
          {suppliers.map((s) => (
            <div key={s.id} className="bg-white dark:bg-[#0D1120] border border-teal-500/20 dark:border-teal-400/25 p-4 text-xs space-y-1 glow-border">
              <div className="flex justify-between font-semibold">
                <span className="text-[#0B1020] dark:text-white">{s.companyName}</span>
                <span className="font-mono text-[#0D9488] dark:text-[#2DD4BF] font-bold">{s.integrationType} · {s.performanceScore}% SLA</span>
              </div>
              <p className="text-[#434C66] dark:text-slate-300">{s.contactName} · {s.email} · MOQ {s.moq} · {s.leadTimeDays}d lead</p>
              <p className="text-[11px] text-[#059669] dark:text-[#34D399] font-medium">
                {s.privateLabelCapable ? `Private Label Ready: ${s.brandingOptions.join(', ')}` : 'Standard Fulfillment'}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Purchase Orders & White-Label Packaging Queue */}
      <div className="lg:col-span-7 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-display text-xl font-bold gradient-heading">Purchase Orders & White-Label Packaging Queue ({purchaseOrders.length})</h3>
        </div>
        {purchaseOrders.map((po) => (
          <div key={po.id} className="bg-white dark:bg-[#0D1120] border border-cyan-500/25 dark:border-cyan-400/25 p-4 space-y-3 text-xs glow-border">
            <div className="flex flex-wrap justify-between items-start gap-2">
              <div>
                <p className="font-mono font-bold text-[#2563EB] dark:text-[#38BDF8]">{po.id} · Parent #{po.parentOrderId}</p>
                <p className="text-[#434C66] dark:text-slate-300">
                  {po.supplierName} · Mode: <strong>{po.channelMode}</strong> · Method: {po.integrationType}
                </p>
              </div>
              <div className="text-right">
                <p className="uppercase font-bold text-[#14B8A6] dark:text-[#2DD4BF]">{po.status.replace(/_/g, ' ')}</p>
                <p className="font-mono font-bold tabular-nums">{formatMoney(po.totalCost, currency)}</p>
              </div>
            </div>
            <div className="bg-gradient-to-r from-cyan-50/70 via-blue-50/60 to-purple-50/70 dark:from-[#0A1628] dark:via-[#0F152B] dark:to-[#18112B] border border-cyan-500/20 dark:border-cyan-400/20 p-2.5 text-[11px] flex flex-wrap justify-between gap-2">
              <span>Brand Packaging: <strong>{po.packagingSpec.packagingType.replace(/_/g, ' ')}</strong></span>
              <span className="text-[#059669] dark:text-[#34D399] font-semibold">No Supplier Branding: {po.packagingSpec.noSupplierBranding ? 'ENFORCED' : 'Off'}</span>
              <span className="text-[#7C3AED] dark:text-[#C4B5FD] font-semibold">No Price Slip: {po.packagingSpec.noSupplierPriceInvoice ? 'ENFORCED' : 'Off'}</span>
            </div>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-[11px] text-[#434C66] dark:text-slate-300">{po.dispatchNotes || 'Ready for dispatch'}</span>
              <button
                type="button"
                onClick={() => dispatchPo(po)}
                className="px-3.5 py-1.5 btn-prism-cyan text-white font-semibold flex items-center gap-1.5"
              >
                <Send className="w-3 h-3" /> Dispatch PO via {po.integrationType}
              </button>
            </div>
          </div>
        ))}

        {dispatchPreview && (
          <div className="bg-[#06070E] text-white border border-[#22D3EE]/40 p-4 text-[11px] font-mono space-y-2">
            <div className="flex justify-between">
              <span className="text-[#22D3EE] font-bold">Latest PO Integration Payload</span>
              <button type="button" onClick={() => setDispatchPreview(null)} className="text-[#F472B6] underline">Close</button>
            </div>
            <pre className="whitespace-pre-wrap overflow-x-auto text-cyan-100">{dispatchPreview}</pre>
          </div>
        )}
      </div>
    </div>
  );
};

// ============================================================================
// 5. WHOLESALE & B2B ACCOUNT / QUOTE APPROVALS
// ============================================================================
export const ErpWholesaleB2BSection: React.FC<ErpSharedProps> = ({
  wholesaleAccounts,
  wholesaleQuotes,
  currency,
  onFeedback,
}) => {
  const approveAccount = async (acc: WholesaleAccount, status: 'approved' | 'rejected') => {
    const defaultDiscount = acc.tier === 'distributor' ? 48 : acc.tier === 'dealer' ? 42 : 35;
    const defaultCredit = acc.tier === 'distributor' ? 50000 : acc.tier === 'dealer' ? 25000 : 10000;
    try {
      await updateDoc(doc(db, 'wholesaleAccounts', acc.id), {
        status,
        discountPercent: status === 'approved' ? defaultDiscount : 0,
        creditLimit: status === 'approved' ? defaultCredit : 0,
        creditTermsDays: status === 'approved' ? 30 : 0,
        updatedAt: serverTimestamp(),
      });
      await writeAuditLog('WHOLESALE_ACCOUNT_REVIEW', 'wholesaleAccount', acc.id, `${acc.businessName} -> ${status}`);
      onFeedback(`${acc.businessName} marked ${status}.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `wholesaleAccounts/${acc.id}`);
    }
  };

  const reviewQuote = async (q: WholesaleQuote, status: 'approved' | 'rejected') => {
    try {
      await updateDoc(doc(db, 'wholesaleQuotes', q.id), {
        status,
        approvedTotal: status === 'approved' ? q.requestedTotal : 0,
        updatedAt: serverTimestamp(),
      });
      await writeAuditLog('WHOLESALE_QUOTE_REVIEW', 'wholesaleQuote', q.id, `Quote ${q.id} -> ${status}`);
      onFeedback(`Quote #${q.id} ${status}.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `wholesaleQuotes/${q.id}`);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-xs">
      <div className="space-y-3">
        <h3 className="font-display text-xl font-bold gradient-heading-warm flex items-center gap-2">
          <Building2 className="w-4 h-4 text-[#F97316] dark:text-[#FBBF24]" /> B2B Dealer & Distributor Applications ({wholesaleAccounts.length})
        </h3>
        {wholesaleAccounts.map((acc) => (
          <div key={acc.id} className="bg-white dark:bg-[#0D1120] border border-orange-500/25 dark:border-amber-400/25 p-4 space-y-2 glow-border">
            <div className="flex justify-between items-start">
              <div>
                <p className="font-bold text-sm text-[#0B1020] dark:text-white">{acc.businessName}</p>
                <p className="text-[#434C66] dark:text-slate-300">{acc.contactName} · GST: <span className="font-mono">{acc.gstNumber}</span></p>
              </div>
              <span className="uppercase font-bold text-[#EA580C] dark:text-[#FBBF24]">{acc.tier} · {acc.status}</span>
            </div>
            <p className="font-mono tabular-nums text-[#2563EB] dark:text-[#38BDF8] font-semibold">
              Credit Limit: {formatMoney(acc.creditLimit, currency)} · Discount: {acc.discountPercent}% · Net {acc.creditTermsDays}d
            </p>
            <div className="flex gap-2 pt-1">
              <button type="button" onClick={() => approveAccount(acc, 'approved')} className="px-3 py-1.5 btn-prism-emerald text-white font-semibold">
                Approve & Grant Credit
              </button>
              <button type="button" onClick={() => approveAccount(acc, 'rejected')} className="px-3 py-1.5 border border-rose-500/35 text-[#E11D48] dark:text-[#FB7185] hover:bg-rose-500 hover:text-white font-semibold transition-colors">
                Reject
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="space-y-3">
        <h3 className="font-display text-xl font-bold gradient-heading flex items-center gap-2">
          <FileSpreadsheet className="w-4 h-4 text-[#7C3AED] dark:text-[#22D3EE]" /> Quote Requests & Negotiations ({wholesaleQuotes.length})
        </h3>
        {wholesaleQuotes.map((q) => (
          <div key={q.id} className="bg-white dark:bg-[#0D1120] border border-purple-500/25 dark:border-fuchsia-400/25 p-4 space-y-2 glow-border">
            <div className="flex justify-between">
              <span className="font-mono font-bold text-[#7C3AED] dark:text-[#C4B5FD]">{q.id} · {q.businessName}</span>
              <span className="uppercase font-bold text-[#EC4899] dark:text-[#F472B6]">{q.status}</span>
            </div>
            <p className="font-mono font-semibold tabular-nums">
              Requested Total: {formatMoney(q.requestedTotal, currency)}
              {q.approvedTotal ? ` · Approved: ${formatMoney(q.approvedTotal, currency)}` : ''}
            </p>
            {q.notes && <p className="text-[#434C66] dark:text-slate-300 italic">{q.notes}</p>}
            <div className="flex gap-2 pt-1">
              <button type="button" onClick={() => reviewQuote(q, 'approved')} className="px-3 py-1.5 btn-prism-emerald text-white font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Approve Quote
              </button>
              <button type="button" onClick={() => reviewQuote(q, 'rejected')} className="px-3 py-1.5 border border-rose-500/35 text-[#E11D48] dark:text-[#FB7185] hover:bg-rose-500 hover:text-white font-semibold transition-colors">
                Decline
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ============================================================================
// 6. RBAC STAFF PERMISSIONS & IMMUTABLE AUDIT LOGS
// ============================================================================
const RBAC_ROLES: ErpRole[] = [
  'super_admin',
  'operations_manager',
  'order_manager',
  'supplier_manager',
  'warehouse_manager',
  'finance_manager',
  'marketing_manager',
  'sales_rep',
  'customer_support',
];

export const ErpFinanceRbacAuditSection: React.FC<ErpSharedProps> = ({ auditLogs, onFeedback }) => {
  const [staffUid, setStaffUid] = useState('');
  const [staffEmail, setStaffEmail] = useState('');
  const [staffRole, setStaffRole] = useState<ErpRole>('operations_manager');

  const assignRole = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!staffUid.trim() || !staffEmail.trim()) return;
    const cleanUid = staffUid.trim().replace(/[^a-zA-Z0-9_-]/g, '_');
    try {
      await setDoc(doc(db, 'admins', cleanUid), {
        uid: cleanUid,
        email: staffEmail.trim(),
        role: staffRole,
        grantedAt: serverTimestamp(),
      });
      await writeAuditLog('ASSIGN_RBAC_ROLE', 'admin', cleanUid, `${staffEmail} granted ${staffRole}`);
      setStaffUid('');
      setStaffEmail('');
      onFeedback(`Assigned RBAC role ${staffRole} to ${staffEmail}.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `admins/${cleanUid}`);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-xs">
      <form onSubmit={assignRole} className="lg:col-span-5 bg-white dark:bg-[#0D1120] border border-violet-500/25 dark:border-purple-400/25 p-5 space-y-3 h-fit glow-border">
        <h3 className="font-display text-lg font-bold gradient-heading flex items-center gap-2">
          <Shield className="w-4 h-4 text-[#7C3AED] dark:text-[#22D3EE]" /> RBAC Staff Role Assignment
        </h3>
        <input type="text" required placeholder="Firebase User UID" value={staffUid} onChange={(e) => setStaffUid(e.target.value)} className="w-full px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] font-mono" />
        <input type="email" required placeholder="Staff Email" value={staffEmail} onChange={(e) => setStaffEmail(e.target.value)} className="w-full px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30]" />
        <select value={staffRole} onChange={(e) => setStaffRole(e.target.value as ErpRole)} className="w-full px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30]">
          {RBAC_ROLES.map((r) => (
            <option key={r} value={r}>{r.replace(/_/g, ' ').toUpperCase()}</option>
          ))}
        </select>
        <button type="submit" className="w-full py-2.5 btn-futuristic text-white font-semibold uppercase tracking-wider">
          Grant RBAC Role
        </button>
      </form>

      <div className="lg:col-span-7 bg-white dark:bg-[#0D1120] border border-cyan-500/25 dark:border-cyan-400/25 p-5 space-y-3 glow-border">
        <h3 className="font-display text-lg font-bold gradient-heading-emerald flex items-center gap-2">
          <Truck className="w-4 h-4 text-[#10B981] dark:text-[#34D399]" /> Immutable ERP Audit Trail ({auditLogs.length})
        </h3>
        <div className="max-h-96 overflow-y-auto divide-y divide-indigo-500/10 dark:divide-cyan-400/10">
          {auditLogs.length === 0 ? (
            <p className="py-6 text-[#434C66] dark:text-slate-400">Audit events will appear here as orders route and ERP mutations occur.</p>
          ) : (
            auditLogs.map((log) => (
              <div key={log.id} className="py-2.5 space-y-0.5">
                <div className="flex justify-between font-mono text-[11px]">
                  <span className="font-bold text-[#7C3AED] dark:text-[#22D3EE]">{log.action}</span>
                  <span className="text-[#434C66] dark:text-slate-400">{log.entityType} / {log.entityId}</span>
                </div>
                <p className="text-[#0B1020] dark:text-white">{log.details}</p>
                <p className="text-[10px] text-[#434C66] dark:text-slate-400">Actor: {log.actorEmail} ({log.actorRole})</p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
