import React, { useState } from 'react';
import { AnimatedCounter, CinematicModal } from './MotionPrimitives';
import {
  AlertTriangle,
  CheckCircle2,
  ClipboardCheck,
  Package,
  ShieldAlert,
  Truck,
  Upload,
  X,
} from 'lucide-react';
import { doc, serverTimestamp, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { KPI_COLOR_THEMES } from '../lib/themePalette';
import {
  CurrencyCode,
  formatMoney,
  Product,
  PurchaseOrder,
  PurchaseOrderStatus,
  Supplier,
} from '../types/store';

interface SupplierPortalModalProps {
  suppliers: Supplier[];
  purchaseOrders: PurchaseOrder[];
  products: Product[];
  currency: CurrencyCode;
  userEmail?: string;
  isAdmin: boolean;
  onClose: () => void;
}

export const SupplierPortalModal: React.FC<SupplierPortalModalProps> = ({
  suppliers,
  purchaseOrders,
  products,
  currency,
  userEmail,
  isAdmin,
  onClose,
}) => {
  const [channelFilter, setChannelFilter] = useState<'all' | 'online_dropship' | 'private_label' | 'offline_wholesale'>('all');
  const [trackingInputs, setTrackingInputs] = useState<Record<string, { tracking: string; carrier: string }>>({});
  const [qcPassedMap, setQcPassedMap] = useState<Record<string, boolean>>({});
  const [stockUpdates, setStockUpdates] = useState<Record<string, number>>({});
  const [feedback, setFeedback] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  const activeSupplier = suppliers.find((s) => s.email === userEmail) || (isAdmin ? suppliers[0] : null);
  const visiblePOs = purchaseOrders.filter((po) => {
    if (!isAdmin && userEmail && po.supplierEmail !== userEmail) return false;
    if (channelFilter !== 'all' && po.channelMode !== channelFilter) return false;
    return true;
  });

  const handlePoTransition = async (po: PurchaseOrder, nextStatus: PurchaseOrderStatus) => {
    const tr = trackingInputs[po.id] || { tracking: po.trackingNumber || '', carrier: po.carrier || 'DHL Express' };
    if (nextStatus === 'shipped' && !tr.tracking.trim()) {
      setFeedback(`Enter tracking number before marking PO #${po.id} as shipped.`);
      return;
    }

    setBusyId(po.id);
    try {
      const res = await fetch('/api/webhooks/supplier-update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          poId: po.id,
          status: nextStatus,
          trackingNumber: tr.tracking.trim(),
          carrier: tr.carrier.trim(),
          notes: `Updated via Supplier Portal (${activeSupplier?.companyName || 'Supplier'})`,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Webhook update failed');

      await updateDoc(doc(db, 'purchaseOrders', po.id), {
        status: nextStatus,
        ...(tr.tracking.trim() ? { trackingNumber: tr.tracking.trim() } : {}),
        ...(tr.carrier.trim() ? { carrier: tr.carrier.trim() } : {}),
        dispatchNotes: data.notes,
        updatedAt: serverTimestamp(),
      });
      setFeedback(`PO #${po.id} updated to ${nextStatus.replace(/_/g, ' ')}.`);
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Unable to update PO.');
    } finally {
      setBusyId(null);
    }
  };

  const uploadQcPhoto = async (po: PurchaseOrder, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusyId(po.id);
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
      const res = await fetch('/api/uploads/media', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dataUrl, filename: `qc_${po.id}` }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'QC photo upload failed');
      await updateDoc(doc(db, 'purchaseOrders', po.id), {
        qcPhotoUrl: data.url,
        updatedAt: serverTimestamp(),
      });
      setQcPassedMap((prev) => ({ ...prev, [po.id]: true }));
      setFeedback(`QC packaging photo verified for PO #${po.id}.`);
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'QC upload error.');
    } finally {
      setBusyId(null);
    }
  };

  const syncSupplierStock = async (prod: Product) => {
    const nextVal = stockUpdates[prod.id];
    if (typeof nextVal !== 'number' || nextVal < 0) return;
    try {
      await updateDoc(doc(db, 'products', prod.id), {
        supplierStock: Math.round(nextVal),
        updatedAt: serverTimestamp(),
      });
      setFeedback(`Synced supplier stock for ${prod.sku} to ${Math.round(nextVal)} units.`);
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Stock sync requires Admin or verified supplier permissions.');
    }
  };

  return (
    <CinematicModal
      backdropClassName="flex items-center justify-center p-2 sm:p-4"
      panelClassName="bg-[#F5F7FF] dark:bg-[#06070E] text-[#090B14] dark:text-[#F8FAFF] w-full max-w-6xl border border-teal-500/30 dark:border-teal-400/25 shadow-2xl max-h-[94vh] flex flex-col overflow-hidden prism-modal-rim"
    >
        <div className="px-6 py-4 bg-gradient-to-r from-[#07141F] via-[#0B2B3C] to-[#08332B] text-white flex items-center justify-between gap-4">
          <div>
            <p className="text-[11px] uppercase tracking-[0.22em] text-teal-300 font-semibold">
              Supplier &amp; Private-Label Fulfillment Portal
            </p>
            <h2 className="font-display text-2xl font-semibold gradient-heading-emerald">
              {activeSupplier ? activeSupplier.companyName : 'Partner Fulfillment Queue'}
            </h2>
          </div>
          <button type="button" onClick={onClose} aria-label="Close Supplier Portal" className="p-2 hover:bg-white/10 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="prism-divider shrink-0" />

        {/* Strict Channel Separation Tabs */}
        <div className="px-6 py-2.5 bg-white dark:bg-[#0D1120] border-b border-indigo-500/15 dark:border-cyan-400/15 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 overflow-x-auto">
            {(
              [
                ['all', `All POs (${visiblePOs.length})`, 'btn-prism-emerald'],
                ['online_dropship', 'Online Dropshipping', 'btn-prism-cyan'],
                ['private_label', 'Private Label', 'btn-futuristic'],
                ['offline_wholesale', 'Offline Wholesale', 'btn-prism-sunset'],
              ] as const
            ).map(([id, label, activeClass]) => (
              <button
                key={id}
                type="button"
                onClick={() => setChannelFilter(id)}
                className={`px-3.5 py-1.5 text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
                  channelFilter === id
                    ? `${activeClass} text-white`
                    : 'text-slate-600 dark:text-slate-300 hover:bg-teal-500/10 hover:text-teal-700 dark:hover:text-teal-300'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
          <span className="text-[11px] text-teal-700 dark:text-teal-300 font-medium flex items-center gap-1.5">
            <ShieldAlert className="w-3.5 h-3.5 text-cyan-500" />
            Dropship &amp; Offline Wholesale POs strictly isolated
          </span>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className={`${KPI_COLOR_THEMES.orders.cardBg} border ${KPI_COLOR_THEMES.orders.border} p-4 relative overflow-hidden glow-border`}>
              <div className={`absolute top-0 left-0 right-0 h-1 ${KPI_COLOR_THEMES.orders.topBar}`} />
              <p className={`text-[11px] uppercase tracking-wider font-semibold ${KPI_COLOR_THEMES.orders.subText}`}>Active PO Queue</p>
              <p className={`font-mono text-2xl font-bold mt-1 ${KPI_COLOR_THEMES.orders.valueText}`}>
                <AnimatedCounter value={visiblePOs.length} />
              </p>
            </div>
            <div className={`${KPI_COLOR_THEMES.profit.cardBg} border ${KPI_COLOR_THEMES.profit.border} p-4 relative overflow-hidden glow-border`}>
              <div className={`absolute top-0 left-0 right-0 h-1 ${KPI_COLOR_THEMES.profit.topBar}`} />
              <p className={`text-[11px] uppercase tracking-wider font-semibold ${KPI_COLOR_THEMES.profit.subText}`}>Shipped POs</p>
              <p className={`font-mono text-2xl font-bold mt-1 ${KPI_COLOR_THEMES.profit.valueText}`}>
                <AnimatedCounter value={visiblePOs.filter((p) => p.status === 'shipped').length} />
              </p>
            </div>
            <div className={`${KPI_COLOR_THEMES.suppliers.cardBg} border ${KPI_COLOR_THEMES.suppliers.border} p-4 relative overflow-hidden glow-border`}>
              <div className={`absolute top-0 left-0 right-0 h-1 ${KPI_COLOR_THEMES.suppliers.topBar}`} />
              <p className={`text-[11px] uppercase tracking-wider font-semibold ${KPI_COLOR_THEMES.suppliers.subText}`}>Partner SLA Score</p>
              <p className={`font-mono text-2xl font-bold mt-1 ${KPI_COLOR_THEMES.suppliers.valueText}`}>
                <AnimatedCounter value={activeSupplier?.performanceScore ?? 96} formatter={(v) => `${Math.round(v)}%`} />
              </p>
            </div>
          </div>

          {feedback && (
            <div className="bg-gradient-to-r from-teal-50 via-white to-cyan-50 dark:from-teal-950/40 dark:via-[#0D1120] dark:to-cyan-950/40 border border-teal-500/40 px-4 py-2.5 text-xs flex justify-between items-center font-medium">
              <span className="text-slate-800 dark:text-teal-100">{feedback}</span>
              <button type="button" onClick={() => setFeedback(null)} className="text-teal-700 dark:text-teal-300 font-semibold hover:underline">
                Dismiss
              </button>
            </div>
          )}

          {visiblePOs.length === 0 ? (
            <div className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-10 text-center text-xs text-slate-600 dark:text-slate-300">
              No Purchase Orders currently assigned to this filter or login ({userEmail || 'Guest'}).
            </div>
          ) : (
            <div className="space-y-4">
              {visiblePOs.map((po) => {
                const tr = trackingInputs[po.id] || {
                  tracking: po.trackingNumber || '',
                  carrier: po.carrier || 'DHL Express',
                };
                return (
                  <div key={po.id} className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-5 space-y-4 glow-border">
                    <div className="flex flex-wrap items-start justify-between gap-4 border-b border-indigo-500/15 dark:border-cyan-400/15 pb-3">
                      <div>
                        <p className="font-mono text-xs font-bold flex items-center gap-2 text-blue-600 dark:text-cyan-300">
                          <Package className="w-4 h-4 text-teal-500" /> {po.id} · Parent #{po.parentOrderId}
                        </p>
                        <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                          Supplier: {po.supplierName} · Mode: <strong className="text-violet-600 dark:text-fuchsia-300">{po.channelMode.replace(/_/g, ' ')}</strong> · Channel: {po.integrationType}
                        </p>
                      </div>
                      <div className="text-right text-xs">
                        <p className="uppercase font-bold text-teal-600 dark:text-teal-300">
                          {po.status.replace(/_/g, ' ')}
                        </p>
                        <p className="font-mono tabular-nums font-bold text-emerald-600 dark:text-emerald-400 mt-0.5">
                          PO Cost: {formatMoney(po.totalCost, currency)}
                        </p>
                      </div>
                    </div>

                    {/* Items & White-Label Packaging Spec */}
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 text-xs">
                      <div className="lg:col-span-6 space-y-1.5">
                        <p className="uppercase tracking-wider text-[11px] font-semibold text-indigo-700 dark:text-cyan-300">
                          Line Items
                        </p>
                        {po.items.map((it, idx) => (
                          <div key={idx} className="flex justify-between py-1 border-b border-indigo-500/10 dark:border-cyan-400/10">
                            <span>
                              {it.name} ({it.shadeName || 'Standard'}) · <span className="font-mono text-slate-500 dark:text-slate-400">{it.supplierSku || it.sku}</span>
                            </span>
                            <span className="font-mono tabular-nums font-bold text-blue-600 dark:text-cyan-300">× {it.quantity}</span>
                          </div>
                        ))}
                      </div>

                      <div className="lg:col-span-6 bg-gradient-to-br from-teal-50/70 via-[#F5F7FF] to-cyan-50/60 dark:from-teal-950/30 dark:via-[#141A30] dark:to-cyan-950/25 border border-teal-500/25 p-3.5 space-y-2">
                        <p className="uppercase tracking-wider text-[11px] font-semibold flex items-center gap-1.5 text-teal-700 dark:text-teal-300">
                          <ClipboardCheck className="w-3.5 h-3.5" /> White-Label Brand Packaging Compliance
                        </p>
                        <div className="grid grid-cols-2 gap-1 text-[11px]">
                          <span>Parcel: {po.packagingSpec.packagingType.replace(/_/g, ' ')}</span>
                          <span>Box Branding: {po.packagingSpec.boxBranding ? 'Required' : 'Standard'}</span>
                          <span>Thank-You Card: {po.packagingSpec.thankYouCard ? 'Include' : 'No'}</span>
                          <span>Custom Label: {po.packagingSpec.customLabel ? 'Private Label' : 'No'}</span>
                          <span className="col-span-2 font-semibold text-emerald-700 dark:text-emerald-400">
                            {po.packagingSpec.noSupplierBranding ? 'STRICT: NO Supplier Branding / NO Price Slip' : ''}
                          </span>
                        </div>
                        <div className="flex items-center justify-between pt-1">
                          <label className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-indigo-600 dark:text-cyan-300 cursor-pointer underline">
                            <Upload className="w-3 h-3" /> Upload Packaging QC Photo
                            <input type="file" accept="image/*" onChange={(e) => uploadQcPhoto(po, e)} className="hidden" />
                          </label>
                          {(qcPassedMap[po.id] || po.qcPhotoUrl) && (
                            <span className="text-[11px] text-emerald-700 dark:text-emerald-400 font-semibold flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3" /> QC Verified
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Supplier Workflow Actions */}
                    <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-indigo-500/15 dark:border-cyan-400/15 text-xs">
                      <div className="flex flex-wrap items-center gap-2">
                        <input
                          type="text"
                          placeholder="Carrier (e.g. DHL Express)"
                          value={tr.carrier}
                          onChange={(e) =>
                            setTrackingInputs((prev) => ({
                              ...prev,
                              [po.id]: { ...tr, carrier: e.target.value },
                            }))
                          }
                          className="px-2.5 py-1.5 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white w-36"
                        />
                        <input
                          type="text"
                          placeholder="Tracking Number"
                          value={tr.tracking}
                          onChange={(e) =>
                            setTrackingInputs((prev) => ({
                              ...prev,
                              [po.id]: { ...tr, tracking: e.target.value },
                            }))
                          }
                          className="px-2.5 py-1.5 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white font-mono w-44"
                        />
                      </div>

                      <div className="flex flex-wrap gap-2">
                        <button
                          type="button"
                          disabled={busyId === po.id}
                          onClick={() => handlePoTransition(po, 'supplier_accepted')}
                          className="px-3 py-1.5 btn-prism-emerald text-white font-semibold"
                        >
                          Accept PO
                        </button>
                        <button
                          type="button"
                          disabled={busyId === po.id}
                          onClick={() => handlePoTransition(po, 'packed')}
                          className="px-3 py-1.5 btn-prism-outline font-semibold"
                        >
                          Mark Packed
                        </button>
                        <button
                          type="button"
                          disabled={busyId === po.id}
                          onClick={() => handlePoTransition(po, 'shipped')}
                          className="px-3 py-1.5 btn-prism-cyan text-white font-semibold flex items-center gap-1"
                        >
                          <Truck className="w-3.5 h-3.5" /> Ship with Tracking
                        </button>
                        <button
                          type="button"
                          disabled={busyId === po.id}
                          onClick={() => handlePoTransition(po, 'delayed')}
                          className="px-3 py-1.5 border border-orange-500/50 text-orange-600 dark:text-amber-300 font-semibold hover:bg-orange-500 hover:text-white transition-colors flex items-center gap-1"
                        >
                          <AlertTriangle className="w-3.5 h-3.5" /> Flag Delay
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {isAdmin && (
            <div className="bg-white dark:bg-[#0D1120] border border-teal-500/25 p-5 space-y-3 glow-border">
              <h3 className="font-display text-lg font-semibold gradient-heading-emerald">Supplier Stock Synchronization</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
                {products.slice(0, 6).map((p) => (
                  <div key={p.id} className="p-3 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/20 dark:border-cyan-400/20 flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-semibold truncate">{p.name}</p>
                      <p className="font-mono text-[11px] text-teal-600 dark:text-teal-300">
                        {p.sku} · Curr: {p.supplierStock ?? 200}
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <input
                        type="number"
                        min={0}
                        placeholder={String(p.supplierStock ?? 200)}
                        value={stockUpdates[p.id] ?? ''}
                        onChange={(e) =>
                          setStockUpdates((prev) => ({ ...prev, [p.id]: Number(e.target.value) }))
                        }
                        className="w-16 px-2 py-1 font-mono border border-indigo-500/25 dark:border-cyan-400/25 bg-white dark:bg-[#0D1120] text-[#090B14] dark:text-white"
                      />
                      <button
                        type="button"
                        onClick={() => syncSupplierStock(p)}
                        className="px-2.5 py-1 btn-prism-cyan text-white font-semibold"
                      >
                        Sync
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
    </CinematicModal>
  );
};
