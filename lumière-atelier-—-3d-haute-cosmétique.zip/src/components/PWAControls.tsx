import React, { useEffect, useState } from 'react';
import { Download, Smartphone, WifiOff, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const OfflineIndicator: React.FC = () => {
  const [offline, setOffline] = useState(typeof navigator !== 'undefined' ? !navigator.onLine : false);

  useEffect(() => {
    const onOffline = () => setOffline(true);
    const onOnline = () => setOffline(false);
    window.addEventListener('offline', onOffline);
    window.addEventListener('online', onOnline);
    return () => {
      window.removeEventListener('offline', onOffline);
      window.removeEventListener('online', onOnline);
    };
  }, []);

  if (!offline) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-4 left-4 z-[80] px-4 py-2.5 bg-gradient-to-r from-amber-600 to-rose-600 text-white text-xs font-semibold shadow-2xl border border-amber-300/50 flex items-center gap-2"
    >
      <WifiOff className="w-4 h-4 shrink-0" />
      <span>Offline Mode — Cached catalog active. Checkout &amp; sync will resume automatically online.</span>
    </div>
  );
};

interface PWAInstallButtonProps {
  compact?: boolean;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ compact = false }) => {
  const { isInstallable, isInstalled, isIOS, promptInstall } = usePWAInstall();
  const [showIosGuide, setShowIosGuide] = useState(false);

  if (isInstalled) return null;
  if (!isInstallable && !isIOS) return null;

  return (
    <div className="relative inline-block">
      <button
        type="button"
        onClick={() => {
          if (isInstallable) {
            void promptInstall();
          } else if (isIOS) {
            setShowIosGuide((v) => !v);
          }
        }}
        className={
          compact
            ? 'px-3 py-1.5 btn-prism-cyan text-white text-[11px] font-semibold flex items-center gap-1.5 whitespace-nowrap'
            : 'px-4 py-2 btn-prism-cyan text-white text-xs font-semibold uppercase tracking-wider flex items-center gap-2 whitespace-nowrap'
        }
      >
        {isIOS ? <Smartphone className="w-3.5 h-3.5" /> : <Download className="w-3.5 h-3.5" />}
        Install App
      </button>

      {showIosGuide && (
        <div className="absolute right-0 bottom-full mb-2 w-64 p-3.5 bg-[#0D1120] text-white border border-cyan-400/40 shadow-2xl text-xs z-50 space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-bold text-cyan-300">Install on iPhone / iPad</span>
            <button type="button" onClick={() => setShowIosGuide(false)} aria-label="Close iOS install instructions">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
          <p className="text-slate-200 leading-relaxed">
            Tap Safari&apos;s <strong>Share</strong> icon, then choose <strong>Add to Home Screen</strong> for full-screen app mode &amp; offline access.
          </p>
        </div>
      )}
    </div>
  );
};
