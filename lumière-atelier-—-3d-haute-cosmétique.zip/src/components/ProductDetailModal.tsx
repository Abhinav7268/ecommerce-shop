import React, { useState } from 'react';
import { CinematicModal } from './MotionPrimitives';
import {
  Bell,
  Camera,
  Check,
  Globe,
  Heart,
  Repeat,
  Scale,
  ShieldCheck,
  ShoppingBag,
  Star,
  Truck,
  Upload,
  X,
  Zap,
} from 'lucide-react';
import { addDoc, collection, doc, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import {
  CurrencyCode,
  Product,
  ProductShade,
  Review,
} from '../types/store';
import { getCategoryStyle } from '../lib/themePalette';
import { ThreeCosmeticStage } from './ThreeCosmeticStage';
import { useLocalization } from '../context/LocalizationContext';
import { getLocalizedProductInfo, getLocalizedProductPrice } from '../lib/localization';

interface ProductDetailModalProps {
  product: Product;
  initialShade?: ProductShade;
  currency: CurrencyCode;
  reviews: Review[];
  isWishlisted: boolean;
  isCompared: boolean;
  userUid?: string;
  userEmail?: string;
  userName?: string;
  onClose: () => void;
  onAddToBag: (product: Product, shade: ProductShade, options?: { subscriptionIntervalDays?: 30 | 60 | 90 }) => void;
  onBuyNow?: (product: Product, shade: ProductShade) => void;
  onToggleWishlist: (product: Product, shade: ProductShade) => void;
  onToggleCompare: (product: Product) => void;
  onOpenTryOn: (product: Product, shade: ProductShade) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  initialShade,
  currency,
  reviews,
  isWishlisted,
  isCompared,
  userUid,
  userEmail,
  userName,
  onClose,
  onAddToBag,
  onBuyNow,
  onToggleWishlist,
  onToggleCompare,
  onOpenTryOn,
}) => {
  const [selectedShade, setSelectedShade] = useState<ProductShade>(initialShade || product.shades[0]);
  const [mediaView, setMediaView] = useState<'3d' | 'photo' | 'video'>('3d');
  const [addedFeedback, setAddedFeedback] = useState(false);
  const [purchasePlan, setPurchasePlan] = useState<'one_time' | 'subscribe'>('one_time');
  const [intervalDays, setIntervalDays] = useState<30 | 60 | 90>(60);
  const [alertEmail, setAlertEmail] = useState(userEmail || '');
  const [alertSaving, setAlertSaving] = useState(false);
  const [alertFeedback, setAlertFeedback] = useState<string | null>(null);

  const handleJoinWaitlist = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = alertEmail.trim();
    if (!cleaned || !cleaned.includes('@')) {
      setAlertFeedback('Enter a valid email address for restock alerts.');
      return;
    }
    setAlertSaving(true);
    setAlertFeedback(null);
    const alertId = `alert_${Date.now()}`;
    try {
      await setDoc(doc(db, 'stockAlerts', alertId), {
        id: alertId,
        productId: product.id,
        productName: product.name,
        ...(userUid ? { userId: userUid } : {}),
        email: cleaned,
        alertType: product.stock <= 0 ? 'back_in_stock' : 'preorder_waitlist',
        status: 'waiting',
        createdAt: serverTimestamp(),
      });
      setAlertFeedback(
        product.stock <= 0
          ? `Registered! We will notify ${cleaned} immediately when ${product.name} restocks.`
          : `Added ${cleaned} to priority VIP pre-order & limited batch drop alerts.`,
      );
    } catch (err) {
      setAlertFeedback(err instanceof Error ? err.message : 'Could not save stock alert.');
    } finally {
      setAlertSaving(false);
    }
  };

  // Review form state
  const [rating, setRating] = useState(5);
  const [reviewTitle, setReviewTitle] = useState('');
  const [reviewComment, setReviewComment] = useState('');
  const [reviewPhotoUrl, setReviewPhotoUrl] = useState('');
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [submittingReview, setSubmittingReview] = useState(false);
  const [reviewMessage, setReviewMessage] = useState<string | null>(null);

  const productReviews = reviews.filter((r) => r.productId === product.id);

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingPhoto(true);
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
      const res = await fetch('/api/uploads/media', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dataUrl, filename: `review_${product.id}` }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Upload failed');
      setReviewPhotoUrl(data.url);
    } catch (err) {
      setReviewMessage(err instanceof Error ? err.message : 'Photo upload failed.');
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userUid) {
      setReviewMessage('Please sign in with Google to publish a verified review.');
      return;
    }
    if (reviewTitle.trim().length < 2 || reviewComment.trim().length < 5) {
      setReviewMessage('Please enter a title and at least 5 characters for your review.');
      return;
    }
    setSubmittingReview(true);
    setReviewMessage(null);
    const revId = `rev_${Date.now()}`;
    try {
      const reviewPayload = {
        id: revId,
        productId: product.id,
        userId: userUid,
        authorName: userName || 'Verified Collector',
        rating,
        title: reviewTitle.trim().slice(0, 140),
        comment: reviewComment.trim().slice(0, 1500),
        shadeName: selectedShade.name,
        ...(reviewPhotoUrl ? { photoUrl: reviewPhotoUrl } : {}),
        verifiedPurchase: true,
        createdAt: serverTimestamp(),
      };

      const { setDoc } = await import('firebase/firestore');
      await setDoc(doc(db, 'reviews', revId), reviewPayload);

      // Update product review metrics boundedly
      const nextCount = (product.reviewCount || 0) + 1;
      const nextRating = Number(
        (((product.rating || 5) * (product.reviewCount || 0) + rating) / nextCount).toFixed(2),
      );
      try {
        await updateDoc(doc(db, 'products', product.id), {
          rating: Math.min(5, Math.max(1, nextRating)),
          reviewCount: nextCount,
          updatedAt: serverTimestamp(),
        });
      } catch {
        // Non-blocking if product is local seed prior to Firestore seed completion
      }

      setReviewTitle('');
      setReviewComment('');
      setReviewPhotoUrl('');
      setReviewMessage('Thank you. Your review is now live.');
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.CREATE, `reviews/${revId}`);
      } catch (wrapped) {
        setReviewMessage(wrapped instanceof Error ? wrapped.message : 'Could not submit review.');
      }
    } finally {
      setSubmittingReview(false);
    }
  };

  // Prevent unused import warning for addDoc if needed
  void addDoc;
  void collection;

  const { country, language, setSelectorOpen, t } = useLocalization();
  const catStyle = getCategoryStyle(product.category);
  const localizedPrice = getLocalizedProductPrice(product, country, currency);
  const localizedComparePrice =
    product.compareAtPrice && product.compareAtPrice > product.price
      ? getLocalizedProductPrice(product, country, currency, product.compareAtPrice)
      : null;
  const localizedInfo = getLocalizedProductInfo(product, language, country);

  return (
    <CinematicModal
      onBackdropClick={onClose}
      backdropClassName="flex items-center justify-center p-2 sm:p-6"
      panelClassName="bg-[#F5F7FF] dark:bg-[#06070E] text-[#090B14] dark:text-[#F8FAFF] w-full max-w-6xl border border-indigo-500/25 dark:border-cyan-400/25 shadow-2xl max-h-[94vh] flex flex-col overflow-hidden prism-modal-rim"
    >
        <div className="flex items-center justify-between px-6 py-3.5 bg-gradient-to-r from-[#090B1A] via-[#1B1443] to-[#0D2744] text-white shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-300">
            <span className={`px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-white bg-gradient-to-r ${catStyle.labelGradient}`}>
              {product.category}
            </span>
            <span aria-hidden="true">·</span>
            <span className="text-cyan-300 font-medium">{product.collection} Collection</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-white/75">{product.sku}</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Product Detail"
            className="p-1.5 hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="prism-divider shrink-0" />

        <div className="overflow-y-auto flex-1">
          <div className="grid grid-cols-1 lg:grid-cols-12">
            {/* Left: Sticky 3D / Studio Media Showcase */}
            <div className="lg:col-span-7 bg-[#06070E] flex flex-col">
              <div className="flex items-center justify-between px-5 py-2.5 bg-[#0D1120] border-b border-cyan-400/15">
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setMediaView('3d')}
                    className={`px-3 py-1 text-xs font-semibold transition-all ${
                      mediaView === '3d' ? 'btn-prism-cyan text-white' : 'text-slate-300 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    3D Studio
                  </button>
                  <button
                    type="button"
                    onClick={() => setMediaView('photo')}
                    className={`px-3 py-1 text-xs font-semibold transition-all ${
                      mediaView === 'photo' ? 'btn-prism-sunset text-white' : 'text-slate-300 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    Editorial Photo
                  </button>
                  {product.videoUrl && (
                    <button
                      type="button"
                      onClick={() => setMediaView('video')}
                      className={`px-3 py-1 text-xs font-semibold transition-all ${
                        mediaView === 'video' ? 'btn-futuristic text-white' : 'text-slate-300 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      Runway Film
                    </button>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => onOpenTryOn(product, selectedShade)}
                  className="px-3 py-1 btn-futuristic text-xs font-semibold flex items-center gap-1.5"
                >
                  <Camera className="w-3.5 h-3.5" /> Virtual Try-On
                </button>
              </div>

              {mediaView === '3d' && (
                <ThreeCosmeticStage
                  modelType={product.modelType}
                  shadeHex={selectedShade.hex}
                  shadeName={selectedShade.name}
                  productName={product.name}
                  heightClass="h-[420px] lg:h-[520px]"
                  fallbackImageUrl={product.imageUrl}
                />
              )}

              {mediaView === 'photo' && (
                <div className={`h-[420px] lg:h-[520px] ${catStyle.backdrop} relative`}>
                  <img
                    src={product.imageUrl}
                    alt={product.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
              )}

              {mediaView === 'video' && product.videoUrl && (
                <div className="h-[420px] lg:h-[520px] bg-black flex items-center justify-center">
                  <video src={product.videoUrl} controls autoPlay loop muted className="w-full h-full object-contain" />
                </div>
              )}
            </div>

            {/* Right: Contiguous Purchase Module */}
            <div className="lg:col-span-5 p-6 sm:p-8 bg-white dark:bg-[#0D1120] flex flex-col justify-between gap-6">
              <div className="space-y-5">
                <div>
                  <div className="flex items-center justify-between gap-2 text-xs text-slate-600 dark:text-slate-300">
                    <span className={`uppercase tracking-[0.15em] font-bold ${catStyle.accentText}`}>
                      {product.brand}
                    </span>
                    <span className="flex items-center gap-1 font-mono font-semibold text-amber-600 dark:text-amber-300 tabular-nums">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      {product.rating.toFixed(1)} ({productReviews.length || product.reviewCount})
                    </span>
                  </div>
                  <h1 className="font-display text-3xl font-semibold text-[#090B14] dark:text-white mt-1 leading-tight">
                    {product.name}
                  </h1>
                  <div className="flex flex-wrap items-baseline gap-3 mt-3">
                    <span className="font-mono text-2xl font-bold tabular-nums text-blue-600 dark:text-cyan-300">
                      {localizedPrice.formatted}
                    </span>
                    {localizedComparePrice && (
                      <span className="font-mono text-sm line-through text-slate-400 dark:text-slate-500 tabular-nums">
                        {localizedComparePrice.formatted}
                      </span>
                    )}
                    <span className="text-xs font-medium text-violet-600 dark:text-fuchsia-300">
                      · {localizedInfo.finishLabel}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                    {localizedPrice.transparencyNote}
                  </p>
                </div>

                {/* Localized Regional Specs, Compliance & Delivery */}
                <div className="p-3 bg-indigo-50/70 dark:bg-[#141A30] border border-indigo-500/20 dark:border-cyan-400/20 space-y-1.5 text-xs">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-indigo-800 dark:text-cyan-200 flex items-center gap-1.5">
                      <Globe className="w-3.5 h-3.5" /> {country.flag} {t('product.shipsTo')} {country.name}
                    </span>
                    <button
                      type="button"
                      onClick={() => setSelectorOpen(true)}
                      className="text-[11px] font-semibold text-[#2563EB] dark:text-[#22D3EE] hover:underline"
                    >
                      Change Region
                    </button>
                  </div>
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-slate-600 dark:text-slate-300">
                    <span className="flex items-center gap-1">
                      <Truck className="w-3 h-3 text-emerald-500" /> {localizedInfo.deliverySummary}
                    </span>
                    <span className="font-mono">
                      Size: <strong>{localizedInfo.measurement.primaryUnit}</strong> ({localizedInfo.measurement.sizeBadge})
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center justify-between gap-2 text-[11px]">
                    <span className="text-emerald-700 dark:text-emerald-300 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" /> {localizedInfo.complianceBadge}
                    </span>
                    <span className="text-slate-500 dark:text-slate-400">{country.taxLabel}</span>
                  </div>
                </div>

                <p className="text-sm text-slate-700 dark:text-slate-200 leading-relaxed">{product.description}</p>

                {/* Shade Picker */}
                <div className="pt-2 border-t border-indigo-500/15 dark:border-cyan-400/15">
                  <div className="flex items-center justify-between text-xs mb-2.5">
                    <span className="font-semibold uppercase tracking-wider text-indigo-700 dark:text-cyan-300">
                      Shade: <span className="text-[#090B14] dark:text-white">{selectedShade.name}</span>
                    </span>
                    {selectedShade.undertone && (
                      <span className="text-pink-600 dark:text-pink-300 font-medium">{selectedShade.undertone} Undertone</span>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-2.5">
                    {product.shades.map((shade) => (
                      <button
                        key={shade.id}
                        type="button"
                        onClick={() => setSelectedShade(shade)}
                        title={`${shade.name} (${shade.undertone || 'Universal'})`}
                        className={`w-9 h-9 rounded-full border-2 transition-transform ${
                          selectedShade.id === shade.id
                            ? 'border-blue-600 dark:border-cyan-300 scale-110 ring-2 ring-fuchsia-500/50'
                            : 'border-indigo-500/25 dark:border-white/25 hover:scale-105'
                        }`}
                        style={{ backgroundColor: shade.hex }}
                      />
                    ))}
                  </div>
                </div>

                {/* Subscribe & Save Auto-Replenish Selector */}
                <div className="p-3 bg-gradient-to-r from-violet-50/70 via-white to-cyan-50/60 dark:from-violet-950/30 dark:via-[#0D1120] dark:to-cyan-950/25 border border-violet-500/25 space-y-2 text-xs">
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setPurchasePlan('one_time')}
                      className={`py-2 px-2.5 border text-left transition-all ${
                        purchasePlan === 'one_time'
                          ? 'border-indigo-600 dark:border-cyan-400 bg-indigo-500/10 font-semibold'
                          : 'border-indigo-500/20 opacity-75 hover:opacity-100'
                      }`}
                    >
                      <p className="text-[11px]">One-Time Purchase</p>
                      <p className="font-mono font-bold text-[#090B14] dark:text-white">{localizedPrice.formatted}</p>
                    </button>
                    <button
                      type="button"
                      onClick={() => setPurchasePlan('subscribe')}
                      className={`py-2 px-2.5 border text-left transition-all ${
                        purchasePlan === 'subscribe'
                          ? 'border-fuchsia-500 bg-fuchsia-500/15 font-semibold'
                          : 'border-indigo-500/20 opacity-75 hover:opacity-100'
                      }`}
                    >
                      <p className="text-[11px] flex items-center gap-1 text-fuchsia-700 dark:text-fuchsia-300">
                        <Repeat className="w-3 h-3" /> Subscribe &amp; Save 12%
                      </p>
                      <p className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                        Auto-Replenish · Cancel Anytime
                      </p>
                    </button>
                  </div>
                  {purchasePlan === 'subscribe' && (
                    <div className="flex items-center justify-between gap-2 pt-1">
                      <span className="text-[11px] text-slate-600 dark:text-slate-300">Delivery Cadence:</span>
                      <div className="flex items-center gap-1.5">
                        {([30, 60, 90] as const).map((days) => (
                          <button
                            key={days}
                            type="button"
                            onClick={() => setIntervalDays(days)}
                            className={`px-2.5 py-1 text-[11px] font-semibold border ${
                              intervalDays === days
                                ? 'btn-futuristic text-white border-transparent'
                                : 'border-indigo-500/25 hover:border-cyan-400'
                            }`}
                          >
                            Every {days}d
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Primary Actions */}
                <div className="space-y-2.5 pt-2">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <button
                      type="button"
                      disabled={product.stock <= 0}
                      onClick={() => {
                        onAddToBag(
                          product,
                          selectedShade,
                          purchasePlan === 'subscribe' ? { subscriptionIntervalDays: intervalDays } : undefined,
                        );
                        setAddedFeedback(true);
                        setTimeout(() => setAddedFeedback(false), 1800);
                      }}
                      className="w-full py-3.5 btn-prism-cyan text-white text-xs font-semibold uppercase tracking-widest flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                      {addedFeedback ? (
                        <>
                          <Check className="w-4 h-4" /> Added to Bag
                        </>
                      ) : product.stock > 0 ? (
                        <>
                          <ShoppingBag className="w-4 h-4" />{' '}
                          {purchasePlan === 'subscribe' ? `Subscribe (${intervalDays}d)` : 'Add to Bag'}
                        </>
                      ) : (
                        'Out of Stock'
                      )}
                    </button>

                    {onBuyNow && (
                      <button
                        type="button"
                        disabled={product.stock <= 0}
                        onClick={() => onBuyNow(product, selectedShade)}
                        className="w-full py-3.5 btn-prism-sunset text-white text-xs font-semibold uppercase tracking-widest flex items-center justify-center gap-2 disabled:opacity-50"
                      >
                        <Zap className="w-4 h-4" /> {t('product.buyNow')} · {localizedPrice.formatted}
                      </button>
                    )}
                  </div>

                  {/* Back-in-Stock / Pre-Order VIP Waitlist */}
                  <form
                    onSubmit={handleJoinWaitlist}
                    className="p-2.5 bg-white dark:bg-[#0D1120] border border-cyan-500/25 flex flex-col sm:flex-row items-stretch sm:items-center gap-2"
                  >
                    <div className="flex items-center gap-1.5 text-[11px] font-semibold text-cyan-700 dark:text-cyan-300 shrink-0">
                      <Bell className="w-3.5 h-3.5" />
                      {product.stock <= 0 ? 'Back-in-Stock Alert:' : 'Pre-Order / Batch Drop:'}
                    </div>
                    <input
                      type="email"
                      required
                      value={alertEmail}
                      onChange={(e) => setAlertEmail(e.target.value)}
                      placeholder="your@email.com"
                      className="flex-1 px-2.5 py-1.5 text-xs border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
                    />
                    <button
                      type="submit"
                      disabled={alertSaving}
                      className="px-3 py-1.5 btn-prism-gold text-white text-[11px] font-semibold whitespace-nowrap disabled:opacity-50"
                    >
                      {alertSaving ? 'Saving…' : 'Notify Me'}
                    </button>
                  </form>
                  {alertFeedback && (
                    <p className="text-[11px] text-emerald-700 dark:text-emerald-300 font-medium">{alertFeedback}</p>
                  )}

                  <div className="grid grid-cols-2 gap-2.5">
                    <button
                      type="button"
                      onClick={() => onToggleWishlist(product, selectedShade)}
                      className={`py-2.5 px-3 border text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                        isWishlisted
                          ? 'border-pink-500 text-pink-600 dark:text-pink-300 bg-pink-500/15'
                          : 'border-indigo-500/20 dark:border-cyan-400/20 hover:border-pink-500 hover:text-pink-600 dark:hover:text-pink-300'
                      }`}
                    >
                      <Heart className={`w-3.5 h-3.5 ${isWishlisted ? 'fill-pink-500 text-pink-500' : ''}`} />
                      {isWishlisted ? 'Saved' : 'Wishlist'}
                    </button>

                    <button
                      type="button"
                      onClick={() => onToggleCompare(product)}
                      className={`py-2.5 px-3 border text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                        isCompared
                          ? 'btn-futuristic border-transparent text-white'
                          : 'border-indigo-500/20 dark:border-cyan-400/20 hover:border-cyan-500 hover:text-blue-600 dark:hover:text-cyan-300'
                      }`}
                    >
                      <Scale className="w-3.5 h-3.5" />
                      {isCompared ? 'Comparing' : 'Compare'}
                    </button>
                  </div>
                </div>

                {/* Ingredient Transparency */}
                <div className="pt-4 border-t border-indigo-500/15 dark:border-cyan-400/15 space-y-2">
                  <p className="text-xs font-semibold uppercase tracking-wider text-indigo-700 dark:text-cyan-300">
                    Full Ingredient Transparency (INCI)
                  </p>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{product.ingredients}</p>
                  <p className="text-xs text-slate-600 dark:text-slate-300">
                    <span className="font-semibold text-[#090B14] dark:text-white">Availability:</span>{' '}
                    <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">{product.stock}</span> units in atelier vault
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Customer Reviews & Photo Reviews Section */}
          <div className="p-6 sm:p-8 border-t border-indigo-500/15 dark:border-cyan-400/15 bg-[#F5F7FF] dark:bg-[#06070E]">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              <div className="lg:col-span-7 space-y-4">
                <h3 className="font-display text-2xl font-semibold gradient-heading">
                  Verified Reviews &amp; Real Shade Photos ({productReviews.length})
                </h3>
                {productReviews.length === 0 ? (
                  <p className="text-sm text-slate-600 dark:text-slate-300 bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-5">
                    No customer reviews yet for this formula. Be the first to share a shade review.
                  </p>
                ) : (
                  <div className="space-y-4">
                    {productReviews.map((rev) => (
                      <div
                        key={rev.id}
                        className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-5 space-y-2 glow-border"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-semibold text-[#090B14] dark:text-white">{rev.authorName}</span>
                            {rev.shadeName && (
                              <span className="text-xs text-fuchsia-600 dark:text-pink-300 font-medium">· Shade: {rev.shadeName}</span>
                            )}
                          </div>
                          <div className="flex items-center gap-0.5">
                            {Array.from({ length: rev.rating }).map((_, idx) => (
                              <Star key={idx} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                            ))}
                          </div>
                        </div>
                        <p className="text-sm font-semibold text-[#090B14] dark:text-white">{rev.title}</p>
                        <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">{rev.comment}</p>
                        {rev.photoUrl && (
                          <img
                            src={rev.photoUrl}
                            alt={`Customer review by ${rev.authorName}`}
                            referrerPolicy="no-referrer"
                            className="mt-2 h-28 w-36 object-cover border border-indigo-500/20 dark:border-cyan-400/20"
                          />
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <form
                onSubmit={handleSubmitReview}
                className="lg:col-span-5 bg-white dark:bg-[#0D1120] border border-violet-500/25 p-5 space-y-4 h-fit glow-border"
              >
                <h4 className="font-display text-xl font-semibold gradient-heading">Write a Photo Review</h4>
                <div>
                  <label className="block text-xs font-semibold text-indigo-700 dark:text-cyan-300 mb-1">Rating</label>
                  <div className="flex items-center gap-1.5">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setRating(star)}
                        className="p-1"
                        aria-label={`Rate ${star} stars`}
                      >
                        <Star
                          className={`w-5 h-5 ${
                            star <= rating ? 'fill-amber-400 text-amber-400' : 'text-slate-300 dark:text-slate-600'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-indigo-700 dark:text-cyan-300 mb-1">Review Title</label>
                  <input
                    type="text"
                    value={reviewTitle}
                    onChange={(e) => setReviewTitle(e.target.value)}
                    placeholder="e.g. Effortless satin pigment"
                    className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-indigo-700 dark:text-cyan-300 mb-1">Your Experience</label>
                  <textarea
                    rows={3}
                    value={reviewComment}
                    onChange={(e) => setReviewComment(e.target.value)}
                    placeholder="Share wear time, undertone match, and texture..."
                    className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                  />
                </div>
                <div>
                  <label className="flex items-center gap-2 text-xs font-semibold text-indigo-700 dark:text-cyan-300 cursor-pointer border border-dashed border-indigo-500/35 dark:border-cyan-400/35 p-2.5 bg-[#F5F7FF] dark:bg-[#141A30] hover:border-fuchsia-500">
                    <Upload className="w-4 h-4 text-fuchsia-500" />
                    <span>{uploadingPhoto ? 'Uploading photo...' : reviewPhotoUrl ? 'Photo Attached' : 'Attach Look Photo (Optional)'}</span>
                    <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
                  </label>
                </div>
                <button
                  type="submit"
                  disabled={submittingReview || uploadingPhoto}
                  className="w-full py-2.5 btn-futuristic text-xs font-semibold uppercase tracking-wider disabled:opacity-60"
                >
                  {submittingReview ? 'Publishing...' : 'Publish Review'}
                </button>
                {reviewMessage && <p className="text-xs font-medium text-emerald-600 dark:text-emerald-400">{reviewMessage}</p>}
              </form>
            </div>
          </div>
        </div>
    </CinematicModal>
  );
};
