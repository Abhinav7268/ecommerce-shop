import React from 'react';
import { CinematicModal } from './MotionPrimitives';
import { X, ShoppingBag } from 'lucide-react';
import { CurrencyCode, formatMoney, Product, ProductShade } from '../types/store';
import { getCategoryStyle } from '../lib/themePalette';

interface CompareDrawerProps {
  items: Product[];
  currency: CurrencyCode;
  onRemove: (productId: string) => void;
  onClose: () => void;
  onAddToBag: (product: Product, shade: ProductShade) => void;
}

export const CompareDrawer: React.FC<CompareDrawerProps> = ({
  items,
  currency,
  onRemove,
  onClose,
  onAddToBag,
}) => {
  if (items.length === 0) return null;

  return (
    <CinematicModal
      onBackdropClick={onClose}
      backdropClassName="flex items-end sm:items-center justify-center p-0 sm:p-4"
      panelClassName="bg-[#F5F7FF] dark:bg-[#06070E] text-[#0A0C12] dark:text-[#F5F7FF] w-full max-w-5xl border border-indigo-500/25 dark:border-cyan-400/25 prism-modal-rim shadow-2xl max-h-[88vh] flex flex-col overflow-hidden"
    >
        <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-[#2563EB] via-[#06B6D4] to-[#7C3AED] text-white">
          <div>
            <p className="text-[11px] uppercase tracking-[0.22em] text-cyan-100 font-semibold">
              Formula Intelligence Matrix
            </p>
            <h2 className="font-display text-2xl font-semibold text-white">
              Side-by-Side Comparison ({items.length})
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Comparison"
            className="p-2 bg-white/15 hover:bg-white/25 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="prism-divider shrink-0" />

        <div className="overflow-x-auto p-6 bg-white dark:bg-[#0D1120]">
          <table className="w-full text-left border-collapse min-w-[640px]">
            <thead>
              <tr className="border-b-2 border-indigo-500/20 dark:border-cyan-400/20 bg-gradient-to-r from-indigo-500/5 via-cyan-500/5 to-fuchsia-500/5">
                <th className="py-3.5 px-4 text-xs font-semibold uppercase tracking-wider text-[#2563EB] dark:text-[#22D3EE] w-40">
                  Attribute
                </th>
                {items.map((prod) => {
                  const catStyle = getCategoryStyle(prod.category);
                  return (
                    <th key={prod.id} className="py-3.5 px-4 align-top w-64">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <span
                            className={`inline-block px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-white mb-1.5 bg-gradient-to-r ${catStyle.labelGradient}`}
                          >
                            {prod.category}
                          </span>
                          <p className="font-display text-lg font-semibold leading-tight">{prod.name}</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => onRemove(prod.id)}
                          className="text-xs font-semibold text-rose-600 dark:text-rose-400 hover:underline shrink-0"
                        >
                          Remove
                        </button>
                      </div>
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody className="text-sm divide-y divide-indigo-500/15 dark:divide-cyan-400/15">
              <tr className="hover:bg-indigo-500/[0.03] dark:hover:bg-cyan-400/[0.04]">
                <td className="py-3.5 px-4 text-xs font-semibold uppercase tracking-wider text-[#475569] dark:text-white/70">Price</td>
                {items.map((p) => (
                  <td key={p.id} className="py-3.5 px-4 font-mono tabular-nums font-bold text-[#2563EB] dark:text-[#22D3EE]">
                    {formatMoney(p.price, currency)}
                  </td>
                ))}
              </tr>
              <tr className="hover:bg-indigo-500/[0.03] dark:hover:bg-cyan-400/[0.04]">
                <td className="py-3.5 px-4 text-xs font-semibold uppercase tracking-wider text-[#475569] dark:text-white/70">Finish</td>
                {items.map((p) => (
                  <td key={p.id} className="py-3.5 px-4 font-medium">
                    <span className="px-2 py-0.5 text-xs bg-violet-500/12 text-[#7C3AED] dark:text-violet-300 font-semibold">
                      {p.finish}
                    </span>
                  </td>
                ))}
              </tr>
              <tr className="hover:bg-indigo-500/[0.03] dark:hover:bg-cyan-400/[0.04]">
                <td className="py-3.5 px-4 text-xs font-semibold uppercase tracking-wider text-[#475569] dark:text-white/70">Collection</td>
                {items.map((p) => (
                  <td key={p.id} className="py-3.5 px-4 font-medium">
                    {p.collection}
                  </td>
                ))}
              </tr>
              <tr className="hover:bg-indigo-500/[0.03] dark:hover:bg-cyan-400/[0.04]">
                <td className="py-3.5 px-4 text-xs font-semibold uppercase tracking-wider text-[#475569] dark:text-white/70">Shades</td>
                {items.map((p) => (
                  <td key={p.id} className="py-3.5 px-4">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {p.shades.map((s) => (
                        <span
                          key={s.id}
                          title={s.name}
                          className="w-4.5 h-4.5 rounded-full border border-black/15 dark:border-white/30 shadow-sm"
                          style={{ backgroundColor: s.hex }}
                        />
                      ))}
                      <span className="text-xs font-medium text-[#475569] dark:text-white/70 ml-1">
                        {p.shades.length} shades
                      </span>
                    </div>
                  </td>
                ))}
              </tr>
              <tr className="hover:bg-indigo-500/[0.03] dark:hover:bg-cyan-400/[0.04]">
                <td className="py-3.5 px-4 text-xs font-semibold uppercase tracking-wider text-[#475569] dark:text-white/70">Key Ingredients</td>
                {items.map((p) => (
                  <td key={p.id} className="py-3.5 px-4 text-xs text-[#475569] dark:text-white/75 leading-relaxed">
                    {p.ingredients}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-4 px-4 text-xs font-semibold uppercase tracking-wider text-[#475569] dark:text-white/70">Action</td>
                {items.map((p) => (
                  <td key={p.id} className="py-4 px-4">
                    <button
                      type="button"
                      onClick={() => onAddToBag(p, p.shades[0])}
                      className="px-4 py-2 btn-prism-cyan text-xs font-semibold inline-flex items-center gap-1.5"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" /> Add to Bag
                    </button>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
    </CinematicModal>
  );
};
