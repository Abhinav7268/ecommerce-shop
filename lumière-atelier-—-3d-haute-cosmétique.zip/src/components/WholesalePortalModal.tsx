import React, { useMemo, useState } from 'react';
import { AnimatedProgressBar, CinematicModal } from './MotionPrimitives';
import {
  Building2,
  CheckCircle2,
  FileSpreadsheet,
  FileText,
  PackageCheck,
  Printer,
  RefreshCw,
  ShoppingCart,
  Upload,
  X,
} from 'lucide-react';
import { doc, serverTimestamp, setDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { getProductErpDefaults } from '../data/seedErp';
import {
  CurrencyCode,
  CustomerType,
  formatMoney,
  Order,
  Product,
  Supplier,
  WholesaleAccount,
  WholesaleQuote,
} from '../types/store';

interface WholesalePortalModalProps {
  products: Product[];
  suppliers: Supplier[];
  wholesaleAccounts: WholesaleAccount[];
  wholesaleQuotes: WholesaleQuote[];
  orders: Order[];
  currency: CurrencyCode;
  userUid?: string;
  userEmail?: string;
  userName?: string;
  onOpenAuth: () => void;
  onClose: () => void;
}

export const WholesalePortalModal: React.FC<WholesalePortalModalProps> = ({
  products,
  suppliers,
  wholesaleAccounts,
  wholesaleQuotes,
  orders,
  currency,
  userUid,
  userEmail,
  userName,
  onOpenAuth,
  onClose,
}) => {
  const [tab, setTab] = useState<'matrix' | 'csv' | 'quotes' | 'account' | 'history'>('matrix');
  const [feedback, setFeedback] = useState<string | null>(null);

  const userAccount = useMemo(
    () => wholesaleAccounts.find((a) => a.userId === userUid) || null,
    [wholesaleAccounts, userUid],
  );
  const activeTier: Exclude<CustomerType, 'retail'> =
    userAccount?.status === 'approved' ? userAccount.tier : 'wholesale';

  // Tier Pricing Helper
  const getTierPrice = (p: Product, idx: number, tier: Exclude<CustomerType, 'retail'>) => {
    const erp = getProductErpDefaults(p, idx);
    if (tier === 'distributor' || tier === 'enterprise') return p.distributorPrice ?? erp.distributorPrice;
    if (tier === 'dealer') return p.dealerPrice ?? erp.dealerPrice;
    return p.wholesalePrice ?? erp.wholesalePrice;
  };

  // Bulk Quick Order Quantities (by productId)
  const [bulkQty, setBulkQty] = useState<Record<string, number>>({});
  const [paymentMode, setPaymentMode] = useState<'Credit Terms' | 'Razorpay' | 'Stripe'>('Credit Terms');
  const [shippingCity, setShippingCity] = useState('Mumbai');
  const [shippingAddressLine, setShippingAddressLine] = useState('Trade Tower, BKC Commercial District');
  const [submittingOrder, setSubmittingOrder] = useState(false);

  // CSV Bulk Order Input
  const [csvBulkText, setCsvBulkText] = useState('LA-LIP-001,15\nLA-FND-004,12');

  // Quote / RFQ Form
  const [quoteNotes, setQuoteNotes] = useState('Need Q3 bridal bulk allocation with custom LUMIÈRE ATELIER ribbon seal.');
  const [submittingQuote, setSubmittingQuote] = useState(false);

  // Registration Form
  const [bizName, setBizName] = useState('');
  const [contactName, setContactName] = useState(userName || '');
  const [bizPhone, setBizPhone] = useState('');
  const [gstNumber, setGstNumber] = useState('');
  const [requestedTier, setRequestedTier] = useState<Exclude<CustomerType, 'retail'>>('dealer');
  const [submittingReg, setSubmittingReg] = useState(false);

  const selectedLines = useMemo(() => {
    return products
      .map((p, idx) => {
        const qty = Math.max(0, Math.round(bulkQty[p.id] || 0));
        if (qty <= 0) return null;
        const erp = getProductErpDefaults(p, idx);
        const moq = p.moq ?? erp.moq;
        const unitPrice = getTierPrice(p, idx, activeTier);
        return { product: p, idx, erp, moq, qty, unitPrice, lineTotal: unitPrice * qty };
      })
      .filter((x): x is NonNullable<typeof x> => Boolean(x));
  }, [products, bulkQty, activeTier]);

  const bulkSubtotal = selectedLines.reduce((s, l) => s + l.lineTotal, 0);
  const moqViolations = selectedLines.filter((l) => l.qty < l.moq);

  const [csvParsing, setCsvParsing] = useState(false);
  const [csvErrors, setCsvErrors] = useState<string[]>([]);

  const handleCsvFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setCsvBulkText(String(reader.result || ''));
    reader.readAsText(file);
  };

  const applyCsvUpload = async () => {
    setCsvParsing(true);
    setCsvErrors([]);
    try {
      const res = await fetch('/api/wholesale/parse-bulk-csv', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          csvText: csvBulkText,
          tier: activeTier,
          catalog: products.map((p, idx) => {
            const erp = getProductErpDefaults(p, idx);
            return {
              id: p.id,
              sku: p.sku,
              name: p.name,
              price: p.price,
              wholesalePrice: p.wholesalePrice ?? erp.wholesalePrice,
              dealerPrice: p.dealerPrice ?? erp.dealerPrice,
              distributorPrice: p.distributorPrice ?? erp.distributorPrice,
              moq: p.moq ?? erp.moq,
            };
          }),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'CSV parsing failed');
      const nextQty: Record<string, number> = { ...bulkQty };
      for (const item of data.matched || []) {
        nextQty[item.productId] = item.quantity;
      }
      setBulkQty(nextQty);
      if (Array.isArray(data.errors) && data.errors.length > 0) {
        setCsvErrors(data.errors);
      }
      if ((data.matchedCount || 0) > 0) {
        setTab('matrix');
        setFeedback(
          `Server validated ${data.matchedCount} SKU(s) (${data.totalUnits} units · ${formatMoney(data.totalUsd, currency)}) into your Bulk Order Matrix.`,
        );
      } else {
        setFeedback('No matching SKUs found. Check CSV formatting (SKU,Quantity).');
      }
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Bulk CSV upload failed.');
    } finally {
      setCsvParsing(false);
    }
  };

  const placeWholesaleOrder = async () => {
    if (!userUid) {
      onOpenAuth();
      return;
    }
    if (selectedLines.length === 0) {
      setFeedback('Enter quantities for at least one SKU.');
      return;
    }
    if (moqViolations.length > 0) {
      setFeedback(
        `MOQ not met for: ${moqViolations.map((v) => `${v.product.name} (Min ${v.moq})`).join(', ')}. Adjust quantities or submit an RFQ.`,
      );
      return;
    }

    setSubmittingOrder(true);
    const orderId = `ord_b2b_${Date.now()}`;
    const orderSource =
      activeTier === 'distributor'
        ? 'Distributor Orders'
        : activeTier === 'dealer'
          ? 'Dealer Orders'
          : 'Retailer Orders';

    try {
      const routeRes = await fetch('/api/orders/route', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId,
          orderSource,
          customerType: activeTier,
          paymentGateway: paymentMode === 'Credit Terms' ? 'COD' : paymentMode,
          discount: 0,
          shippingCost: 18,
          requestedPackagingType: 'wholesale_master_carton',
          items: selectedLines.map((l) => ({
            productId: l.product.id,
            name: l.product.name,
            sku: l.product.sku,
            shadeName: l.product.shades[0]?.name || 'Assorted',
            shadeHex: l.product.shades[0]?.hex || '#9E1B32',
            quantity: l.qty,
            unitPrice: l.unitPrice,
            purchasePrice: l.erp.purchasePrice,
            supplierId: l.erp.supplierId,
            supplierSku: l.erp.supplierSku,
            warehouseId: l.erp.warehouseId,
            fulfillmentMethod: l.erp.fulfillmentMethod,
            ownedStock: l.erp.ownedStock,
            supplierStock: l.erp.supplierStock,
          })),
          suppliers: suppliers.map((s) => ({
            id: s.id,
            companyName: s.companyName,
            email: s.email,
            integrationType: s.integrationType,
            leadTimeDays: s.leadTimeDays,
            privateLabelCapable: s.privateLabelCapable,
          })),
        }),
      });
      const routed = await routeRes.json();
      if (!routeRes.ok) throw new Error(routed.error || 'Routing failed');

      const poIds = (routed.purchaseOrders || []).map((po: { id: string }) => po.id);
      await setDoc(doc(db, 'orders', orderId), {
        id: orderId,
        userId: userUid,
        customerName: userAccount?.businessName || userName || 'Wholesale Partner',
        customerEmail: userEmail || '',
        items: selectedLines.map((l) => ({
          productId: l.product.id,
          name: l.product.name,
          shadeName: l.product.shades[0]?.name || 'Assorted',
          shadeHex: l.product.shades[0]?.hex || '#9E1B32',
          quantity: l.qty,
          unitPrice: l.unitPrice,
          purchaseCost: Number((l.erp.purchasePrice * l.qty).toFixed(2)),
          supplierId: l.erp.supplierId,
          fulfillmentMethod: l.erp.fulfillmentMethod,
        })),
        subtotal: Number(bulkSubtotal.toFixed(2)),
        discount: 0,
        total: Number((bulkSubtotal + 18).toFixed(2)),
        currency,
        paymentGateway: paymentMode === 'Credit Terms' ? 'COD' : paymentMode,
        paymentMethod: paymentMode === 'Credit Terms' ? `Net ${userAccount?.creditTermsDays || 30} Days` : paymentMode,
        paymentStatus: paymentMode === 'Credit Terms' ? 'pending' : 'paid',
        orderStatus: 'confirmed',
        trackingNumber: `B2B-${Math.floor(100000 + Math.random() * 899999)}`,
        shippingAddress: {
          id: 'b2b_primary',
          label: 'Commercial Hub',
          fullName: userAccount?.businessName || userName || 'Wholesale Partner',
          phone: userAccount?.phone || '+91 98200 00000',
          line1: shippingAddressLine,
          city: shippingCity,
          state: 'Commercial Zone',
          postalCode: '400051',
          country: 'India',
        },
        refundStatus: 'none',
        refundAmount: 0,
        orderSource,
        salesChannel: 'WHOLESALE_B2B',
        customerType: activeTier,
        fulfillmentType: routed.fulfillmentType || 'offline_wholesale',
        erpStatus: routed.erpStatus || 'ORDER_VERIFIED',
        warehouseId: routed.warehouseId || 'wh_mumbai_central',
        ...(poIds.length > 0 ? { supplierOrderIds: poIds } : {}),
        purchaseCost: routed.financials?.purchaseCost ?? 0,
        shippingCost: 18,
        packagingCost: routed.financials?.packagingCost ?? 4.2,
        gatewayFee: routed.financials?.gatewayFee ?? 0,
        taxAmount: routed.financials?.taxAmount ?? 0,
        grossProfit: routed.financials?.grossProfit ?? 0,
        netProfit: routed.financials?.netProfit ?? 0,
        timeline: routed.timeline || [],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      for (const po of routed.purchaseOrders || []) {
        await setDoc(doc(db, 'purchaseOrders', po.id), {
          ...po,
          customerUid: userUid,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }

      setBulkQty({});
      setFeedback(`Wholesale Order #${orderId} placed & routed (${routed.fulfillmentType}).`);
      setTab('history');
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Wholesale order placement failed.');
    } finally {
      setSubmittingOrder(false);
    }
  };

  const submitRfq = async () => {
    if (!userUid) {
      onOpenAuth();
      return;
    }
    if (selectedLines.length === 0) {
      setFeedback('Select at least one product quantity in the Quick SKU Matrix to request a custom quote.');
      return;
    }
    setSubmittingQuote(true);
    const quoteId = `rfq_${Date.now()}`;
    try {
      await setDoc(doc(db, 'wholesaleQuotes', quoteId), {
        id: quoteId,
        accountId: userAccount?.id || `wacc_${userUid}`,
        userId: userUid,
        businessName: userAccount?.businessName || userName || 'Prospective B2B Partner',
        items: selectedLines.map((l) => ({
          productId: l.product.id,
          sku: l.product.sku,
          name: l.product.name,
          quantity: l.qty,
          targetUnitPrice: Number((l.unitPrice * 0.92).toFixed(2)),
        })),
        requestedTotal: Number((bulkSubtotal * 0.92).toFixed(2)),
        status: 'requested',
        notes: quoteNotes.trim(),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setFeedback(`Quote Request #${quoteId} submitted for executive pricing review.`);
      setTab('quotes');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `wholesaleQuotes/${quoteId}`);
    } finally {
      setSubmittingQuote(false);
    }
  };

  const submitWholesaleApplication = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userUid) {
      onOpenAuth();
      return;
    }
    setSubmittingReg(true);
    const id = `wacc_${userUid}`;
    try {
      await setDoc(doc(db, 'wholesaleAccounts', id), {
        id,
        userId: userUid,
        businessName: bizName.trim(),
        contactName: contactName.trim(),
        email: userEmail || '',
        phone: bizPhone.trim(),
        gstNumber: gstNumber.trim().toUpperCase(),
        tier: requestedTier,
        status: 'pending',
        creditLimit: 0,
        creditUsed: 0,
        creditTermsDays: 0,
        discountPercent: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setFeedback('Wholesale & GST application submitted. Admin approval unlocks dealer credit terms.');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `wholesaleAccounts/${id}`);
    } finally {
      setSubmittingReg(false);
    }
  };

  const wholesaleOrders = orders.filter(
    (o) => o.salesChannel === 'WHOLESALE_B2B' || (o.customerType && o.customerType !== 'retail'),
  );

  return (
    <CinematicModal
      backdropClassName="flex items-center justify-center p-2 sm:p-4"
      panelClassName="bg-[#F5F7FF] dark:bg-[#06070E] text-[#090B14] dark:text-[#F8FAFF] w-full max-w-6xl border border-orange-500/30 dark:border-amber-400/25 shadow-2xl max-h-[94vh] flex flex-col overflow-hidden prism-modal-rim"
    >
        <div className="px-6 py-4 bg-gradient-to-r from-[#090B1A] via-[#2B1438] to-[#3B180A] text-white flex items-center justify-between gap-4">
          <div>
            <p className="text-[11px] uppercase tracking-[0.22em] text-amber-300 font-semibold">
              B2B Trade &amp; Distribution Portal
            </p>
            <h2 className="font-display text-2xl font-semibold gradient-heading-warm">
              Wholesale, Dealer &amp; Distributor Desk
            </h2>
          </div>
          <div className="flex items-center gap-3">
            <span className="px-3 py-1 bg-gradient-to-r from-amber-500/20 to-orange-500/25 border border-amber-400/40 text-xs font-mono text-amber-200 whitespace-nowrap">
              Active Tier: <strong className="text-amber-300 uppercase">{activeTier}</strong>
            </span>
            <button type="button" onClick={onClose} aria-label="Close Wholesale Portal" className="p-2 hover:bg-white/10 transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
        <div className="prism-divider shrink-0" />

        {/* Navigation Bar */}
        <div className="px-6 py-2.5 bg-white dark:bg-[#0D1120] border-b border-indigo-500/15 dark:border-cyan-400/15 flex items-center gap-1.5 overflow-x-auto">
          {(
            [
              { id: 'matrix', label: 'Quick SKU Matrix', icon: ShoppingCart, active: 'btn-prism-sunset' },
              { id: 'csv', label: 'CSV Bulk Upload', icon: FileSpreadsheet, active: 'btn-prism-cyan' },
              { id: 'quotes', label: `Quotes & RFQ (${wholesaleQuotes.length})`, icon: FileText, active: 'btn-futuristic' },
              { id: 'account', label: 'Business & GST Registration', icon: Building2, active: 'btn-prism-gold' },
              { id: 'history', label: `B2B Orders (${wholesaleOrders.length})`, icon: RefreshCw, active: 'btn-prism-emerald' },
            ] as const
          ).map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setTab(item.id)}
                className={`px-3.5 py-2 text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-all ${
                  tab === item.id
                    ? `${item.active} text-white`
                    : 'text-slate-600 dark:text-slate-300 hover:bg-orange-500/10 hover:text-orange-600 dark:hover:text-amber-300'
                }`}
              >
                <Icon className="w-3.5 h-3.5" /> {item.label}
              </button>
            );
          })}
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {userAccount && userAccount.creditLimit > 0 && (
            <div className="bg-gradient-to-br from-amber-50 via-white to-orange-50/70 dark:from-amber-950/35 dark:via-[#0D1120] dark:to-orange-950/25 border border-amber-500/30 p-4 glow-border">
              <AnimatedProgressBar
                label={`Corporate Credit Facility (${userAccount.businessName})`}
                valueLabel={`${formatMoney(userAccount.creditUsed, currency)} / ${formatMoney(userAccount.creditLimit, currency)}`}
                percent={(userAccount.creditUsed / Math.max(1, userAccount.creditLimit)) * 100}
                tone="orange"
              />
            </div>
          )}

          {feedback && (
            <div className="bg-gradient-to-r from-cyan-50 via-white to-violet-50 dark:from-cyan-950/40 dark:via-[#0D1120] dark:to-violet-950/40 border border-cyan-500/40 px-4 py-2.5 text-xs flex justify-between items-center font-medium">
              <span className="text-slate-800 dark:text-cyan-100">{feedback}</span>
              <button type="button" onClick={() => setFeedback(null)} className="text-indigo-600 dark:text-cyan-300 font-semibold hover:underline">
                Dismiss
              </button>
            </div>
          )}

          {!userUid && (
            <div className="bg-gradient-to-r from-violet-50 via-white to-pink-50 dark:from-violet-950/40 dark:via-[#0D1120] dark:to-pink-950/30 border border-violet-500/30 p-4 flex items-center justify-between gap-4">
              <p className="text-xs text-slate-700 dark:text-slate-200">
                Sign in with your corporate email to submit wholesale orders, GST verification, and custom RFQs.
              </p>
              <button
                type="button"
                onClick={onOpenAuth}
                className="px-4 py-2 btn-futuristic text-white text-xs font-semibold shrink-0"
              >
                Sign In
              </button>
            </div>
          )}

          {tab === 'matrix' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-8 bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 overflow-x-auto glow-border">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-indigo-500/20 dark:border-cyan-400/20 text-indigo-700 dark:text-cyan-300 uppercase tracking-wider">
                      <th className="py-3 px-4">SKU &amp; Product</th>
                      <th className="py-3 px-3 text-right">Retail</th>
                      <th className="py-3 px-3 text-right">Your Tier</th>
                      <th className="py-3 px-3 text-right">MOQ</th>
                      <th className="py-3 px-3 text-right">Avail</th>
                      <th className="py-3 px-4 text-right">Order Qty</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-indigo-500/10 dark:divide-cyan-400/10">
                    {products.map((p, idx) => {
                      const erp = getProductErpDefaults(p, idx);
                      const moq = p.moq ?? erp.moq;
                      const tierPrice = getTierPrice(p, idx, activeTier);
                      const qty = bulkQty[p.id] || 0;
                      const underMoq = qty > 0 && qty < moq;
                      return (
                        <tr key={p.id}>
                          <td className="py-2.5 px-4">
                            <p className="font-semibold text-[#090B14] dark:text-white">{p.name}</p>
                            <p className="font-mono text-[11px] text-slate-500 dark:text-slate-400">
                              {p.sku} · <span className="text-violet-600 dark:text-fuchsia-400">{erp.fulfillmentMethod.replace('_', ' ')}</span>
                            </p>
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-400 dark:text-slate-500 line-through">
                            {formatMoney(p.price, currency)}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono tabular-nums font-bold text-emerald-600 dark:text-emerald-400">
                            {formatMoney(tierPrice, currency)}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono tabular-nums text-orange-600 dark:text-amber-300 font-semibold">{moq}</td>
                          <td className="py-2.5 px-3 text-right font-mono tabular-nums text-blue-600 dark:text-cyan-300">
                            {(p.ownedStock ?? erp.ownedStock) + (p.supplierStock ?? erp.supplierStock)}
                          </td>
                          <td className="py-2.5 px-4 text-right">
                            <input
                              type="number"
                              min={0}
                              value={qty || ''}
                              placeholder="0"
                              onChange={(e) =>
                                setBulkQty((prev) => ({
                                  ...prev,
                                  [p.id]: Math.max(0, Math.round(Number(e.target.value) || 0)),
                                }))
                              }
                              className={`w-20 px-2 py-1 text-right font-mono tabular-nums border bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white ${
                                underMoq ? 'border-orange-500 text-orange-600 dark:text-amber-300' : 'border-indigo-500/25 dark:border-cyan-400/25'
                              }`}
                            />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Bulk Checkout & Quote Summary */}
              <div className="lg:col-span-4 bg-gradient-to-b from-white via-white to-orange-50/40 dark:from-[#0D1120] dark:via-[#0D1120] dark:to-orange-950/20 border border-orange-500/25 dark:border-amber-400/25 p-5 space-y-4 h-fit glow-border">
                <h3 className="font-display text-xl font-semibold gradient-heading-warm">Wholesale Order Summary</h3>
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-600 dark:text-slate-300">Selected SKUs</span>
                    <span className="font-mono tabular-nums font-semibold text-violet-600 dark:text-violet-300">{selectedLines.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600 dark:text-slate-300">Total Units</span>
                    <span className="font-mono tabular-nums font-semibold text-cyan-600 dark:text-cyan-300">
                      {selectedLines.reduce((s, l) => s + l.qty, 0)}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm font-bold pt-2 border-t border-indigo-500/15 dark:border-cyan-400/15">
                    <span>Tier Subtotal</span>
                    <span className="font-mono tabular-nums text-emerald-600 dark:text-emerald-400">{formatMoney(bulkSubtotal, currency)}</span>
                  </div>
                </div>

                {moqViolations.length > 0 && (
                  <p className="text-[11px] text-orange-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/35 border border-amber-500/40 p-2.5">
                    MOQ alert: {moqViolations.length} SKU(s) are below minimum order quantity. Increase units or submit a custom Quote Request (RFQ).
                  </p>
                )}

                <div className="space-y-2 text-xs">
                  <label className="block font-semibold text-indigo-700 dark:text-cyan-300">Delivery City / Commercial Hub</label>
                  <input
                    type="text"
                    value={shippingCity}
                    onChange={(e) => setShippingCity(e.target.value)}
                    className="w-full px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
                  />
                  <input
                    type="text"
                    value={shippingAddressLine}
                    onChange={(e) => setShippingAddressLine(e.target.value)}
                    className="w-full px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
                  />
                  <label className="block font-semibold text-indigo-700 dark:text-cyan-300 pt-1">Settlement Terms</label>
                  <select
                    value={paymentMode}
                    onChange={(e) => setPaymentMode(e.target.value as 'Credit Terms' | 'Razorpay' | 'Stripe')}
                    className="w-full px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
                  >
                    <option value="Credit Terms">B2B Credit Terms (Net 30/45 Invoice)</option>
                    <option value="Razorpay">Instant Razorpay Corporate UPI / RTGS</option>
                    <option value="Stripe">International Corporate Card (Stripe)</option>
                  </select>
                </div>

                <div className="space-y-2 pt-2">
                  <button
                    type="button"
                    disabled={submittingOrder || selectedLines.length === 0}
                    onClick={placeWholesaleOrder}
                    className="w-full py-3 btn-prism-sunset text-white text-xs font-semibold uppercase tracking-widest disabled:opacity-50"
                  >
                    {submittingOrder ? 'Routing B2B Order...' : 'Place Bulk Order'}
                  </button>
                  <button
                    type="button"
                    disabled={submittingQuote || selectedLines.length === 0}
                    onClick={submitRfq}
                    className="w-full py-2.5 btn-prism-outline text-xs font-semibold disabled:opacity-50"
                  >
                    {submittingQuote ? 'Submitting RFQ...' : 'Request Custom Quote (RFQ)'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {tab === 'csv' && (
            <div className="bg-white dark:bg-[#0D1120] border border-cyan-500/25 p-6 space-y-4 max-w-2xl glow-border">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="font-display text-xl font-semibold gradient-heading">CSV / Excel Bulk Order Upload</h3>
                <label className="px-3 py-1.5 border border-cyan-500/40 text-cyan-700 dark:text-cyan-300 text-xs font-semibold cursor-pointer hover:bg-cyan-500/10 flex items-center gap-1.5">
                  <FileSpreadsheet className="w-3.5 h-3.5" /> Import .CSV File
                  <input type="file" accept=".csv,.txt" onChange={handleCsvFileUpload} className="hidden" />
                </label>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300">
                Upload a `.csv` file or paste comma-separated lines (`SKU,Quantity`) for live server-side tier pricing &amp; MOQ validation.
              </p>
              <textarea
                rows={6}
                value={csvBulkText}
                onChange={(e) => setCsvBulkText(e.target.value)}
                className="w-full p-3 font-mono text-xs border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
              />
              {csvErrors.length > 0 && (
                <div className="p-3 bg-rose-50 dark:bg-rose-950/35 border border-rose-500/35 text-[11px] text-rose-700 dark:text-rose-300 space-y-1">
                  {csvErrors.map((err, i) => (
                    <p key={i}>{err}</p>
                  ))}
                </div>
              )}
              <button
                type="button"
                disabled={csvParsing}
                onClick={() => void applyCsvUpload()}
                className="px-5 py-2.5 btn-prism-cyan text-white text-xs font-semibold uppercase tracking-wider flex items-center gap-2 disabled:opacity-50"
              >
                <Upload className="w-3.5 h-3.5" /> {csvParsing ? 'Validating SKUs & MOQ…' : 'Validate & Load into Order Matrix'}
              </button>
            </div>
          )}

          {tab === 'quotes' && (
            <div className="space-y-4">
              <div className="bg-white dark:bg-[#0D1120] border border-violet-500/25 p-5 space-y-3 glow-border">
                <h3 className="font-display text-xl font-semibold gradient-heading">Negotiation &amp; Quote Requests (RFQ)</h3>
                <div className="flex flex-col sm:flex-row gap-3">
                  <input
                    type="text"
                    value={quoteNotes}
                    onChange={(e) => setQuoteNotes(e.target.value)}
                    placeholder="Packaging, private label, or payment terms note..."
                    className="flex-1 px-3 py-2 text-xs border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
                  />
                  <button
                    type="button"
                    onClick={submitRfq}
                    className="px-4 py-2 btn-futuristic text-white text-xs font-semibold shrink-0"
                  >
                    Create RFQ from Matrix
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {wholesaleQuotes.map((q) => (
                  <div key={q.id} className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-5 space-y-2 text-xs glow-border">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-mono font-semibold text-blue-600 dark:text-cyan-300">{q.id}</p>
                        <p className="text-slate-600 dark:text-slate-300">{q.businessName}</p>
                      </div>
                      <span className="px-2 py-0.5 bg-violet-500/15 text-violet-700 dark:text-fuchsia-300 uppercase font-semibold">
                        {q.status}
                      </span>
                    </div>
                    <div className="divide-y divide-indigo-500/10 dark:divide-cyan-400/10 py-1">
                      {q.items.map((it, i) => (
                        <div key={i} className="py-1 flex justify-between">
                          <span>
                            {it.name} × {it.quantity}
                          </span>
                          <span className="font-mono tabular-nums text-emerald-600 dark:text-emerald-400">
                            {formatMoney(it.targetUnitPrice * it.quantity, currency)}
                          </span>
                        </div>
                      ))}
                    </div>
                    <div className="flex justify-between font-semibold pt-2 border-t border-indigo-500/15 dark:border-cyan-400/15">
                      <span>Requested: {formatMoney(q.requestedTotal, currency)}</span>
                      {q.approvedTotal && (
                        <span className="text-emerald-600 dark:text-emerald-400">Approved: {formatMoney(q.approvedTotal, currency)}</span>
                      )}
                    </div>
                    {q.notes && <p className="text-slate-600 dark:text-slate-300 italic">{q.notes}</p>}
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === 'account' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-gradient-to-br from-amber-50/70 via-white to-violet-50/60 dark:from-amber-950/25 dark:via-[#0D1120] dark:to-violet-950/25 border border-amber-500/25 p-6 space-y-3 text-xs glow-border">
                <h3 className="font-display text-xl font-semibold gradient-heading-warm">Current Business Profile</h3>
                {userAccount ? (
                  <div className="space-y-2 text-slate-700 dark:text-slate-200">
                    <p>
                      <strong>Business:</strong> {userAccount.businessName}
                    </p>
                    <p>
                      <strong>GST / Tax ID:</strong> <span className="font-mono text-indigo-600 dark:text-cyan-300">{userAccount.gstNumber}</span>
                    </p>
                    <p>
                      <strong>Tier &amp; Status:</strong>{' '}
                      <span className="text-orange-600 dark:text-amber-300 font-semibold">
                        {userAccount.tier.toUpperCase()} · {userAccount.status.toUpperCase()}
                      </span>
                    </p>
                    <p className="font-mono tabular-nums">
                      <strong>Credit Line:</strong>{' '}
                      <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
                        {formatMoney(userAccount.creditLimit, currency)}
                      </span>{' '}
                      (Used: {formatMoney(userAccount.creditUsed, currency)}) · Net {userAccount.creditTermsDays} Days
                    </p>
                  </div>
                ) : (
                  <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                    No approved wholesale account linked to your login yet. Submit your business details on the right to unlock Dealer / Distributor tier pricing and Net credit terms.
                  </p>
                )}
              </div>

              <form onSubmit={submitWholesaleApplication} className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-6 space-y-3 text-xs glow-border">
                <h3 className="font-display text-xl font-semibold gradient-heading">Register B2B / Dealer Account</h3>
                <input
                  type="text"
                  required
                  placeholder="Registered Company / Salon / Retail Chain Name"
                  value={bizName}
                  onChange={(e) => setBizName(e.target.value)}
                  className="w-full px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    required
                    placeholder="Authorized Buyer Name"
                    value={contactName}
                    onChange={(e) => setContactName(e.target.value)}
                    className="px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
                  />
                  <input
                    type="tel"
                    required
                    placeholder="Business Phone"
                    value={bizPhone}
                    onChange={(e) => setBizPhone(e.target.value)}
                    className="px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    required
                    placeholder="GST / VAT / Tax ID"
                    value={gstNumber}
                    onChange={(e) => setGstNumber(e.target.value)}
                    className="px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white font-mono uppercase"
                  />
                  <select
                    value={requestedTier}
                    onChange={(e) => setRequestedTier(e.target.value as Exclude<CustomerType, 'retail'>)}
                    className="px-3 py-2 border border-indigo-500/25 dark:border-cyan-400/25 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
                  >
                    <option value="wholesale">Wholesale Partner</option>
                    <option value="dealer">Authorized Dealer</option>
                    <option value="distributor">Regional Distributor</option>
                    <option value="enterprise">Enterprise / Bridal Chain</option>
                  </select>
                </div>
                <button
                  type="submit"
                  disabled={submittingReg}
                  className="w-full py-2.5 btn-prism-gold text-white font-semibold uppercase tracking-wider"
                >
                  {submittingReg ? 'Submitting...' : 'Submit Business & GST Verification'}
                </button>
              </form>
            </div>
          )}

          {tab === 'history' && (
            <div className="space-y-3">
              {wholesaleOrders.length === 0 ? (
                <div className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-8 text-center text-xs text-slate-600 dark:text-slate-300">
                  No B2B orders recorded yet. Use the Quick SKU Matrix to create a wholesale order.
                </div>
              ) : (
                wholesaleOrders.map((ord) => (
                  <div key={ord.id} className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-4 flex flex-wrap items-center justify-between gap-4 text-xs glow-border">
                    <div>
                      <p className="font-mono font-semibold flex items-center gap-1.5 text-blue-600 dark:text-cyan-300">
                        <PackageCheck className="w-3.5 h-3.5 text-emerald-500" /> {ord.id} · {ord.orderSource}
                      </p>
                      <p className="text-slate-600 dark:text-slate-300 mt-0.5">
                        {ord.items.length} SKU(s) · Fulfillment: <span className="text-violet-600 dark:text-fuchsia-300 font-medium">{ord.fulfillmentType}</span> · Status: {ord.erpStatus || ord.orderStatus}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">{formatMoney(ord.total, currency)}</span>
                      <button
                        type="button"
                        onClick={() => {
                          const next: Record<string, number> = {};
                          ord.items.forEach((it) => {
                            next[it.productId] = it.quantity;
                          });
                          setBulkQty(next);
                          setTab('matrix');
                          setFeedback(`Loaded ${ord.items.length} SKU(s) from #${ord.id} for one-click reorder.`);
                        }}
                        className="px-3 py-1.5 btn-prism-cyan text-white font-semibold flex items-center gap-1"
                      >
                        <CheckCircle2 className="w-3 h-3" /> One-Click Reorder
                      </button>
                      <button
                        type="button"
                        onClick={() => window.print()}
                        className="px-3 py-1.5 btn-prism-outline font-medium flex items-center gap-1"
                      >
                        <Printer className="w-3 h-3" /> Bulk Invoice
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
    </CinematicModal>
  );
};
