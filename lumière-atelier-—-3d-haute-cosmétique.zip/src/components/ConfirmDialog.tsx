import React from 'react';
import { AlertTriangle, ShieldCheck, X } from 'lucide-react';
import { CinematicModal } from './MotionPrimitives';

interface ConfirmDialogProps {
  open: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  destructive?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmDialog: React.FC<ConfirmDialogProps> = ({
  open,
  title,
  message,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  destructive = false,
  onConfirm,
  onCancel,
}) => {
  if (!open) return null;

  return (
    <CinematicModal
      zIndexClass="z-[90]"
      onBackdropClick={onCancel}
      backdropClassName="flex items-center justify-center p-4"
      panelClassName="bg-white dark:bg-[#0D1120] text-[#0A0C12] dark:text-[#F5F7FF] w-full max-w-md border border-indigo-500/25 dark:border-cyan-400/25 prism-modal-rim shadow-2xl overflow-hidden"
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="confirm-dialog-title"
      >
        <div
          className={`px-5 py-4 flex items-center justify-between gap-3 text-white ${
            destructive
              ? 'bg-gradient-to-r from-[#F43F5E] via-[#EC4899] to-[#F97316]'
              : 'bg-gradient-to-r from-[#2563EB] via-[#7C3AED] to-[#06B6D4]'
          }`}
        >
          <div className="flex items-center gap-2.5">
            {destructive ? (
              <AlertTriangle className="w-4 h-4 text-amber-200 shrink-0" />
            ) : (
              <ShieldCheck className="w-4 h-4 text-cyan-200 shrink-0" />
            )}
            <h3 id="confirm-dialog-title" className="font-display text-xl font-semibold text-white">
              {title}
            </h3>
          </div>
          <button
            type="button"
            onClick={onCancel}
            aria-label="Close confirmation dialog"
            className="p-1.5 bg-white/15 hover:bg-white/25 text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="prism-divider" />
        <div className="p-5 text-sm text-[#475569] dark:text-white/80 leading-relaxed">{message}</div>
        <div className="px-5 py-3.5 bg-[#F5F7FF] dark:bg-[#06070E] border-t border-indigo-500/15 dark:border-cyan-400/15 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 btn-prism-outline text-xs font-semibold uppercase tracking-wider"
          >
            {cancelLabel}
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider text-white transition-all ${
              destructive
                ? 'btn-prism-sunset'
                : 'btn-futuristic'
            }`}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </CinematicModal>
  );
};
