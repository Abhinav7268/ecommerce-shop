import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { RectAreaLightUniformsLib } from 'three/addons/lights/RectAreaLightUniformsLib.js';
import { ChevronDown, ChevronUp, RotateCcw } from 'lucide-react';
import { ModelType } from '../types/store';
import { useMotionPreferences } from '../context/MotionContext';

interface ThreeCosmeticStageProps {
  modelType: ModelType;
  shadeHex: string;
  shadeName?: string;
  productName?: string;
  heightClass?: string;
  fallbackImageUrl?: string;
}

type CameraPreset = 'hero' | 'macro' | 'top';
type LightingMood = 'champagne' | 'crimson' | 'rosequartz' | 'daylight';

const _vec3TargetPos = new THREE.Vector3();
const _vec3TargetLook = new THREE.Vector3();

function detectSoftwareGl(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

function createProceduralMarbleTexture(darkMode: boolean): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.fillStyle = darkMode ? '#1b181d' : '#e6dfd5';
    ctx.fillRect(0, 0, 512, 512);
    for (let i = 0; i < 42; i++) {
      ctx.strokeStyle = darkMode
        ? `rgba(210, 185, 155, ${0.03 + (i % 5) * 0.015})`
        : `rgba(140, 125, 110, ${0.04 + (i % 4) * 0.02})`;
      ctx.lineWidth = 1 + (i % 3);
      ctx.beginPath();
      let x = (i * 37) % 512;
      let y = 0;
      ctx.moveTo(x, y);
      for (let s = 1; s <= 8; s++) {
        x += Math.sin(i + s * 0.9) * 28;
        y = (s / 8) * 512;
        ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

function createContactShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const grad = ctx.createRadialGradient(128, 128, 12, 128, 128, 122);
    grad.addColorStop(0, 'rgba(0,0,0,0.62)');
    grad.addColorStop(0.5, 'rgba(0,0,0,0.22)');
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 256, 256);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createChromaticStudioBackdropTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const base = ctx.createLinearGradient(0, 0, 512, 512);
    base.addColorStop(0, '#0F184A');
    base.addColorStop(0.38, '#2A105C');
    base.addColorStop(0.72, '#430D57');
    base.addColorStop(1, '#0C2B4D');
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, 512, 512);

    const glows: Array<[number, number, number, string]> = [
      [110, 110, 260, 'rgba(37, 99, 235, 0.58)'],
      [410, 120, 240, 'rgba(6, 182, 212, 0.52)'],
      [256, 390, 260, 'rgba(236, 72, 153, 0.50)'],
      [430, 400, 210, 'rgba(249, 115, 22, 0.36)'],
      [110, 380, 200, 'rgba(124, 58, 237, 0.45)'],
    ];
    for (const [gx, gy, gr, color] of glows) {
      const rg = ctx.createRadialGradient(gx, gy, 10, gx, gy, gr);
      rg.addColorStop(0, color);
      rg.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = rg;
      ctx.fillRect(0, 0, 512, 512);
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export const ThreeCosmeticStage: React.FC<ThreeCosmeticStageProps> = ({
  modelType,
  shadeHex,
  shadeName = 'Signature Shade',
  productName = 'LUMIÈRE ATELIER',
  heightClass = 'h-[440px] lg:h-[540px]',
  fallbackImageUrl,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const motionPrefs = useMotionPreferences();
  const [webglFailed, setWebglFailed] = useState(false);
  const [dockCollapsed, setDockCollapsed] = useState(false);
  const [isOpen, setIsOpen] = useState(true);
  const [autoSpin, setAutoSpin] = useState(true);
  const [explodeLevel, setExplodeLevel] = useState(0);
  const [preset, setPreset] = useState<CameraPreset>('hero');
  const [mood, setMood] = useState<LightingMood>('champagne');

  const controlsStateRef = useRef({
    modelType,
    shadeHex,
    isOpen: true,
    autoSpin: true,
    explodeLevel: 0,
    preset: 'hero' as CameraPreset,
    mood: 'champagne' as LightingMood,
    transitionActive: false,
    lightingEnabled: motionPrefs.effectiveGlobalLighting,
    lightScale: motionPrefs.ambientLightingScale,
    lightSpeed: motionPrefs.lightSpeedMultiplier,
    reducedMotion: motionPrefs.effectiveReducedMotion,
    hex1: motionPrefs.lightPalette.hex1,
    hex2: motionPrefs.lightPalette.hex2,
    hex3: motionPrefs.lightPalette.hex3,
  });

  useEffect(() => {
    controlsStateRef.current.modelType = modelType;
    controlsStateRef.current.shadeHex = shadeHex;
    controlsStateRef.current.isOpen = isOpen;
    controlsStateRef.current.autoSpin = autoSpin;
    controlsStateRef.current.explodeLevel = explodeLevel;
    controlsStateRef.current.mood = mood;
    controlsStateRef.current.lightingEnabled = motionPrefs.effectiveGlobalLighting;
    controlsStateRef.current.lightScale = motionPrefs.ambientLightingScale;
    controlsStateRef.current.lightSpeed = motionPrefs.lightSpeedMultiplier;
    controlsStateRef.current.reducedMotion = motionPrefs.effectiveReducedMotion;
    controlsStateRef.current.hex1 = motionPrefs.lightPalette.hex1;
    controlsStateRef.current.hex2 = motionPrefs.lightPalette.hex2;
    controlsStateRef.current.hex3 = motionPrefs.lightPalette.hex3;
  }, [modelType, shadeHex, isOpen, autoSpin, explodeLevel, mood, motionPrefs]);

  const selectPreset = (next: CameraPreset) => {
    setPreset(next);
    controlsStateRef.current.preset = next;
    controlsStateRef.current.transitionActive = true;
  };

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareGl();
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: 'high-performance',
        alpha: false,
      });
    } catch {
      setWebglFailed(true);
      return;
    }

    const width = container.clientWidth || 720;
    const height = container.clientHeight || 480;

    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const handleContextLost = (e: Event) => {
      e.preventDefault();
      setWebglFailed(true);
    };
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);

    const scene = new THREE.Scene();
    const backdropTex = createChromaticStudioBackdropTexture();
    scene.background = backdropTex;
    scene.fog = new THREE.FogExp2(0x1b1040, 0.042);

    const pmrem = new THREE.PMREMGenerator(renderer);
    const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;
    pmrem.dispose();

    const camera = new THREE.PerspectiveCamera(36, width / height, 0.1, 60);
    camera.position.set(2.9, 2.25, 4.3);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.06;
    controls.enablePan = false;
    controls.minDistance = 2.1;
    controls.maxDistance = 7.5;
    controls.maxPolarAngle = Math.PI * 0.48;
    controls.target.set(0, 0.95, 0);
    controls.addEventListener('start', () => {
      controlsStateRef.current.transitionActive = false;
    });

    // 3-Point Studio Lighting + Vivid Chromatic Rim Lights
    const hemi = new THREE.HemisphereLight(0xc7d2fe, 0x2a144d, 0.95);
    scene.add(hemi);

    const keyLight = new THREE.DirectionalLight(0xfff5eb, 2.5);
    keyLight.position.set(4.5, 6.2, 4.2);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.left = -3;
    keyLight.shadow.camera.right = 3;
    keyLight.shadow.camera.top = 3;
    keyLight.shadow.camera.bottom = -3;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const rimLightA = new THREE.PointLight(0xec4899, 9.0, 15, 1.5);
    rimLightA.position.set(-3.2, 2.8, -2.5);
    scene.add(rimLightA);

    const rimLightB = new THREE.PointLight(0x22d3ee, 8.8, 15, 1.5);
    rimLightB.position.set(3.2, 2.1, -2.4);
    scene.add(rimLightB);

    const orbitNeonLight = new THREE.PointLight(0x7c3aed, 7.5, 14, 1.5);
    orbitNeonLight.position.set(0, 1.4, 3.2);
    scene.add(orbitNeonLight);

    if (!isSoftwareGl) {
      RectAreaLightUniformsLib.init();
      const softbox = new THREE.RectAreaLight(0xe0f2fe, 3.6, 3.5, 2.2);
      softbox.position.set(-2.5, 3.6, 2.8);
      softbox.lookAt(0, 1.0, 0);
      scene.add(softbox);
    }

    // Ground Pedestal & Contact Shadow (Zero Floating)
    const marbleTex = createProceduralMarbleTexture(true);
    marbleTex.anisotropy = renderer.capabilities.getMaxAnisotropy();
    const shadowTex = createContactShadowTexture();

    const floorGeo = new THREE.PlaneGeometry(24, 24);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x16123a,
      roughness: 0.55,
      metalness: 0.25,
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -0.02;
    floor.receiveShadow = !isSoftwareGl;
    scene.add(floor);

    const plinthGeo = new THREE.CylinderGeometry(1.45, 1.56, 0.24, 64);
    const plinthMat = new THREE.MeshStandardMaterial({
      map: marbleTex,
      roughness: 0.42,
      metalness: 0.12,
    });
    const plinth = new THREE.Mesh(plinthGeo, plinthMat);
    plinth.position.y = 0.1;
    plinth.receiveShadow = !isSoftwareGl;
    scene.add(plinth);

    const plinthRingGeo = new THREE.TorusGeometry(1.46, 0.018, 16, 64);
    const goldMat = new THREE.MeshPhysicalMaterial({
      color: 0xd9b382,
      metalness: 0.94,
      roughness: 0.18,
      anisotropy: 0.8,
      clearcoat: 0.3,
    });
    const plinthRing = new THREE.Mesh(plinthRingGeo, goldMat);
    plinthRing.rotation.x = Math.PI / 2;
    plinthRing.position.y = 0.22;
    scene.add(plinthRing);

    // 360° Neon Emissive Halo Ring beneath the Marble Plinth
    const neonHaloGeo = new THREE.TorusGeometry(1.62, 0.024, 16, 72);
    const neonHaloMat = new THREE.MeshStandardMaterial({
      color: 0x22d3ee,
      emissive: 0x22d3ee,
      emissiveIntensity: 2.2,
      roughness: 0.2,
      metalness: 0.4,
    });
    const neonHaloRing = new THREE.Mesh(neonHaloGeo, neonHaloMat);
    neonHaloRing.rotation.x = Math.PI / 2;
    neonHaloRing.position.y = 0.01;
    scene.add(neonHaloRing);

    const contactPlane = new THREE.Mesh(
      new THREE.PlaneGeometry(2.1, 2.1),
      new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, opacity: 0.55, depthWrite: false }),
    );
    contactPlane.rotation.x = -Math.PI / 2;
    contactPlane.position.y = 0.225;
    scene.add(contactPlane);

    // Shared Cosmetic Materials
    const shadeMaterial = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(shadeHex),
      roughness: 0.34,
      metalness: 0.02,
      clearcoat: 0.25,
      clearcoatRoughness: 0.35,
      sheen: 0.55,
      sheenRoughness: 0.45,
      sheenColor: new THREE.Color(shadeHex).lerp(new THREE.Color(0xffffff), 0.35),
    });

    const obsidianMat = new THREE.MeshPhysicalMaterial({
      color: 0x161318,
      metalness: 0.35,
      roughness: 0.22,
      clearcoat: 0.8,
      clearcoatRoughness: 0.12,
    });

    const roseGoldMat = new THREE.MeshPhysicalMaterial({
      color: 0xd9a08b,
      metalness: 0.92,
      roughness: 0.16,
      anisotropy: 0.8,
    });

    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0xf7f2ee,
      metalness: 0.0,
      roughness: 0.18,
      transmission: isSoftwareGl ? 0 : 0.72,
      transparent: true,
      opacity: isSoftwareGl ? 0.36 : 1,
      ior: 1.52,
      thickness: 0.8,
      depthWrite: false,
    });

    // Product Pivot Group seated cleanly on plinth top (y = 0.225)
    const productRoot = new THREE.Group();
    productRoot.position.y = 0.225;
    scene.add(productRoot);

    const partRefs: {
      cap?: THREE.Object3D;
      collar?: THREE.Object3D;
      bullet?: THREE.Object3D;
      base?: THREE.Object3D;
      lid?: THREE.Object3D;
      panGroup?: THREE.Object3D;
    } = {};

    const buildModel = (type: ModelType) => {
      while (productRoot.children.length > 0) {
        const c = productRoot.children[0];
        productRoot.remove(c);
      }
      partRefs.cap = undefined;
      partRefs.collar = undefined;
      partRefs.bullet = undefined;
      partRefs.base = undefined;
      partRefs.lid = undefined;
      partRefs.panGroup = undefined;

      if (type === 'lipstick') {
        // 1. Octagonal/chamfered gold base
        const baseGroup = new THREE.Group();
        const baseMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.34, 0.72, 32), goldMat);
        baseMesh.position.y = 0.36;
        baseMesh.castShadow = !isSoftwareGl;
        baseGroup.add(baseMesh);

        const footRing = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 0.08, 32), obsidianMat);
        footRing.position.y = 0.04;
        baseGroup.add(footRing);
        productRoot.add(baseGroup);
        partRefs.base = baseGroup;

        // 2. Knurled twist collar + inner sleeve
        const collarGroup = new THREE.Group();
        const collarMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.36, 32), roseGoldMat);
        collarMesh.position.y = 0.88;
        collarGroup.add(collarMesh);

        const sleeveMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.44, 32), goldMat);
        sleeveMesh.position.y = 1.15;
        collarGroup.add(sleeveMesh);
        productRoot.add(collarGroup);
        partRefs.collar = collarGroup;

        // 3. Sculpted beveled oblique lipstick bullet
        const bulletGroup = new THREE.Group();
        const bulletBody = new THREE.Mesh(new THREE.CylinderGeometry(0.185, 0.195, 0.48, 36), shadeMaterial);
        bulletBody.position.y = 1.48;
        bulletBody.castShadow = !isSoftwareGl;
        bulletGroup.add(bulletBody);

        const tipCone = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.185, 0.32, 36), shadeMaterial);
        tipCone.position.y = 1.88;
        tipCone.rotation.x = 0.28;
        tipCone.scale.set(1, 1, 0.82);
        tipCone.castShadow = !isSoftwareGl;
        bulletGroup.add(tipCone);
        productRoot.add(bulletGroup);
        partRefs.bullet = bulletGroup;

        // 4. Magnetic outer cap
        const capGroup = new THREE.Group();
        const capShell = new THREE.Mesh(new THREE.CylinderGeometry(0.325, 0.325, 0.92, 32), obsidianMat);
        capShell.position.y = 1.65;
        capShell.castShadow = !isSoftwareGl;
        capGroup.add(capShell);

        const capCrown = new THREE.Mesh(new THREE.CylinderGeometry(0.33, 0.33, 0.08, 32), goldMat);
        capCrown.position.y = 2.11;
        capGroup.add(capCrown);

        const capRim = new THREE.Mesh(new THREE.TorusGeometry(0.325, 0.015, 12, 36), goldMat);
        capRim.rotation.x = Math.PI / 2;
        capRim.position.y = 1.19;
        capGroup.add(capRim);
        productRoot.add(capGroup);
        partRefs.cap = capGroup;
      } else if (type === 'bottle') {
        // Luxury frosted glass serum/foundation bottle
        const baseGroup = new THREE.Group();
        const innerFluid = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 1.18, 36), shadeMaterial);
        innerFluid.position.y = 0.65;
        baseGroup.add(innerFluid);

        const glassShell = new THREE.Mesh(new THREE.CylinderGeometry(0.48, 0.48, 1.32, 40), glassMat);
        glassShell.position.y = 0.68;
        glassShell.renderOrder = 2;
        glassShell.castShadow = !isSoftwareGl;
        baseGroup.add(glassShell);

        const heavyBase = new THREE.Mesh(new THREE.CylinderGeometry(0.47, 0.46, 0.14, 36), goldMat);
        heavyBase.position.y = 0.07;
        baseGroup.add(heavyBase);
        productRoot.add(baseGroup);
        partRefs.base = baseGroup;

        const collarGroup = new THREE.Group();
        const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.34, 0.24, 32), goldMat);
        neck.position.y = 1.44;
        collarGroup.add(neck);

        const pump = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.2, 0.28, 24), roseGoldMat);
        pump.position.y = 1.66;
        collarGroup.add(pump);

        const nozzle = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.07, 0.26), goldMat);
        nozzle.position.set(0, 1.74, 0.14);
        collarGroup.add(nozzle);
        productRoot.add(collarGroup);
        partRefs.collar = collarGroup;

        const capGroup = new THREE.Group();
        const overcap = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.34, 0.56, 32), obsidianMat);
        overcap.position.y = 1.78;
        overcap.renderOrder = 3;
        capGroup.add(overcap);
        productRoot.add(capGroup);
        partRefs.cap = capGroup;
      } else if (type === 'compact') {
        // Rose-gold sculpted blush/highlighter compact with hinged mirror lid
        const baseGroup = new THREE.Group();
        const bottomTray = new THREE.Mesh(new THREE.CylinderGeometry(0.84, 0.8, 0.18, 48), roseGoldMat);
        bottomTray.position.y = 0.09;
        bottomTray.castShadow = !isSoftwareGl;
        baseGroup.add(bottomTray);

        const innerWell = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 0.75, 0.04, 48), obsidianMat);
        innerWell.position.y = 0.175;
        baseGroup.add(innerWell);

        const powderDome = new THREE.Mesh(
          new THREE.SphereGeometry(0.68, 40, 20, 0, Math.PI * 2, 0, Math.PI * 0.26),
          shadeMaterial,
        );
        powderDome.position.y = 0.04;
        powderDome.scale.set(1, 0.45, 1);
        baseGroup.add(powderDome);
        productRoot.add(baseGroup);
        partRefs.base = baseGroup;

        const lidPivot = new THREE.Group();
        lidPivot.position.set(0, 0.18, -0.82);
        const lidShell = new THREE.Mesh(new THREE.CylinderGeometry(0.84, 0.84, 0.12, 48), roseGoldMat);
        lidShell.position.set(0, 0.06, 0.82);
        lidShell.castShadow = !isSoftwareGl;
        lidPivot.add(lidShell);

        const mirrorMat = new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 1, roughness: 0.04 });
        const mirror = new THREE.Mesh(new THREE.CylinderGeometry(0.72, 0.72, 0.02, 40), mirrorMat);
        mirror.position.set(0, -0.005, 0.82);
        lidPivot.add(mirror);
        productRoot.add(lidPivot);
        partRefs.lid = lidPivot;
      } else if (type === 'palette') {
        // 12-pan couture eyeshadow palette
        const baseGroup = new THREE.Group();
        const tray = new THREE.Mesh(new THREE.BoxGeometry(1.85, 0.14, 1.12), obsidianMat);
        tray.position.y = 0.07;
        tray.castShadow = !isSoftwareGl;
        baseGroup.add(tray);

        const goldTrim = new THREE.Mesh(new THREE.BoxGeometry(1.88, 0.04, 1.15), goldMat);
        goldTrim.position.y = 0.03;
        baseGroup.add(goldTrim);

        const panGroup = new THREE.Group();
        const primaryColor = new THREE.Color(shadeHex);
        const panOffsets = [-0.72, -0.43, -0.14, 0.14, 0.43, 0.72];
        const rowOffsets = [-0.26, 0.26];
        let idx = 0;
        for (const rz of rowOffsets) {
          for (const px of panOffsets) {
            const c = primaryColor.clone().offsetHSL((idx - 5) * 0.025, 0.04, (idx % 3 - 1) * 0.12);
            const panMat = new THREE.MeshPhysicalMaterial({
              color: c,
              roughness: idx % 2 === 0 ? 0.55 : 0.22,
              metalness: idx % 2 === 0 ? 0.05 : 0.55,
            });
            const pan = new THREE.Mesh(new THREE.BoxGeometry(0.23, 0.04, 0.4), panMat);
            pan.position.set(px, 0.14, rz);
            panGroup.add(pan);
            idx++;
          }
        }
        baseGroup.add(panGroup);
        productRoot.add(baseGroup);
        partRefs.base = baseGroup;
        partRefs.panGroup = panGroup;

        const lidPivot = new THREE.Group();
        lidPivot.position.set(0, 0.14, -0.56);
        const lidBody = new THREE.Mesh(new THREE.BoxGeometry(1.85, 0.08, 1.12), obsidianMat);
        lidBody.position.set(0, 0.04, 0.56);
        lidBody.castShadow = !isSoftwareGl;
        lidPivot.add(lidBody);

        const mirrorMat = new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 1, roughness: 0.04 });
        const mirror = new THREE.Mesh(new THREE.PlaneGeometry(1.66, 0.92), mirrorMat);
        mirror.rotation.x = Math.PI / 2;
        mirror.position.set(0, -0.002, 0.56);
        lidPivot.add(mirror);
        productRoot.add(lidPivot);
        partRefs.lid = lidPivot;
      } else {
        // Artisanal Makeup Brush
        const baseGroup = new THREE.Group();
        const handlePts = [
          new THREE.Vector2(0.0, 0.0),
          new THREE.Vector2(0.06, 0.05),
          new THREE.Vector2(0.11, 0.55),
          new THREE.Vector2(0.13, 1.15),
          new THREE.Vector2(0.13, 1.25),
        ];
        const handle = new THREE.Mesh(new THREE.LatheGeometry(handlePts, 32), obsidianMat);
        handle.castShadow = !isSoftwareGl;
        baseGroup.add(handle);
        productRoot.add(baseGroup);
        partRefs.base = baseGroup;

        const collarGroup = new THREE.Group();
        const ferrule = new THREE.Mesh(new THREE.CylinderGeometry(0.175, 0.13, 0.44, 32), goldMat);
        ferrule.position.y = 1.46;
        ferrule.castShadow = !isSoftwareGl;
        collarGroup.add(ferrule);
        productRoot.add(collarGroup);
        partRefs.collar = collarGroup;

        const bristlePts = [
          new THREE.Vector2(0.17, 0.0),
          new THREE.Vector2(0.27, 0.25),
          new THREE.Vector2(0.24, 0.5),
          new THREE.Vector2(0.08, 0.64),
          new THREE.Vector2(0.0, 0.66),
        ];
        const bristleMat = new THREE.MeshPhysicalMaterial({
          color: 0xd9cbbd,
          roughness: 0.72,
          sheen: 0.8,
          sheenColor: new THREE.Color(shadeHex),
        });
        const bristles = new THREE.Mesh(new THREE.LatheGeometry(bristlePts, 36), bristleMat);
        bristles.position.y = 1.66;
        bristles.castShadow = !isSoftwareGl;
        productRoot.add(bristles);
        partRefs.bullet = bristles;
      }
    };

    buildModel(modelType);
    let currentBuiltType: ModelType = modelType;
    let currentShadeHex = shadeHex;

    let frameId = 0;
    let disposed = false;
    let lastTime = performance.now();

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync ? gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0) : null;
      if (!sync) {
        frameId = window.setTimeout(cb, 80);
        return;
      }
      gl.flush();
      const poll = () => {
        if (disposed) {
          gl.deleteSync(sync);
          return;
        }
        const state = gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    let openLerp = 1;
    let explodeLerp = 0;

    function tick() {
      if (disposed) return;
      const now = performance.now();
      const delta = Math.min((now - lastTime) / 1000, 0.05);
      lastTime = now;

      const s = controlsStateRef.current;

      if (s.modelType !== currentBuiltType) {
        currentBuiltType = s.modelType;
        buildModel(currentBuiltType);
      }

      if (s.shadeHex !== currentShadeHex) {
        currentShadeHex = s.shadeHex;
        shadeMaterial.color.set(currentShadeHex);
        shadeMaterial.sheenColor.set(currentShadeHex).lerp(new THREE.Color(0xffffff), 0.35);
      }

      // 360° Continuously Orbiting Neon Studio Lighting Rig
      const elapsedSec = now * 0.001;
      const orbitRate = s.reducedMotion || isSoftwareGl ? 0 : 0.45 / Math.max(0.5, s.lightSpeed);
      const angleA = elapsedSec * orbitRate;
      const angleB = angleA + (Math.PI * 2) / 3;
      const angleC = angleA + (Math.PI * 4) / 3;

      rimLightA.position.set(Math.cos(angleA) * 3.5, 2.55 + Math.sin(angleA * 1.4) * 0.35, Math.sin(angleA) * 3.5);
      rimLightB.position.set(Math.cos(angleB) * 3.4, 2.15 + Math.cos(angleB * 1.2) * 0.3, Math.sin(angleB) * 3.4);
      orbitNeonLight.position.set(Math.cos(angleC) * 3.2, 1.35 + Math.sin(angleC) * 0.25, Math.sin(angleC) * 3.2);

      const intensityBoost = s.lightingEnabled ? Math.max(0.45, s.lightScale) : 0.2;
      rimLightA.intensity = 9.0 * intensityBoost;
      rimLightB.intensity = 8.8 * intensityBoost;
      orbitNeonLight.intensity = 7.5 * intensityBoost;

      // Studio Mood Lighting blended with Global Lighting Palette
      if (s.mood === 'champagne') {
        rimLightA.color.setHex(s.hex1);
        rimLightB.color.setHex(s.hex2);
        orbitNeonLight.color.setHex(s.hex3);
      } else if (s.mood === 'crimson') {
        rimLightA.color.setHex(0xec4899);
        rimLightB.color.setHex(0xf97316);
        orbitNeonLight.color.setHex(0xd946ef);
      } else if (s.mood === 'rosequartz') {
        rimLightA.color.setHex(0xa855f7);
        rimLightB.color.setHex(0x22d3ee);
        orbitNeonLight.color.setHex(0xec4899);
      } else {
        rimLightA.color.setHex(0x22d3ee);
        rimLightB.color.setHex(0x2563eb);
        orbitNeonLight.color.setHex(0x10b981);
      }

      neonHaloMat.color.copy(rimLightA.color);
      neonHaloMat.emissive.copy(rimLightA.color);
      neonHaloMat.emissiveIntensity = s.lightingEnabled ? 1.8 + Math.sin(elapsedSec * 1.6) * 0.45 : 0.25;

      // Smooth Exponential Damping for Open/Closed & Exploded View
      openLerp = THREE.MathUtils.damp(openLerp, s.isOpen ? 1 : 0, 5.5, delta);
      explodeLerp = THREE.MathUtils.damp(explodeLerp, s.explodeLevel, 5.5, delta);

      if (partRefs.cap) {
        if (currentBuiltType === 'lipstick') {
          partRefs.cap.position.y = openLerp * 0.68 + explodeLerp * 0.65;
          partRefs.cap.position.x = openLerp * 0.92;
          partRefs.cap.position.z = openLerp * -0.18;
          partRefs.cap.rotation.z = openLerp * -0.22;
        } else {
          partRefs.cap.position.y = openLerp * 0.72 + explodeLerp * 0.55;
          partRefs.cap.position.x = openLerp * 0.85;
        }
      }
      if (partRefs.collar) {
        partRefs.collar.position.y = explodeLerp * 0.28;
      }
      if (partRefs.bullet) {
        partRefs.bullet.position.y = (currentBuiltType === 'brush' ? 1.66 : 0) + explodeLerp * 0.52 + (currentBuiltType === 'lipstick' ? openLerp * 0.08 : 0);
      }
      if (partRefs.lid) {
        const targetAngle = s.isOpen ? -Math.PI * 0.58 : 0;
        partRefs.lid.rotation.x = THREE.MathUtils.damp(partRefs.lid.rotation.x, targetAngle, 5.5, delta);
        partRefs.lid.position.y = (currentBuiltType === 'compact' ? 0.18 : 0.14) + explodeLerp * 0.35;
      }

      if (s.autoSpin && !isSoftwareGl) {
        productRoot.rotation.y += delta * 0.38;
      }

      if (s.transitionActive) {
        if (s.preset === 'hero') {
          _vec3TargetPos.set(2.9, 2.25, 4.3);
          _vec3TargetLook.set(0, 0.95, 0);
        } else if (s.preset === 'macro') {
          _vec3TargetPos.set(1.3, 2.05, 2.15);
          _vec3TargetLook.set(0, 1.45, 0);
        } else {
          _vec3TargetPos.set(0.05, 4.6, 1.4);
          _vec3TargetLook.set(0, 0.65, 0);
        }
        camera.position.x = THREE.MathUtils.damp(camera.position.x, _vec3TargetPos.x, 5, delta);
        camera.position.y = THREE.MathUtils.damp(camera.position.y, _vec3TargetPos.y, 5, delta);
        camera.position.z = THREE.MathUtils.damp(camera.position.z, _vec3TargetPos.z, 5, delta);
        controls.target.x = THREE.MathUtils.damp(controls.target.x, _vec3TargetLook.x, 5, delta);
        controls.target.y = THREE.MathUtils.damp(controls.target.y, _vec3TargetLook.y, 5, delta);
        controls.target.z = THREE.MathUtils.damp(controls.target.z, _vec3TargetLook.z, 5, delta);
        if (camera.position.distanceTo(_vec3TargetPos) < 0.03) {
          s.transitionActive = false;
        }
      }

      controls.update();
      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }
    tick();

    const handleResize = () => {
      if (!container || disposed) return;
      const w = container.clientWidth || 720;
      const h = container.clientHeight || 480;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    const ro = new ResizeObserver(handleResize);
    ro.observe(container);

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      ro.disconnect();
      controls.dispose();
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      envTex.dispose();
      backdropTex.dispose();
      marbleTex.dispose();
      shadowTex.dispose();
      floorGeo.dispose();
      floorMat.dispose();
      plinthGeo.dispose();
      plinthMat.dispose();
      plinthRingGeo.dispose();
      neonHaloGeo.dispose();
      neonHaloMat.dispose();
      renderer.dispose();
    };
  }, []);

  if (webglFailed) {
    return (
      <div className={`relative w-full ${heightClass} bg-[#06070E] overflow-hidden flex items-center justify-center`}>
        {fallbackImageUrl ? (
          <img
            src={fallbackImageUrl}
            alt={productName}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-90"
          />
        ) : (
          <div className="text-center text-white/85 p-8">
            <p className="font-display text-2xl">{productName}</p>
            <p className="text-xs text-cyan-300 mt-1">{shadeName}</p>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className={`relative w-full ${heightClass} bg-[#06070E] overflow-hidden select-none`}>
      {/* Isolated WebGL Canvas Mount */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Minimal Top-Left Label (Zero obstruction) */}
      <div className="pointer-events-none absolute top-4 left-5 z-10 text-white">
        <p className="text-[11px] uppercase tracking-[0.22em] text-[#22D3EE] font-semibold">Interactive 3D Atelier</p>
        <p className="font-display text-xl leading-tight mt-0.5 text-white">{productName}</p>
        <div className="flex items-center gap-2 mt-1 text-xs text-white/80">
          <span
            className="inline-block w-3 h-3 rounded-full border border-white/60"
            style={{ backgroundColor: shadeHex }}
          />
          <span>{shadeName}</span>
          <span aria-hidden="true" className="text-[#EC4899]">·</span>
          <span className="text-cyan-200/90">Drag to Orbit</span>
        </div>
      </div>

      {/* Collapsible Bottom Control Dock (Solid/RGBA, no backdrop-filter over WebGL) */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10 w-[min(92vw,740px)] flex flex-col items-center">
        <button
          type="button"
          onClick={() => setDockCollapsed((v) => !v)}
          className="px-3.5 py-1 bg-[#0D1120] text-[#22D3EE] hover:text-white border border-cyan-400/35 border-b-0 text-[11px] font-semibold tracking-wider uppercase flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
        >
          {dockCollapsed ? (
            <>
              <ChevronUp className="w-3.5 h-3.5" /> Show 3D Controls
            </>
          ) : (
            <>
              <ChevronDown className="w-3.5 h-3.5" /> Hide 3D Controls
            </>
          )}
        </button>

        {!dockCollapsed && (
          <div className="w-full bg-[#0D1120]/95 border border-cyan-400/30 px-4 py-2.5 text-white flex flex-wrap items-center justify-between gap-3 shadow-2xl shadow-indigo-950/60">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsOpen((v) => !v)}
                className={`px-3 py-1.5 text-xs font-semibold transition-all whitespace-nowrap shrink-0 ${
                  isOpen
                    ? 'bg-gradient-to-r from-[#EC4899] to-[#F97316] text-white'
                    : 'bg-white/10 text-white/85 hover:bg-white/20'
                }`}
              >
                {isOpen ? 'Close Cap' : 'Open Cap'}
              </button>
              <button
                type="button"
                onClick={() => setAutoSpin((v) => !v)}
                className={`px-3 py-1.5 text-xs font-semibold transition-all whitespace-nowrap shrink-0 ${
                  autoSpin
                    ? 'bg-gradient-to-r from-[#2563EB] to-[#06B6D4] text-white'
                    : 'bg-white/10 text-white/85 hover:bg-white/20'
                }`}
              >
                {autoSpin ? '360° Spin On' : 'Spin Paused'}
              </button>
            </div>

            <div className="flex items-center gap-2">
              <label htmlFor="explode-range" className="text-[11px] font-semibold text-cyan-200 whitespace-nowrap">
                Explode
              </label>
              <input
                id="explode-range"
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={explodeLevel}
                onChange={(e) => setExplodeLevel(Number(e.target.value))}
                className="w-20 accent-[#22D3EE] cursor-pointer"
              />
            </div>

            <div className="flex items-center gap-1 bg-white/10 p-0.5 border border-white/10">
              {(['hero', 'macro', 'top'] as CameraPreset[]).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => selectPreset(p)}
                  className={`px-2.5 py-1 text-[11px] font-semibold capitalize transition-colors whitespace-nowrap shrink-0 ${
                    preset === p
                      ? 'bg-gradient-to-r from-[#7C3AED] to-[#D946EF] text-white'
                      : 'text-white/80 hover:text-white'
                  }`}
                >
                  {p}
                </button>
              ))}
              <button
                type="button"
                onClick={() => {
                  setExplodeLevel(0);
                  selectPreset('hero');
                }}
                aria-label="Reset camera"
                className="p-1 text-cyan-300 hover:text-white"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="flex items-center gap-1.5">
              {(
                [
                  { id: 'champagne', label: 'Gold', swatch: '#F59E0B' },
                  { id: 'crimson', label: 'Ruby', swatch: '#EC4899' },
                  { id: 'rosequartz', label: 'Prism', swatch: '#A855F7' },
                  { id: 'daylight', label: 'Cyan', swatch: '#22D3EE' },
                ] as const
              ).map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setMood(m.id)}
                  title={`Studio lighting: ${m.label}`}
                  className={`w-5 h-5 rounded-full border-2 transition-transform ${
                    mood === m.id ? 'border-white scale-115 shadow-sm shadow-white/50' : 'border-white/35 hover:scale-105'
                  }`}
                  style={{ backgroundColor: m.swatch }}
                />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
