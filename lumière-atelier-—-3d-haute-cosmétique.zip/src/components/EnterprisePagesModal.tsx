import React, { useState } from 'react';
import { CinematicModal } from './MotionPrimitives';
import {
  BookOpen,
  CheckCircle2,
  FileText,
  HelpCircle,
  Loader2,
  MapPin,
  MessageSquare,
  PackageSearch,
  Send,
  Truck,
  X,
} from 'lucide-react';
import { doc, serverTimestamp, setDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import {
  BlogPost,
  Category,
  CmsPage,
  CurrencyCode,
  formatMoney,
  Order,
  ShippingZone,
} from '../types/store';

export type EnterpriseModalView = 'page' | 'blog' | 'support' | 'track' | 'sitemap';

interface EnterprisePagesModalProps {
  initialView: EnterpriseModalView;
  initialSlug?: string;
  cmsPages: CmsPage[];
  blogPosts: BlogPost[];
  shippingZones: ShippingZone[];
  categories: Category[];
  orders: Order[];
  currency: CurrencyCode;
  userUid?: string;
  userEmail?: string;
  userName?: string;
  onSelectCategory: (categoryName: string) => void;
  onOpenAuth: () => void;
  onClose: () => void;
}

const ORDER_MILESTONES = ['processing', 'confirmed', 'packed', 'shipped', 'out_for_delivery', 'delivered'];

export const EnterprisePagesModal: React.FC<EnterprisePagesModalProps> = ({
  initialView,
  initialSlug,
  cmsPages,
  blogPosts,
  shippingZones,
  categories,
  orders,
  currency,
  userUid,
  userEmail,
  userName,
  onSelectCategory,
  onOpenAuth,
  onClose,
}) => {
  const [view, setView] = useState<EnterpriseModalView>(initialView);
  const [activeSlug, setActiveSlug] = useState<string>(initialSlug || cmsPages[0]?.slug || 'about');
  const [activePost, setActivePost] = useState<BlogPost | null>(null);
  const [blogCategoryFilter, setBlogCategoryFilter] = useState('All');

  // Support Form State
  const [ticketName, setTicketName] = useState(userName || '');
  const [ticketEmail, setTicketEmail] = useState(userEmail || '');
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketOrderId, setTicketOrderId] = useState('');
  const [ticketMessage, setTicketMessage] = useState('');
  const [submittingTicket, setSubmittingTicket] = useState(false);
  const [ticketSuccess, setTicketSuccess] = useState<string | null>(null);
  const [ticketError, setTicketError] = useState<string | null>(null);

  // Order Tracking & Pincode Serviceability
  const [trackQuery, setTrackQuery] = useState('');
  const [pincode, setPincode] = useState('');
  const [pinCountry, setPinCountry] = useState('India');
  const [pinChecking, setPinChecking] = useState(false);
  const [pinResult, setPinResult] = useState<{
    serviceable: boolean;
    zone: string;
    carrier: string;
    estimatedDays: string;
    codAvailable: boolean;
    shippingFeeUsd: number;
    freeAboveUsd: number;
  } | null>(null);
  const [pinError, setPinError] = useState<string | null>(null);

  const visiblePages = cmsPages.filter((p) => p.visible);
  const currentPage = visiblePages.find((p) => p.slug === activeSlug) || visiblePages[0];
  const publishedPosts = blogPosts.filter((b) => b.published);
  const blogCategories = ['All', ...Array.from(new Set(publishedPosts.map((p) => p.category || 'Editorial')))];
  const filteredPosts = publishedPosts.filter(
    (p) => blogCategoryFilter === 'All' || (p.category || 'Editorial') === blogCategoryFilter,
  );

  const matchedOrder = trackQuery.trim()
    ? orders.find(
        (o) =>
          o.id.toLowerCase() === trackQuery.trim().toLowerCase() ||
          (o.trackingNumber && o.trackingNumber.toLowerCase() === trackQuery.trim().toLowerCase()),
      )
    : orders[0];

  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmittingTicket(true);
    setTicketError(null);
    setTicketSuccess(null);
    const id = `tkt_${Date.now()}`;
    try {
      await setDoc(doc(db, 'supportTickets', id), {
        id,
        ...(userUid ? { userId: userUid } : {}),
        name: ticketName.trim(),
        email: ticketEmail.trim(),
        subject: ticketSubject.trim(),
        message: ticketMessage.trim(),
        ...(ticketOrderId.trim() ? { orderId: ticketOrderId.trim() } : {}),
        status: 'open',
        createdAt: serverTimestamp(),
      });
      setTicketSubject('');
      setTicketMessage('');
      setTicketOrderId('');
      setTicketSuccess(`Support ticket #${id} created. Our Atelier concierge will respond shortly.`);
    } catch (err) {
      setTicketError(err instanceof Error ? err.message : 'Unable to submit support request.');
    } finally {
      setSubmittingTicket(false);
    }
  };

  const checkPincode = async (e: React.FormEvent) => {
    e.preventDefault();
    setPinChecking(true);
    setPinError(null);
    setPinResult(null);
    try {
      const res = await fetch('/api/shipping/check-pincode', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pincode, country: pinCountry }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Could not verify postal code.');
      setPinResult(data);
    } catch (err) {
      setPinError(err instanceof Error ? err.message : 'Serviceability check failed.');
    } finally {
      setPinChecking(false);
    }
  };

  return (
    <CinematicModal
      onBackdropClick={onClose}
      backdropClassName="flex items-center justify-center p-2 sm:p-6"
      panelClassName="bg-[#F5F7FF] dark:bg-[#06070E] text-[#090B14] dark:text-[#F8FAFF] w-full max-w-6xl border border-indigo-500/25 dark:border-cyan-400/25 shadow-2xl max-h-[94vh] flex flex-col overflow-hidden prism-modal-rim"
    >
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4 px-6 py-4 bg-gradient-to-r from-[#090B1A] via-[#211346] to-[#112A48] text-white">
          <div>
            <p className="text-[11px] uppercase tracking-[0.22em] text-cyan-300 font-semibold">
              Maison Knowledge &amp; Services
            </p>
            <h2 className="font-display text-2xl font-semibold gradient-heading-hero">
              {view === 'blog'
                ? 'Atelier Beauty Journal'
                : view === 'support'
                  ? 'Help Center & Concierge Support'
                  : view === 'track'
                    ? 'Order Tracking & Delivery Checker'
                    : view === 'sitemap'
                      ? 'Complete Storefront Sitemap'
                      : currentPage?.title || 'Atelier Information'}
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close Modal"
            className="p-2 hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="prism-divider shrink-0" />

        {/* Navigation Strip */}
        <div className="px-6 py-2.5 bg-white dark:bg-[#0D1120] border-b border-indigo-500/15 dark:border-cyan-400/15 flex items-center gap-1.5 overflow-x-auto">
          {(
            [
              { id: 'page', label: 'Company & Policies', icon: FileText, active: 'btn-futuristic' },
              { id: 'blog', label: `Beauty Journal (${publishedPosts.length})`, icon: BookOpen, active: 'btn-prism-sunset' },
              { id: 'track', label: 'Track Order & Shipping', icon: Truck, active: 'btn-prism-cyan' },
              { id: 'support', label: 'Contact & Help Center', icon: HelpCircle, active: 'btn-prism-emerald' },
              { id: 'sitemap', label: 'Sitemap', icon: MapPin, active: 'btn-prism-gold' },
            ] as const
          ).map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setView(item.id);
                  setActivePost(null);
                }}
                className={`px-3.5 py-2 text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-all ${
                  view === item.id
                    ? `${item.active} text-white`
                    : 'text-slate-600 dark:text-slate-300 hover:bg-indigo-500/10 hover:text-indigo-600 dark:hover:text-cyan-300'
                }`}
              >
                <Icon className="w-3.5 h-3.5" /> {item.label}
              </button>
            );
          })}
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* CMS Pages & Policies */}
          {view === 'page' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <aside className="lg:col-span-4 space-y-4">
                {(['company', 'support', 'policy', 'custom'] as const).map((groupName) => {
                  const groupPages = visiblePages.filter((p) => p.group === groupName);
                  if (groupPages.length === 0) return null;
                  return (
                    <div
                      key={groupName}
                      className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-4 space-y-2 glow-border"
                    >
                      <p className="text-[11px] uppercase tracking-[0.18em] text-violet-600 dark:text-cyan-300 font-semibold">
                        {groupName} Pages
                      </p>
                      <div className="flex flex-col gap-1">
                        {groupPages.map((p) => (
                          <button
                            key={p.id}
                            type="button"
                            onClick={() => setActiveSlug(p.slug)}
                            className={`text-left px-3 py-1.5 text-xs transition-all ${
                              currentPage?.slug === p.slug
                                ? 'btn-futuristic text-white font-semibold'
                                : 'text-slate-700 dark:text-slate-200 hover:bg-indigo-500/10 hover:text-indigo-700 dark:hover:text-cyan-300'
                            }`}
                          >
                            {p.title}
                          </button>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </aside>

              <div className="lg:col-span-8 bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-8 space-y-4 h-fit glow-border">
                {currentPage ? (
                  <>
                    <p className="text-[11px] uppercase tracking-[0.2em] text-fuchsia-600 dark:text-cyan-300 font-semibold">
                      {currentPage.group} · /{currentPage.slug}
                    </p>
                    <h3 className="font-display text-3xl font-semibold gradient-heading">{currentPage.title}</h3>
                    <div className="text-sm text-slate-700 dark:text-slate-200 leading-relaxed whitespace-pre-line pt-3 border-t border-indigo-500/15 dark:border-cyan-400/15">
                      {currentPage.content}
                    </div>
                  </>
                ) : (
                  <p className="text-sm text-slate-500 dark:text-slate-400">Select a page from the directory.</p>
                )}
              </div>
            </div>
          )}

          {/* Editorial Blog Hub */}
          {view === 'blog' && (
            <div className="space-y-6">
              {activePost ? (
                <article className="max-w-3xl mx-auto bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-8 space-y-5 glow-border">
                  <button
                    type="button"
                    onClick={() => setActivePost(null)}
                    className="text-xs font-semibold text-blue-600 dark:text-cyan-300 hover:underline"
                  >
                    ← Back to Beauty Journal
                  </button>
                  {activePost.coverImage && (
                    <img
                      src={activePost.coverImage}
                      alt={activePost.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-72 object-cover border border-indigo-500/20 dark:border-cyan-400/20"
                    />
                  )}
                  <div className="space-y-2">
                    <p className="text-xs uppercase tracking-[0.18em] text-pink-600 dark:text-pink-300 font-semibold">
                      {activePost.category || 'Editorial'} · By {activePost.author || 'Atelier Editors'}
                    </p>
                    <h3 className="font-display text-3xl font-semibold gradient-heading">{activePost.title}</h3>
                  </div>
                  <div className="text-sm text-slate-700 dark:text-slate-200 leading-relaxed whitespace-pre-line border-t border-indigo-500/15 dark:border-cyan-400/15 pt-4">
                    {activePost.content}
                  </div>
                </article>
              ) : (
                <>
                  <div className="flex flex-wrap items-center gap-2">
                    {blogCategories.map((cat) => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setBlogCategoryFilter(cat)}
                        className={`px-3.5 py-1.5 text-xs font-semibold border transition-all ${
                          blogCategoryFilter === cat
                            ? 'btn-prism-sunset border-transparent text-white'
                            : 'bg-white dark:bg-[#0D1120] border-indigo-500/20 dark:border-cyan-400/20 text-slate-700 dark:text-slate-200 hover:border-pink-500'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {filteredPosts.map((post) => (
                      <article
                        key={post.id}
                        className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 flex flex-col justify-between glow-border overflow-hidden"
                      >
                        <div>
                          {post.coverImage && (
                            <img
                              src={post.coverImage}
                              alt={post.title}
                              referrerPolicy="no-referrer"
                              className="w-full h-48 object-cover"
                            />
                          )}
                          <div className="p-5 space-y-2">
                            <p className="text-[11px] uppercase tracking-[0.18em] text-pink-600 dark:text-pink-300 font-semibold">
                              {post.category || 'Editorial'}
                            </p>
                            <h3 className="font-display text-xl font-semibold leading-snug">{post.title}</h3>
                            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{post.excerpt}</p>
                          </div>
                        </div>
                        <div className="px-5 pb-5">
                          <button
                            type="button"
                            onClick={() => setActivePost(post)}
                            className="w-full py-2.5 btn-prism-outline text-xs font-semibold uppercase tracking-wider"
                          >
                            Read Article
                          </button>
                        </div>
                      </article>
                    ))}
                  </div>
                </>
              )}
            </div>
          )}

          {/* Track Order + Pincode Serviceability */}
          {view === 'track' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-7 bg-white dark:bg-[#0D1120] border border-cyan-500/25 p-6 space-y-5 glow-border">
                <div className="flex items-center gap-2">
                  <PackageSearch className="w-5 h-5 text-cyan-500" />
                  <h3 className="font-display text-2xl font-semibold gradient-heading">Live Shipment Tracker</h3>
                </div>

                {!userUid ? (
                  <div className="p-5 bg-gradient-to-r from-cyan-50 to-violet-50 dark:from-cyan-950/35 dark:to-violet-950/35 border border-cyan-500/30 space-y-3">
                    <p className="text-xs text-slate-700 dark:text-slate-200">
                      Sign in to view your live shipment milestones, courier tracking numbers, and downloadable invoices.
                    </p>
                    <button
                      type="button"
                      onClick={onOpenAuth}
                      className="px-4 py-2 btn-futuristic text-white text-xs font-semibold uppercase tracking-wider"
                    >
                      Sign In to Track Orders
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Enter Order ID (ord_...) or Tracking ID (LA-...)"
                        value={trackQuery}
                        onChange={(e) => setTrackQuery(e.target.value)}
                        className="flex-1 px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs font-mono text-[#090B14] dark:text-white"
                      />
                    </div>

                    {matchedOrder ? (
                      <div className="border border-indigo-500/20 dark:border-cyan-400/20 bg-[#F5F7FF] dark:bg-[#141A30] p-5 space-y-4">
                        <div className="flex flex-wrap justify-between gap-2 text-xs border-b border-indigo-500/15 dark:border-cyan-400/15 pb-3">
                          <span className="font-mono font-bold text-blue-600 dark:text-cyan-300">Order #{matchedOrder.id}</span>
                          <span className="font-mono font-semibold text-violet-600 dark:text-fuchsia-300">
                            Tracking: {matchedOrder.trackingNumber || 'Pending Dispatch'}
                          </span>
                        </div>
                        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                          {ORDER_MILESTONES.map((step, idx) => {
                            const currentIdx = ORDER_MILESTONES.indexOf(matchedOrder.orderStatus);
                            const done = currentIdx >= idx;
                            return (
                              <div key={step} className="space-y-1">
                                <div className={`h-1.5 ${done ? 'bg-gradient-to-r from-[#2563EB] via-[#D946EF] to-[#10B981]' : 'bg-indigo-500/15 dark:bg-white/10'}`} />
                                <p className={`text-[11px] capitalize ${done ? 'font-semibold text-indigo-700 dark:text-cyan-300' : 'opacity-50'}`}>
                                  {step.replace(/_/g, ' ')}
                                </p>
                              </div>
                            );
                          })}
                        </div>
                        <p className="text-xs text-slate-600 dark:text-slate-300">
                          Destination: {matchedOrder.shippingAddress.city}, {matchedOrder.shippingAddress.country} · Total{' '}
                          <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">{formatMoney(matchedOrder.total, currency)}</span>
                        </p>
                      </div>
                    ) : (
                      <p className="text-xs text-slate-600 dark:text-slate-300">
                        No matching orders found in your account yet.
                      </p>
                    )}
                  </>
                )}
              </div>

              <div className="lg:col-span-5 space-y-5">
                <form
                  onSubmit={checkPincode}
                  className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-6 space-y-3 glow-border"
                >
                  <h3 className="font-display text-xl font-semibold gradient-heading">Pincode &amp; Carrier Estimator</h3>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      required
                      placeholder="PIN / ZIP (e.g. 400001)"
                      value={pincode}
                      onChange={(e) => setPincode(e.target.value)}
                      className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs font-mono text-[#090B14] dark:text-white"
                    />
                    <select
                      value={pinCountry}
                      onChange={(e) => setPinCountry(e.target.value)}
                      className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs text-[#090B14] dark:text-white"
                    >
                      <option>India</option>
                      <option>United States</option>
                      <option>United Kingdom</option>
                      <option>France</option>
                      <option>UAE</option>
                      <option>Japan</option>
                    </select>
                  </div>
                  <button
                    type="submit"
                    disabled={pinChecking}
                    className="w-full py-2.5 btn-prism-cyan text-white text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2"
                  >
                    {pinChecking && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                    Check Serviceability
                  </button>
                  {pinError && <p className="text-xs text-rose-600 dark:text-rose-400">{pinError}</p>}
                  {pinResult && (
                    <div className="p-3 bg-gradient-to-r from-emerald-50 to-cyan-50 dark:from-emerald-950/35 dark:to-cyan-950/35 border border-emerald-500/35 text-xs space-y-1">
                      <p className="font-semibold text-emerald-700 dark:text-emerald-300">
                        {pinResult.zone} · {pinResult.carrier}
                      </p>
                      <p>Estimated Delivery: {pinResult.estimatedDays}</p>
                      <p>COD Eligible: {pinResult.codAvailable ? 'Yes' : 'Prepaid Only'}</p>
                    </div>
                  )}
                </form>

                <div className="bg-white dark:bg-[#0D1120] border border-emerald-500/25 p-5 space-y-2.5 glow-border">
                  <p className="text-xs font-semibold uppercase tracking-wider text-emerald-700 dark:text-emerald-300">
                    Global Shipping Zones
                  </p>
                  {shippingZones
                    .filter((z) => z.active)
                    .map((z) => (
                      <div
                        key={z.id}
                        className="text-xs border-b border-indigo-500/10 dark:border-cyan-400/10 pb-2 last:border-b-0 last:pb-0 flex justify-between gap-3"
                      >
                        <div>
                          <p className="font-semibold">{z.name}</p>
                          <p className="text-slate-500 dark:text-slate-400">{z.estimatedDays}</p>
                        </div>
                        <span className="font-mono font-semibold text-blue-600 dark:text-cyan-300 shrink-0">
                          {z.baseRate === 0 ? 'Free' : formatMoney(z.baseRate, currency)}
                        </span>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          )}

          {/* Support & Contact Us */}
          {view === 'support' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <form
                onSubmit={handleSubmitTicket}
                className="lg:col-span-7 bg-white dark:bg-[#0D1120] border border-emerald-500/25 p-6 space-y-4 glow-border"
              >
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-emerald-500" />
                  <h3 className="font-display text-2xl font-semibold gradient-heading-emerald">Contact Atelier Concierge</h3>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    required
                    placeholder="Your Full Name"
                    value={ticketName}
                    onChange={(e) => setTicketName(e.target.value)}
                    className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                  />
                  <input
                    type="email"
                    required
                    placeholder="Email Address"
                    value={ticketEmail}
                    onChange={(e) => setTicketEmail(e.target.value)}
                    className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    required
                    placeholder="Subject (e.g. Shade Consultation, Order Issue)"
                    value={ticketSubject}
                    onChange={(e) => setTicketSubject(e.target.value)}
                    className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                  />
                  <input
                    type="text"
                    placeholder="Order ID (Optional)"
                    value={ticketOrderId}
                    onChange={(e) => setTicketOrderId(e.target.value)}
                    className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm font-mono text-[#090B14] dark:text-white"
                  />
                </div>
                <textarea
                  rows={4}
                  required
                  minLength={5}
                  placeholder="Describe your inquiry in detail..."
                  value={ticketMessage}
                  onChange={(e) => setTicketMessage(e.target.value)}
                  className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                />
                {ticketError && <p className="text-xs text-rose-600 dark:text-rose-400">{ticketError}</p>}
                {ticketSuccess && (
                  <p className="text-xs text-emerald-700 dark:text-emerald-400 font-medium flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 shrink-0" /> {ticketSuccess}
                  </p>
                )}
                <button
                  type="submit"
                  disabled={submittingTicket}
                  className="px-6 py-3 btn-prism-emerald text-white text-xs font-semibold uppercase tracking-widest flex items-center gap-2"
                >
                  {submittingTicket ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                  Submit Ticket
                </button>
              </form>

              <div className="lg:col-span-5 space-y-4">
                <div className="bg-gradient-to-br from-blue-50/80 via-white to-violet-50/70 dark:from-blue-950/30 dark:via-[#0D1120] dark:to-violet-950/30 border border-blue-500/25 p-6 space-y-3 glow-border">
                  <h4 className="font-display text-xl font-semibold gradient-heading">Boutique Studios &amp; Hours</h4>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    Paris Flagship: 24 Rue du Faubourg Saint-Honoré
                    <br />
                    Mumbai Atelier: Kala Ghoda Heritage Precinct
                    <br />
                    Tokyo Lab: Minami-Aoyama, Minato-ku
                  </p>
                  <p className="text-xs font-mono font-semibold text-blue-600 dark:text-cyan-300">
                    concierge@lumiereatelier.luxury · Mon–Sat 09:00–21:00
                  </p>
                </div>

                <div className="bg-white dark:bg-[#0D1120] border border-violet-500/25 p-6 space-y-2 glow-border">
                  <h4 className="font-display text-xl font-semibold gradient-heading-warm">Quick Answers</h4>
                  <p className="text-xs text-slate-600 dark:text-slate-300">
                    Looking for Shipping, Refund, Warranty, or FAQ policies? Switch to Company &amp; Policies above.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveSlug('faq');
                      setView('page');
                    }}
                    className="mt-2 px-4 py-2 btn-prism-outline text-xs font-semibold"
                  >
                    Open Full FAQ
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Complete Interactive Sitemap */}
          {view === 'sitemap' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white dark:bg-[#0D1120] border border-cyan-500/25 p-6 space-y-3 glow-border">
                <h3 className="font-display text-xl font-semibold text-blue-600 dark:text-cyan-300">Categories &amp; Subcategories</h3>
                <ul className="space-y-1.5 text-xs">
                  {categories
                    .filter((c) => c.visible !== false)
                    .map((cat) => (
                      <li key={cat.id}>
                        <button
                          type="button"
                          onClick={() => {
                            onSelectCategory(cat.name);
                            onClose();
                          }}
                          className="hover:text-cyan-600 dark:hover:text-cyan-300 text-left font-medium"
                        >
                          {cat.parentId ? `↳ ${cat.name}` : cat.name}
                        </button>
                      </li>
                    ))}
                </ul>
              </div>

              <div className="bg-white dark:bg-[#0D1120] border border-violet-500/25 p-6 space-y-3 glow-border">
                <h3 className="font-display text-xl font-semibold text-violet-600 dark:text-fuchsia-300">Company, Legal &amp; Support Pages</h3>
                <ul className="space-y-1.5 text-xs">
                  {visiblePages.map((p) => (
                    <li key={p.id}>
                      <button
                        type="button"
                        onClick={() => {
                          setActiveSlug(p.slug);
                          setView('page');
                        }}
                        className="hover:text-fuchsia-600 dark:hover:text-fuchsia-300 text-left font-medium"
                      >
                        {p.title}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-white dark:bg-[#0D1120] border border-orange-500/25 p-6 space-y-3 glow-border">
                <h3 className="font-display text-xl font-semibold text-orange-600 dark:text-amber-300">Beauty Journal &amp; XML Index</h3>
                <ul className="space-y-1.5 text-xs">
                  {publishedPosts.map((post) => (
                    <li key={post.id}>
                      <button
                        type="button"
                        onClick={() => {
                          setActivePost(post);
                          setView('blog');
                        }}
                        className="hover:text-orange-600 dark:hover:text-amber-300 text-left font-medium"
                      >
                        {post.title}
                      </button>
                    </li>
                  ))}
                </ul>
                <div className="pt-4 border-t border-indigo-500/15 dark:border-cyan-400/15 text-xs space-y-1">
                  <a href="/sitemap.xml" target="_blank" rel="noreferrer" className="block text-blue-600 dark:text-cyan-300 hover:underline font-medium">
                    /sitemap.xml (Search Engine Index)
                  </a>
                  <a href="/robots.txt" target="_blank" rel="noreferrer" className="block text-blue-600 dark:text-cyan-300 hover:underline font-medium">
                    /robots.txt (Crawler Directives)
                  </a>
                </div>
              </div>
            </div>
          )}
        </div>
    </CinematicModal>
  );
};
