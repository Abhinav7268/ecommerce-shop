import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { useMotionPreferences } from '../context/MotionContext';

/**
 * AmbientLightingEngine — Full-Viewport 360° Cinematic Lighting & Neon Illumination System
 *
 * Strictly `fixed inset-0 pointer-events-none` sibling layers so it NEVER creates a top gap
 * or traps high-z-index perimeter/corner illumination inside a `z-0` stacking context.
 *
 * Architecture:
 *  - Layer 1 (z-0):  Multi-directional horizontal & vertical light beams, floating ambient orbs,
 *                    and animated SVG energy waves flowing across backgrounds.
 *  - Layer 2 (z-25): Desktop interactive rAF-throttled mouse-follow radial chromatic spotlight.
 *  - Layer 3 (z-55): 4 dynamic corner illumination sweeps pulsing smoothly at all 4 corners.
 *  - Layer 4 (z-75): 360° 4-edge continuous neon perimeter strips with dual clockwise +
 *                    counter-clockwise GSAP light streaks & glowing corner nodes across ALL
 *                    pages, dashboards, drawers, and modals.
 */
export const AmbientLightingEngine: React.FC = () => {
  const {
    effectiveGlobalLighting,
    effectiveBackgroundLighting,
    effectiveBorderGlow,
    effectiveMouseLighting,
    effectiveReducedMotion,
    ambientLightingScale,
    neonGlowScale,
    lightSpeedMultiplier,
    lightPalette,
    isMobileViewport,
    mobileLightingOptimization,
  } = useMotionPreferences();

  // Layer 1 refs (background beams & orbs)
  const hBeamRef = useRef<HTMLDivElement | null>(null);
  const vBeamRef = useRef<HTMLDivElement | null>(null);
  const diagBeamRef = useRef<HTMLDivElement | null>(null);
  const orb1Ref = useRef<HTMLDivElement | null>(null);
  const orb2Ref = useRef<HTMLDivElement | null>(null);
  const orb3Ref = useRef<HTMLDivElement | null>(null);
  const orb4Ref = useRef<HTMLDivElement | null>(null);

  // Layer 2 ref (mouse spotlight)
  const mouseSpotRef = useRef<HTMLDivElement | null>(null);

  // Layer 3 refs (4 dynamic corner sweeps)
  const cornerTLRef = useRef<HTMLDivElement | null>(null);
  const cornerTRRef = useRef<HTMLDivElement | null>(null);
  const cornerBRRef = useRef<HTMLDivElement | null>(null);
  const cornerBLRef = useRef<HTMLDivElement | null>(null);

  // Layer 4 refs (360° 4-edge primary clockwise + secondary counter-clockwise light streaks)
  const topStreakRef = useRef<HTMLDivElement | null>(null);
  const rightStreakRef = useRef<HTMLDivElement | null>(null);
  const bottomStreakRef = useRef<HTMLDivElement | null>(null);
  const leftStreakRef = useRef<HTMLDivElement | null>(null);
  const topStreakAltRef = useRef<HTMLDivElement | null>(null);
  const bottomStreakAltRef = useRef<HTMLDivElement | null>(null);

  // GSAP 360° continuous cinematic choreography (smooth sine curves — zero strobing)
  useEffect(() => {
    if (!effectiveGlobalLighting || effectiveReducedMotion) return;

    const s = Math.max(0.5, lightSpeedMultiplier);
    const ctx = gsap.context(() => {
      // 1. Primary Clockwise 360° Perimeter Neon Streaks (Top -> Right -> Bottom -> Left)
      if (
        effectiveBorderGlow &&
        topStreakRef.current &&
        rightStreakRef.current &&
        bottomStreakRef.current &&
        leftStreakRef.current
      ) {
        const perimeterTl = gsap.timeline({ repeat: -1 });
        perimeterTl
          .fromTo(
            topStreakRef.current,
            { xPercent: -115, opacity: 0.15 },
            { xPercent: 225, opacity: 1, duration: 3.6 * s, ease: 'sine.inOut' },
            0,
          )
          .fromTo(
            rightStreakRef.current,
            { yPercent: -115, opacity: 0.15 },
            { yPercent: 225, opacity: 1, duration: 3.4 * s, ease: 'sine.inOut' },
            1.8 * s,
          )
          .fromTo(
            bottomStreakRef.current,
            { xPercent: 225, opacity: 0.15 },
            { xPercent: -115, opacity: 1, duration: 3.6 * s, ease: 'sine.inOut' },
            3.5 * s,
          )
          .fromTo(
            leftStreakRef.current,
            { yPercent: 225, opacity: 0.15 },
            { yPercent: -115, opacity: 1, duration: 3.4 * s, ease: 'sine.inOut' },
            5.2 * s,
          );

        // Opposing secondary chromatic light pulse for continuous dual-edge energy
        if (topStreakAltRef.current) {
          gsap.fromTo(
            topStreakAltRef.current,
            { xPercent: 230, opacity: 0.2 },
            { xPercent: -120, opacity: 0.9, duration: 5.8 * s, repeat: -1, ease: 'sine.inOut', delay: 1.4 * s },
          );
        }
        if (bottomStreakAltRef.current) {
          gsap.fromTo(
            bottomStreakAltRef.current,
            { xPercent: -120, opacity: 0.2 },
            { xPercent: 230, opacity: 0.9, duration: 6.2 * s, repeat: -1, ease: 'sine.inOut', delay: 2.2 * s },
          );
        }
      }

      // 2. Dynamic 4-Corner Illumination Breathing & Sweeps
      const corners = [
        cornerTLRef.current,
        cornerTRRef.current,
        cornerBRRef.current,
        cornerBLRef.current,
      ].filter(Boolean);
      corners.forEach((el, idx) => {
        gsap.to(el, {
          scale: 1.24,
          opacity: 0.92,
          duration: (5.2 + idx * 0.85) * s,
          repeat: -1,
          yoyo: true,
          ease: 'sine.inOut',
          delay: idx * 1.15 * s,
        });
      });

      // 3. Multi-Directional Moving Light Beams & Floating Ambient Orbs
      if (effectiveBackgroundLighting) {
        if (hBeamRef.current) {
          gsap.fromTo(
            hBeamRef.current,
            { yPercent: -25, opacity: 0.14 },
            {
              yPercent: 115,
              opacity: 0.36,
              duration: 13 * s,
              repeat: -1,
              yoyo: true,
              ease: 'sine.inOut',
            },
          );
        }
        if (vBeamRef.current) {
          gsap.fromTo(
            vBeamRef.current,
            { xPercent: -25, opacity: 0.12 },
            {
              xPercent: 120,
              opacity: 0.34,
              duration: 16 * s,
              repeat: -1,
              yoyo: true,
              ease: 'sine.inOut',
            },
          );
        }
        if (diagBeamRef.current) {
          gsap.fromTo(
            diagBeamRef.current,
            { xPercent: -60, yPercent: -20, opacity: 0.08 },
            {
              xPercent: 85,
              yPercent: 40,
              opacity: 0.24,
              duration: 19 * s,
              repeat: -1,
              yoyo: true,
              ease: 'sine.inOut',
            },
          );
        }

        const orbs = [
          { el: orb1Ref.current, x: 80, y: 58, dur: 11.5 },
          { el: orb2Ref.current, x: -90, y: 68, dur: 14 },
          { el: orb3Ref.current, x: 70, y: -74, dur: 13 },
          { el: orb4Ref.current, x: -75, y: -64, dur: 15 },
        ];
        orbs.forEach((o, i) => {
          if (!o.el) return;
          gsap.to(o.el, {
            x: o.x,
            y: o.y,
            scale: 1.15,
            duration: o.dur * s,
            repeat: -1,
            yoyo: true,
            ease: 'sine.inOut',
            delay: i * 0.9 * s,
          });
        });
      }
    });

    return () => ctx.revert();
  }, [
    effectiveGlobalLighting,
    effectiveBackgroundLighting,
    effectiveBorderGlow,
    effectiveReducedMotion,
    lightSpeedMultiplier,
    lightPalette.c1,
  ]);

  // Desktop Interactive Mouse-Follow Radial Chromatic Illumination (rAF-throttled)
  useEffect(() => {
    if (!effectiveMouseLighting) return;
    const spot = mouseSpotRef.current;
    if (!spot) return;

    let targetX = window.innerWidth * 0.5;
    let targetY = window.innerHeight * 0.35;
    let curX = targetX;
    let curY = targetY;
    let active = false;
    let rafId = 0;

    const onMove = (e: PointerEvent) => {
      if (e.pointerType === 'touch') return;
      targetX = e.clientX;
      targetY = e.clientY;
      active = true;
    };

    const onLeave = () => {
      active = false;
    };

    const tick = () => {
      curX += (targetX - curX) * 0.12;
      curY += (targetY - curY) * 0.12;
      spot.style.transform = `translate3d(${curX - 250}px, ${curY - 250}px, 0)`;
      spot.style.opacity = active ? String(Math.min(0.46, 0.3 * ambientLightingScale)) : '0';
      rafId = requestAnimationFrame(tick);
    };

    window.addEventListener('pointermove', onMove, { passive: true });
    document.addEventListener('mouseleave', onLeave);
    rafId = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('pointermove', onMove);
      document.removeEventListener('mouseleave', onLeave);
    };
  }, [effectiveMouseLighting, ambientLightingScale]);

  if (!effectiveGlobalLighting) return null;

  const { c1, c2, c3, c4 } = lightPalette;
  const reducedMobile = isMobileViewport && mobileLightingOptimization;
  const edgeOpacity = Math.min(1, 0.8 * neonGlowScale);
  const ambientOpacity = Math.min(1, ambientLightingScale);

  return (
    <>
      {/* =================================================================== */}
      {/* LAYER 1 (z-0): BACKGROUND AMBIENT LIGHT WAVES, BEAMS & FLOATING ORBS*/}
      {/* =================================================================== */}
      {effectiveBackgroundLighting && (
        <div
          aria-hidden="true"
          className="fixed inset-0 pointer-events-none overflow-hidden z-0"
          style={{ opacity: ambientOpacity }}
        >
          {/* Horizontal, Vertical & Diagonal Moving Chromatic Light Beams */}
          <div
            ref={hBeamRef}
            className="absolute left-0 right-0 h-[30vh] -top-[10vh] blur-3xl will-change-transform"
            style={{
              background: `linear-gradient(90deg, transparent 0%, ${c1}36 22%, ${c3}30 52%, ${c4}32 78%, transparent 100%)`,
            }}
          />
          {!reducedMobile && (
            <>
              <div
                ref={vBeamRef}
                className="absolute top-0 bottom-0 w-[26vw] -left-[10vw] blur-3xl will-change-transform"
                style={{
                  background: `linear-gradient(180deg, transparent 0%, ${c2}32 24%, ${c4}2A 56%, ${c1}30 82%, transparent 100%)`,
                }}
              />
              <div
                ref={diagBeamRef}
                className="absolute -inset-24 blur-[90px] will-change-transform"
                style={{
                  background: `linear-gradient(125deg, transparent 28%, ${c1}22 44%, ${c3}1E 54%, ${c4}20 64%, transparent 78%)`,
                }}
              />
            </>
          )}

          {/* Soft Glowing Floating Light Orbs */}
          <div
            ref={orb1Ref}
            className="absolute -top-24 left-[8%] w-[360px] h-[360px] rounded-full blur-[110px] will-change-transform"
            style={{ background: `radial-gradient(circle, ${c1}48 0%, transparent 70%)` }}
          />
          <div
            ref={orb2Ref}
            className="absolute top-[28%] -right-24 w-[380px] h-[380px] rounded-full blur-[115px] will-change-transform"
            style={{ background: `radial-gradient(circle, ${c4}44 0%, transparent 70%)` }}
          />
          {!reducedMobile && (
            <>
              <div
                ref={orb3Ref}
                className="absolute bottom-[14%] left-[10%] w-[340px] h-[340px] rounded-full blur-[110px] will-change-transform"
                style={{ background: `radial-gradient(circle, ${c3}42 0%, transparent 70%)` }}
              />
              <div
                ref={orb4Ref}
                className="absolute -bottom-24 right-[16%] w-[360px] h-[360px] rounded-full blur-[115px] will-change-transform"
                style={{ background: `radial-gradient(circle, ${c2}44 0%, transparent 70%)` }}
              />
            </>
          )}

          {/* Animated SVG Ambient Light Waves (Low-cost vector illumination) */}
          {!reducedMobile && (
            <svg
              viewBox="0 0 1440 900"
              preserveAspectRatio="none"
              className="absolute inset-0 w-full h-full opacity-30 dark:opacity-42"
            >
              <defs>
                <linearGradient id="ambientWaveA" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor={c1} stopOpacity="0" />
                  <stop offset="28%" stopColor={c1} stopOpacity="0.9" />
                  <stop offset="62%" stopColor={c3} stopOpacity="0.85" />
                  <stop offset="100%" stopColor={c4} stopOpacity="0" />
                </linearGradient>
                <linearGradient id="ambientWaveB" x1="100%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor={c4} stopOpacity="0" />
                  <stop offset="32%" stopColor={c4} stopOpacity="0.85" />
                  <stop offset="68%" stopColor={c2} stopOpacity="0.85" />
                  <stop offset="100%" stopColor={c1} stopOpacity="0" />
                </linearGradient>
              </defs>
              <path
                d="M-40,210 C320,110 680,330 1080,180 C1260,115 1380,205 1480,155"
                fill="none"
                stroke="url(#ambientWaveA)"
                strokeWidth="1.6"
                className="ambient-svg-wave-a"
              />
              <path
                d="M-40,700 C360,590 740,790 1120,640 C1290,575 1390,660 1480,610"
                fill="none"
                stroke="url(#ambientWaveB)"
                strokeWidth="1.4"
                className="ambient-svg-wave-b"
              />
            </svg>
          )}
        </div>
      )}

      {/* =================================================================== */}
      {/* LAYER 2 (z-25): DESKTOP INTERACTIVE MOUSE-FOLLOW RADIAL SPOTLIGHT   */}
      {/* =================================================================== */}
      {effectiveMouseLighting && (
        <div
          ref={mouseSpotRef}
          aria-hidden="true"
          className="fixed top-0 left-0 w-[500px] h-[500px] rounded-full pointer-events-none z-[25] opacity-0 transition-opacity duration-300 will-change-transform mix-blend-screen"
          style={{
            background: `radial-gradient(circle, ${c1}38 0%, ${c3}24 38%, ${c4}16 60%, transparent 74%)`,
            filter: 'blur(26px)',
          }}
        />
      )}

      {/* =================================================================== */}
      {/* LAYER 3 (z-55): 4 DYNAMIC CORNER ILLUMINATION SWEEPS                */}
      {/* =================================================================== */}
      <div
        aria-hidden="true"
        className="fixed inset-0 pointer-events-none overflow-hidden z-[55]"
        style={{ opacity: Math.min(0.7, 0.36 * ambientOpacity) }}
      >
        <div
          ref={cornerTLRef}
          className="absolute -top-28 -left-28 w-72 h-72 rounded-full blur-[78px] opacity-60 will-change-transform"
          style={{ background: `radial-gradient(circle, ${c1}85 0%, ${c2}35 45%, transparent 72%)` }}
        />
        <div
          ref={cornerTRRef}
          className="absolute -top-28 -right-28 w-72 h-72 rounded-full blur-[78px] opacity-60 will-change-transform"
          style={{ background: `radial-gradient(circle, ${c4}85 0%, ${c3}35 45%, transparent 72%)` }}
        />
        <div
          ref={cornerBRRef}
          className="absolute -bottom-28 -right-28 w-72 h-72 rounded-full blur-[78px] opacity-60 will-change-transform"
          style={{ background: `radial-gradient(circle, ${c2}85 0%, ${c1}35 45%, transparent 72%)` }}
        />
        <div
          ref={cornerBLRef}
          className="absolute -bottom-28 -left-28 w-72 h-72 rounded-full blur-[78px] opacity-60 will-change-transform"
          style={{ background: `radial-gradient(circle, ${c3}85 0%, ${c4}35 45%, transparent 72%)` }}
        />
      </div>

      {/* =================================================================== */}
      {/* LAYER 4 (z-75): 360° 4-EDGE CONTINUOUS NEON PERIMETER STRIPS        */}
      {/* Visible cleanly around ALL 4 screen edges on every page & modal     */}
      {/* =================================================================== */}
      {effectiveBorderGlow && (
        <div
          aria-hidden="true"
          className="fixed inset-0 pointer-events-none overflow-hidden z-[75]"
          style={{ opacity: edgeOpacity }}
        >
          {/* Top Neon Boundary Strip + Dual Energy Streaks */}
          <div className="lighting-edge-top">
            <div
              ref={topStreakRef}
              className="absolute top-0 left-0 h-full w-[42%] will-change-transform"
              style={{
                background: `linear-gradient(90deg, transparent 0%, ${c1} 32%, #FFFFFF 52%, ${c4} 75%, transparent 100%)`,
                boxShadow: `0 0 20px 3px ${c1}AA`,
              }}
            />
            {!reducedMobile && (
              <div
                ref={topStreakAltRef}
                className="absolute top-0 left-0 h-full w-[28%] will-change-transform"
                style={{
                  background: `linear-gradient(90deg, transparent 0%, ${c3} 40%, #FFFFFF 55%, ${c2} 75%, transparent 100%)`,
                  boxShadow: `0 0 16px 2px ${c3}99`,
                }}
              />
            )}
          </div>

          {/* Right Neon Boundary Strip */}
          <div className="lighting-edge-right">
            <div
              ref={rightStreakRef}
              className="absolute top-0 right-0 w-full h-[42%] will-change-transform"
              style={{
                background: `linear-gradient(180deg, transparent 0%, ${c4} 32%, #FFFFFF 52%, ${c3} 75%, transparent 100%)`,
                boxShadow: `0 0 20px 3px ${c4}AA`,
              }}
            />
          </div>

          {/* Bottom Neon Boundary Strip + Dual Energy Streaks */}
          <div className="lighting-edge-bottom">
            <div
              ref={bottomStreakRef}
              className="absolute bottom-0 left-0 h-full w-[42%] will-change-transform"
              style={{
                background: `linear-gradient(270deg, transparent 0%, ${c3} 32%, #FFFFFF 52%, ${c2} 75%, transparent 100%)`,
                boxShadow: `0 0 20px 3px ${c3}AA`,
              }}
            />
            {!reducedMobile && (
              <div
                ref={bottomStreakAltRef}
                className="absolute bottom-0 left-0 h-full w-[28%] will-change-transform"
                style={{
                  background: `linear-gradient(270deg, transparent 0%, ${c1} 40%, #FFFFFF 55%, ${c4} 75%, transparent 100%)`,
                  boxShadow: `0 0 16px 2px ${c4}99`,
                }}
              />
            )}
          </div>

          {/* Left Neon Boundary Strip */}
          <div className="lighting-edge-left">
            <div
              ref={leftStreakRef}
              className="absolute top-0 left-0 w-full h-[42%] will-change-transform"
              style={{
                background: `linear-gradient(0deg, transparent 0%, ${c2} 32%, #FFFFFF 52%, ${c1} 75%, transparent 100%)`,
                boxShadow: `0 0 20px 3px ${c2}AA`,
              }}
            />
          </div>

          {/* 4 Luminous Corner Energy Nodes */}
          <span
            className="fixed top-0 left-0 w-3 h-3 rounded-br-full pointer-events-none neon-pulse-subtle"
            style={{ background: `radial-gradient(circle at top left, #FFFFFF 0%, ${c1} 45%, transparent 80%)` }}
          />
          <span
            className="fixed top-0 right-0 w-3 h-3 rounded-bl-full pointer-events-none neon-pulse-subtle"
            style={{ background: `radial-gradient(circle at top right, #FFFFFF 0%, ${c4} 45%, transparent 80%)` }}
          />
          <span
            className="fixed bottom-0 right-0 w-3 h-3 rounded-tl-full pointer-events-none neon-pulse-subtle"
            style={{ background: `radial-gradient(circle at bottom right, #FFFFFF 0%, ${c2} 45%, transparent 80%)` }}
          />
          <span
            className="fixed bottom-0 left-0 w-3 h-3 rounded-tr-full pointer-events-none neon-pulse-subtle"
            style={{ background: `radial-gradient(circle at bottom left, #FFFFFF 0%, ${c3} 45%, transparent 80%)` }}
          />
        </div>
      )}
    </>
  );
};
