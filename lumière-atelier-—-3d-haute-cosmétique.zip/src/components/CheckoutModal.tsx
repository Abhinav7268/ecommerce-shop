import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { AnimatedProgressBar, CinematicModal } from './MotionPrimitives';
import {
  CheckCircle2,
  CreditCard,
  Globe,
  Loader2,
  Lock,
  Printer,
  RefreshCw,
  ShieldCheck,
  Truck,
  X,
  AlertTriangle,
} from 'lucide-react';
import { doc, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import {
  ALL_CURRENCIES,
  CartItem,
  CountryCode,
  Coupon,
  CURRENCY_RATES,
  CurrencyCode,
  formatMoney,
  GatewayName,
  GiftCard,
  LockedCheckoutQuote,
  Order,
  Product,
  SavedAddress,
  SiteSettings,
  Supplier,
} from '../types/store';
import { getProductErpDefaults } from '../data/seedErp';
import { useLocalization } from '../context/LocalizationContext';
import { ALL_COUNTRIES, COUNTRY_CONFIGS, resolveCountryByNameOrCode } from '../lib/localization';

interface GatewayInfo {
  id: GatewayName;
  name: string;
  region: string;
  supportedCountries?: string[];
  supportedCurrencies?: string[];
  mode: string;
  methods: string[];
}

interface CheckoutModalProps {
  cart: CartItem[];
  products: Product[];
  suppliers: Supplier[];
  currency: CurrencyCode;
  coupons: Coupon[];
  giftCards?: GiftCard[];
  siteSettings: SiteSettings;
  savedAddresses: SavedAddress[];
  userUid?: string;
  userEmail?: string;
  userName?: string;
  onSignInPrompt: () => void;
  onClearCart: () => void;
  onClose: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  cart,
  products,
  suppliers,
  currency,
  coupons,
  giftCards = [],
  siteSettings,
  savedAddresses,
  userUid,
  userEmail,
  userName,
  onSignInPrompt,
  onClearCart,
  onClose,
}) => {
  const { country: activeCountry, currency: activeCurrency, t } = useLocalization();

  const [gateways, setGateways] = useState<GatewayInfo[]>([]);
  const [checkoutCountryCode, setCheckoutCountryCode] = useState<CountryCode>(() => {
    const defaultAddrInit = savedAddresses.find((a) => a.isDefault) || savedAddresses[0];
    if (defaultAddrInit?.country) {
      return resolveCountryByNameOrCode(defaultAddrInit.country).code;
    }
    return activeCountry.code;
  });
  const checkoutCountry = COUNTRY_CONFIGS[checkoutCountryCode] || activeCountry;

  const [settlementCurrency, setSettlementCurrency] = useState<CurrencyCode>(
    currency || activeCurrency || checkoutCountry.currency,
  );
  const [selectedGateway, setSelectedGateway] = useState<GatewayName>(
    checkoutCountry.preferredGateways[0] || 'Stripe',
  );
  const [selectedMethod, setSelectedMethod] = useState<string>('Debit/Credit Card');
  const [upiId, setUpiId] = useState('collector@okaxis');
  const [emiPlan, setEmiPlan] = useState('3 Months (No Cost)');
  const [couponInput, setCouponInput] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponMsg, setCouponMsg] = useState<string | null>(null);
  const [giftCardInput, setGiftCardInput] = useState('');
  const [appliedGiftCard, setAppliedGiftCard] = useState<GiftCard | null>(null);
  const [giftCardMsg, setGiftCardMsg] = useState<string | null>(null);

  const applyGiftCard = () => {
    const code = giftCardInput.trim().toUpperCase();
    const found = giftCards.find((g) => g.code.toUpperCase() === code && g.active && g.balanceUsd > 0);
    if (!found) {
      setAppliedGiftCard(null);
      setGiftCardMsg('Gift card code not found or has $0 balance.');
      return;
    }
    setAppliedGiftCard(found);
    setGiftCardMsg(`Gift Card ${found.code} applied (up to $${found.balanceUsd.toFixed(2)} USD credit).`);
  };

  const defaultAddr = savedAddresses.find((a) => a.isDefault) || savedAddresses[0];
  const [address, setAddress] = useState<SavedAddress>(
    defaultAddr || {
      id: `addr_${Date.now()}`,
      label: 'Primary',
      fullName: userName || '',
      phone: '',
      line1: '',
      city: '',
      state: '',
      postalCode: '',
      country: checkoutCountry.name,
    },
  );

  const [step, setStep] = useState<'details' | 'sandbox' | 'confirmed' | 'failed'>('details');
  const [processing, setProcessing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [lockedQuote, setLockedQuote] = useState<LockedCheckoutQuote | null>(null);
  const [quoteLoading, setQuoteLoading] = useState(false);
  const [quoteError, setQuoteError] = useState<string | null>(null);
  const [gatewaySession, setGatewaySession] = useState<{
    orderId: string;
    txId: string;
    gatewayOrderId: string;
    nonce: string;
    serverToken: string;
    amountInCurrency: number;
    currency: CurrencyCode;
    mode: string;
  } | null>(null);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);
  const [pinStatus, setPinStatus] = useState<{
    carrier: string;
    estimatedDays: string;
    codAvailable: boolean;
    shippingFeeUsd: number;
  } | null>(null);
  const [pinChecking, setPinChecking] = useState(false);

  const flashDiscountPercent = siteSettings.flashSaleActive ? siteSettings.flashSaleDiscount || 0 : 0;

  // Lock authoritative server-side checkout quote (FX, shipping, tax, customs duty)
  const requestLockedQuote = useCallback(async () => {
    if (cart.length === 0) return null;
    setQuoteLoading(true);
    setQuoteError(null);
    try {
      const res = await fetch('/api/localization/lock-quote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          countryCode: checkoutCountryCode,
          currency: settlementCurrency,
          couponDiscountPercent: appliedCoupon?.discountPercent || 0,
          flashDiscountPercent,
          items: cart.map((c) => {
            const prod = products.find((p) => p.id === c.productId);
            const regionalPriceLocal = prod?.regionalPrices?.[settlementCurrency];
            return {
              productId: c.productId,
              unitPriceUsd: c.price,
              quantity: c.quantity,
              ...(typeof regionalPriceLocal === 'number' ? { regionalPriceLocal } : {}),
            };
          }),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Could not lock checkout quote.');
      const quote = data as LockedCheckoutQuote;
      setLockedQuote(quote);
      return quote;
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to lock checkout prices.';
      setQuoteError(msg);
      return null;
    } finally {
      setQuoteLoading(false);
    }
  }, [cart, products, checkoutCountryCode, settlementCurrency, appliedCoupon, flashDiscountPercent]);

  useEffect(() => {
    void requestLockedQuote();
  }, [requestLockedQuote]);

  const checkServiceability = async () => {
    if (!address.postalCode.trim()) return;
    setPinChecking(true);
    try {
      const res = await fetch('/api/shipping/check-pincode', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pincode: address.postalCode,
          country: checkoutCountry.name,
          countryCode: checkoutCountryCode,
        }),
      });
      const data = await res.json();
      if (res.ok && data.serviceable) {
        setPinStatus({
          carrier: data.carrier,
          estimatedDays: data.estimatedDays,
          codAvailable: Boolean(data.codAvailable),
          shippingFeeUsd: Number(data.shippingFeeUsd || 0),
        });
      }
    } catch {
      // Ignore transient network error
    } finally {
      setPinChecking(false);
    }
  };

  useEffect(() => {
    fetch('/api/payments/gateways')
      .then((r) => r.json())
      .then((data) => {
        if (Array.isArray(data.gateways)) {
          setGateways(data.gateways);
        }
      })
      .catch(() => {});
  }, []);

  const codAllowed = siteSettings.codEnabled !== false && checkoutCountry.codAvailable;

  const availableGateways = useMemo(() => {
    const baseList: GatewayInfo[] =
      gateways.length > 0
        ? gateways
        : [
            { id: 'Razorpay', name: 'Razorpay', region: 'India & Global', supportedCountries: ['IN', 'SG', 'AE', 'US', 'GB'], mode: 'sandbox', methods: ['UPI', 'Google Pay', 'PhonePe', 'Paytm', 'Debit/Credit Card', 'Net Banking', 'Wallets', 'EMI'] },
            { id: 'Cashfree', name: 'Cashfree', region: 'India', supportedCountries: ['IN'], mode: 'sandbox', methods: ['UPI', 'Debit/Credit Card', 'Net Banking'] },
            { id: 'PayU', name: 'PayU India', region: 'India', supportedCountries: ['IN'], mode: 'sandbox', methods: ['UPI', 'Debit/Credit Card', 'EMI'] },
            { id: 'CCAvenue', name: 'CCAvenue', region: 'India & UAE', supportedCountries: ['IN', 'AE', 'SA'], mode: 'sandbox', methods: ['Net Banking', 'Debit/Credit Card', 'Apple Pay', 'Mada'] },
            { id: 'Stripe', name: 'Stripe Global', region: 'Worldwide', supportedCountries: ALL_COUNTRIES.map((c) => c.code), mode: 'sandbox', methods: ['Debit/Credit Card', 'Apple Pay', 'Google Pay', 'SEPA / Giropay (EU)', 'Alipay / WeChat Pay (CN)', 'JCB / Konbini (JP)'] },
            { id: 'PayPal', name: 'PayPal International', region: 'Global', supportedCountries: ALL_COUNTRIES.map((c) => c.code), mode: 'sandbox', methods: ['PayPal Wallet', 'Debit/Credit Card'] },
            { id: 'COD', name: 'Cash on Delivery', region: 'IN / AE / SA', supportedCountries: ['IN', 'AE', 'SA'], mode: 'active', methods: ['Pay on Delivery'] },
          ];

    const filtered = baseList.filter((gw) => {
      if (gw.id === 'COD' && !codAllowed) return false;
      if (gw.supportedCountries && gw.supportedCountries.length > 0) {
        return gw.supportedCountries.includes(checkoutCountryCode);
      }
      return true;
    });

    // Sort with region-recommended gateways first
    return filtered.sort((a, b) => {
      const aIdx = checkoutCountry.preferredGateways.indexOf(a.id);
      const bIdx = checkoutCountry.preferredGateways.indexOf(b.id);
      const aRank = aIdx === -1 ? 99 : aIdx;
      const bRank = bIdx === -1 ? 99 : bIdx;
      return aRank - bRank;
    });
  }, [gateways, codAllowed, checkoutCountryCode, checkoutCountry.preferredGateways]);

  useEffect(() => {
    if (availableGateways.length > 0 && !availableGateways.some((g) => g.id === selectedGateway)) {
      setSelectedGateway(availableGateways[0].id);
    }
  }, [availableGateways, selectedGateway]);

  const currentGateway = availableGateways.find((g) => g.id === selectedGateway);
  useEffect(() => {
    if (currentGateway && !currentGateway.methods.includes(selectedMethod)) {
      setSelectedMethod(currentGateway.methods[0]);
    }
  }, [selectedGateway, currentGateway, selectedMethod]);

  const subtotalUsd = lockedQuote?.subtotalUsd ?? cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const totalDiscountUsd = lockedQuote?.discountUsd ?? 0;
  const finalTotalUsd = lockedQuote?.totalUsd ?? Math.max(1, subtotalUsd - totalDiscountUsd);
  const amountInCurrency = lockedQuote?.totalLocal ?? 0;

  const applyCoupon = () => {
    setCouponMsg(null);
    const code = couponInput.trim().toUpperCase();
    const found = coupons.find((c) => c.code.toUpperCase() === code && c.active);
    if (!found) {
      setCouponMsg('Coupon code is invalid or expired.');
      return;
    }
    if (found.minOrderAmount && subtotalUsd < found.minOrderAmount) {
      setCouponMsg(`Minimum order of ${formatMoney(found.minOrderAmount, settlementCurrency)} required.`);
      return;
    }
    setAppliedCoupon(found);
    setCouponMsg(`Applied ${found.code} (${found.discountPercent}% off) — quote re-locked.`);
  };

  const initiatePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userUid) {
      onSignInPrompt();
      return;
    }
    if (!address.fullName || !address.phone || !address.line1 || !address.city || !address.postalCode) {
      setErrorMsg('Please complete all required shipping address fields.');
      return;
    }

    setProcessing(true);
    setErrorMsg(null);
    const orderId = `ord_${Date.now()}`;
    const txId = `tx_${Date.now()}`;

    try {
      // Ensure we always have a fresh server-locked quote — never submit an unverified FX estimate
      let activeQuote = lockedQuote;
      if (!activeQuote || Date.now() >= new Date(activeQuote.expiresAt).getTime() - 10_000) {
        activeQuote = await requestLockedQuote();
      }
      if (!activeQuote) {
        throw new Error('Unable to lock confirmed checkout prices with server. Please retry.');
      }

      const res = await fetch('/api/payments/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId,
          amount: activeQuote.totalLocal,
          currency: activeQuote.settlementCurrency,
          gateway: selectedGateway,
          method: selectedMethod,
          customerEmail: userEmail,
          quoteLock: {
            quoteId: activeQuote.quoteId,
            quoteSignature: activeQuote.quoteSignature,
            countryCode: activeQuote.countryCode,
            settlementCurrency: activeQuote.settlementCurrency,
            totalLocal: activeQuote.totalLocal,
            totalUsd: activeQuote.totalUsd,
            lockedRate: activeQuote.lockedRate,
            expiresAt: activeQuote.expiresAt,
          },
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (data.code === 'QUOTE_EXPIRED') {
          await requestLockedQuote();
        }
        throw new Error(data.error || 'Could not initiate gateway session.');
      }

      const nextSession = {
        orderId,
        txId,
        gatewayOrderId: data.gatewayOrderId,
        nonce: data.nonce,
        serverToken: data.serverToken,
        amountInCurrency: activeQuote.totalLocal,
        currency: activeQuote.settlementCurrency,
        mode: data.mode,
      };
      setGatewaySession(nextSession);

      if (selectedGateway === 'COD') {
        await completeVerification(nextSession, false);
      } else {
        setStep('sandbox');
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Checkout initiation failed.');
    } finally {
      setProcessing(false);
    }
  };

  const completeVerification = async (
    session: NonNullable<typeof gatewaySession>,
    simulateFailure: boolean,
  ) => {
    if (!userUid) return;
    setProcessing(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/payments/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId: session.orderId,
          gateway: selectedGateway,
          gatewayOrderId: session.gatewayOrderId,
          amount: session.amountInCurrency,
          currency: session.currency,
          nonce: session.nonce,
          serverToken: session.serverToken,
          simulateFailure,
        }),
      });
      const verifyData = await res.json();

      const trackingNumber = `LA-${Math.floor(10000000 + Math.random() * 89999999)}`;
      const isPaid = verifyData.verified && verifyData.status === 'succeeded';
      const isCod = selectedGateway === 'COD' && verifyData.verified;

      // Call ERP Automatic Order Routing Engine
      let routingData: {
        orderSource?: Order['orderSource'];
        salesChannel?: Order['salesChannel'];
        customerType?: Order['customerType'];
        fulfillmentType?: Order['fulfillmentType'];
        erpStatus?: Order['erpStatus'];
        warehouseId?: string;
        purchaseOrders?: Array<Record<string, unknown> & { id: string }>;
        financials?: {
          purchaseCost: number;
          shippingCost: number;
          packagingCost: number;
          gatewayFee: number;
          taxAmount: number;
          grossProfit: number;
          netProfit: number;
        };
        timeline?: Order['timeline'];
      } = {};

      try {
        const routeRes = await fetch('/api/orders/route', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            orderId: session.orderId,
            orderSource: 'Online Store',
            customerType: 'retail',
            paymentGateway: selectedGateway,
            discount: Number(totalDiscountUsd.toFixed(2)),
            shippingCost: pinStatus?.shippingFeeUsd ?? 0,
            requestedPackagingType: 'custom_brand_box',
            items: cart.map((c, idx) => {
              const prod = products.find((p) => p.id === c.productId);
              const erp = prod ? getProductErpDefaults(prod, idx) : null;
              return {
                productId: c.productId,
                name: c.name,
                sku: prod?.sku || c.productId,
                shadeName: c.shade.name,
                shadeHex: c.shade.hex,
                quantity: c.quantity,
                unitPrice: c.price,
                purchasePrice: erp?.purchasePrice ?? Number((c.price * 0.42).toFixed(2)),
                supplierId: erp?.supplierId,
                supplierSku: erp?.supplierSku,
                warehouseId: erp?.warehouseId,
                fulfillmentMethod: erp?.fulfillmentMethod || 'own_inventory',
                ownedStock: erp?.ownedStock ?? prod?.stock ?? 10,
                supplierStock: erp?.supplierStock ?? 200,
                taxRatePercent: erp?.taxRatePercent ?? 12,
              };
            }),
            suppliers: suppliers.map((s) => ({
              id: s.id,
              companyName: s.companyName,
              email: s.email,
              integrationType: s.integrationType,
              leadTimeDays: s.leadTimeDays,
              privateLabelCapable: s.privateLabelCapable,
            })),
          }),
        });
        if (routeRes.ok) {
          routingData = await routeRes.json();
        }
      } catch {
        // Fallback to standard D2C allocation if routing service unavailable
      }

      // Real-time Fraud Risk Evaluation
      let fraudScore = 10;
      let fraudFlags: string[] = ['Passed automated screening'];
      let fraudReview = false;
      try {
        const fraudRes = await fetch('/api/orders/evaluate-fraud', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            totalUsd: lockedQuote?.totalUsd ?? finalTotalUsd,
            itemCount: cart.reduce((s, c) => s + c.quantity, 0),
            paymentGateway: selectedGateway,
            countryCode: checkoutCountryCode,
            shippingCountry: address.country,
            highValueThresholdUsd: siteSettings.fraudHighValueThresholdUsd ?? 500,
            autoHoldScore: siteSettings.fraudAutoHoldScore ?? 60,
          }),
        });
        if (fraudRes.ok) {
          const fraudData = await fraudRes.json();
          fraudScore = Number(fraudData.score ?? 10);
          fraudFlags = Array.isArray(fraudData.flags) ? fraudData.flags : fraudFlags;
          fraudReview = Boolean(fraudData.requiresManualReview);
        }
      } catch {
        // Non-blocking fallback
      }

      const giftCardAppliedUsd = appliedGiftCard
        ? Number(Math.min(appliedGiftCard.balanceUsd, lockedQuote?.totalUsd ?? finalTotalUsd).toFixed(2))
        : 0;
      const adjustedTotalUsd = Number(Math.max(0, (lockedQuote?.totalUsd ?? finalTotalUsd) - giftCardAppliedUsd).toFixed(2));
      const poIds = (routingData.purchaseOrders || []).map((p) => p.id);

      const orderDoc: Order = {
        id: session.orderId,
        userId: userUid,
        customerName: address.fullName,
        customerEmail: userEmail || '',
        items: cart.map((c, idx) => {
          const prod = products.find((p) => p.id === c.productId);
          const erp = prod ? getProductErpDefaults(prod, idx) : null;
          return {
            productId: c.productId,
            name: c.name,
            shadeName: c.shade.name,
            shadeHex: c.shade.hex,
            quantity: c.quantity,
            unitPrice: c.price,
            purchaseCost: Number(((erp?.purchasePrice ?? c.price * 0.42) * c.quantity).toFixed(2)),
            supplierId: erp?.supplierId || 'sup_laboratoire_paris',
            fulfillmentMethod: erp?.fulfillmentMethod || 'own_inventory',
          };
        }),
        subtotal: Number((lockedQuote?.subtotalUsd ?? subtotalUsd).toFixed(2)),
        discount: Number(((lockedQuote?.discountUsd ?? totalDiscountUsd) + giftCardAppliedUsd).toFixed(2)),
        total: adjustedTotalUsd,
        currency: session.currency,
        paymentGateway: selectedGateway,
        paymentMethod: selectedMethod === 'EMI' ? `EMI (${emiPlan})` : selectedMethod,
        paymentStatus: isPaid ? 'paid' : isCod ? 'pending' : 'failed',
        orderStatus: isPaid || isCod ? 'confirmed' : 'processing',
        trackingNumber,
        ...(appliedCoupon ? { couponCode: appliedCoupon.code } : {}),
        ...(appliedGiftCard && giftCardAppliedUsd > 0
          ? { giftCardCode: appliedGiftCard.code, giftCardDiscount: giftCardAppliedUsd }
          : {}),
        fraudScore,
        fraudFlags,
        shippingAddress: { ...address, country: checkoutCountry.name },
        refundStatus: 'none',
        refundAmount: 0,
        orderSource: routingData.orderSource || 'Online Store',
        salesChannel: routingData.salesChannel || 'D2C_ONLINE',
        customerType: routingData.customerType || 'retail',
        fulfillmentType: routingData.fulfillmentType || 'own_inventory',
        erpStatus:
          isPaid || isCod
            ? fraudReview
              ? 'MANUAL_REVIEW'
              : routingData.erpStatus || 'PAYMENT_CONFIRMED'
            : 'PAYMENT_FAILED',
        warehouseId: routingData.warehouseId || 'wh_mumbai_central',
        ...(poIds.length > 0 ? { supplierOrderIds: poIds } : {}),
        purchaseCost: routingData.financials?.purchaseCost ?? Number((subtotalUsd * 0.42).toFixed(2)),
        shippingCost: lockedQuote?.shippingUsd ?? routingData.financials?.shippingCost ?? 0,
        packagingCost: routingData.financials?.packagingCost ?? 1.85,
        gatewayFee: routingData.financials?.gatewayFee ?? 0,
        taxAmount: lockedQuote?.taxUsd ?? routingData.financials?.taxAmount ?? 0,
        grossProfit: routingData.financials?.grossProfit ?? Number((finalTotalUsd * 0.58).toFixed(2)),
        netProfit: routingData.financials?.netProfit ?? Number((finalTotalUsd * 0.52).toFixed(2)),
        countryCode: checkoutCountryCode,
        customsDuty: lockedQuote?.customsDutyUsd ?? 0,
        lockedExchangeRate: lockedQuote?.lockedRate ?? 1,
        ...(lockedQuote?.quoteId ? { quoteId: lockedQuote.quoteId } : {}),
        settlementTotal: session.amountInCurrency,
        taxLabel: lockedQuote?.taxLabel ?? checkoutCountry.taxLabel,
        shippingCarrier: lockedQuote?.shippingCarrier ?? checkoutCountry.shippingCarrier,
        ...(routingData.timeline ? { timeline: routingData.timeline } : {}),
      };

      await setDoc(doc(db, 'orders', session.orderId), {
        ...orderDoc,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      // Deduct redeemed gift card balance monotonically in Firestore
      if ((isPaid || isCod) && appliedGiftCard && giftCardAppliedUsd > 0) {
        try {
          const remaining = Number(Math.max(0, appliedGiftCard.balanceUsd - giftCardAppliedUsd).toFixed(2));
          await updateDoc(doc(db, 'giftCards', appliedGiftCard.id), {
            balanceUsd: remaining,
            updatedAt: serverTimestamp(),
          });
        } catch {
          // Non-blocking if local seed card
        }
      }

      // Persist Subscribe & Save recurring subscriptions for opted-in cart lines
      if (isPaid || isCod) {
        for (const item of cart) {
          if (item.subscriptionIntervalDays) {
            const subId = `sub_${Date.now()}_${item.productId.slice(-6)}`;
            const nextDate = new Date(Date.now() + item.subscriptionIntervalDays * 86400_000)
              .toISOString()
              .slice(0, 10);
            try {
              await setDoc(doc(db, 'subscriptions', subId), {
                id: subId,
                userId: userUid,
                customerEmail: userEmail || '',
                productId: item.productId,
                productName: item.name,
                shadeName: item.shade.name,
                shadeHex: item.shade.hex,
                unitPriceUsd: Number((item.price * 0.88).toFixed(2)),
                discountPercent: 12,
                intervalDays: item.subscriptionIntervalDays,
                quantity: item.quantity,
                status: 'active',
                nextBillingDate: nextDate,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
              });
            } catch {
              // Non-blocking
            }
          }
        }
      }

      await setDoc(doc(db, 'transactions', session.txId), {
        id: session.txId,
        orderId: session.orderId,
        userId: userUid,
        gateway: selectedGateway,
        method: orderDoc.paymentMethod,
        amount: session.amountInCurrency,
        currency: session.currency,
        status: isPaid ? 'succeeded' : isCod ? 'initiated' : 'failed',
        gatewayOrderId: session.gatewayOrderId,
        ...(verifyData.gatewayPaymentId ? { gatewayPaymentId: verifyData.gatewayPaymentId } : {}),
        signatureVerified: Boolean(verifyData.verified),
        webhookReceived: Boolean(verifyData.webhookConfirmed),
        ...(verifyData.failureReason ? { failureReason: verifyData.failureReason } : {}),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      if (isPaid || isCod) {
        // Persist split supplier Purchase Orders if dropship/private-label items exist
        if (routingData.purchaseOrders && routingData.purchaseOrders.length > 0) {
          for (const po of routingData.purchaseOrders) {
            try {
              await setDoc(doc(db, 'purchaseOrders', po.id), {
                ...po,
                customerUid: userUid,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
              });
            } catch {
              // Continue order confirmation even if PO write hits edge constraint
            }
          }
        }

        // Synchronize inventory & notify customer
        for (const item of cart) {
          try {
            const prod = products.find((p) => p.id === item.productId);
            const currentStock = prod?.stock ?? item.quantity;
            const currentOwned = prod?.ownedStock ?? currentStock;
            await updateDoc(doc(db, 'products', item.productId), {
              stock: Math.max(0, currentStock - item.quantity),
              ownedStock: Math.max(0, currentOwned - item.quantity),
              reservedStock: (prod?.reservedStock ?? 0) + item.quantity,
              updatedAt: serverTimestamp(),
            });
          } catch {
            // Skip if product is local-only seed
          }
        }

        const notifId = `notif_${Date.now()}`;
        await setDoc(doc(db, 'users', userUid, 'notifications', notifId), {
          id: notifId,
          userId: userUid,
          title: `Order ${session.orderId} Confirmed`,
          message: `Confirmed via ${selectedGateway} (${orderDoc.paymentMethod}). Tracking: ${trackingNumber}`,
          read: false,
          createdAt: serverTimestamp(),
        });

        try {
          const logId = `audit_${Date.now()}`;
          await setDoc(doc(db, 'auditLogs', logId), {
            id: logId,
            actorUid: userUid,
            actorEmail: userEmail || '',
            actorRole: 'customer',
            action: 'ORDER_ROUTED_CHECKOUT',
            entityType: 'order',
            entityId: session.orderId,
            details: `Channel: ${orderDoc.salesChannel} | Fulfillment: ${orderDoc.fulfillmentType} | POs: ${poIds.length}`,
            createdAt: serverTimestamp(),
          });
        } catch {
          // Audit non-blocking
        }

        setConfirmedOrder(orderDoc);
        onClearCart();
        setStep('confirmed');
      } else {
        setConfirmedOrder(orderDoc);
        setErrorMsg(verifyData.failureReason || 'Payment authorization declined.');
        setStep('failed');
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Payment verification failed.');
    } finally {
      setProcessing(false);
    }
  };

  const retryFailedPayment = async () => {
    if (!confirmedOrder || !userUid) return;
    setProcessing(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/payments/retry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId: confirmedOrder.id,
          gateway: selectedGateway,
          method: selectedMethod,
          amount: confirmedOrder.settlementTotal || amountInCurrency,
          currency: confirmedOrder.currency || settlementCurrency,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.verified) throw new Error(data.error || 'Retry failed');

      await updateDoc(doc(db, 'orders', confirmedOrder.id), {
        paymentStatus: selectedGateway === 'COD' ? 'pending' : 'paid',
        orderStatus: 'confirmed',
        paymentGateway: selectedGateway,
        paymentMethod: selectedMethod,
        updatedAt: serverTimestamp(),
      });

      const retryTxId = `tx_retry_${Date.now()}`;
      await setDoc(doc(db, 'transactions', retryTxId), {
        id: retryTxId,
        orderId: confirmedOrder.id,
        userId: userUid,
        gateway: selectedGateway,
        method: selectedMethod,
        amount: confirmedOrder.settlementTotal || amountInCurrency,
        currency: confirmedOrder.currency || settlementCurrency,
        status: selectedGateway === 'COD' ? 'initiated' : 'succeeded',
        gatewayOrderId: data.gatewayOrderId,
        gatewayPaymentId: data.gatewayPaymentId,
        signatureVerified: true,
        webhookReceived: true,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      setConfirmedOrder({
        ...confirmedOrder,
        paymentStatus: selectedGateway === 'COD' ? 'pending' : 'paid',
        orderStatus: 'confirmed',
      });
      onClearCart();
      setStep('confirmed');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Payment retry failed.');
    } finally {
      setProcessing(false);
    }
  };

  const checkoutProgressPct = step === 'details' ? 33 : step === 'sandbox' ? 68 : step === 'confirmed' ? 100 : 50;

  return (
    <CinematicModal
      backdropClassName="flex items-center justify-center p-2 sm:p-4"
      panelClassName="bg-[#F5F7FF] dark:bg-[#06070E] text-[#090B14] dark:text-[#F8FAFF] w-full max-w-5xl border border-indigo-500/25 dark:border-cyan-400/25 shadow-2xl max-h-[94vh] flex flex-col overflow-hidden prism-modal-rim"
    >
        <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-[#090B1A] via-[#171E48] to-[#0E313E] text-white">
          <div>
            <p className="text-[11px] uppercase tracking-[0.22em] text-cyan-300 font-semibold">Encrypted Checkout</p>
            <h2 className="font-display text-2xl font-semibold gradient-heading-hero">Complete Your Atelier Order</h2>
          </div>
          <button type="button" onClick={onClose} aria-label="Close Checkout" className="p-2 hover:bg-white/10 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="prism-divider shrink-0" />
        <div className="px-6 py-2.5 bg-white dark:bg-[#0D1120] border-b border-indigo-500/15 dark:border-cyan-400/15">
          <AnimatedProgressBar
            percent={checkoutProgressPct}
            label={
              step === 'details'
                ? 'Step 1 of 3 · Delivery & Payment Method'
                : step === 'sandbox'
                  ? 'Step 2 of 3 · Secure Gateway Verification'
                  : step === 'confirmed'
                    ? 'Step 3 of 3 · Order Confirmed & Routed'
                    : 'Payment Verification Required'
            }
            valueLabel={`${checkoutProgressPct}%`}
            tone={step === 'failed' ? 'rose' : step === 'confirmed' ? 'emerald' : 'cyan'}
            heightClass="h-1.5"
          />
        </div>

        <div className="overflow-y-auto flex-1 p-6">
          {step === 'details' && (
            <form onSubmit={initiatePayment} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              <div className="lg:col-span-7 space-y-6">
                {!userUid && (
                  <div className="bg-gradient-to-r from-blue-50 via-white to-violet-50 dark:from-blue-950/35 dark:via-[#0D1120] dark:to-violet-950/35 border border-blue-500/35 p-4 flex items-center justify-between gap-4">
                    <p className="text-xs text-slate-700 dark:text-slate-200">
                      Sign in with Google to save your order history, live tracking, and payment receipts.
                    </p>
                    <button
                      type="button"
                      onClick={onSignInPrompt}
                      className="px-4 py-2 btn-futuristic text-white text-xs font-semibold whitespace-nowrap"
                    >
                      Google Sign-In
                    </button>
                  </div>
                )}

                {/* Shipping Details */}
                <div className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-5 space-y-4 glow-border">
                  <div className="flex items-center justify-between">
                    <h3 className="font-display text-xl font-semibold gradient-heading">1. Delivery Address</h3>
                    {savedAddresses.length > 0 && (
                      <select
                        onChange={(e) => {
                          const found = savedAddresses.find((a) => a.id === e.target.value);
                          if (found) setAddress(found);
                        }}
                        className="text-xs border border-indigo-500/25 dark:border-cyan-400/25 px-2.5 py-1 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white"
                      >
                        {savedAddresses.map((a) => (
                          <option key={a.id} value={a.id}>
                            {a.label} — {a.city}
                          </option>
                        ))}
                      </select>
                    )}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <input
                      type="text"
                      required
                      placeholder="Full Name"
                      value={address.fullName}
                      onChange={(e) => setAddress({ ...address, fullName: e.target.value })}
                      className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                    />
                    <input
                      type="tel"
                      required
                      placeholder="Mobile Phone"
                      value={address.phone}
                      onChange={(e) => setAddress({ ...address, phone: e.target.value })}
                      className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                    />
                    <input
                      type="text"
                      required
                      placeholder="Street Address & Apartment"
                      value={address.line1}
                      onChange={(e) => setAddress({ ...address, line1: e.target.value })}
                      className="sm:col-span-2 px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                    />
                    <input
                      type="text"
                      required
                      placeholder="City"
                      value={address.city}
                      onChange={(e) => setAddress({ ...address, city: e.target.value })}
                      className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                    />
                    <input
                      type="text"
                      required
                      placeholder="State / Province"
                      value={address.state}
                      onChange={(e) => setAddress({ ...address, state: e.target.value })}
                      className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                    />
                    <div className="flex gap-2">
                      <input
                        type="text"
                        required
                        placeholder={checkoutCountry.postalPlaceholder}
                        aria-label={checkoutCountry.postalLabel}
                        value={address.postalCode}
                        onChange={(e) => setAddress({ ...address, postalCode: e.target.value })}
                        className="flex-1 px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                      />
                      <button
                        type="button"
                        onClick={checkServiceability}
                        disabled={pinChecking}
                        className="px-3 py-2 btn-prism-cyan text-white text-xs font-semibold shrink-0"
                      >
                        {pinChecking ? '...' : 'Verify Zone'}
                      </button>
                    </div>
                    <select
                      aria-label="Destination Country"
                      value={checkoutCountryCode}
                      onChange={(e) => {
                        const nextCode = e.target.value as CountryCode;
                        const nextCfg = COUNTRY_CONFIGS[nextCode] || COUNTRY_CONFIGS.US;
                        setCheckoutCountryCode(nextCode);
                        setSettlementCurrency(nextCfg.currency);
                        setAddress((prev) => ({ ...prev, country: nextCfg.name }));
                        setPinStatus(null);
                      }}
                      className="px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white font-medium"
                    >
                      {ALL_COUNTRIES.map((c) => (
                        <option key={c.code} value={c.code}>
                          {c.flag} {c.name} ({c.currency})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="p-3 bg-gradient-to-r from-indigo-50/90 to-cyan-50/90 dark:from-indigo-950/35 dark:to-cyan-950/35 border border-indigo-500/25 dark:border-cyan-400/25 text-xs space-y-1">
                    <div className="flex items-center justify-between gap-2 font-semibold text-indigo-800 dark:text-cyan-200">
                      <span className="flex items-center gap-1.5">
                        <Truck className="w-4 h-4 text-emerald-500 shrink-0" />
                        {pinStatus?.carrier || checkoutCountry.shippingCarrier}
                      </span>
                      <span className="font-mono text-[11px]">{pinStatus?.estimatedDays || checkoutCountry.estimatedDelivery}</span>
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300">
                      {checkoutCountry.complianceBadge} · {checkoutCountry.customsNote}
                    </p>
                  </div>
                </div>

                {/* Multi-Gateway Payment Selector */}
                <div className="bg-white dark:bg-[#0D1120] border border-indigo-500/20 dark:border-cyan-400/20 p-5 space-y-4 glow-border">
                  <div className="flex items-center justify-between">
                    <h3 className="font-display text-xl font-semibold gradient-heading">2. Payment Gateway &amp; Method</h3>
                    <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" /> HMAC Verified
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {availableGateways.map((gw) => (
                      <button
                        key={gw.id}
                        type="button"
                        onClick={() => setSelectedGateway(gw.id)}
                        className={`p-2.5 border text-left transition-all ${
                          selectedGateway === gw.id
                            ? 'btn-futuristic border-transparent text-white'
                            : 'border-indigo-500/20 dark:border-cyan-400/20 hover:border-cyan-500 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-white'
                        }`}
                      >
                        <p className="text-xs font-semibold truncate">{gw.name}</p>
                        <p className={`text-[10px] ${selectedGateway === gw.id ? 'text-white/85' : 'text-slate-500 dark:text-slate-400'}`}>
                          {gw.mode === 'live' ? 'Live' : gw.mode === 'active' ? 'Verified COD' : 'Sandbox Test'}
                        </p>
                      </button>
                    ))}
                  </div>

                  <div>
                    <p className="text-xs font-semibold text-indigo-700 dark:text-cyan-300 mb-2">Payment Method</p>
                    <div className="flex flex-wrap gap-2">
                      {(currentGateway?.methods || ['UPI', 'Google Pay', 'PhonePe', 'Paytm', 'Debit/Credit Card', 'Net Banking', 'Wallets', 'EMI']).map(
                        (method) => (
                          <button
                            key={method}
                            type="button"
                            onClick={() => setSelectedMethod(method)}
                            className={`px-3 py-1.5 text-xs border transition-all ${
                              selectedMethod === method
                                ? 'btn-prism-cyan border-transparent text-white font-semibold'
                                : 'border-indigo-500/20 dark:border-cyan-400/20 bg-[#F5F7FF] dark:bg-[#141A30] text-[#090B14] dark:text-slate-200 hover:border-cyan-500'
                            }`}
                          >
                            {method}
                          </button>
                        ),
                      )}
                    </div>
                  </div>

                  {(selectedMethod === 'UPI' || selectedMethod === 'Google Pay' || selectedMethod === 'PhonePe' || selectedMethod === 'Paytm') && (
                    <div>
                      <label className="block text-xs font-semibold text-indigo-700 dark:text-cyan-300 mb-1">UPI ID / VPA</label>
                      <input
                        type="text"
                        value={upiId}
                        onChange={(e) => setUpiId(e.target.value)}
                        className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm font-mono text-[#090B14] dark:text-white"
                      />
                    </div>
                  )}

                  {selectedMethod === 'EMI' && (
                    <div>
                      <label className="block text-xs font-semibold text-indigo-700 dark:text-cyan-300 mb-1">Select EMI Tenure</label>
                      <select
                        value={emiPlan}
                        onChange={(e) => setEmiPlan(e.target.value)}
                        className="w-full px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-sm text-[#090B14] dark:text-white"
                      >
                        <option>3 Months (No Cost)</option>
                        <option>6 Months (Standard)</option>
                        <option>12 Months (Low Interest)</option>
                      </select>
                    </div>
                  )}

                  {selectedGateway === 'COD' && lockedQuote && (
                    <p className="text-xs text-slate-700 dark:text-slate-200 bg-amber-50 dark:bg-amber-950/30 p-3 border border-amber-500/35">
                      Cash on Delivery ({checkoutCountry.name}): Confirmed total payable upon courier verification is{' '}
                      <span className="font-mono font-bold text-amber-700 dark:text-amber-300">
                        {formatMoney(lockedQuote.totalLocal, lockedQuote.settlementCurrency, { alreadyConverted: true })}
                      </span>
                      .
                    </p>
                  )}
                </div>
              </div>

              {/* Order Summary & Server-Locked Quote */}
              <div className="lg:col-span-5 bg-gradient-to-b from-white via-white to-violet-50/50 dark:from-[#0D1120] dark:via-[#0D1120] dark:to-violet-950/25 border border-violet-500/25 p-5 flex flex-col justify-between gap-5 h-fit glow-border">
                <div className="space-y-4">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-display text-xl font-semibold gradient-heading">Order Summary</h3>
                    <div className="flex items-center gap-1.5">
                      <Globe className="w-3.5 h-3.5 text-[#2563EB] dark:text-[#22D3EE]" />
                      <select
                        aria-label="Checkout Settlement Currency"
                        value={settlementCurrency}
                        onChange={(e) => setSettlementCurrency(e.target.value as CurrencyCode)}
                        className="px-2 py-1 text-xs font-mono font-bold bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-[#2563EB] dark:text-[#22D3EE]"
                      >
                        {ALL_CURRENCIES.map((code) => (
                          <option key={code} value={code}>
                            {code} ({CURRENCY_RATES[code].symbol.trim()})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Server-Locked FX Quote Status Bar */}
                  <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/30 text-[11px] space-y-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bold text-emerald-700 dark:text-emerald-300 flex items-center gap-1">
                        <Lock className="w-3 h-3" /> {t('checkout.lockedQuote')}
                      </span>
                      <button
                        type="button"
                        onClick={() => void requestLockedQuote()}
                        disabled={quoteLoading}
                        className="text-[10px] font-semibold text-indigo-700 dark:text-cyan-300 hover:underline flex items-center gap-1"
                      >
                        <RefreshCw className={`w-2.5 h-2.5 ${quoteLoading ? 'animate-spin' : ''}`} />
                        {quoteLoading ? 'Locking...' : 'Refresh'}
                      </button>
                    </div>
                    {lockedQuote ? (
                      <div className="font-mono text-[10px] text-slate-700 dark:text-slate-300 flex flex-wrap justify-between gap-1">
                        <span>
                          Rate: 1 USD = {lockedQuote.lockedRate} {lockedQuote.settlementCurrency} ({lockedQuote.rateSource === 'live' ? 'Live FX' : 'Ref'})
                        </span>
                        <span>ID: {lockedQuote.quoteId}</span>
                      </div>
                    ) : (
                      <p className="text-[11px] text-amber-700 dark:text-amber-300">
                        {quoteError || 'Calculating server-locked checkout totals...'}
                      </p>
                    )}
                  </div>

                  <div className="divide-y divide-indigo-500/10 dark:divide-cyan-400/10 max-h-48 overflow-y-auto">
                    {cart.map((item) => (
                      <div key={`${item.productId}-${item.shade.id}`} className="py-2 flex justify-between gap-3 text-sm">
                        <div className="min-w-0">
                          <p className="font-semibold truncate">{item.name}</p>
                          <p className="text-xs text-fuchsia-600 dark:text-pink-300">
                            {item.shade.name} · Qty {item.quantity}
                          </p>
                        </div>
                        <span className="font-mono tabular-nums font-semibold text-blue-600 dark:text-cyan-300 shrink-0">
                          {formatMoney(
                            item.price * item.quantity,
                            lockedQuote?.settlementCurrency || settlementCurrency,
                            lockedQuote ? { overrideRate: lockedQuote.lockedRate } : undefined,
                          )}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Coupon & Gift Card */}
                  <div className="pt-2 border-t border-indigo-500/15 dark:border-cyan-400/15 space-y-2">
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Promo code (e.g. ATELIER15)"
                        value={couponInput}
                        onChange={(e) => setCouponInput(e.target.value)}
                        className="flex-1 px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-indigo-500/25 dark:border-cyan-400/25 text-xs uppercase font-mono text-[#090B14] dark:text-white"
                      />
                      <button
                        type="button"
                        onClick={applyCoupon}
                        className="px-4 py-2 btn-prism-gold text-white text-xs font-semibold"
                      >
                        Apply
                      </button>
                    </div>
                    {couponMsg && <p className="text-xs font-medium text-emerald-600 dark:text-emerald-400">{couponMsg}</p>}

                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Gift card (e.g. LUMIERE-VIP-50)"
                        value={giftCardInput}
                        onChange={(e) => setGiftCardInput(e.target.value)}
                        className="flex-1 px-3 py-2 bg-[#F5F7FF] dark:bg-[#141A30] border border-amber-500/30 text-xs uppercase font-mono text-[#090B14] dark:text-white"
                      />
                      <button
                        type="button"
                        onClick={applyGiftCard}
                        className="px-4 py-2 btn-prism-cyan text-white text-xs font-semibold"
                      >
                        Redeem
                      </button>
                    </div>
                    {giftCardMsg && <p className="text-xs font-medium text-amber-600 dark:text-amber-300">{giftCardMsg}</p>}
                  </div>

                  {/* Transparent Itemized Breakdown (Server-Locked Figures Only) */}
                  {lockedQuote && (
                    <div className="space-y-1.5 text-xs sm:text-sm pt-2 border-t border-indigo-500/15 dark:border-cyan-400/15">
                      <div className="flex justify-between text-slate-600 dark:text-slate-300">
                        <span>Merchandise Subtotal ({checkoutCountry.code})</span>
                        <span className="font-mono tabular-nums">
                          {formatMoney(lockedQuote.subtotalLocal, lockedQuote.settlementCurrency, { alreadyConverted: true })}
                        </span>
                      </div>

                      {lockedQuote.discountLocal > 0 && (
                        <div className="flex justify-between text-pink-600 dark:text-pink-300 font-medium">
                          <span>
                            Savings {appliedCoupon ? `(${appliedCoupon.code})` : flashDiscountPercent > 0 ? '(Flash Sale)' : ''}
                          </span>
                          <span className="font-mono tabular-nums">
                            -{formatMoney(lockedQuote.discountLocal, lockedQuote.settlementCurrency, { alreadyConverted: true })}
                          </span>
                        </div>
                      )}

                      <div className="flex justify-between text-slate-600 dark:text-slate-300">
                        <span className="truncate pr-2">
                          {t('checkout.shipping')} ({lockedQuote.shippingCarrier.split('/')[0].trim()})
                        </span>
                        {lockedQuote.freeShippingApplied ? (
                          <span className="text-emerald-600 dark:text-emerald-400 font-semibold shrink-0">Complimentary</span>
                        ) : (
                          <span className="font-mono tabular-nums shrink-0">
                            {formatMoney(lockedQuote.shippingLocal, lockedQuote.settlementCurrency, { alreadyConverted: true })}
                          </span>
                        )}
                      </div>

                      <div className="flex justify-between text-slate-600 dark:text-slate-300">
                        <span>{lockedQuote.taxLabel}</span>
                        <span className="font-mono tabular-nums">
                          {formatMoney(lockedQuote.taxLocal, lockedQuote.settlementCurrency, { alreadyConverted: true })}
                        </span>
                      </div>

                      <div className="flex justify-between text-slate-600 dark:text-slate-300">
                        <span>
                          {t('checkout.customsDuty')}
                          {lockedQuote.customsDutyRatePercent > 0 ? ` (${lockedQuote.customsDutyRatePercent}%)` : ''}
                        </span>
                        <span className="font-mono tabular-nums">
                          {lockedQuote.customsSupported
                            ? lockedQuote.customsDutyLocal > 0
                              ? formatMoney(lockedQuote.customsDutyLocal, lockedQuote.settlementCurrency, { alreadyConverted: true })
                              : 'Exempt / $0'
                            : 'Assessed on Delivery'}
                        </span>
                      </div>

                      <div className="flex justify-between font-bold text-base pt-2.5 border-t border-indigo-500/20 dark:border-cyan-400/20">
                        <span>{t('checkout.finalTotal')} ({lockedQuote.settlementCurrency})</span>
                        <span className="font-mono text-emerald-600 dark:text-emerald-400 tabular-nums">
                          {formatMoney(lockedQuote.totalLocal, lockedQuote.settlementCurrency, { alreadyConverted: true })}
                        </span>
                      </div>

                      {lockedQuote.settlementCurrency !== 'USD' && (
                        <p className="text-[10px] text-slate-500 dark:text-slate-400 font-mono text-right">
                          Base equivalent: ${lockedQuote.totalUsd.toFixed(2)} USD · Locked until {new Date(lockedQuote.expiresAt).toLocaleTimeString()}
                        </p>
                      )}
                    </div>
                  )}
                </div>

                {(errorMsg || quoteError) && (
                  <p className="text-xs text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/40 p-2.5 border border-rose-300 dark:border-rose-700/60">
                    {errorMsg || quoteError}
                  </p>
                )}

                <button
                  type="submit"
                  disabled={processing || quoteLoading || !lockedQuote || cart.length === 0}
                  className="w-full py-3.5 btn-futuristic text-white text-xs font-semibold uppercase tracking-widest flex items-center justify-center gap-2 disabled:opacity-60"
                >
                  {processing ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" /> Creating Verified Order...
                    </>
                  ) : quoteLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" /> Locking Exchange Rate &amp; Taxes...
                    </>
                  ) : selectedGateway === 'COD' ? (
                    `Place COD Order (${lockedQuote ? formatMoney(lockedQuote.totalLocal, lockedQuote.settlementCurrency, { alreadyConverted: true }) : ''})`
                  ) : (
                    <>
                      <CreditCard className="w-4 h-4" /> Pay {lockedQuote ? formatMoney(lockedQuote.totalLocal, lockedQuote.settlementCurrency, { alreadyConverted: true }) : ''} via {selectedGateway}
                    </>
                  )}
                </button>
              </div>
            </form>
          )}

          {step === 'sandbox' && gatewaySession && (
            <div className="max-w-lg mx-auto bg-white dark:bg-[#0D1120] border border-cyan-500/30 p-8 space-y-5 text-center glow-border">
              <p className="text-xs uppercase tracking-[0.2em] text-cyan-600 dark:text-cyan-300 font-semibold">
                {selectedGateway} {gatewaySession.mode.toUpperCase()} Authorization
              </p>
              <h3 className="font-display text-3xl font-bold font-mono tabular-nums gradient-heading">
                {formatMoney(gatewaySession.amountInCurrency, gatewaySession.currency, { alreadyConverted: true })}
              </h3>
              <div className="text-xs text-slate-700 dark:text-slate-200 space-y-1 bg-[#F5F7FF] dark:bg-[#141A30] p-4 border border-indigo-500/20 dark:border-cyan-400/20 text-left font-mono">
                <p>Gateway Order: {gatewaySession.gatewayOrderId}</p>
                <p>Method: {selectedMethod}</p>
                <p>Order Ref: {gatewaySession.orderId}</p>
                {lockedQuote && <p>Locked Quote: {lockedQuote.quoteId} (1 USD = {lockedQuote.lockedRate} {lockedQuote.settlementCurrency})</p>}
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                Complete sandbox gateway authorization below. Server-side HMAC-SHA256 verification and webhook confirmation will execute immediately using your locked settlement quote.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <button
                  type="button"
                  disabled={processing}
                  onClick={() => completeVerification(gatewaySession, false)}
                  className="py-3 btn-prism-emerald text-white text-xs font-semibold uppercase tracking-wider"
                >
                  {processing ? 'Verifying...' : 'Authorize Payment'}
                </button>
                <button
                  type="button"
                  disabled={processing}
                  onClick={() => completeVerification(gatewaySession, true)}
                  className="py-3 border border-rose-500/40 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-500 hover:text-white transition-colors"
                >
                  Simulate Decline (Test Retry)
                </button>
              </div>
            </div>
          )}

          {step === 'failed' && confirmedOrder && (
            <div className="max-w-lg mx-auto bg-white dark:bg-[#0D1120] border border-rose-400 dark:border-rose-500/50 p-8 space-y-5 text-center">
              <AlertTriangle className="w-10 h-10 text-rose-500 mx-auto" />
              <h3 className="font-display text-2xl font-semibold">Payment Authorization Declined</h3>
              <p className="text-sm text-slate-600 dark:text-slate-300">{errorMsg}</p>
              <p className="text-xs font-mono text-slate-500 dark:text-slate-400">Order #{confirmedOrder.id} saved as Failed — Ready for Retry</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
                <button
                  type="button"
                  disabled={processing}
                  onClick={retryFailedPayment}
                  className="px-6 py-3 btn-prism-sunset text-white text-xs font-semibold uppercase tracking-wider"
                >
                  {processing ? 'Retrying...' : `Retry via ${selectedGateway}`}
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-6 py-3 btn-prism-outline text-xs font-semibold"
                >
                  View in Dashboard
                </button>
              </div>
            </div>
          )}

          {step === 'confirmed' && confirmedOrder && (
            <div className="max-w-2xl mx-auto bg-white dark:bg-[#0D1120] border border-emerald-500/35 p-8 space-y-6 glow-border">
              <div className="flex items-start justify-between gap-4 border-b border-indigo-500/15 dark:border-cyan-400/15 pb-5">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-8 h-8 text-emerald-500 shrink-0" />
                  <div>
                    <p className="text-xs uppercase tracking-[0.2em] text-emerald-600 dark:text-emerald-400 font-semibold">
                      Order Confirmed
                    </p>
                    <h3 className="font-display text-2xl font-semibold gradient-heading-emerald">
                      Order #{confirmedOrder.id}
                    </h3>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-3.5 py-2 btn-prism-outline text-xs font-semibold flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" /> Print Invoice
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
                <div>
                  <p className="text-slate-500 dark:text-slate-400">Tracking ID</p>
                  <p className="font-mono font-semibold text-blue-600 dark:text-cyan-300 mt-0.5">{confirmedOrder.trackingNumber}</p>
                </div>
                <div>
                  <p className="text-slate-500 dark:text-slate-400">Gateway</p>
                  <p className="font-semibold mt-0.5">{confirmedOrder.paymentGateway}</p>
                </div>
                <div>
                  <p className="text-slate-500 dark:text-slate-400">Method</p>
                  <p className="font-semibold mt-0.5">{confirmedOrder.paymentMethod}</p>
                </div>
                <div>
                  <p className="text-slate-500 dark:text-slate-400">Status</p>
                  <p className="font-semibold text-emerald-600 dark:text-emerald-400 mt-0.5 capitalize">{confirmedOrder.paymentStatus}</p>
                </div>
              </div>

              <div className="border-t border-indigo-500/15 dark:border-cyan-400/15 pt-4 space-y-2 text-sm">
                {confirmedOrder.items.map((item, idx) => (
                  <div key={idx} className="flex justify-between">
                    <span>
                      {item.name} ({item.shadeName}) × {item.quantity}
                    </span>
                    <span className="font-mono tabular-nums">
                      {formatMoney(
                        item.unitPrice * item.quantity,
                        (confirmedOrder.currency as CurrencyCode) || settlementCurrency,
                        confirmedOrder.lockedExchangeRate
                          ? { overrideRate: confirmedOrder.lockedExchangeRate }
                          : undefined,
                      )}
                    </span>
                  </div>
                ))}
                {(confirmedOrder.shippingCost ?? 0) > 0 && (
                  <div className="flex justify-between text-xs text-slate-600 dark:text-slate-300">
                    <span>Shipping ({confirmedOrder.shippingCarrier || checkoutCountry.shippingCarrier})</span>
                    <span className="font-mono">
                      {formatMoney(
                        confirmedOrder.shippingCost || 0,
                        (confirmedOrder.currency as CurrencyCode) || settlementCurrency,
                        confirmedOrder.lockedExchangeRate ? { overrideRate: confirmedOrder.lockedExchangeRate } : undefined,
                      )}
                    </span>
                  </div>
                )}
                {(confirmedOrder.taxAmount ?? 0) > 0 && (
                  <div className="flex justify-between text-xs text-slate-600 dark:text-slate-300">
                    <span>{confirmedOrder.taxLabel || 'Applicable Tax'}</span>
                    <span className="font-mono">
                      {formatMoney(
                        confirmedOrder.taxAmount || 0,
                        (confirmedOrder.currency as CurrencyCode) || settlementCurrency,
                        confirmedOrder.lockedExchangeRate ? { overrideRate: confirmedOrder.lockedExchangeRate } : undefined,
                      )}
                    </span>
                  </div>
                )}
                {(confirmedOrder.customsDuty ?? 0) > 0 && (
                  <div className="flex justify-between text-xs text-slate-600 dark:text-slate-300">
                    <span>Import Customs Duty</span>
                    <span className="font-mono">
                      {formatMoney(
                        confirmedOrder.customsDuty || 0,
                        (confirmedOrder.currency as CurrencyCode) || settlementCurrency,
                        confirmedOrder.lockedExchangeRate ? { overrideRate: confirmedOrder.lockedExchangeRate } : undefined,
                      )}
                    </span>
                  </div>
                )}
                <div className="flex justify-between font-semibold pt-2 border-t border-black/10 dark:border-white/10">
                  <span>Confirmed Total Settled ({confirmedOrder.currency})</span>
                  <span className="font-mono tabular-nums text-emerald-600 dark:text-emerald-400">
                    {confirmedOrder.settlementTotal
                      ? formatMoney(confirmedOrder.settlementTotal, confirmedOrder.currency as CurrencyCode, { alreadyConverted: true })
                      : formatMoney(confirmedOrder.total, (confirmedOrder.currency as CurrencyCode) || settlementCurrency)}
                  </span>
                </div>
                {confirmedOrder.quoteId && (
                  <p className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                    Quote Ref: {confirmedOrder.quoteId} · Locked FX: 1 USD = {confirmedOrder.lockedExchangeRate} {confirmedOrder.currency} · Destination: {confirmedOrder.shippingAddress.country}
                  </p>
                )}
              </div>

              <button
                type="button"
                onClick={onClose}
                className="w-full py-3 btn-futuristic text-white text-xs font-semibold uppercase tracking-widest"
              >
                Continue Exploring Atelier
              </button>
            </div>
          )}
        </div>
    </CinematicModal>
  );
};
